---
categoria: apuntes
area: cornea
emoji: 👁️
seccion: Cornée
orden_seccion: 4
orden: 19
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-10-02
---
# Kératite neurotrophique KN/NK

Neurotrophic Keratitis (NK) is a corneal degenerative disease characterized by a reduction or absence of corneal sensitivity. In NK, corneal innervation by the trigeminal nerve is impaired. Partial or complete loss of corneal sensation may result in epithelial keratopathy, epithelial defect, stromal ulceration, and eventually corneal perforation.

## ETIOLOGY

Every ocular or systemic condition altering corneal sensory innervation—which runs from the cornea itself to the pontine trigeminal nucleus—can result in NK.

- Most common ocular conditions associated with NK are herpes keratitis (zoster and simplex), topical anesthetic abuse, chemical and physical burns, contact lens abuse, topical drug toxicity, irradiation to eye or adnexa, and corneal surgery.
- Chronic use of topical medications containing benzalkonium chloride (BAK) may reduce corneal sensation via nerve damage and impair corneal epithelial healing.[2]
- With regards to corneal procedures, both corneal refractive procedures, laser in situ keratomileusis (LASIK) and photorefractive keratectomy (PRK), have been linked to NK.[3] [4][5]The incidence of transient nerve damage, however, seems to be significantly higher in LASIK than in PRK.[6] Corneal transplantation surgery, and specifically penetrating keratoplasty (PK) and deep anterior lamellar keratoplasty (DALK), can result in reduced central corneal sensitivity 12 months after either surgical approach.[7] Endothelial keratoplasty (DSAEK or DMEK) does not significantly affect central corneal sensitivity, and thus, may not be associated with NK.[8] A reduction of corneal sensation was also observed in keratoconus eyes following collagen crosslinking.[9]
- Non-corneal ocular surgeries or procedures can also induce NK. Vitrectomy for retinal detachment and photocoagulation to treat diabetic retinopathy have been associated with development or worsening of NK.[10] Routine, single session, indirect laser for proliferative diabetic retinopathy has been reported as a possible cause of NK via damaging ciliary nerves.[11]
- Non-ocular causes include neurosurgical procedures or trauma damaging the fifth cranial nerve, stroke, aneurysms, multiple sclerosis, intracranial masses (e.g. acoustic neuroma), diabetes (NK has been described as the sole sign of diabetes in a patient),[12] leprosy, vitamin A deficiency, and drugs (narcoleptics and antipsychotics). Congenital hypoplasia of the trigeminal nerve has also been described in association with NK.[13]
