---
categoria: apuntes
area: cornea
emoji: 💧
seccion: Conj + Episclere + Sclere
orden_seccion: 25
orden: 20
fuente: OneNote del Dr. Castilla Martí
fecha: 2022-09-16
---
# Episclérite

Inflamm de l'épisclère

Atteinte bénigne auto-limite, récurrente, frequemment bilaterale.

Plus freq chez jeunes adultes F>H

Rare chez enfantes.

2 types:

- simple
- et nodulaire, differenciable cliniquement.

## ETIOLOGIES

- Idiopathiques (majoritairement)
- Associe à atteinte oculaire: Sécheresse oculaire, blépharite, rosacée oculaire, atopie, port de LDC.
- Associe à atteinte systemique (surtout sclérite, rarement épisclérite): Maladie inflammatoires: Connectivites et vasculites (10% cas): arthrite rhumatoide, arthtite réeactionnelle ( syndrome de Reiter), maladie de Crhon, RCUH-La rectocolite hémorragique est une maladie inflammatoire chronique intestinale (MICI), LES-Lupus erit systemique, SPA, syndrome chrug-strauss, granulomatose avec polyangeite, maladie de Behçet...Goutte, Maladie thyroidiennes.
- Infections: Herpes zoster, TBC, syphilis, Borreliose, Toxoplasmose...
- Rares: Tumeurs malignes: leucemie de type T, Lymphome de Hodking.
- Origine mixte: medicaments: topiramate, pamidronate, biphopsphonates...

## Symptomes

| **EPISCLERITE SIMPLE 75%** | **EPISCLERITE NODULAIRE 25%** |
|---|---|
| -Debut aigue <24h, puis résolution progress vers qqs jours.<br>Rougeur sectorielle / (2/3 des cas) > diffuse 1/3 cas<br>Inconfort léger ( voire absent) à severe<br>Sensation de sable<br>Photophobie<br>Larmoiment | Rougeur localisée, remarquée le plus souvent au reveil<br>Début plus insidieux (2-3j), avec augmentation progressiove de la rougeur et de l'inconfort<br>Impression de CE<br>Photophobie<br>Larmoiment |
