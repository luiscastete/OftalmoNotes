---
categoria: apuntes
area: neuro
emoji: 🧠
seccion: Neuro-Ophta
orden_seccion: 8
orden: 19
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-04-15
---
# Diplopie binoculaire aigue

Apparition soudaine d'une vision double avec les deux yeux ouverts. Vision simple avec un seul ouvert.

## AA

Douleur

Atteinte fonction visuelle?

Autres troubles neuro?

## STATUS

Oculomotilité

Paupieres ( ptosis ou rétraction palpébrale)

Exophtalmétrie de Hertel.

Pupilles (anisocorie)

FO (pâleur ou oedeme papillaire)

## DD

- **Myopathie:** myosite, maladie de Basedow ( La maladie de Basedow ou Graves-Basedow est une hyperthyroïdie auto-immune (maladie de la thyroïde). La personne atteinte produit des anticorps anormaux (stimulant le recepteur de la TSH) dirigés contre les cellules folliculaires de la thyroïde. Plutôt que de détruire ces cellules, comme le ferait tout anticorps normal, ces anticorps reproduisent les effets de la TSH et stimulent continuellement la libération d'hormones thyroïdiennes, provoquant une hyperthyroïdie accompagnée de signes cliniques spécifiques)
- **Neuromusculaire:** myasthénie
- **Orbitopathie:** cellulite orbitaire, fracture, tumeur, hématome, fistule carotido-caverneuse.
- **Nueorpathie péripherique:** paresie du II,IV, VI.
- **Atteinte centrale:** III, IV,VI, OIN, skew deviation.
- **Décompensation d'une phorie préexistante.**

## BILAN COMPLEMENTAIRE

En fonction du dx suspecté et après examen clinique:

- IRM orbitaire et cérebrale
- Bilan sanguin
- Test glaçon ( myasthenia)
- Test au Tensilon ( myasthenie)
- Biopsie de l'artere temporale ( maladie de Horton)
