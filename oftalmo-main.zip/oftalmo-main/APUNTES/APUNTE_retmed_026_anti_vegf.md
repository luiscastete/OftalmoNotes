---
categoria: apuntes
area: retina-medica
emoji: 🩸
seccion: Ret Med y coroides
orden_seccion: 19
orden: 26
fuente: OneNote del Dr. Castilla Martí
---
# Anti-VEGF

## Tabla maestra de anti-VEGF intravítreos

| **Nombre comercial** | **Molécula** | **Qué es / diana** | **Dosis IVT habitual** | **Característica diferencial** | **Idea mental para recordarlo** |
|---|---|---|---|---|---|
| **Lucentis®** | **Ranibizumab** | Fragmento Fab anti-VEGF-A | **0,5 mg / 0,05 mL** | Molécula pequeña, sin Fc; inhibición específica VEGF-A; enorme experiencia clínica | **Anti-VEGF clásico y puro** |
| **Eylea® 2 mg** | **Aflibercept** | Proteína de fusión/receptor señuelo: VEGF-A, VEGF-B y PlGF | **2 mg / 0,05 mL** | Mayor espectro de ligandos que ranibizumab; gran experiencia en retina | **VEGF-trap clásico** |
| **Eylea® 8 mg** | **Aflibercept** | Mismo mecanismo que aflibercept 2 mg | **8 mg / 0,07 mL** | Misma molécula a dosis 4×; diseñada para aumentar durabilidad | **Aflibercept de alta dosis** |
| **Vabysmo®** | **Faricimab** | Anticuerpo biespecífico: **VEGF-A + Ang-2** | **6 mg / 0,05 mL** | Único de esta tabla con doble vía VEGF/Ang-2 | **Doble mecanismo** |
| **Avastin®** | **Bevacizumab** | Anticuerpo monoclonal completo anti-VEGF-A | **1,25 mg / 0,05 mL**\* | Muy utilizado históricamente; medicamento oncológico | **Anti-VEGF off-label** |
