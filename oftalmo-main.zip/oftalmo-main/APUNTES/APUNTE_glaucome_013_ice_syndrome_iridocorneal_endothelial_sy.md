---
categoria: apuntes
area: glaucoma
emoji: 🟢
seccion: Glaucome
orden_seccion: 5
orden: 13
fuente: OneNote del Dr. Castilla Martí
---
# ❄️ ICE Syndrome – Iridocorneal Endothelial Syndrome

## ❄️ICE Syndrome – Iridocorneal Endothelial Syndrome

## ✅¿Qué es el ICE Syndrome?

El **síndrome iridocorneal endotelial (ICE)** es un **trastorno ocular raro, adquirido y unilateral**, que afecta principalmente a **mujeres de mediana edad**. Se caracteriza por una **proliferación anómala de las células endoteliales corneales**, que adoptan un **comportamiento epitelial**: proliferan, migran y se adhieren a estructuras del segmento anterior, como el **ángulo iridocorneal** y la **superficie del iris**.

Corneal endothelium that behaves like epithelial tissue

🔬 Este crecimiento anómalo produce:

• **Glaucoma secundario** (≈50%): por obstrucción trabecular y cierre angular por contracción.

• **Descompensación corneal**: por disfunción endotelial.

• Cambios progresivos en el **iris** y el **ángulo**.

## 🧬¿Por qué se llama “ICE”?

ICE = **Irido-Corneal Endothelial Syndrome**

Se llama así porque involucra principalmente tres estructuras:

• **Irido-** → Cambios en el **iris**.

• **Corneal** → Afectación del **endotelio corneal**.

• **Endothelial** → La alteración primaria es en el **endotelio corneal**, que prolifera de forma anómala.

Este endotelio “epitelializado” puede migrar sobre el ángulo y el iris, provocando sinequias, distorsión pupilar y opacidad corneal.

## 📋Presentaciones clínicas (3 subtipos)
