---
categoria: apuntes
area: retina-medica
emoji: 🩸
seccion: Ret Med y coroides
orden_seccion: 19
orden: 1
fuente: OneNote del Dr. Castilla Martí
fecha: 2022-09-02
---
# CRSC

La choriorétinopathie séreuse centrale (CRSC)

Maculopathie d'origine inconnu, caracterise par le passage de liquide provenant de la choroide à travers EPR qui induit un décollement séreux rétinien (DSR).

Fuga a nivel del EPR.

Coroides gruesa e hiperpermeable - que permite que fluido coriocapilar pase al espacio subretiniano.

Normalmente es autolimitada.

Pero puede complicar con:

-1-daño en el EPR provocando una epiteliopatia pigmentaria difusa retiniana -DRPE

-2- formacion membrana neovascular coroideas - NVC

Recurrencia o cronicidad en 40-50% pac

## SYMPT

-Vision flou

-BAV brutale/modere UNILATERAL ( 0.7 à 1.0)

-plus freq. hommes de moyenne age

-bilat en 14-40%

-Scotome relatif central ou paracentrale

-métamorphopsies.

-micropsies (affection de la perception visuelle humaine dans laquelle des objets sont perçus plus petits qu'ils ne le sont en réalité)

-Dyschromatopsies

-Phenomenus visuelles inespecifiques (halos jaunatres de type aura migraneuse)

-+/- si DSR extramaculaire

-FR: uso de CORTICOIDES ++, HTA, Helicobacter pylori +, transtornos del sueño, enfer.autoimmune, uso psicofarmacos, personalidad tipo A: Alta competividad-Impaciencia-Orientacion al logro-Hostilidad o agresividad contenida-Urgencia de tiempo/sentido de prisa constante. Embarazo 3er trimestre.
