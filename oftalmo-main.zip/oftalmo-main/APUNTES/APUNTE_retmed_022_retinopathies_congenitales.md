---
categoria: apuntes
area: retina-medica
emoji: 🩸
seccion: Ret Med y coroides
orden_seccion: 19
orden: 22
fuente: OneNote del Dr. Castilla Martí
fecha: 2024-06-07
---
# Rétinopathies congénitales

Atteinte visuelle le plus souvent bilaterale, globalement symétrique et évolutive, en absence de causes inflammatoire, toxique ou paranéoplasique.

## BILAN

- Ant fam + arbre généalogique
- AV
- Vision des couleurs
- CV 10° et péripherique Goldmann – AKII
- Cliches couleurs et AF
- OCT mac et NO
- OCT AF
- A-OCT
- OPTOS + OPTOS AF
- Photo Pôle postérieur
- +/- angio-fluo
- Bilan électrophysiologique: ERG global +/- ERGmf ; EOG
- Consultation en oculogénétique et génétique

+/- full field ERG, PerGEN, MP1 et 15 HUE? Selon Dr.Viet Tran.

## MACULOPATHIES HEREDITAIRES

- ARBRE FIG 71-1

- **MALADIE DE STARGARDT**

  - Maculopathie héréditaire la plus frequente.
  - Dx normalement <25ans
  - Transmission Autosom récessive - géne ABCA4 chr1

  - **SIGNES**
  - BAV
  - Photophobie
  - Scotome
  - Dyschromatopsie d'axe rouge-vert

  - **EX COMPLEMENTAIRES**
  - Photos:
  - remainement maculaire, autofluorescence maculaire hétérogène, tâches flavimaculées hyperautofluorescentes, épargme peripapillaire.

  - **OCT**
  - Atteinte EP et des photorécepteurs
  - Perte du clivus
  - Amincissement rétinien

  - **ANGIO FLUO**
  - Silence choroidien – effet masque par accumulation de lipofuscine au niveau EP

  - **ERG**
  - Reponse photopique et scotopique normales – type 1
  - Réponse photopique altérée - type 2
  - Réponse photopique et scotopique altérées - type 3

  - **TT**
  - Lunettes couvrantes et limitation des apports en Vit A si mutation gen ABCA4.
  - Pronostic svere de façon précoce <1/10 avant age de 20 ans.

- **\*\*FORMES PARTICULIERS: maladie Stargardt dominante - Gène ELOVL4**

- Les symptomes appairesent après 20 ans, la vision des couleurs est logtemps conservée. Examen retrouve des remainements maculaires avec autofluorescence hétérogène et une épargne papillaire.
- OCT: La perte de ligne des photorecepteurs est plus limité que dans la forme autosom récessive.
- On notera absnece de silence choroidien à l'angio à la fluo
- Seul ERG multifocal est altére, ERG global est normale.
