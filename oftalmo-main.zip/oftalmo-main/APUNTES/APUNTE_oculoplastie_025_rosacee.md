---
categoria: apuntes
area: oculoplastica
emoji: 🫥
seccion: Oculo-Plastie
orden_seccion: 3
orden: 25
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-03-31
---
# Rosacée

La rosacée est une maladie oculaire et cutanée frequente. L'atteinte oculaire est isole dans 25% descas,

et consiste avant tout en une blépharite posterieur avec secherese évaportaive.

## ATTEINTE CUTANéE

Elle touche le visage et se deroule en 4 stades:

- 1.flushes du visage, déclenchées par chaleur, les émotions et certains aliments ( épices, alcohol et acids)
- 2.télangiectasies et érythrose des pommettes, du front du nez.
- 3.éruption papulopustuleuse, l'acne rosacée
- 4.rhinophyma: hypertrophie des glandes sébacées du nez.

## ATTEINTE OCULAIRE

- **BLéPHARITE POST ET DYSFONCTIONNEMENT DES GLAND MEIBOMIUS.**
- Blépharite qui peut etre post ou mixte avec secheresse evaporative ( KPS inf, BUT <, pannus cornéen néovasculaire inf, cononctivite papillofolliculaire, fibrose conj moderée...
- **infiltra/ulceres catarrhaux** dus a une reaction immuno sur surinfection staph palpebrale) - symptomes: douleur ocualire avec photophobie et larmoiment
- Signes: pseudo-abces cornéen peripheriques plutot inferieur arrondis, blancs avec intervalle sais avec du limbe.
- **Kératoconjonctivite phlycténulaire:** atteinte chronique de l'enfant ou adult. Souvent unilateral. Lie a une reaction immunologique sur staph palpebrale.
- Symptomes: cahalazions, puis épisodes de rougeur oculaire avec photophobie et larmoiment.
- Signes: phlyctenes conj, limbique ou cornéens ( petites vésicules transparents): néovascularisation cornéen inf. Infiltrats cornéens aigus, type infiltratscatarraux, pouvants laisser des ciactrices opaquesnéovasculairesées.

## TT

## ATTEINTE OCULAIRE

Tt blépharite post idem.

Cas particulier:

- **Infiltrats catarrhaux:** cortis locaux en phase aigue. Comme kératite marginale.
- **Rosacée phlycténulaire:** soins des paupieres + cure azithromycine:  2xj pdt 3j 3xmois pdt 2 mois, 2xj pdt 3j 2xmois pour 2 mois puis 1x par mois ( dur ett minimale 4-6 mois). Si echec ciclosporine 2% 4gtt/j en schema degressif pdt 6 mois.

- Cure doxycicline 0'025% 4-3-2-1 pdt 4m +soins des paupieres + optava + PVA le soir

## ATTEINTE CUTANéE

Antibioteraphie orale: cyclines, azithromycine ou macrolies.

Antibiotherapie locale cutanée: métronidazole.

Tt par laser des télangiecztasies cutanées.

## Disease Entity

Rosacea is a chronic inflammatory acneiform skin condition that leads to erythema of the skin on the face and neck.  It can frequently involve the eyes with studies showing ocular involvement in 6-58% of patients.

It is characterized by:

A malar rash, which can include papules and pustules on the face and neck.

The hallmarks of ocular rosacea include:

-bilateral chronic blepharitis

-meibomian gland dysfunction.

At the slit lamp, eyelid margin telangiectasia, and inspissation of the meibomian glands are seen. Patients frequently develop evaporative dry eye. Some patients develop recurrent chalazia.

## SYMPT

burning and foreign body sensation.

Left untreated, recurrent episodes can lead to peripheral corneal ulceration, corneal scarring, and neovascularization.

## Clinical Presentation

Facial features of rosacea include erythematous changes involving the malar region, nose, and eyelids. These characteristic changes range from mild discoloration to severe, violaceous changes to skin tone. Telangiectasias are another defining feature in this region. Some clinical presentations may include papulopustular changes.

LAF:

Slit-lamp examination of the eyelid margins reveals:

## -Telangiectasia and erythema of the lid margin in 50–94% of patients.

-Meibomian gland dysfunction is present in up to 92% of rosacea patients and is characterized by excess, abnormally turbid meibomian gland secretion, which causes plugging of the gland orifices and recurrent hordeolum/chalazion.

-Additionally, the ocular surface inflammation leads to interpalpebral bulbar conjunctival hyperemia, as well as follicular and papillary reaction.

-Rhinophyma of the nose can occur as a late finding.

-Corneal alterations are also detected in 25–50% of patients with ocular rosacea and may range from mild punctate epithelial keratitis accompanying the blepharoconjunctivitis to corneal neovascularization, infiltration, ulceration and perforation.[2]

One potential severe complication on the spectrum of rosacea, Morbihan syndrome can present as insidious swelling of the forehead, nose, glabella, cheeks and periorbital regions of the face.[4] Common additional signs, similar to rosacea include erythema, telangiectasias, papules, pustules and facial flushing.[4]

## Diagnosis

Originally, rosacea was classified by subtype by the National Rosacea Society Expert Committee[5]:

1.Erythematotelangiectatic

2.Papulopustular

3.Phymatous

4.Ocular

## TTT

Conservative management includes lifestyle modification (avoidance of triggers), warm compresses, eyelid scrubs, and digital massage.[1][3][6]

Medical management varies depending on severity.

To relieve the dry eye associated with ocular rosacea, artificial tears and lubricating agents are used.

-Systemic, subantimicrobial tetracyclines (doxycycline, minocycline) and macrolides (azithromycin) are thought to decrease inflammation associated with rosacea and are often first-line agents for patients with moderate disease.[1][7][8]

°°°While antibiotics may present a great treatment option for patients with ocular rosacea, side effects should be considered (vaginal/oral candidiasis, gastrointestinal distress, photosensitivity, teratogenicity, Stevens-Johnson syndrome, and allergies).

At the lower doses used for ocular rosacea management, it is postulated that oral antibiotics have a favorable impact on matrix metalloproteinases, interleukins, nitric oxide, activated B-lymphocytes, and collagen abnormalities that have been associated with this disease.[1] Topical metronidazole has a grade A evidence rating for the treatment of mild to moderate inflammatory rosacea, with a small study showing an improvement in rosacea-related eyelid health.[1][3]

Immunosuppressive agents, such as cyclosporine, have also been used to reduce chronic eyelid and corneal inflammation.[1][3] Although the medical literature reports mixed results, interventional office treatments include Lipiflow/Intense Pulse Light therapy, meibomian gland expression, and punctal occlusion may be considered.[1][9][10] Treatment of chalazia may require excision. Severe ophthalmic disease may require ocular surface reconstruction (amniotic membrane placement, conjunctival flap, tissue adhesives), and penetrating keratoplasty for corneal perforation.[1]

Future interventions may include novel therapies for various cytokines, chemokines, and angiogenesis factors. As our knowledge of the cellular and molecular basis for ocular rosacea grows, the management will most likely transition to a highly-selective and more targeted approach.

Blephademodex

Shampoo de the

Oculta blepha plus - lima 16.01.01.00

## Ocular Rosacea Treatment

While there is no cure for rosacea, ophthalmologists can help control and treat its symptoms.

Here are some treatments for eye symptoms:

- Steroid eye drops and ointments to reduce redness and swelling
- Antibiotic pills or ointments to treat eye infection and rosacea of the skin
- Artificial tears to help keep eyes moist. (DO NOT take eye drops that treat bloodshot eyes. These can make ocular rosacea symptoms worse.)
- Eyelid scrubs to keep your eyes clean and free of infection. Here is what to do: Gently clean your eyelids with a washcloth. To do this, use a special eyelid cleaning product or baby shampoo mixed with warm water. Also, apply a warm cloth or pad to your closed eyes as often as your doctor recommends.

- Antb topique: lequels?? Ivermectine, metro y azufro.  Azyter.
- Commenta fonctionne le IPL?

- Plutôt les tétracyclines les meilleures

- Posologie ant

- Isotretoine orale - RACCUTAN! Attention!
