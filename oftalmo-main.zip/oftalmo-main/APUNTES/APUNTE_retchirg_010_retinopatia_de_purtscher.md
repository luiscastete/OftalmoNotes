---
categoria: apuntes
area: retina-quirurgica
emoji: 🪡
seccion: Ret Chirg
orden_seccion: 6
orden: 10
fuente: OneNote del Dr. Castilla Martí
---
# Retinopatía de Purtscher

La **retinopatía de Purtscher** es una entidad vasculopática retiniana rara, generalmente asociada a **traumatismos torácicos cerrados**, **fracturas óseas largas** o **compresiones craneales severas**, aunque también puede aparecer en contextos no traumáticos como **pancreatitis aguda**, **lupus eritematoso sistémico**, **preeclampsia** y **nefropatías** (en estos casos se denomina *Purtscher-like retinopathy*).

## Características clínicas

- **Inicio súbito de pérdida visual**, generalmente bilateral pero asimétrica.
- **Lesiones fundoscópicas** típicas:
  - **Manchas algodonosas** (microinfartos en la capa de fibras nerviosas).
  - **Hemorragias intrarretinianas** (especialmente peripapilares).
  - **Manchas de Purtscher**: áreas blanquecinas retinianas en zonas peripapilares, distintas de las manchas algodonosas.
  - La mácula puede estar comprometida.

## Fisiopatología

Se cree que está mediada por **embolización microvascular** (complejos inmunes, agregados leucocitarios, grasa, aire o fibrina) que ocluyen la microvasculatura retiniana.

## Diagnóstico

- **Clínico**, apoyado por la historia de trauma o enfermedad sistémica.
- **OCT**: puede mostrar edema macular cistoide o disrupción de la arquitectura retiniana.
- **Angiografía con fluoresceína**: zonas de hipofluorescencia por no perfusión capilar y bloqueo por hemorragias.
