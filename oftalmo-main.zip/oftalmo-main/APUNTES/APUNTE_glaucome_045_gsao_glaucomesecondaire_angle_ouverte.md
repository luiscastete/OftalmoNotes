---
categoria: apuntes
area: glaucoma
emoji: 🟢
seccion: Glaucome
orden_seccion: 5
orden: 45
fuente: OneNote del Dr. Castilla Martí
fecha: 2024-06-12
---
# GSAO – Glaucome Secondaire Angle ouverte

Ssecondaire à angle ouverte forment un groupe hétèrogene de maladie ou la PIO élevée est le ppal F pathologique causnat la neuropathie optique glaucomateuse.

GSAO causés par une maladie oculaire

- Glaucome exfoliatif ou pseudoexfoliatif - GPEX
- Glaucome pigmentaire - PG
- Glaucome à angle ouvertinduit par le cristallin
- Glaucome assoce à une hémorragie intraoculaire
- Glaucome uvéitique
- Glaucome néovasculaire
- Glaucome et tumeurs intraoculaires

GSAO post traumatiques

GSAO iatrogènes

- Glaucome cortisonique
- Glaucome après chirurgie oculaire et laser
- Glaucome après chirurgie vitréorétinienne

GSAO et maladie extraoculaire

- Glaucome causé par une pression veineuse épisclérale élevée
