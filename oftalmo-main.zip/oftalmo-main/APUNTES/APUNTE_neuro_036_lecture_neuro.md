---
categoria: apuntes
area: neuro
emoji: 🧠
seccion: Neuro-Ophta
orden_seccion: 8
orden: 36
fuente: OneNote del Dr. Castilla Martí
---
# Lecture Neuro

16.05.24

VISUEL FIELDS

Concept illes avec CV

Absolute scotomas come from retinal visions

1st look db: normal bitween 30 for foveal, the central one, then in parafoveal points they will go down to 25-30db, then the more ther are in peripherie they will decrease, they will stay at 10ns at max peripherie.

If they go down they show they have lost sensitivity.

RFNL
