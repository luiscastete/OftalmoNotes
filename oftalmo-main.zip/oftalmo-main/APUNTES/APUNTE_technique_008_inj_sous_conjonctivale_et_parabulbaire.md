---
categoria: apuntes
area: general
emoji: 🛠️
seccion: Technique-Procedures
orden_seccion: 13
orden: 8
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-04-01
---
# Inj. Sous-conjonctivale et parabulbaire

## INDICATIONS

UAA refractaires aux cortis topiques

Mauvaise compliance

Forte reaction CA 3+ cellules

Uintermediare et post

## INJ SOUS-CONJONCTIVALE

- Anesthesie topique tetracaine/oxy
- **Aiguille jaune 30G**
- Seringue 3ml

## Prepartion;

Corticoides (CELESTENE) –Betamethasone 4mg/ml: 1ml

+ Lidocaine (sans adrenaline-2eme ajouter sur siringe de cette maniere premier en entrer pdt injection) 10mg/ml-0,5ml

Piquer rangentiellement avec biseau oriente paralellement au globe et vers le hat, en région conjontivale inf à 3-4mm du limbe de façon à etre masque par paupiere inferieur en évitant les vssx sanguins.

Injection lente du melange en totalite

## INJ PARABULBAIRE

- Desinfection cutanée de la paupiere inf
- **Aiguille orange 25G**
- Seringue 3ml

## Préparation

Corticosteroides ( Betamethasone 4mg/ml)- 1ml

Lidocaine ( sans adrenaline) 10ml – 0,5ml

Prendre le cadre osseux orbitaire inferieur comme repère: placer un index entre le bord orbitaire inf dans sa partie laterale et le globe, afin de soulever ce dernier.

Demander au patient de regarder en haut.

Insertion transpalpebrale de l'aiguille biseau vers le hautr, dans le quadrant 1/3 temorale inf, en longeant le rebord orbitaire, légèrement incliné vers le bas pour éviter de perforer le globe ( attention: douleur en cas de contact avec le périoste) jusqua la garde.
