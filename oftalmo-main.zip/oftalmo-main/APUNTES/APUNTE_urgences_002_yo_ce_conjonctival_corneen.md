---
categoria: apuntes
area: urgencias
emoji: 🚑
seccion: URGENCES---TRAUMATOLOGIE
orden_seccion: 2
orden: 2
fuente: OneNote del Dr. Castilla Martí
fecha: 2022-09-07
---
# Yo CE conjonctival/cornéen

Corps étranger incrusté superficiellement à la surface de la conjonctive ou de la cornée

## SYMPTOMES

Sensation de CE

Larmoiment

Photophobie

Démangeaison/Douleur

## SIGNES

HC

Erosion cornéenne ou laceration conjonctivale

## ETIOLOGIES

Nature du CE: CE métallique? Végétal?

AA

Type CE? Taille? Mécanisme/cinetique?

## STATUS

AV-TIO

LAF: inspection de la conjonctive + éversion palpebrale, de la cornée, de la CA.

Lesion: localisation, taille et profondeur?

Test Fluo

Exclure perforation oculaire et un CE intraoculaire ( CEIO)

\*\*ASTUCE\*\*DR.DOSSO RECOMMENDATION: si tu as le doute si reste encore de CE ou est la rouille ou infiltrat?? OCT SA CORNEE – la tu vas avoir tout info.

## BILAN

Si suspicion CEIO: add CT-Scan natif ( jamais IRM si suspition CEIO métalliquecar risque migration)

## Tt

Anesthesie local + ablation CE avec triangle ou aiguille.

Si rouille cornéen: ablation avec aiguille ou fraise. Si imposible ablation complete: debut ttt coll atb PC dans 48/72h pour ablation rouille résiduelle.

ATTENTION: la rouille persistante provoque une kératite inflammatoire +/- BAV si dans l'axe de vision. Un tatouage brunatre est sans consequence.

## Tt topique

Si atteinte Cornéen: tobrex ou floxal coll (si vegetal) 4xj pendant 5-7j.

Si atteinte conjontival: Tobrex ou floxal pommade (si vegetal) 4xj pendant 5-7j.

Add Optava 4-8xj + PVA le soir 14J.

Si douleur imp. Pansement occlusif jusqu'au lendemain matin avec:

-Tobrex/floxal cll 1 gtt + PVA + Homatropine 1 gtt ( provoque mydriase  pendant 48/72)

Si inflammation en CA et infiltrat encore fluo + ( tu ne peux pas cortis encore) tu veux augmenter le atb:

Combination floxal (ofloxacino-quinolones 2em generation) + tobradex (tobramicine)

Vigamox (fluoroquinolone mes puisante de 4em generation) mais pas combiner avec floxal car 2 quinolones mieux avec tobradex

Donc mieux combinations: floxal + tobradex ou vigamox +tobradex

Et si tu veux faire servir que une suele quinolone – mieux vigamox 8xj que floxal plus puisante

Si cicatrice sympt:

FML/DEXAFREE schéma degressif 3xj pdt 2 sem, 2xj pdt 2 sem et 1xj pdt 2 sem et STOP.

Si plaie fluo – et que cicatrise suivi de contrôle dans 1 mois ou fin de ttt sans problemes, pas besoin avant.

## SUIVI

Pas cô d'office, à évaluer selon lée cas.

Si lésion centrale ou BAV: PC dans 48-72h.
