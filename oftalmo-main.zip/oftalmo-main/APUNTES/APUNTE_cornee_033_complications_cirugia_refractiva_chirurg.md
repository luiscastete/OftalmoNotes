---
categoria: apuntes
area: cornea
emoji: 👁️
seccion: Cornée
orden_seccion: 4
orden: 33
fuente: OneNote del Dr. Castilla Martí
---
# Complications Cirugía refractiva chirurgie refractive

Contraindications refractive surgery:

- Patients with collagen vascular, auto-immune or immunodeficiency disease
- Women who are pregnant or nursing - including woman who actively trying to get pregnant
- Patients with abnormal topography
- Patients with unstable refraction. In general should be stable for at least 1 year.
- Medications: isotretinoin-accutane and amiodarone.

📍**Diffuse Lamellar Keratitis (DLK)**

📍**Interface Fluid Syndrome (IFS)**

ar de cara al EBO:

## 🔶1.Diffuse Lamellar Keratitis (DLK)

## ✅¿Qué es?

Una **reacción inflamatoria estéril** (no infecciosa) que aparece en el **espacio interface** entre el flap corneal y el estroma subyacente tras cirugía LASIK.

## 🕒¿Cuándo aparece?

Generalmente entre el **día 1 y el 5 post-LASIK**.

## 🧠¿Por qué ocurre?

- Trauma quirúrgico
- Contaminación con toxinas, meibomio, polvo, talco de guantes
- **Defectos epiteliales**
- Cirugía con energía excesiva (femtosegundo)

## 👁️

## Signos clínicos

- Infiltrados celulares difusos en el **interface**
- Puede afectar la agudeza visual si progresa
- Sin hiperemia conjuntival llamativa ni dolor

## 🎯Clasificación en grados (1 a 4)

- **Grado 1–2:** leve, central o periférico
- **Grado 3–4:** puede comprometer la visión si no se trata

## 💊Tratamiento

- **Corticoides tópicos intensivos**
- En grados avanzados: levantar el flap y lavar con BSS

## 🧠Clave para el EBO

DLK = inflamación **estéril**, aparece **temprano**, se trata con **corticoides**.

## 🔷2.Interface Fluid Syndrome (IFS)

(*también llamado “Pressure-induced stromal keratitis” – PISK*)

## ✅¿Qué es?

Acumulación de **fluido entre el flap y el estroma corneal**, **causada por hipertensión ocular** — muchas veces inducida por corticoides postoperatorios.

## 🕒¿Cuándo aparece?

Puede ser **días o semanas después de la cirugía**, incluso **meses o años** si el paciente vuelve a usar esteroides.

## 🧠¿Por qué ocurre?

- **Aumento de la PIO real**, que no se detecta bien con tonometría por aplanación (da **falsos valores bajos** por el flap)
- Resultado: **filtración de humor acuoso al interface**

## 👁️Signos clínicos

- Disminución de AV
- Aparición de fluido entre flap y estroma (espacio claro en lámpara de hendidura)
- PIO medida normal o ligeramente elevada (¡pero falsamente baja!)

## ❗Diagnóstico difícil si no se sospecha

## 💊Tratamiento

- **Suspender corticoides**
- **Iniciar tratamiento hipotensor agresivo**
- Monitorizar con **OCT corneal y campo visual**

## 🧠Clave para el EBO

IFS = **fluido por hipertensión ocular**, **empeora con corticoides**, PIO **falsamente normal**, se trata **bajando la PIO**.

## 🔄Tabla comparativa rápida

| **Característica** | **DLK** | **IFS** |
|---|---|---|
| Origen | Inflamación estéril | Hipertensión ocular |
| Inicio | 1–5 días post-LASIK | Días/semanas, incluso tardío |
| PIO | Normal | Elevada (pero falsamente normal) |
| Causa común | Cirugía, tóxicos, epitelio | Corticoides postoperatorios |
| Clínica | Infiltrados en interface | Fluido en interface |
| Tratamiento | Corticoides tópicos | **Suspender corticoides**, hipotensores |
| Pronóstico | Bueno si precoz | Bueno si se detecta a tiempo |
