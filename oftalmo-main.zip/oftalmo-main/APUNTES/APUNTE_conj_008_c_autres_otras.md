---
categoria: apuntes
area: cornea
emoji: 💧
seccion: Conj + Episclere + Sclere
orden_seccion: 25
orden: 8
fuente: OneNote del Dr. Castilla Martí
---
# C. Autres Otras

## 2.4. Otras conjuntivitis

## 2.4.1. Síndrome oculoglandular de Parinaud

## Etiología

La causa más frecuente es la enfermedad por arañazo de gato, causada por *Bartonella henselae*. Otras etiologías incluyen *Francisella tularensis*, *Sporothrix schenckii*, micobacterias y *Chlamydia trachomatis* (serotipos L1-L3).

## Clínica

Conjuntivitis granulomatosa unilateral con linfadenopatía regional dolorosa y síntomas sistémicos leves.

## Diagnóstico

Basado en la historia clínica y serología. La PCR puede ser útil en casos específicos.

## Tratamiento

Antibióticos sistémicos como doxiciclina o azitromicina. En casos complicados, se pueden considerar combinaciones con rifampicina o trimetoprim-sulfametoxazol.

## 2.4.2. Síndrome de Reiter (artritis reactiva)

## Etiología

Es una espondiloartropatía reactiva asociada a infecciones genitourinarias (por *Chlamydia trachomatis*) o gastrointestinales (*Salmonella*, *Shigella*, *Yersinia*, *Campylobacter*).

## Clínica

Tríada clásica de conjuntivitis, uretritis y artritis. La conjuntivitis suele ser bilateral, con secreción mucopurulenta, y puede asociarse a uveítis anterior.
