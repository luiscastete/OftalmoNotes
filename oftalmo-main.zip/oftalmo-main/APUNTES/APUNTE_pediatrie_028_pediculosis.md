---
categoria: apuntes
area: pediatria
emoji: 🧸
seccion: Pediatrie
orden_seccion: 9
orden: 28
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-04-16
---
# PEDICULOSIS

Impre:

Poux et lentes visualises sur base des cils et sourcils.

Enfante peu collaborant. impossible ablation lentes et poux à la pincette.

add bacterio avec poux + lentes pour identification parasitologique ce jour

Pediculosis

Poux pubiens (morpions)/Phtirius inguinalis --- transmission sexuel?

att:

add vaseline blanche 3xj pdt 2 sem

add fucithalmic gel 2xj pdt 2 sem
