---
categoria: apuntes
area: retina-medica
emoji: 🩸
seccion: Ret Med y coroides
orden_seccion: 19
orden: 7
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-07-24
---
# OACR – Obstruction Artere centrale de la retine

Occlusion de l'artere centrale de la rétine provoquant une ischémie rétinnienne dans les 4 quadrants

La retine neuro-sensorielle est ischemique de façon irreversible après 90 mins d'occlusion arterielle.

La circulation provenant de ACR irrigue la moitie interne de la retine nottament les fibres optiques. Une occlussion au niveau ce systeme entraine une atrophie des couches internes de la retine. Le centre de la macula n'est pas vascularise- zone avasculaire centrale.

La nutrition a cet endroit est assure par les echanges avec circulation choriudienne sous-jacente.

Cependant l'information visuelle chemine vers les nerfs optiques via fibres optiques interpapillomaculaires. C'est atrophie de ces fibres qui entrain l'enffodremnt de AV.

Le site anatomique de l'occlusion determinera s'il s'agit d'une occlusion:

- l'artere centrale de la retine OACR – 60%
- De brance arterielle OBR– 35%
- Ou cilioretinienne ou arteriole <5%

RARE: 1/10.000 age moyen >55 ans

## SYMPTOMES

BAV brutale unilàterale ( abssence de perception de lumiere à CLD)

INDOLORE ( Sauf si causée par maladie de Horton)

OEIL blanc

+/-  parfois ant. amaurose fugace

## SIGNES

- AV effondre –sauf si a cilio-retinniene présente
- Pupille en Mydriase aréflective, avec abolition du RAPD profond et conservation du reflexe consensuel – lorque en eclaire l'oeil adelphe.
- Macula: aspect en cherry-red spot
- Oedeme blanc ischemique- Retineblânchatre dans les 4 quadrants
- Embole parfois visible au FO (20% cas)
- Retrécissement du calibre arteriel
