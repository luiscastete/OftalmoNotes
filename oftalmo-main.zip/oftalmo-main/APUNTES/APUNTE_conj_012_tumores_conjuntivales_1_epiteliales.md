---
categoria: apuntes
area: cornea
emoji: 💧
seccion: Conj + Episclere + Sclere
orden_seccion: 25
orden: 12
fuente: OneNote del Dr. Castilla Martí
---
# Tumores Conjuntivales 1.Epiteliales

## 🧠Apuntes resumen: Tumores conjuntivales (Tema 5)

## 5.1. Tumores epiteliales

## ✅Tumores epiteliales benignos

| **Lesión** | **Características principales** | **Tratamiento** |
|---|---|---|
| **Disqueratosis intraepitelial benigna hereditaria** | Autosómica dominante (cr. 4), limbo, gelatinosa, sin invasión ni displasia. También en faringe y boca. | Extirpación (puede recidivar) |
| **Hiperplasia pseudoepiteliomatosa** | Nódulo hiperqueratósico reactivo, sin displasia ni vasos | Observación o escisión |
| **Papiloma escamoso conjuntival** | Sésil o pedunculado, VPH (6-11 más comunes), jóvenes 20-40 años. Invertido = crecimiento endofítico | Extirpación + crioterapia. IFNa-2b, MMC o 5-FU posibles |
| **Queratosis actínica** | Leucoplásica, lenta, limbo interpalpebral. Sobre pinguécula o pterigion | Escisión (puede progresar a carcinoma) |
