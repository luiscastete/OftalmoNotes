---
categoria: apuntes
area: uveitis
emoji: 🔥
seccion: Immuno-infectio
orden_seccion: 7
orden: 15
fuente: OneNote del Dr. Castilla Martí
---
# Birdshot chorioretinopathy

## 📌2.2.7. Coriorretinopatía en perdigonada (Birdshot chorioretinopathy)

## 🧠Etiología y características generales

- **Tipo**: Coroiditis multifocal granulomatosa bilateral.
- **Grupo etario**: Adultos de mediana edad 40s.
- **Asociación genética**:
  - **HLA-A29** positivo en >90% de los casos.
  - Incrementa riesgo x224 (presente en ~7% población general).
- **No asociada a patología sistémica**.

## 👁️Clínica

- **Síntomas**:
  - Visión borrosa
  - Miodesopsias
  - Nictalopía
  - Alteración en visión de colores

- **Signos**:
  - Poca o nula inflamación en segmento anterior.
  - Vitritis en grado variable.
  - Lesiones coroidales **blanquecinas, cremosas**, que irradian desde el nervio óptico.
    - Mejor visibles en oftalmoscopia indirecta.
    - No se pigmentan con el tiempo.
  - En fase aguda: **vasculitis retiniana no oclusiva**, **papilitis** y **edema macular quístico (EMQ)**.
