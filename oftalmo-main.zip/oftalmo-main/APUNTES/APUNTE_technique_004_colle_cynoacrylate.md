---
categoria: apuntes
area: general
emoji: 🛠️
seccion: Technique-Procedures
orden_seccion: 13
orden: 4
fuente: OneNote del Dr. Castilla Martí
fecha: 2024-02-05
---
# Colle cynoacrylate

## Indications

Perforations cornéenne

Ulcere perforé

Descemetocèle...

Principes de base

Composition cyanoacrylate

Keep it dry and apply it fast

Polymerisation de la colle si mouillée--garder la surface de cornée sèche pour permettre à la colle d'adhérer au stroma.

Materiel

Oxybuprocaine ou Tétracaine en gtt

Ecarteur palpebral

Une tube de colle cyanoacrylate ex: Histoacryl

Triangles stériles

Procedure:

A la lampe à fénte
