---
categoria: apuntes
area: oculoplastica
emoji: 🫥
seccion: Oculo-Plastie
orden_seccion: 3
orden: 3
fuente: OneNote del Dr. Castilla Martí
---
# Lesiones palpebrales benignas

## 🟣2.18. Nevus melanocítico

## Definición

- Tercera lesión benigna más frecuente en región periocular (tras papilomas y quistes epidérmicos).
- Origen: agrupación de *nevocitos* (melanocitos no diferenciados) en epidermis y dermis.

## 🔹Tipos

## 📌Congénito

- Poco frecuente. Generalmente pequeños, pero pueden ser extensos.
- Color uniforme. Histología similar a los adquiridos.
- Variante: **Nevus en beso** → afecta a párpados superior e inferior; puede contener pelo.

## Manejo

- Asintomáticos: no requieren tratamiento.
- Indicaciones de resección: crecimiento, transformación maligna o impacto estético.
- Técnica: afeitado o escisión en cuña.

## 📌Adquirido

Clasificados por localización histológica → representan fases evolutivas:

| **Fase / Tipo** | **Descripción** | **Edad típica** | **Potencial maligno** |
|---|---|---|---|
| 🔸 Nevus juntural | Mácula plana, homogéneamente pigmentada. Células en unión dermoepidérmica. | Jóvenes | Bajo-moderado |
| 🔸 Nevus compuesto | Lesión elevada y pigmentada. Células en unión + dermis. | Mediana edad | Bajo |
| 🔸 Nevus intradérmico | Lesión elevada, escasamente pigmentada (a menudo amelanótica). Solo en dermis. | Ancianos | Nulo |

## 🟣2.22. Melanocitosis dérmica (Nevus de Ota)

## Definición

- Nevo azul congénito.
- Afecta piel del párpado (coloración azul-grisácea), con posible extensión a región frontal.

## Etiopatogenia

- Proliferación de melanocitos dérmicos en territorio del **V par craneal** (1º y 2º dermatomo).

## Epidemiología

- Más común en mujeres de origen africano, asiático o hispano.

## Variante asociada

- **Melanocitosis oculodérmica**: afecta piel + úvea + epiesclera.
- Riesgo de malignización (melanoma): **1/400** casos.

## Tratamiento

- No existe tratamiento curativo; se indica seguimiento periódico por el riesgo de malignización ocular.

## 🟣2.25. Hemangioma capilar

## Definición

- Tumor benigno vascular **congénito**, más frecuente en el **párpado superior**.
- Puede extenderse a la **órbita**.

## Etiopatogenia

- Proliferación unilateral de vasos en **dermis y tejido subcutáneo**.
- De **color rojo brillante**, aumenta con el **llanto** y **blanquea con la presión** (signo típico).

## Curso clínico

- Aparece en los **primeros meses de vida**.
- **Crecimiento rápido** durante el primer año.
- Involución progresiva entre los **4 y 5 años** siguientes.

## Complicaciones

- Puede provocar:
  - **Ptosis mecánica**
  - **Ambliopía por deprivación**
  - **Anisometropía**
  - **Estrabismo**

## Tratamiento

- **Indicaciones**: riesgo de ambliopía o compromiso visual.
- **Opción de elección**:→ **Inyecciones intralesionales de corticoides**.

## 🟣2.26. Mancha en vino de Oporto

## Definición

- **Hemangioma cavernoso subcutáneo** congénito, unilateral.
- Lesión rosada de bordes definidos → oscurece con el tiempo (color púrpura).
- **No blanquea con la presión** (diferente del hemangioma capilar).

## Síndrome asociado

- Puede formar parte del **síndrome de Sturge-Weber**→ Angiomatosis encefalo-trigeminal (afectación neurológica + ocular).

## Manejo

- Estético: láser.
- Neurológico y oftalmológico: seguimiento multidisciplinar.
