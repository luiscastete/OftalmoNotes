---
categoria: apuntes
area: cornea
emoji: 👁️
seccion: Cornée
orden_seccion: 4
orden: 3
fuente: OneNote del Dr. Castilla Martí
---
# Anatomie

The anterior corneal surface has a dioptric power of 48D. The posterior corneal surface has a dioptric power of -5.8D. Therefore the average dioptric power is around 42 to 43D.

3 predominant glycosaminoglycans found in corneal stroma are:

Keratan sulfate

Chondroitin sulfate

Dermatan surlfate

The lens is the most sensitive followed by the cornea - retina and optic nerve.

There is generally a period of 2-3 years before the cataract develops with radiation.

1.1. Anatomía y fisiología

La córnea es un tejido transparente y avascular, responsable de tres cuartas partes de la potencia óptica del ojo (43.25 D, siendo la potencia dióptrica total del ojo humano normal 58.6D).

Para su nutrición, depende de la difusión de gluco-

sa desde el humor acuoso y del oxígeno que difunde a

través de la película lagrimal. Junto a ello, la periferia

recibe oxígeno desde la circulación del limbo.

La córnea es el tejido corporal con mayor densidad

nerviosa, por lo que trastornos como las abrasiones

y la queratopatía bullosa se asocian a intenso dolor,

fotofobia y lagrimeo; existen dos plexos nerviosos,

uno subepitelial y otro estromal profundo, inervados

ambos por la primera división del trigémino.

Mide 10-11 mm en dirección vertical y 11-12 mm

en dirección horizontal. Su espesor central tiene un

promedio de 540 mm, siendo más grueso hacia la pe-

riferia.

1.1.1. Composición de la córnea.
