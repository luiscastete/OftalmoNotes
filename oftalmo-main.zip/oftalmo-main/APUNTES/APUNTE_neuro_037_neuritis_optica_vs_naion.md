---
categoria: apuntes
area: neuro
emoji: 🧠
seccion: Neuro-Ophta
orden_seccion: 8
orden: 37
fuente: OneNote del Dr. Castilla Martí
---
# Neuritis optica vs NAION

**Cuadro Comparativo: Neuritis Óptica vs Neuropatía Óptica Isquémica Anterior No Arterítica (NAION)**

| **Característica🧐** | **Neuritis Óptica (Optic Neuritis)** | **Neuropatía Óptica Isquémica Anterior No Arterítica (NAION)** |
|---|---|---|
| **Edad típica** 🎂 | 20–45 años | >50 años |
| **Inicio** 🚀 | Rápido (horas a días) | Súbito, frecuentemente al despertar |
| **Dolor ocular** 😖 | Presente, sobre todo con movimiento ocular | Ausente o mínimo |
| **Pérdida visual** 👁️‍🗨️ | Progresiva en pocos días | Súbita y generalmente fija |
| **Apariencia del nervio óptico** 🔍 | Normal o leve edema (o retrobulbar) | Edema de papila difuso o sectorial, palideciendo luego |
| **Defecto campimétrico** 🎯 | Escotoma central | Escotoma altitudinal (frecuentemente inferior) |
| **Visión cromática** 🌈 | Muy alterada | Relativamente preservada |
| **Pupila de Marcus Gunn (RAPD)** 🔦 | Presente | Presente |
| **Factores de riesgo** ⚠️ | Esclerosis múltiple, infecciones virales | HTA, DM, dislipidemia, apnea del sueño |
| **Recuperación** 🛠️ | Espontánea o acelerada con corticoides IV | Parcial; pobre recuperación visual |
| **Tratamiento** 💉 | Corticoides IV (en casos seleccionados) | Control de factores vasculares; sin terapia curativa |
| **Fisiopatología** 🧠 | Inflamación y desmielinización inmunomediada del nervio óptico | Infarto isquémico por hipoperfusión de la circulación ciliar posterior |
