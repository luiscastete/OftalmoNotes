---
categoria: apuntes
area: general
emoji: 💊
seccion: Pharmacologie Farma
orden_seccion: 23
orden: 9
fuente: OneNote del Dr. Castilla Martí
---
# ROUTES OF ADMINISTRATION

**Topical:** absorption related to corneal penetration.

1 drop = 50 μL (20–40 drops in most bottles) Conjunctival cul-de-sac holds only 10 μL (20% of drop)\*\*\*

***Drop diluted by reflex tearing and normal tear turnover:*** only ∼50% of drug that reaches the cul-de-sac is present 4 minutes later (10% of drop), and only 17% (3.4% of drug) is present after 10 minutes

## Corneal barriers to penetration

**TIGHT JUNCTIONS** (epithelium and endothelium): limit passage of hydrophilic drugs

**STROMA** (water rich): limits passage of lipophilic drugs

## Methods of increasing absorption

- 1. Add surfactants (disrupts epithelial integrity; e.g., benzalkonium chloride, topical anesthetic).
- 2. Promote punctal occlusion (decreases drainage).
- 3. Close eyelid (no blinking) after drops are placed for 5 minutes.
- 4. Increase lipid solubility of drug (increases pH); more important than
  - water solubility.
- 5. Increase frequency of drops.

- Topical medications have systemic adverse effects because the drugs bypass hepatic “first-pass” metabolism (cul-de-sac → nasolacrimal duct → mucosa → bloodstream).
