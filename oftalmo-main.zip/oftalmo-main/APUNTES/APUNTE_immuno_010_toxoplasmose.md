---
categoria: apuntes
area: uveitis
emoji: 🔥
seccion: Immuno-infectio
orden_seccion: 7
orden: 10
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-08-18
---
# Toxoplasmose

## DEFINITION

Cause plus freq d'inflammation su segment posterior d'origine infectieuse

Infection parasitaire causée par del protozaire intracellullaire obligatoire, **Toxoplasma gondi.**

Origene congenital ou acquise.

Prise en charge depende essentiellement localisation foyer.

\_\_EPIDEMIOLOGIE

## Toxoplasma gondi, existe sous 3 formes evolutives

-Tachyzoites ou formes libres

-bradyzoites contenus dans kystes

-oocystes

## COMMENT REFEERER?

## DX

## Formes typiques

## SYMPTOMES

Majoritariament asymptomatique (sujets immunocompetents) mais risque serieux si femmes encentes, séropositives au VIH ou systeme immunitaire affaibli.

## OCULAIRES

- Rougeur
- Douleur profonde
- Photophobie
- BAV
- Amputation CV
- Absence de sécretions
- Myodesopsies

## SYSTEMIQUES
