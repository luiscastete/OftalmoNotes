---
categoria: apuntes
area: glaucoma
emoji: 🟢
seccion: Glaucome
orden_seccion: 5
orden: 22
fuente: OneNote del Dr. Castilla Martí
---
# Schwartz-Matsuo syndrome

Is a rise in IOP pressure in the setting of a chronic rhegmatogenous retinal detachment. Matsuo demonstrated the presence of photoreceptors outer segments.

Macrophages laden with proteinaceous material are found in phacolytic glaucoma - where the swollen macrophages then block the trab meshwork.

Ghost cell glaucoma which is secondary to open angle glaucoma caused by degenerated red blood cells blocking de trab.

Ghost cells are RBC that have lost their hemoglobin. They can develop 1-3 months after vitreous hemorrage.

This contrats with hemolytic glaucoma which is a glaucoma caused by hemoglobin-laded macrophages that block trab.
