---
categoria: apuntes
area: oculoplastica
emoji: 🫥
seccion: Oculo-Plastie
orden_seccion: 3
orden: 16
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-08-16
---
# Fracture du cadre orbitaire

Fracture d'un ou plusieurs des os entourant de l'orbite.

Fracture plus freq: Plancher de l'orbite

## SIGNES

Oedeme periorbitaire

Hématome palpébral en mocle

+/- emphysème sous-cutané - crépitations

Limitation à oculomotricite ( surtout en elevation)

+/- hypoesthesie sur territoire du nerf infra-orbitaire- joue et lèvre superieures ipsilateral

+/-enophtalmie

Bradycardie- en cas stimulation et incarcelation musculaire

## STATUS

AA: type trauma? Cinétique, douleur oculomotricite? Diplopie binoculaire? Hypoesthesie de la joue?

AV-TIO—exclure rupture du globe.

Ishihara-Pupilles

Oculomotricite

Evaluation du cadre orbitaire: palpation du rebord orbitaire ipsilaterale et bilateral pour comparison +/- marche d'escalier à la palpation.

Evaluation des paupieres: crépitations - emphyseme sous cutanée, hématome.

LAF: micro hyphema, inflammation en CA...

FO dilaté: exclure lésions chorio-retiniennes.

## BILAN

## IMPORTANTE: exclure lesion intra-oculaire ou neuropathie optique.

CT scan orbitaire et os de la face avec coupes fines: à effectuer chez tous les patient si suspicionde fracture du cade orbitaire.

Si perte de connaisance/amnésie circonstancielle: faire CT cerebral.

## TT

## MEDICAL

Rappel tétanos si besoin.

Interdiction de se moucher pdt 10j.

Compresses froids

+/- ATB oer os augmentin 625mg 3xj pdt 7j

L'antibiothetapie profilactique- pour prevention cellulite orbitaire- ne doit pas etre considere comme tt obligatoire.

+/- corticotherapie per os: si oedeme importante.

Demande de consultation chirirgie maxilo-facial.

## CHIRURGICALE

## Intervention en urence si

- Perforation oculaire.
- Fracture en trappe de l'enfant.

## Intervention dans 10-15j si

- Fracture du placher de l'orbite etendue >50%.
- Diplopie au regard primaire ou vers le bas sans amélioration depuis 10j.
- Fractures multiples—plancher et paroi médiale.
- Traumatisme avec fractures complexes

## SUIVI

Cô 1-2 sem pour suivi diplopie et énophtalmie en ophtalmologie et chirurgie maxilo-faciale.

Si traumatisme intra-oculaire: cô à 1 mois avec gonio + FO dilaté.
