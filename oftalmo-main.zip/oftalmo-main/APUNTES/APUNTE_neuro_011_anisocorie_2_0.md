---
categoria: apuntes
area: neuro
emoji: 🧠
seccion: Neuro-Ophta
orden_seccion: 8
orden: 11
fuente: OneNote del Dr. Castilla Martí
---
# Anisocorie 2.0

## 🔍

## ¿Por qué sospechamos pupila de Adie en este caso?

## ✅Mujer joven, asintomática, 26 años

- **La pupila de Adie** es más común en **mujeres jóvenes**.
- Muchas veces se **descubre incidentalmente**, sin síntomas visuales relevantes.

## ✅Anisocoria queaumenta con luz intensa

- Esto sugiere que **la pupila más grande (midriática) es la anómala**, ya que:
  - En condiciones de luz, **la pupila normal se contrae**.
  - La pupila afectada **no responde bien a la luz**, por lo tanto la **anisocoria se acentúa**.
- Esto **descarta** en gran medida un **síndrome de Horner**, que se acentúa en la oscuridad (por falta de dilatación).
