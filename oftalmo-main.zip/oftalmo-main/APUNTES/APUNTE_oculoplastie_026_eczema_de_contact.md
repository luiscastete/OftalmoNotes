---
categoria: apuntes
area: oculoplastica
emoji: 🫥
seccion: Oculo-Plastie
orden_seccion: 3
orden: 26
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-12-12
---
# Eczema de contact

C'est la cause plus frequnece d'inflmm palpebrale

Les agents en cause sont: produits cosmetiques, collyres-néosynéphrine, solution entretien de lentilles de contact, profuits faux cils.

On retrouve souvent lesionns érythémateuso-squameuses prurigineuses associes ou pas à une conjonctivite folliculaire

TT:

Éviction de l'allergène.

Dermatocorticoides clase I ou II

Ttt:

Ablation des faux cils que dès possible

Ultracortenol pommade 2xj pdt 1 sem

Opatanol 2xj pdt 1 sem

Optava 4xj pdt 2 sem

PC si besoin/pejoration

Autre option add PVA pour remolir cils et les enlever et suivre ttt en haut.

Ttt:

Nettoyer la colle avec adiction de Pommade vitamin A et masser avec compresses humides

Dexafree collyre 3xj pendant 4j ensuite 2xj pendant 4j et 1xj pendant 4j et STOP.

Opatanol 2xj pendant 1 semaine

Optava 4xj pendant 2 semaine

Viscotear gel le soir avant dormir pendant 2 semaine

Att:cf ordo

PC si besoin/pejoration
