---
categoria: apuntes
area: oculoplastica
emoji: 🫥
seccion: Oculo-Plastie
orden_seccion: 3
orden: 32
fuente: OneNote del Dr. Castilla Martí
---
# Tumeur orbitairs

Lesions vasculaires orbitales

Concrétions

Secretions
