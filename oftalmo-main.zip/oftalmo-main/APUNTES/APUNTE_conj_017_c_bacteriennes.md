---
categoria: apuntes
area: cornea
emoji: 💧
seccion: Conj + Episclere + Sclere
orden_seccion: 25
orden: 17
fuente: OneNote del Dr. Castilla Martí
fecha: 2024-07-02
---
# C. BACTERIENNES

## 👁️‍🗨️2.2 CONJUNTIVITIS BACTERIANA – GENERALIDADES

## 🔬

## Fisiopatología

- Proliferación bacteriana en la conjuntiva → inflamación → reclutamiento de neutrófilos → secreción mucopurulenta.
- En formas crónicas, como *S. aureus* o *Moraxella*, se asocian a blefaritis e infiltrados catarrales.

## 💧FORMA CLÍNICA AGUDA TÍPICA

## 📌Características clínicas

- Inicio súbito, secreción mucopurulenta moderada.
- Papilas tarsales, sin folículos.
- Adenopatía preauricular **inusual** salvo formas graves o hiperagudas.

## 🧫Etiología común y prevalencia

| **Patógeno** | **Frecuencia / notas clínicas** |
|---|---|
| **S. aureus** | Adultos. Causa más frecuente. Crónica. Asociada a blefaritis. |
| **H. influenzae (no tipificable)** | Niños pequeños. Flicténulas. Puede producir clínica sistémica. |
| **S. pneumoniae** | Niños. Forma aguda clásica. |
| **Moraxella lacunata** | Niños/adultos. Blefaritis angular, tendencia a cronificación. |
| **Germenes GN (E. coli, Pseudomonas, etc.)** | Casos hospitalarios, exposición corneal, inmunosupresión. |
| **Neisseria gonorrhoeae/meningitidis** | Muy grave (hiperaguda). Rara. ETS o autoinoculación. Rápida perforación corneal posible. |
