---
categoria: apuntes
area: retina-quirurgica
emoji: 🪡
seccion: Ret Chirg
orden_seccion: 6
orden: 5
fuente: OneNote del Dr. Castilla Martí
fecha: 2024-05-15
---
# Syndrome MATSUO SCHWARTZ

Uveite associée à un décollement de rétine
