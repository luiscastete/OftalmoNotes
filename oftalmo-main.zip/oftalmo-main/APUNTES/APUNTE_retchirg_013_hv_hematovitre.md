---
categoria: apuntes
area: retina-quirurgica
emoji: 🪡
seccion: Ret Chirg
orden_seccion: 6
orden: 13
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-03-12
---
# HV - Hématovitré

Hemorragie dans la cavite vitreenne

## SYMPT

BAV indolore, soudaine, unilaterale ( vsion rouge/orange/filamentes pas noire) -sauf si traumatime.

Myodesopsies

Amputation du CV

## SIGNES

Cellules hématiques dans vitre ant.

Si MODERE: FO partiellement visible, cellules hématiques dans vitre.

Si SEVERE: FO non visualisable +/- discret RAPD

Si CHRONIQUE: aspect blanchatre/jaunatre par degradation de hemoglobine

Aspect de la retine selon etiologie.

## ETIOLOGIES

DPV ( avec ou sans dechirure de la retine)

RDP normalment presente egalemnt dans l'oeil contralateral\*\*\*\*

Traumatisme

Autre (plus rare): OBCR/OVCR, macroanvrisme de la retine syndrome de Terson, DMLA neovasculaire, drepanocystose...

## AA

Recherche etiologie: nottament si trauma, DM? FRCV? Anticoag? Problemes de coag?

## STATUS

AV-TIO

## LAF : recherche rubeosis

FO dilate: compare avec oeil contralateral

## BILAN

Si FO non visible: US echo-B: retine a plat? Dechirure? **A faire avec CDC.**

Labo: HBA1c, bilan crase complet, FSC.
