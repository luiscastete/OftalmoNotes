---
categoria: apuntes
area: neuro
emoji: 🧠
seccion: Neuro-Ophta
orden_seccion: 8
orden: 24
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-09-28
---
# Paralysie Supranucléaire Progressive-PSP

La paralysie supranucléaire progressive est une affection dégénérative rare du système nerveux central qui altère progressivement les mouvements volontaires des yeux, qui provoque:

-une bradykinésie,

-une rigidité musculaire avec une dystonie axiale évolutive, une paralysie pseudobulbaire et une démence. Le diagnostic est clinique. Le traitement est symptomatique.
