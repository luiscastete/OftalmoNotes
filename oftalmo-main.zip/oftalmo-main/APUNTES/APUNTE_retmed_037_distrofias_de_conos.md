---
categoria: apuntes
area: retina-medica
emoji: 🩸
seccion: Ret Med y coroides
orden_seccion: 19
orden: 37
fuente: OneNote del Dr. Castilla Martí
---
# Distrofias de conos

## 4. Distrofias de conos

## 4.1. Características generales

- Trastornos hereditarios que afectan a los conos, especialmente en la mácula.
- Aparecen desde el nacimiento o en la infancia.
- Causan: **disminución AV central**, **fotofobia**, **nictalopía** (en algunas), **nistagmo** y **anomalías de visión de color**.
- Afectan en mayor proporción a personas en edad laboral.

## 4.2. Tipos y características

## 🔴Acromatopsia completa

- **Herencia**: Autosómica recesiva.
- **Clínica**: AV ~0.1, nistagmo pendular, sin visión colores, fotofobia intensa, fenómeno de Flynn.
- **ERG**: Conos ausentes, bastones normales.
- **Fondo/OCT**: Normal o con cambios maculares sutiles.
- **Genética**: CNGA3, CNGB3 (cascada de fototransducción).

## 🔵Monocromatismo de conos azules

- **Herencia**: Ligada al X.
- **Clínica**: Solo funcionan conos azules y bastones, tritanopia, miopía.
- **ERG**: Respuesta de conos S conservada.
- **OCT**: Adelgazamiento macular, alteración focal.
- **Fondo**: Retina miope, atrofia en mayores.
