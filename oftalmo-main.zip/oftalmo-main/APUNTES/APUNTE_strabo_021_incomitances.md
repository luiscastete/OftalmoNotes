---
categoria: apuntes
area: pediatria
emoji: 👀
seccion: Strabo-logie
orden_seccion: 22
orden: 21
fuente: OneNote del Dr. Castilla Martí
---
# Incomitances

Incomitances alphabetiques

Correspondent a une difference de l'angle de deviation entre le regard en haut et en bas en vision de loin.

2 type majeurs : le syndrome V et le syndrome A.

SYNDROME V

Diference au moins 15-signe triangle- entre le haut et le bas.

Une esotropie sera plus importante dans le regard en bas que dans le regard en haut, alors que une exotropie sera plus importante dans le regard en haut que dans le regard en bas.

SYNDROME A

Diference de au moins 10-signe triangle- ENTRE LE REGARD EN HAUT ETE EN BAS.

Une esotropie sera plus evidente en le regard en haut que dans le regard en bas, alors que exotropie sera plus importante dans le regard en bas que dans le regard en haut.
