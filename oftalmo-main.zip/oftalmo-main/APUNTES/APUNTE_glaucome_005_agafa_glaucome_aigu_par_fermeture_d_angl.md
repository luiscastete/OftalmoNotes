---
categoria: apuntes
area: glaucoma
emoji: 🟢
seccion: Glaucome
orden_seccion: 5
orden: 5
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-02-05
---
# aGAFA - Glaucome aigu par fermeture d'angle

Fermeture aigue angle irido-cornéen

## SYMPT

Rougeur oculaire

Douleurs

BAV

## SIGNES

BAV variable

TIO Haute >40mmHg

HC +/- cercle perikératique

Oedeme cornéen épithélial

CA étroite +/- Tyndall

Pupille en semi-mydriase arreflexique

Glauckomflecken ( Glaukomflecken are small anterior subcapsular opacities secondary to lens epithelial necrosis resulting from acute angle closure glaucoma. These photographs from two different patients show central glaukomflecken and iris atrophy secondary to prior episodes of acute angle closure glaucoma.)

## ETIOLOGIE

## Primaire

Bloc pupillaire

Iris plateau

## Secondaire

Bloc pupillaire: Cristallin ( cataracte post-trauma, laxite zonulaire..), séclusion pupillaire, synechies posterieurs, vitré, silicone, implant phaque, implant en CA..

GNV, syndrome ICE, membranes inflammatoires, PAS,

Glaucome malin, tumerus oculaire, silicone ou gaz, effusion uveal,

Medicamenteuse: Topiramate, sulfonamides...
