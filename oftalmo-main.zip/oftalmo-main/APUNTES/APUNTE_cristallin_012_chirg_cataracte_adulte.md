---
categoria: apuntes
area: catarata
emoji: 🔍
seccion: Cristallin - Lens
orden_seccion: 21
orden: 12
fuente: OneNote del Dr. Castilla Martí
fecha: 2024-01-28
---
# Chirg. Cataracte adulte

POSTERIOR CAPSULAR RUPTURE - PCR

Risk factors:

Surgeon inexperience

Smaller pupil size

Presnece of pseudoexfoliation

Denser cataract

History of previous intravitreal injection

Post polar cataract

History of ocular trauma

Intrraoperative signes PCR:

Sudden deepeing of anterior chamber

Momentary pupillary expansion

Lens nicleus does not rotate well

Lens nucleus doen not come to the phako tip like it did before

Lens tilt or drop

Occlusion of phako tip without any fragments at tip

Primary goals during PCR:

1-REMOVE AS MUCH LENS MATERIAL AS YOU SAFELY CAN

2-prevent vitreous prolapse or remove all vitreous that is anterior to the lens capsule

3-insert an intraocular lens in a safe ans stable location

General surgical steps:

- Do nOT withdraw your phaco tip.
- Fill the anterior chamber with dispersive viscoelastic
- Slowly withdraw your phaco tip and asses how to remove the remaining nuclear material
- Remove cortical material as throughly as possible
- Perform a thorough anterior vitrectomy
- Insert the appropriate intraocular lens IOL
