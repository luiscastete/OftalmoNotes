---
categoria: apuntes
area: cornea
emoji: 👁️
seccion: Cornée
orden_seccion: 4
orden: 24
fuente: OneNote del Dr. Castilla Martí
fecha: 2024-02-07
---
# Topography

Para que usar la topo?

- Determinar la **regularidad y simetria** de la cornea para:
- Dx de patologia corneal
- Valorar calidad optica de la cornea

- Conocer **su potencia** para:
- Planificar cirugias de indole o con objetivo refractivo

Con que?

MAPAS TOPGRAFICOS:

Para determinar la regularidad y simetria:

- **1.mapas de curvatura ( discos placido)**
- **2.mapas de elevacion ( otras tecnologias analisis superficie)**

Para conocer la potencia corneal:

- **3.mapas refractivos – potencia corneal.**

## 🔬

## Diferencias clave: Topografía vs. Tomografía Corneal

| **Característica** | **Topografía corneal** | **Tomografía corneal** |
|---|---|---|
| **Qué mide** | Curvatura de la **superficie anterior** corneal (relieve, potencia) | **Mapa tridimensional** del espesor, curvatura anterior y posterior de la córnea |
| **Tecnología usada** | Proyección de anillos de Placido (disco de Placido) | Escaneo Scheimpflug, OCT o láser de baja coherencia |
| **Zonas evaluadas** | Solo **superficie anterior** | **Superficie anterior + posterior + grosor corneal** |
| **Mapas generados** | Potencia axial, tangencial, elevación anterior | Elevación anterior/posterior, pachimetría, mapas de curvatura tridimensional |
| **Ejemplos de equipos** | Keratograph, TMS, Medmont | Pentacam, Galilei, Sirius, Orbscan, CASIA (OCT) |
| **Útil para** | Detección de astigmatismo, queratocono inicial | Evaluación completa para queratocono, ectasias, planificación quirúrgica |
| **Limitaciones** | No detecta ectasias posteriores ni afinamiento periférico | Más sensible a cambios tempranos y patológicos |
