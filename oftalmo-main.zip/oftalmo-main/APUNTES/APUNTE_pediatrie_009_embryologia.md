---
categoria: apuntes
area: pediatria
emoji: 🧸
seccion: Pediatrie
orden_seccion: 9
orden: 9
fuente: OneNote del Dr. Castilla Martí
---
# Embryologia

## 🧬

**Resumen del origen embriológico de las principales estructuras oculares**

| **Estructura** | **Origen embrionario** |
|---|---|
| **Epitelio corneal (anterior)** | Ectodermo superficial |
| **Estroma corneal (incl. Bowman y colágeno)** | Cresta neural (ectomesénquima) |
| **Endotelio corneal (y membrana de Descemet)** | Cresta neural |
| **Cristalino** | Ectodermo superficial (placoda del cristalino) |
| **Epitelio pigmentario de retina (EPR)** | Neuroectodermo (capa externa de copa óptica) |
| **Retina neural (capa fotorreceptora, bipolar, ganglionar…)** | Neuroectodermo (capa interna de copa óptica) |
| **Músculo esfínter y dilatador del iris** | Neuroectodermo (único músculo derivado de neuroectodermo) |
| **Estroma del iris y cuerpo ciliar** | Cresta neural |
| **Esclerótica** | Cresta neural |
| **Coroides** | Mesénquima (influencia de cresta neural) |
| **Epit. anterior del iris y ciliar** | Neuroectodermo |
| **Nervio óptico y fibras gliales (astroglía)** | Neuroectodermo (evaginación del diencéfalo) |
| **Músculos extraoculares** | Mesodermo precordal / somitómeros |
| **Conjuntiva y párpados** | Ectodermo superficial + mesénquima |
| **Glándula lagrimal** | Ectodermo superficial |
| **Vasos sanguíneos oculares (incl. coroideos)** | Mesodermo |
