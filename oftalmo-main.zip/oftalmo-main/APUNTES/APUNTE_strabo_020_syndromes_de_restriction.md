---
categoria: apuntes
area: pediatria
emoji: 👀
seccion: Strabo-logie
orden_seccion: 22
orden: 20
fuente: OneNote del Dr. Castilla Martí
---
# Syndromes de restriction

## SYNDROME DE BROWN pg 124 kit de strabologie.

Congenital unilaterale et sporadique.

Limitationn d'elevation et adduction ( champ action muscle OI) - INHABILITY TO ELEVATE EYE IN ADDUCTION.

Cette limitation est cependant la consequence d'une atteinte localisee au niveau du muscle OS.

ETIOLOGIE

Congenitale - probablement  anomalie developpement OS.

Forme adquise possible mais rare.

CLINIQUE

Limitation de l'elevation en adduction.

3 niveaus de severite

Legere - orthophorie presente en position primaire avec limittaion dans les champs OI

Moyenne et sevre - s'accompagne d'une phenomenun de downshot dans les efforts de abduction.

Severe - s'accompagne de hypotropie O atteinte en position primaire, susceptible de d'etre compense par torticolis menton relevee.

La sensorialite est generalement normale avec development vision binoculaire.

STATUS

Presence de click syndrome + torticolis.

Examen coordimetrique: hypoaction dans champ du muscle OI. + hyperaction m DS contralaterale est presnete avec normalite pour l'ebaissement.-

IRM-SCANNER : seront demandes pour confirmer l'etiologie inflammatoir ou traumatique

DDX:

1.paralysis isolee OI. Mias la diference sera la hyperaction du OS dans la paralysis.

2.syndrome adherence OI.
