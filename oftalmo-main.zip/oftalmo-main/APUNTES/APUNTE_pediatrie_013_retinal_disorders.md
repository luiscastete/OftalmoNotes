---
categoria: apuntes
area: pediatria
emoji: 🧸
seccion: Pediatrie
orden_seccion: 9
orden: 13
fuente: OneNote del Dr. Castilla Martí
---
# Retinal disorders

**PERSISTENT HYPERPLASTIC PRIMARY VITREOUS - PHPV; PERSISTENT FETAL VASCULATURE**

Unilateral microphthalmia with sprectrum of findings from prominent hyaloid vessel remnant with large Mittendorf dot from prominent hyaloid vessel remnant with large mittendorf dot and bergmeister papillae to angle closure

Caused by incomplete regression of tunica vasculosa lentis and primary vitreous

Sporadic

FINDINGS:

Microphtalmia, vascularized retrolental plaque-may contain cartilage-, prominent radial vessels, on iris surface, shallow AV, iris vacsularization, may have cataract.

TT: observation +/- lensectomie

Prognosis: depending of amblyopia , depends of status post segment.

## COLOBOMA

Pg 128

## RETINOPATHY OF PREMATURITY - ROP

Ya en otra nota visto importancia

## FAMILIAL EXUDATIVE VITREORETINOPATHY - FEVR

Most are unaware that they have this disorder.

Rare, progressive developmental abnormalities of peripheral retinal vasculature.

FINDINGS: similar to ROP

- Stage1: avascular peripheral retina but things chnagings…
- Stage 2: fibrovascular proliferation with neovascularisation, exudates, dragging of disc and macula, retina folds and detachments, visual lost after 2-3th decade.
- Stage 3: Cicatrization
