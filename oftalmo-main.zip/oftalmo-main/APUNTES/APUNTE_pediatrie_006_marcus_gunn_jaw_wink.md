---
categoria: apuntes
area: pediatria
emoji: 🧸
seccion: Pediatrie
orden_seccion: 9
orden: 6
fuente: OneNote del Dr. Castilla Martí
---
# Marcus-Gunn jaw Wink

Marcus Gunn syndrome, also known as Marcus Gunn jaw-winking syndrome, is a congenital condition where a drooping eyelid ("ptosis") lifts and appears to "wink" when the jaw is moved. This synkinetic movement occurs because of abnormal nerve connections between the jaw muscles and the eyelid muscle. The condition is usually present at birth but may be noticed later, often during activities like feeding or chewing, and typically affects only one eye.

V1 –ophtalmic division and V2 maxillary division of the trigeminal nerve are purely sensory.

The mandibular division V3 has sensory and motor function.

CN V3 innervates the external pterygoid muscle and CN III inervates the levator superioris muscle of the upper eyelid.
