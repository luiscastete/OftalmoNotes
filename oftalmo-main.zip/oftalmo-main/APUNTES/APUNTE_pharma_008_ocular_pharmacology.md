---
categoria: apuntes
area: general
emoji: 💊
seccion: Pharmacologie Farma
orden_seccion: 23
orden: 8
fuente: OneNote del Dr. Castilla Martí
---
# Ocular pharmacology

**Pharmacodynamics:** the study of the biochemical and physiologic effects of drugs and their mechanisms of action

**Pharmacokinetics:** the study of the factors that determine the relationship between drug dosage and the change in concentration over time in a biological system; the movement of drug through the body, including absorption, distribution, metabolism, and excretion

**Bioavailability:** the amount of drug absorbed (penetration into ocular tissues)

**Toxicity:** adverse effects of drug and other components of medications (preservatives); affected by pharmacodynamics and pharmacokinetics

Topical ocular medications absorbed through mucous membranes (conjunctiva, nasopharynx), iris, and ciliary body, which avoids first-pass metabolism of liver, increasing risk of systemic effects, particularly in children; 50%–99% of dose can be absorbed systemically, but amount limited by tear dilution and washout.

**Preservatives:** can enhance corneal permeability and have corneal toxicity

**Quaternary ammoniums** (cationic surfactants, detergents): benzalkonium chloride (BAK), benzododecinium bromide, cetrimide, polyquaterniu apraclonidine m-1
