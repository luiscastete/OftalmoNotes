---
categoria: apuntes
area: retina-medica
emoji: 🩸
seccion: Ret Med y coroides
orden_seccion: 19
orden: 18
fuente: OneNote del Dr. Castilla Martí
---
# Sindrome Isquemia Ocular (SIO)

## 🧠5. SÍNDROME DE ISQUEMIA OCULAR (SIO)

## 🧾Definición

Síndrome caracterizado por **hipoperfusión ocular crónica** debida a **estenosis severa (≥90%) de la arteria carótida ipsilateral**. Afecta la irrigación del ojo, produciendo cambios isquémicos en segmento anterior y posterior.

## 📈Epidemiología

- 90% tienen **estenosis carotídea ≥90%**.
- Edad >55 años.
- Causa principal: **aterosclerosis** carotídea.
- Otras causas: arteritis de células gigantes, Takayasu, aneurismas disecantes, hiperhomocisteinemia, PCR elevada.

## 👁️Clínica

## 🔹Síntomas

- **Pérdida visual gradual**.
- **Dolor ocular** (localizado en órbita).
- **Adaptación a la oscuridad lenta tras luz intensa**.
