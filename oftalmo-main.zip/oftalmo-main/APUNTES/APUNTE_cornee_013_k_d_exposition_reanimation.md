---
categoria: apuntes
area: cornea
emoji: 👁️
seccion: Cornée
orden_seccion: 4
orden: 13
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-10-30
---
# K. d'exposition -réanimation

Atteinte cornéene par secheresse oculaire sur fermeture incomplet ou inadequate de la paupiere. La production de larme est normale.

## SYMPTOMES

Symptomes de sécheresse oculaire +++

Sympt. Exacerbes lors de conditions d'exposition: air-conditionné, exposition au vent, chauffage, activites diminuant la freq de clignement des yeux-travail sur écran...

## SIGNES

Signes de secheresse +++ qui pouvent entrainer une ulceration cornéenne et mener a une pérforation.

## ETIOLOGIES

- Lagopthalmie palpébrale: provoque un assèchement de la cornée d'origine évaporative.
- Lagophtalmie d'origine multiple:
  - Neurologique: paralyse faciale NC VII—paralyse palpébrale +/- sensibilité cornéen reduite- NC V
  - Musculaire: maladie de Parkinson ++
  - Mécanique: exopthalmie –tumeur, jémorragie parabulbaire.., cicarice post-trauma ou post blépharoplastie.

## STATUS

- AV-TIO
- Evlauer fermeture palpebrale. Si necessaire, mesurer le degre de lagopthlamie.
- Tester la sensibilite cornéenne.
- LAF: avec fluo, exclure infection, amincissement, une ulceration ou perforation.

## TT

- **Medical:**
- LA + PVA + Pansement oculaire nocturne pour lagophtalmie.

- **Chirurgicale:**
- Tarsorraphie
- Greffe de membrane amniotique
- Décompression orbitaire pour exopthlamie

## Autres mesures

Stopper tout tt topique toxique pour la cornée

Traiter blépharite concomitante

LDC thérapeutique

## PROTECTION OCULAIRE EN REANIMATION

Veiller à la protection oculaire des patient neuro-sedates en sejour de réanimation.

Surtout en positiins ventrale prolongée, qui interdit les soins oculaires.

Avant de retourner en position ventrale, installer dans les deux yeux:

Add floxal gtt 1xj + viscotears ou celluvisc ou PVA

Fermture des paupieres par sparadrap hypoallergique.

Il faut veiller à éviter la compression des globes oculaire . Risque de neuropathie optique ischemique aigue.
