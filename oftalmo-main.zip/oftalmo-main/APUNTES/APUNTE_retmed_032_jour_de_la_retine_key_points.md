---
categoria: apuntes
area: retina-medica
emoji: 🩸
seccion: Ret Med y coroides
orden_seccion: 19
orden: 32
fuente: OneNote del Dr. Castilla Martí
---
# Jour de la retine.Key points

Ttt dmla exaudative-Eandi.

Treat and extend:

Loding dose 1-2-3 mois et ensuite on voit si 4-5 mois et ondecide si on peut espace selon activite.

Future PDS-port delivery system.

Dosage continue et persistante long temps avec risc intervention chirg.

Permet reduir stress injections mensuels.
