---
categoria: apuntes
area: retina-quirurgica
emoji: 🪡
seccion: Ret Chirg
orden_seccion: 6
orden: 7
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-02-15
---
# DVP

Separation de la hyaloide posterieure de la retine neurosensorielle, posterieurment à la base du vitré.

## SYMPT

Phosphenes: Arciformes, souvent en temporale, lors mov ocualires et dans la pénombre/nuit ++ évident.

Myodesopsies

Flou visuel

## SIGNES

AV conserve

Anneau de Weiss ( = DPV complet): anneau translucide de tisu fibrogial, correspond al'attache rompue du vitre avec NO. En suspension devant region papillaire.

## ETIOLOGIES

## STATUS

AV-TIO

LAF: CA et vitre ant: recherche de celules pigmentes: tobacco dust.

FO dilate minutieux de la peripherie ( recherche traction, dechirure, trou, decollement) +/- examen V3M/ Superquad pour visualisation jusqu'a ora serrata.

## BILAN

USB pour exclure DR si Hemorragie vitreene.

OCT mac (optionnel): peu demontrer detachement de la hyaloide post.

## TTT SUIVI

DPV AIGUE SIMPLE

-Rassure patient et explique signes d'urgence rhegmatogènes

-Si sympt >3 sem: pas PC systematique.

-Si symp < 3 sem: PC 3-4 sem avec FO dilate ODG.

DPV AVEC HV peu dense SANS DECHIRURE
