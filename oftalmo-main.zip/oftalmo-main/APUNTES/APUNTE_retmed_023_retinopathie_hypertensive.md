---
categoria: apuntes
area: retina-medica
emoji: 🩸
seccion: Ret Med y coroides
orden_seccion: 19
orden: 23
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-07-24
---
# Rétinopathie Hypertensive

Atteinte de vssx rétiniens en réponse à une hypertension arterielle aigue ou chronique (<140/90mmHg)

## SYMTOMES

Asymtomatique

BAV rare

## SIGNES

## Presque tjrs bilateral.

Si unilateral penser à une stenose carotidienne du côte non atteint. Épargnant la rétine des effects de HTA.\*\*\*

Signes +/ par ordre de gravité (séquentiel) mais en cas HTA maligne cette séquence n'est pas tjrs respectée.

- Constriction (amincissement) artériolaire diffuse et focale
- Artériosclérose des vaisseuauxx (aspect cuivré).
- Tortuosite arteriolare
- Croisement arterio-veineux (signe de Gunn)
- Nodules cotonneux
- Exsudats durs
- Macroanévrisme
- Hémorragie en flammèche
- Oedeme papillaire (Si HTA MALIGNE)

- Atteinte choroiideinne si HTA acceléréé
- chez jeune adulte
- +/- OBCR/OVCR ( complications)

## CLASSIFICATIONS

Plusieurs classificaions: il faut donc préciser la classification utiulisé.

- **Classification keith-Waganer-Barker:** la plus utilise mais dificile de diferencier les stades précoces.

| **Grade 1** | Constriction atériolaire **diffuse**<br>Arteriosclérose minime |
|---|---|
| **Grade 2** | Grade 1 +<br>+ constriction artériolaire **focale**<br>+ artériosclérose moderé-sévère<br>+ **Croisement arterioveineux** |
| **Grade 3** | Grade 2 +<br>+ Hémorragie en flammèche<br>+ nodules cotonneux<br>+ Exsudats durs |
| **Grade 4** | Grade 3 +  + Oedeme papillaire |

- **Classification de Wong-Mitchell.**

| **Minime** | Constriction artériolaire Focale ou diffuse<br>Arteriosclérose - aspect cuivre<br>Croisement artérioveineux<br>---Combinaison de ces signes possible |
|---|---|
| **Modéré** | Hémorragie ( dot et/ou Blot et/ou flammèche)<br>Nodules cottonneux<br>Exsudats durs<br>---Combinaisons de ces signes possible |
| **Malin** | Modéré<br>+Oedeme papillaire<br>+ HTA SéVèRE |
