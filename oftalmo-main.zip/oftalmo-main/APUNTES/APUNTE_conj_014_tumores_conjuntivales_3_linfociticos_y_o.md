---
categoria: apuntes
area: cornea
emoji: 💧
seccion: Conj + Episclere + Sclere
orden_seccion: 25
orden: 14
fuente: OneNote del Dr. Castilla Martí
---
# Tumores Conjuntivales 3.Linfociticos y otros

## 🧠5.3. Linfoma conjuntival

## 🔍Generalidades

- **3er tumor maligno conjuntival más frecuente**, tras melanoma.
- Representa **1,5% de tumores conjuntivales** y el **8% de LNH extranodales**.
- Más frecuente en **adultos de edad media** (~6ª década).
- Deriva del **tejido linfoide asociado a conjuntiva**.
- Habitualmente **linfoma no Hodgkin (LNH) de células B**, mayoritariamente:
  - **MALT (zona marginal extranodal)** (~66%)
  - Folicular
  - Raros: células del manto, difuso de células B grandes (alto grado)

## 🧬Factores de riesgo

- **Estímulo inflamatorio crónico**.
- Inmunodeficiencia (VIH), autoinmunidad.
- Infecciones: *Chlamydia psittaci*, *H. pylori*, VHC (no confirmadas del todo).

## 👁️Clínica

- **Masa salmón**, móvil, subconjuntival, **elevada**, **no vascularizada**, insidiosa.
- Suele estar en **fornix o conjuntiva bulbar**.
- A veces se presenta como **conjuntivitis folicular crónica**.
- Puede ser **bilateral** (20%) y tener **afectación sistémica** (20-30%).

## 🧪Diagnóstico

- **HR-OCT**: masa subepitelial homogénea con epitelio normal.
- **Biopsia imprescindible** (formol + fresco para IHQ, citometría, genética).
- Estudio sistémico completo: **PET**, **TC**, **biopsia de médula ósea**.

## 💊Tratamiento

- **Radioterapia externa** (20-30Gy): elección en lesiones localizadas.
- **IFN o rituximab intralesional**: buena respuesta.
- **Doxiciclina oral**: útil si hay *Chlamydia psittaci* (hasta 60% remisión).
- **Quimioterapia sistémica**: en alto grado o afectación sistémica (rituximab + CHOP, VCP, etc.)

## 📈Pronóstico

- **Excelente**, con supervivencia >90%.
- Riesgo de afectación sistémica tardía → seguimiento semestral 5 años, luego anual.

## 🧠5.4. Otros tumores conjuntivales

## 🔹5.4.1. Granuloma piógeno y hemangioma capilar

- **Granuloma piógeno**: hemangioma reactivo tras trauma o cirugía. Rápido crecimiento. Tratamiento: corticoides tópicos o extirpación.
- **Hemangioma capilar**: sin trauma previo, sin inflamación, aparece en adultos. Exéresis simple o crioterapia.

## 🔹5.4.2. Sarcoma de Kaposi

- **Neoplasia vascular maligna** (asociada a HHV-8), en contexto de **SIDA**.
- Lesión subconjuntival **roja, nodular, vascularizada**, sobre todo en **fornix inferior**.
- Tratamiento:
  - Observación si control inmunológico con TARGA.
  - Cirugía, crioterapia, radioterapia, vinblastina o IFN-α intralesional si progresivo.

## 🔹5.4.3. Coristomas epibulbares

- **Lesión congénita heterotópica**: tejido en localización anómala.
- Tipos:
  - **Dermoide epibulbar**: masa blanquecina sólida en limbo inferotemporal. Puede contener pelo y glándulas.
  - **Dermolipoma**: masa amarilla (tejido adiposo) en cuadrante superotemporal.
- Pueden causar **astigmatismo, ambliopía**. Tratamiento quirúrgico si afectación funcional o cosmética.
- Asociaciones: colobomas, síndrome de Goldenhar, Treacher-Collins, nevus sebáceo lineal.

## 📊Tabla comparativa

| **Tumor** | **Clínica característica** | **Tipo histológico más frecuente** | **Diagnóstico** | **Tratamiento principal** | **Pronóstico** |
|---|---|---|---|---|---|
| **Linfoma conjuntival** | Masa salmón, fornix o bulbar | LNH tipo MALT | Biopsia + HR-OCT + estudio sistémico | Radioterapia externa (20-30 Gy) |  |
| **Granuloma piógeno** | Lesión vascular post-trauma | Hemangioma reactivo | Clínico / biopsia si duda | Corticoide tópico o cirugía | Excelente |
| **Sarcoma de Kaposi** | Masa rojiza nodular vascular, SIDA | Neoplasia vascular (HHV-8) | Clínico, VIH + | Observación o radioterapia / IFN | Variable (mejor con TARGA) |
| **Coristoma epibulbar** | Masa congénita sólida, limbo inferotemporal | Dermoide / dermolipoma | Clínico | Cirugía si funcional o estética | Bueno, no maligniza |
