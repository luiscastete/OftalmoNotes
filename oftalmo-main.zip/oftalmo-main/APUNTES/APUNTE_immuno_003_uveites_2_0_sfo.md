---
categoria: apuntes
area: uveitis
emoji: 🔥
seccion: Immuno-infectio
orden_seccion: 7
orden: 3
fuente: OneNote del Dr. Castilla Martí
fecha: 2024-04-05
---
# Uveites 2.0 - SFO?

Les uveites regriuoent les inflammations intraoculaires de l'uvee – iris, corps ciliare et choroide. Elles peuvent etre isolees au niveau ophtalmologique ou associes a une atteinte systemique. Elles peuvente etre: anterieur, intermediares, posterieures ou atteindre les 3 parties: panuveite.

## STATUS

## AA ++ IMPORTANTE

- Antecedents
- allergies
- Ethnie
- Age
- Voyage pays tropicaux? Quand?
- Mode de vie et lieu de travail
- Historique de la symptomatologie
- Eventuels signes systemique: gastriques, urologiques, neurologiques, rhumatologiques, dermatologiques, ORL, pneumologiques
- Tt actuelle

## SIGNES

- Oiel rouge a type cercle perikeratique
- Douleureux
- BAV
- Larmoiments, photophobie, blepharospasme modere
- Tyndall ou flare proteique en CA- parfois hypopion
- Precipites retro descemetiques ou retrocorneens granulomateux ou non
- Synechies iridocristaliennes- SIC

## Examen ophtalmologique

- AV

- TIO
- Uveites hypertones: herpes, VZV, heterochromie de fuchs, sarcoidose, TBC, syndrome de Posner-Schlossman >40mmHg, toxoplasmose, spondiloarthropathies et artrite juvenile idiopathique- AJI, Behcet, syphilis.

- Si HTIO secondaire a cortis topiques? Corticorespondeur?

- SA:
  - CA:
  - Tyndal cellulaire 1-4 croix et proteique flare 1-4 croix
  - Precipites retrodescemetiques – fig 55:
    - Aspect fin-non granulomateux, Uveite non granulomateuse
    - En graisse de mouton- granulomateux = sarcoidose, TBC, VKH, siphilis...
    - Recherche de hypopion:
      - Unilateral: HLA B27, endophtalmie, lymphome
      - Bilateral: Behcet, sarcoidose

      - Etiologie uveites à hypopion: spondiloarthropathies, AJI, Behcet, leptospirosis, herpes, hemopathies, enfophtalmie.

  - IRIS:
  - recherche de:
    - synechies iridocrsitalliniennes-SIC
    - Atrophie irienne (Iris transilluminable, sectorielle, diffuse evocatrice Herpes)
    - Nodules irienes ( Koeppe et Busacca)
    - Heterochromie irienne de Fuchs

    - Etiologie uveites NON synechiantes: Chorioretinnopathie de birdshot, heterochromie irienne de Fuchs, Posner schlossman, uveites intermediares.
