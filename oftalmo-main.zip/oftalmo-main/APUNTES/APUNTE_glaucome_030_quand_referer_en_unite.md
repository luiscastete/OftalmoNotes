---
categoria: apuntes
area: glaucoma
emoji: 🟢
seccion: Glaucome
orden_seccion: 5
orden: 30
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-03-13
---
# Quand référer en unite

HTIO

Traité stable ( sans signes de glaucome-OCT,CV normal)

Non traitée, à risque faible ( TIO < 25mmHg, pachymetrie normale, AF négative).

Glaucome suspect ( papille, CV)

Syndrome pseudo-exfoliatif ( PEX) ou syndrome de dispersion pigmentaire (SDP) SANS SIGNES DE GLAUCOME ( tio DANS LA NORME, PAPILLE SAINE,, oct + cv NORMAL)

GPAO : stable ( patient qui prend une gtt ou une gtt combinée: Xalacom, Duotrav, Ganfort) avec examens OCT,CV stables.

NOTE:

Tous les patients qui sont traites et qui sont stables doivent être controles 2x année.

Les patients qui sont suspect ou qui ont HTIO non traite à risque faible doivent etre vus chaque 9-12m.
