---
categoria: apuntes
area: neuro
emoji: 🧠
seccion: Neuro-Ophta
orden_seccion: 8
orden: 26
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-08-24
---
# Névrite optique

Inflammation du nerf optiquem d'origine idiopathique ou démyélinisante

Souvent associe à la sclérose en plaques ( SEP)

Age 20-50 ans typique

Femme>homme

## SYMPT

BAV subaigue évoluant sur qqs heures/jours

Douleurs orbitaires et/ou à l'oculomotilite (90%)

Phosphenes (30%)

## SIGNES

Névrite optique rétrobulbaire: sans amélioration visible de la papille (65%)

Névrite optique typique: Papillite (35%)

## STATUS

AV: BAV de degré variable

Test couleurs:

- Test ishihara
- Test désaturation au rouge: Dyschromatopsie
- \*Test àu contratse chez A.Kawasaki?\*\* discussion avec elle, permet vraiment examen NO.

Test pupilles: RAPD de l'eil affecté

CV par confrontation, CV 30°: déficit variable.

Oculomotricité: douleurese

FO dilaté: normal / papillite

OCT: RFNL, RGCL – importante pour le suivi\*

## BILAN ( Supplémentaire)

IRM cérébrale et coupes fines orbitaires avec et san injection de gadolinium et supression de la graisse.

Délai < 1 sem.

Si presentation clinique typique: pas urgence pour une IRM le même.

Evaluation neuro CHUV
