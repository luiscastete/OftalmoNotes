---
categoria: apuntes
area: uveitis
emoji: 🔥
seccion: Immuno-infectio
orden_seccion: 7
orden: 18
fuente: OneNote del Dr. Castilla Martí
fecha: 2024-05-13
---
# Maladie EALES

Entité apparement aux vascularites rétiniennes périphriques idiopatiques. Elle se présnete sous la forme de vascularites occlsuives. Sa physiologie est inconnue.

## EPIDEMIO ET ETIO

Population touchée avant 40 ans

Legere predominance chez les sujets maculins

Affection bilat.

Il n'exist pas d'étiologie clairement identifiée meme si le bacille de Koch est rétrouve chez les patients originaires de zone endemique

## SIGNES

Peut etre decouverte fortuite

Peut etre associe à un tyndall antérieur, voir ehyalite

Survenue de néovvsx préretinnienes à la limite entre territoires perfuses et non perfuses souvent en rétine prééquatoriale. Ces néovvsx peuvent le ssea fan de la drepanocytoses

Reveletaion maladie par complications néovasculaires: homovitrée, tractions rétinines par voiles fibrovasculaires

Absence signes extraoculaires

## DX DD

Souvent rattache TBC sans lie établi

Autres vacularités occlusives dont la cause est connu:drépanocytose, syndrome Susac, Behçet, sarcoidose, toxo, connectivite.

## EX COMPLEMENTAIRES

Angio fluo:

Arret brutal perfusion rétinienne et difussion depuis les neovssx préretinienes.

Parfois ischémies maculaires avec discret élargissement de la ZAC réduisant le pronostic visuelle

ZAC OCT: permet dx de décollement maculaire en cas de doute.

## TT

Laser argon des territoires ischémiques peut suffire

Parfois tt chirugicale est nécessaire en cas tractions Vitreoretinienes ou hémovitrée limitant réalisation laser
