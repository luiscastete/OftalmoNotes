---
categoria: apuntes
area: pediatria
emoji: 👀
seccion: Strabo-logie
orden_seccion: 22
orden: 18
fuente: OneNote del Dr. Castilla Martí
---
# Vocabulario fundamental estrabologia

## 🔹Desviaciones latentes vs. manifiestas

- **Forias (φ, phorias):**
  - **Desviaciones latentes**, es decir, solo se manifiestan cuando se rompe la fusión (por ejemplo, con el test de cover-uncover).
  - En condiciones normales, el sistema fusional las compensa → el paciente no presenta diplopía.
  - Ejemplo: **esoforia**, **exoforia**, **hiperforia**.
- **Tropias (τ, tropias):**
  - **Desviaciones manifiestas**, siempre presentes aunque haya fusión.
  - El paciente puede tener diplopía, supresión o ambliopía como mecanismos de compensación.
  - Ejemplo: **esotropia**, **exotropia**, **hipertropia**, **hipotropia**.

## 🔹Según la dirección de la desviación

- **Horizontales:**
  - **Esotropia / esoforia** → el ojo se desvía hacia adentro.
  - **Exotropia / exoforia** → el ojo se desvía hacia afuera.
- **Verticales:**
  - **Hipertropia / hiperforia** → el ojo está más alto que el contralateral.
  - **Hipotropia / hipoforia** → el ojo está más bajo.
- **Torsionales:**
  - **Ciclotropias / ciclophorias** → rotaciones del ojo sobre su eje anteroposterior.
  - **Exociclotropia** (rotación temporal del polo superior) y **inciclotropia** (rotación nasal del polo superior).
