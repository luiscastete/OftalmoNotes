---
categoria: apuntes
area: cornea
emoji: 👁️
seccion: Cornée
orden_seccion: 4
orden: 26
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-01-30
---
# Ulcère cornénne

Érosion épithelial avec atteinte du stroma cornéen: peut etre infect ou stérile.

SYMPT:

SIGNES:

ETIOLOGIES:

STATUS:

TTT:

SUIVI:
