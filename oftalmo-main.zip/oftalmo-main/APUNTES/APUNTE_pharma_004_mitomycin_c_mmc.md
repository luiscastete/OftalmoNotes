---
categoria: apuntes
area: general
emoji: 💊
seccion: Pharmacologie Farma
orden_seccion: 23
orden: 4
fuente: OneNote del Dr. Castilla Martí
---
# Mitomycin C MMC

La **mitomicina C (MMC)** es un **antibiótico antineoplásico** con **acción antimetabólica**, que se utiliza en oftalmología por su potente capacidad **antifibrótica** y **antiproliferativa**. Aunque originalmente fue aislada del *Streptomyces caespitosus* como agente quimioterapéutico, su uso se ha expandido ampliamente en procedimientos oftálmicos, especialmente para **modular cicatrización** y prevenir fibrosis.

## 🔬

## Mecanismo de acción

- La mitomicina C es un **agente alquilante**: se **activa intracelularmente** y se une de forma covalente al ADN.
- **Forma enlaces cruzados entre hebras de ADN**, impidiendo la **replicación del ADN y la síntesis de ARN/proteínas**.
- Esto **inhibe la proliferación celular**, especialmente en **fibroblastos**, que son clave en la cicatrización excesiva.
