---
categoria: apuntes
area: cornea
emoji: 👁️
seccion: Cornée
orden_seccion: 4
orden: 1
fuente: OneNote del Dr. Castilla Martí
fecha: 2022-09-18
---
# K. infectieuse/Bacterienne

Infiltration stromale avec défet épithélial en regard ( ulcère).

## SYMPT

rougeur, larmoiement, photophobie, douleur (SI DISPROPORTIONEE.. PENSER EN AMIBES).

## SIGNES

infiltrat cornéen avec fluo +.

Autres: si lessions satelites ( penser fongique),

celules CA, Hypopion.

infiltrats radiaux perinerveux ou disciforme ( penser amibes ou herpes),

précipités détrodescemétiques (PRD)

## FACTEURS DE RISK

LDC – gram +  et gram - ( psuedomonas)

LDC souple de longue dure + mauvais hygiene + eau de robinet + trauma avec LDC avec expo eau---  ACANTHAMOEBA

Pathologie surface—cocci gram +, champi.

Trauma--

BILAN:

## -Quand LDC--- TOUJOURS FROTTIS! recomendation Bao.

**-FROTTIS CORNéEN!!!!** ( si critères de gravite, chez porteuse de LDC, si LDC et pseudodendrites: exclure amibienne) : examen direct, culture: bact + fongique, PCR: acanthamoeba, herpes, champis, candida.

- **CRITERES DE GRAVITE:**

- infiltrat grande taille >2mm
- infiltrat sur l'axe optique.
- Infiltration stromale profonde or deep stroma  >50%
- réaction en CA > 1 cell, hypopion.
- Abcès après trauma avec contamination  végétal / terre
- mauvais évolution sous atb instaures
- Signes et apparence anormale/atypiques champis? Acanthamoeba?
- Generaux: Enfant, Immunodepresion, Troubles cognitifs, Non-autonome pour installer gtts.
