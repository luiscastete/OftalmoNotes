---
categoria: apuntes
area: uveitis
emoji: 🔥
seccion: Immuno-infectio
orden_seccion: 7
orden: 17
fuente: OneNote del Dr. Castilla Martí
---
# PANUVEÍTIS

| **Entidad** | **Tipo de uveítis** | **Hallazgos específicos** | **Diagnóstico imagen** | **Asociación sistémica** | **Tratamiento** |
|---|---|---|---|---|---|
| **Vogt-Koyanagi-Harada (VKH)** | Panuveítis granulomatosa bilateral | DR serosos, nódulos de Dalen-Fuchs, sunset glow, vitiligo, tinnitus | AFG cielo estrellado, AVI hipocianescencias, OCT DR serosos | Auditiva, cutánea (vitiligo, poliosis), neurológica | Corticoides sistémicos + inmunosupresores |
| **Oftalmía simpática** | Panuveítis granulomatosa bilateral | DR serosos, nódulos de Dalen-Fuchs, antecedente traumático previo | Igual que VKH, pero con antecedente traumático | Ninguna específica (excepto trauma) | Corticoides sistémicos + inmunosupresores |
| **Sarcoidosis ocular** | Uveítis anterior/posterior/panuveítis granulomatosa | Nódulos en iris (de Busacca), granulomas perivasculares, sarcoides pulmonares | Granulomas coroideos en OCT/AFG, hallazgos torácicos | Pulmonar, cutánea, ganglionar | Corticoides + inmunosupresores (metotrexato) |
| **Sífilis ocular** | Uveítis anterior/posterior variable | Infiltrados retinianos, vasculitis, lesiones discoides, VDRL+/FTA-Abs+ | Serologías, lesiones retinianas, PCR de humor acuoso | Sífilis secundaria/terciaria, neurosífilis | Antibióticos (penicilina G), corticoides si necesario |
| **Tuberculosis ocular** | Panuveítis granulomatosa | Tubérculos coroideos, vasculitis, afectación sistémica pulmonar | AFG, PCR de humor acuoso, imágenes pulmonares | TB activa pulmonar o latente | Antituberculosos + corticoides |

5. PANUVEÍTIS

Las panuveítis implican la inflamación simultánea de todos los compartimentos anatómicos del ojo (segmento anterior, vítreo y retina o coroides) sin predominio de ninguno de ellos como foco inflamatorio original. Es común que existan complicaciones estructurales. Generalmente los cuadros son bilaterales, aunque el grado de afectación y el tiempo de presentación pueden ser asimétricos. Se tratarán las panuveítis de causa inmune a continuación.

Existen 4 grandes enfermedades:

1-Sarcoidosis

2-Sindrome de Vogt-Koyanagi-Harda - VKH

3-Oftalmia simpatica

4-Enfermdad de Behçet
