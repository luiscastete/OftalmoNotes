---
categoria: apuntes
area: cornea
emoji: 👁️
seccion: Cornée
orden_seccion: 4
orden: 14
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-01-30
---
# K. herpetiques

## KERATITE EPITHELIAL

## SIGNES

Lesions dendritiques

Ulcere geographique fluo + ( grave + HC ++ ABCèS)

Diminution sensibilite cornéenne

## TTT

- **PHASE ACTIVE:**

- TOPIQUE: Acyclovir pommade 5xj pdt 7J puis 3xj pdt 7j ( quand c'est clairement épithélial ) +/-

- PER OS: Valacyclovir ( valtrex ) 500 / 1000mg 3xj 7j ( quand il y a uveite normalment) puis 500mg 3xj pdt 7j

- Tobrex ou Floxal gtt 4-6xj pdt 7j + cyclopegie si douleur

- Attention car ACIVISION est toxique pour cornée fonctione bien pdt 2 sem et apres trop toxique

- Donc si mauvaise evolution
- Diminution acivision add valtrex therapeutique
- Rdv dans 3 j

- **JAMAIS CORTIS dans cette phase**

- SUIVI: 3-5j

- **PHASE CICATRICIELLE**

- Si BAV sur opacite centrale: DX 3xj avec schéma degressif DX 3xj pdt 10j, DX 2xj pdt 10j, DX 1xj pdt 10j.
- SUIVI TIO dans 10-15j
- PC dans 1-2 mois

- \*\*Filipo aime bien mantenir le valtrex 500mg 3xj avec le DX si encore infiltrat stromale quand fluo – pour nous proteger si repousse.

- **TT PREVENTIF\*\*\***

- Valaciclovir 500mg 2xj ou aciclovir 800mg 2xj dans les cas suivantes:
  - Kératite épithélial apres 3 récurrences par an
  - Kératite profondes apres 2 recurrences par an
  - En cas de chirurgie de l'oeil
