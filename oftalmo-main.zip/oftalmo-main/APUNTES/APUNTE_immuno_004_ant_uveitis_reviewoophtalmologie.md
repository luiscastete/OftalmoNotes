---
categoria: apuntes
area: uveitis
emoji: 🔥
seccion: Immuno-infectio
orden_seccion: 7
orden: 4
fuente: OneNote del Dr. Castilla Martí
---
# Ant. Uveitis - ReviewOOphtalmologie

ANTERIOR UVEITIS

Inflammation of iris (iritis) + ciliary body (cyclitis); exsudation of white blood cells and protein into AC secondary to breakdown of the blood-aqueous barrier and increased vascular permeability, may have minimal spill-over into retrolental space.

Most common cause of ant uveitis in adults is idiopathic (50%) followed by HLA-B27 asocicted uveitis, must rule out: infection, malignancy, medication or trauma.

Most common cause of acute, noninfectius hypopion iritis is HLA B27 associated iritis.

## ETIOLOGY

- **CHILDREN:**

- **YOUNG ADULTS:**

- **OLDER ADULTS:**
