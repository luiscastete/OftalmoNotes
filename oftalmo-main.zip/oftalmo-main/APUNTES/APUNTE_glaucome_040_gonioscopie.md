---
categoria: apuntes
area: glaucoma
emoji: 🟢
seccion: Glaucome
orden_seccion: 5
orden: 40
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-03-11
---
# Gonioscopie

Ecxamen de l'angle-irido-cornéen

Commencer angle inf: normalment angle plus ouvert

## INDICATIONS

## MATERIEL

## PROCEDURE

## 👁️1. ¿Qué estructuras vemos en la gonioscopía y en qué orden?

Desde **anterior a posterior**, en un ángulo **completamente abierto**, las estructuras del ángulo iridocorneal se observan en este orden:

| **Orden** | **Estructura** | **Descripción** |
|---|---|---|
| 1️⃣ | **Línea de Schwalbe** | Reflejo brillante o línea blanca → representa la terminación de la membrana de Descemet |
| 2️⃣ | **Malla trabecular** | Área gris/marrón → drenaje del humor acuoso (zona pigmentada = más posterior = funcional) |
| 3️⃣ | **Espolón escleral** | Línea blanca gruesa → marca la inserción del músculo longitudinal del cuerpo ciliar |
| 4️⃣ | **Banda ciliar** | Área oscura, más profunda → raíz del cuerpo ciliar (no siempre visible) |
|  |  |  |
