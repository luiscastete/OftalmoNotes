---
categoria: apuntes
area: retina-quirurgica
emoji: 🪡
seccion: Ret Chirg
orden_seccion: 6
orden: 6
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-01-31
---
# DR

Separation de la neuro.rétine de l'épithelium pigmentaire.

## SYMPT

phosphenes, myodesopsies, amputation CV, BAV.

## SIGNES

Possibles: cellules pigmentées dans vitré anterieur ( tobaco dust )

Hématovitré,

vitreoretinopathie proliferante.

RAPD (en cas DR très étendu)

- DR rhegmatogène: retine très mobile avec mouvements de l'oeil, forme convexe.
- DR tractionnel: moins mobile avec mouvements, concave, souvent 2ar à une membrane.
- DR séreux: fluid sous-rétinien pouvant changer de position en fonction de la position du patient.

## ETIOLOGIES

Rhegmatogene

Tractionel

Séreux

## DD

Rétinoschisis: aspect convexe ou kystique, généralment chez le patient. Hypermetrope, loalise en région temporale-inf, souvent bilaterale, peu mobile, aspect d'une ligen de demarcartion. Disctiontion claire à OCT.

Hyaloide anterieur proéminente: absence de la vascularuisation rétinniene en surface.

## STATUS

AV: 1.0 si macula ON

TIO diminué en generale ( sauf si syndrome de Schjwartz-Matsuo)

CV par confrontation ou automatise

FO dilate: V3M/Retina180/supersquad, ophtalmoscope indirecte avec indentation
