---
categoria: apuntes
area: uveitis
emoji: 🔥
seccion: Immuno-infectio
orden_seccion: 7
orden: 27
fuente: OneNote del Dr. Castilla Martí
---
# Tipos Hipersensibilidad

## 🧪

## Tipo I – Hipersensibilidad inmediata (anafiláctica)

- **Mecanismo**: Mediada por **IgE** unida a mastocitos y basófilos → liberación de histamina y otros mediadores.
- **Ejemplos**: Anafilaxia, asma alérgica, conjuntivitis alérgica, urticaria.

## 🧬

## Tipo II – Hipersensibilidad citotóxica

- **Mecanismo**: Mediada por **IgG o IgM** dirigidas contra antígenos celulares → activación del complemento o citotoxicidad.
- **Ejemplos**: Anemia hemolítica autoinmune, enfermedad de Graves, rechazo hiperagudo de trasplantes.

## 🧫

## Tipo III – Hipersensibilidad por inmunocomplejos

- **Mecanismo**: Formación de **complejos antígeno-anticuerpo** que se depositan en tejidos → inflamación por activación del complemento.
- **Ejemplos**: Lupus eritematoso sistémico, artritis reumatoide, vasculitis, reacción del suero.
