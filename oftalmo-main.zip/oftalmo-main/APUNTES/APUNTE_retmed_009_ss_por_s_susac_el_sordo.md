---
categoria: apuntes
area: retina-medica
emoji: 🩸
seccion: Ret Med y coroides
orden_seccion: 19
orden: 9
fuente: OneNote del Dr. Castilla Martí
---
# SS por S.Susac "el Sordo"

OACR + SORDERA NEUROSENSORIAL Y ENCEPHALOPATIA
