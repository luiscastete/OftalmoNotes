---
categoria: apuntes
area: retina-quirurgica
emoji: 🪡
seccion: Ret Chirg
orden_seccion: 6
orden: 18
fuente: OneNote del Dr. Castilla Martí
---
# LESIONES PREDISPONENTES DE DESPRENDIMIENTO DE RETINA (DR)

## LESIONES PREDISPONENTES DE DESPRENDIMIENTO DE RETINA (DR)

## 🧬CLASIFICACIÓN según capa retiniana predominante afectada

| **Tipo de degeneración** | **Capa afectada** | **Riesgo de DR** | **Ejemplos** |
|---|---|---|---|
| **Degeneraciones de retina externa** | Fotorreceptores y EPR | Bajo | Degeneración pavimentosa (“empedrado”) |
| **Degeneraciones intrarretinianas** | Capas medias retinianas | Bajo | Raras veces conllevan DR |
| **Degeneraciones de interfase vítreo-retiniana** | Retina interna e interfaz | **Alto** | Degeneración lattice, baba de caracol |

## 🔬LESIONES CLAVE

## 1.Degeneración en empedrado (pavimentosa)

- Afecta **capas externas**.
- Apariencia blanquecina.
- **No asociada a riesgo elevado de DR**.

## 2.Degeneración en baba de caracol

- Afecta la **interfase vítreo-retiniana**.
- Puede generar **tracción vítreo-retiniana**, por tanto, **mayor riesgo de DR**.

## 3.Degeneración en empalizada (lattice)

- **Más importante** clínicamente.
- *La degeneración Lattice y los desprendimientos de retina regmatógenos se localizan con más frecuencia en la zona superior*
- *de la retina periférica.*
- Adelgazamientos retinianos **ovalados o circulares**, disposición **circunferencial**.
- Asocia:
  - **Licuefacción vítrea** adyacente.
  - **Adhesión vítrea** fuerte en los bordes → mayor riesgo de desgarro.
- **Riesgo de DR: 10–20%**.
- Aunque **no hay evidencia definitiva** de que el láser profiláctico evite el DR, se **suele aplicar fotocoagulación láser** en casos de:
  - Degeneración lattice extensa.
  - Ojo contralateral con DR.

6. DIAGNÓSTICO DIFERENCIAL DEL DR. RETINOSQUISIS SENIL

La retinosquisis senil es la única degeneración periférica de la retina que afecta a las capas medias de la retina. Es más frecuente en mujeres hipermétropes y es bilateral en el 50% de los casos8. Afecta a los cuadrantes temporales e inferiores y es generalmente asintomática, pero puede progresar hacia el polo posterior si se combina la presencia de un agujero de la pared interna con otro de la pared externa de la bolsa; en cualquier caso, este riesgo es muy bajo, de alrededor del 0,07%. Figura 3.

## 📌CONCEPTO CLAVE EBO (EBO KEY)

🔑 **Degeneración lattice** = **mayor riesgo de DR** → frecuente **láser profiláctico** en pacientes con antecedentes de DR en ojo adelfo.
