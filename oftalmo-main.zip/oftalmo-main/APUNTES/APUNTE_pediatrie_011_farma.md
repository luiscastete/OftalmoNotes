---
categoria: apuntes
area: pediatria
emoji: 🧸
seccion: Pediatrie
orden_seccion: 9
orden: 11
fuente: OneNote del Dr. Castilla Martí
fecha: 2024-04-15
---
# Farma

Protocole dilatation:

-Chez le nourrison et l'enfant: tropicamide à 2-3 reprises dans le 30 mis qui precedent l'examen. En cas de dilattaion insuffisante – enfants melanodermes nottament – possibilite de ajouter un gtt d'atropine- 0'3% jusq 2 ans 0,5% audela.

Chez premature: tropicamide + néosynephrine 2,5%- preparation hospitaliere: 1gtt 30 mins puis une autre 15 min avant l'examen.
