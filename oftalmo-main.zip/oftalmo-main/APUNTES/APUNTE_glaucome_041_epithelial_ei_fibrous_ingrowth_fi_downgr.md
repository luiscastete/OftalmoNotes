---
categoria: apuntes
area: glaucoma
emoji: 🟢
seccion: Glaucome
orden_seccion: 5
orden: 41
fuente: OneNote del Dr. Castilla Martí
---
# Epithelial (EI) - Fibrous ingrowth (FI) /downgrowth

## 📑Epithelial vs Fibrous Ingrowth – Resumen EBO

## 🔬Definición

- **Epithelial ingrowth:** proliferación de células epiteliales dentro de la cámara anterior a través de heridas quirúrgicas/corneales.
- **Fibrous ingrowth:** proliferación de tejido fibroso (fibroblastos y colágeno) en heridas quirúrgicas o incisiones oculares.

## 👁️Hallazgos clínicos

- **Epithelial:** lámina plana, brillante, transparente; puede invadir ángulo → glaucoma secundario.
- **Fibrous:** masa blanquecina, densa, cicatricial; más localizada y estática.

## 🧪Diferenciación diagnóstica

- **Biomicroscopía:**
  - Epithelial → aspecto liso, vidrioso.
  - Fibrous → opaco, elevado.
- **OCT segmento anterior / UBM:** delimita extensión y densidad.
- **Test con láser Nd:YAG/argón:**
  - **Epithelial ingrowth → blanquea (burbuja blanca)** por liberación de gas celular.
  - **Fibrous ingrowth → no blanquea**, no hay cambio visible.
