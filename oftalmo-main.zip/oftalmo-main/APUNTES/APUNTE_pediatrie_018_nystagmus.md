---
categoria: apuntes
area: pediatria
emoji: 🧸
seccion: Pediatrie
orden_seccion: 9
orden: 18
fuente: OneNote del Dr. Castilla Martí
---
# Nystagmus

DORSAL MIDBRAIN SYNDROME - PARINAUD SYNDROME

- Signes:
  - Paralysis of upgaze
  - Defective voluntray convergence
  - Pupillary light-near dissociation
  - Convernegce-retrcation nystagmus
  - Eyelid retraction -

  - Monst common cause of dorsal midbrain syndrome are pinealoma and congenital aqueductal stenosis.
  - In women by multiple esclerosis.
  - In elderly is midbrain stroke.

- DOWNBEAT NYSTAGMUS
  - Most often caused by an Arnild-Chiari malformation.
