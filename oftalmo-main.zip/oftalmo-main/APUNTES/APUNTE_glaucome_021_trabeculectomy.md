---
categoria: apuntes
area: glaucoma
emoji: 🟢
seccion: Glaucome
orden_seccion: 5
orden: 21
fuente: OneNote del Dr. Castilla Martí
---
# Trabeculectomy

## 📑Trabeculectomy – Notas EBO

## 🔬Definición

- Cirugía de glaucoma que consiste en crear una **fístula entre la cámara anterior y el espacio subconjuntival** para permitir la salida del humor acuoso.
- Forma un **bleb de filtración** (ampolla subconjuntival).
- Objetivo: **disminuir la PIO** para prevenir progresión glaucomatosa.

## 📊Técnica básica

- Incisión conjuntival (fornix o limbus-based).
- Colgajo escleral parcial (rectangular/triangular).
- Exéresis de un bloque de tejido en el ángulo (trabeculectomía “-ectomía” = resección).
- Iridectomía periférica.
- Cierre parcial del colgajo escleral → salida controlada del humor acuoso.
- Cierre conjuntival.

💊 Se suele usar **antimetabolitos** (MMC, 5-FU) para reducir cicatrización.

## 👁️Indicaciones

- Glaucoma de ángulo abierto o cerrado cuando tratamiento médico/láser insuficiente.
- Glaucomas secundarios refractarios (ej. pseudoexfoliativo, pigmentario, inflamatorio).
