---
categoria: apuntes
area: neuro
emoji: 🧠
seccion: Neuro-Ophta
orden_seccion: 8
orden: 3
fuente: OneNote del Dr. Castilla Martí
---
# Neurofibromateuse NF 1

Liens:

cdo212\_CV\_P001\_P003-V2:cdo (cahiers-ophtalmologie.fr)

## MANIFESTATIONS OPTHA NF1

-Neurofibrome plexiforme d ela paupiere sup.

-La dysplasie du sphenoide --responsable –dystopie orbitaire +/- exopthalmie

-l'ectropion du feuillet post de l'iris

-Le glaucome congénital ou infantil

-La buphtalmie sans glaucome

-Anomalies vasculaires rétinnienes

-Tâches hyperréflectives sur clichés en infrarouge--tâches de Yasunari

-Gliomes des voies visuelles

-Hypertension intracraniene

## SUIVI OPTHA

- AV + TIO
- CV par confrontation si doute cinetique
- Pupillles, RAPD
- FO
- OCT mac, RFNL, CL et infrarouge
- +/- photo iris si possible
