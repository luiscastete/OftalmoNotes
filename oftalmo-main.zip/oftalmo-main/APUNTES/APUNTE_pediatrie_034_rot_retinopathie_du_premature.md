---
categoria: apuntes
area: pediatria
emoji: 🧸
seccion: Pediatrie
orden_seccion: 9
orden: 34
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-08-24
---
# ROT-Rétinopathie du prématuré

ROP affecte les nouveau-nes prematures hypotrophes a la naissance.

Les manifestation systemiques conferent un risque suplemmentaire: anemie, septicemie et concentration plasmatique baisse en vit E.

La cause exacte de la ROP n'est pas claire, mais une exposition precoce a des concentrations eleves de Oxygene ambiant semble un FR majeur. Auj mieux miatrises.

Dans la phase precose du developpement de la ROP la croissance des vssx est retarde par l'hyperoxie, mais par la suite l'hypoxie retinienne favorise une vascularisation anormale. La retine n'a pas de vssx sanguins jusq 4eme-32 sem mois de gestation, puis les complexes vasculaires se developpent des vssx hyaloides de la papille vers la peripherie. La retine nasale est entierement vascularise apres 8 mois de gestatation, la peripherie temporale dans le mois qui suit l'accouchement. Le facteur de croissance endothelial vasculaire –VEGF joue probablement un role important dans le processus de vascularisation. Dans les pays en developpement l'incidence de la ROP augmente ces derniers annes, en lien avec l'amelioration des therapeutiques intensives en neonatologie.

## A RETENIR

**Bebes nes avant 32 sem ou pesant moins de 1500g doivent etre despistes pour ROP.**

## Examen FO avec Casque + associant eventuelle depression sclerale. +++

## ROP ACTIVE

- **SIEGE DE L'ATTEINTE**

- Des zones concentriques centres sur la papille son decrites:

- ZONE I- cercle imaginaire dont rayon double entre distance papille et centre macula.

- ZONE II-s'extend concentrique a partir du bord zone I avec rayon qui s'entend du papille a l'ora serrata nasale.

- ZONE III- constitue d'un croissant temporale residuek ant a zone III

- **SEVERITE**

- Cette classif correspond a la severite de la reponse vasculaire anormale a la jonction de la retine peripherique avasculaire immature et posterieur vascularise. La severite de la atteinte oculaire dans son ensemble est donnee par la manifestation la plus grave.

- **Stade 1: LIGNE DE DEMARCATION**

- **Stade 2: CRETE**

- **Stade 3: Proliferation fibrovasculaire preretinniene**

- **Stade 4: DECOLLEMENT PARTIELLE DE LA RETINE.**
- **4a: DR extramaculaire**
- **4b: Maculaire**

- **Stade 5: DR TOTAL**

- **Stade plus ou + : FR de progression et se caracterise par:**
  - **Dilatation et une tortuosite des vssx sanguins au niveau de 2/4 de FO.**
  - **Echece dilatation pupillaire**
  - **Hyalite**
