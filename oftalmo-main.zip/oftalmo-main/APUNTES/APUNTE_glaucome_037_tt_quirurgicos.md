---
categoria: apuntes
area: glaucoma
emoji: 🟢
seccion: Glaucome
orden_seccion: 5
orden: 37
fuente: OneNote del Dr. Castilla Martí
---
# Tt quirurgicos

## 💉Tratamientos Quirúrgicos en el Manejo del Glaucoma

Este documento resume en formato clínico y práctico todas las técnicas quirúrgicas utilizadas para el tratamiento del glaucoma, con estructura tipo pregunta-respuesta, y priorizando la utilidad real en consulta.

---

❓ ¿Cómo se clasifican las cirugías para el glaucoma?

Las cirugías incisionales se dividen en dos grandes grupos:

🔷 A. Cirugías Penetrantes

- Atraviesan completamente la esclera y comunican la cámara anterior con el espacio subconjuntival.

- Ejemplos: \*\*Trabeculectomía\*\*, \*\*implantes de drenaje (válvulas)\*\*

🟢 B. Cirugías No Penetrantes

- No acceden a la cámara anterior de forma directa.

- Ejemplos: \*\*Esclerectomía profunda no perforante (EPNP)\*\*, \*\*Viscocanalostomía\*\*

---

❓ ¿Qué es la trabeculectomía y cómo funciona?

🧬 Principio:

Crear una fístula que permita que el humor acuoso salga de la cámara anterior hacia el espacio subconjuntival, donde se forma una \*\*ampolla filtrante\*\*.

⚙️ Técnica:

1. Disección conjuntival y colgajo escleral superficial

2. Escisión parcial del trabéculo

3. Iridectomía periférica
