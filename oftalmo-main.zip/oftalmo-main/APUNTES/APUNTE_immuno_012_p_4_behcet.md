---
categoria: apuntes
area: uveitis
emoji: 🔥
seccion: Immuno-infectio
orden_seccion: 7
orden: 12
fuente: OneNote del Dr. Castilla Martí
fecha: 2024-05-13
---
# P.4 -Behçet

Maladie de Behçet est une maladie de systeme inflammatoire chronique récidivante, d'étiologie inconnue. Elle est caract par inflam intraoculaire + des ulcerations des muqueuses buccale et genitale + lesions cutanées.

## EPIDEMIOLOGIE

MB touche plus freq patients du pourtour méditerranéen et du Japon – l'ancienne route de la soie.

L'atteinte oculaire survient chez environ 70% des patients atteintes MB. Elle est bilaterale dans le plus de 70% des cas.  L'atteinte posterieur/panuveite est la forme plus freq des uveites chez ses patients.

L'atteinte phtalmologique peut etre le signe inaugurale de la MB dans 10-35% des cas- caract par inflamm intraoculaire récurrente entrecoupée par poussées inflammatoires aigues.

Classiquement touché l'adulte jeune 25-35 ans mais peut survenr chez l'enfant. Preponderance masculine.

Maladie multifactorielle. Connue pour avoir une prédisposition génétique, elle est associée au HLA-B51.

## SIGNES OCULAIRES

Le patient peut presenter une BAV, oeil rouge, des corps flottants de façon uni-bilaterale.

Les ppal atteintes ophtalmologiques sont:

- uveite anterieurs avec hypopion
- Nécrose rétinniene
- Vasculies rétinnienes
- Hémorragies et oedeme rétiniens
- Hyalite, hémorragie intravitrenné, oclsuion capillaire et neovascularisation retinnene.

Les manifestations rares oculaires comprennent: phtes conjonctivaux, épisclérite, kératite filamenteuse, conjonctivite et paralysie oculomotrice secondaire à neuro-MB.

## Entre les épisodes inflammatoires, l'examen ophta peut etre normal.
