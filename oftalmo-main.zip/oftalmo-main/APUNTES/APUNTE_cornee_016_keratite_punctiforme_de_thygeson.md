---
categoria: apuntes
area: cornea
emoji: 👁️
seccion: Cornée
orden_seccion: 4
orden: 16
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-10-02
---
# Kératite punctiforme de Thygeson

Thygeson Superficial Punctate Keratitis - EyeWiki
