---
categoria: apuntes
area: catarata
emoji: 🔍
seccion: Cristallin - Lens
orden_seccion: 21
orden: 10
fuente: OneNote del Dr. Castilla Martí
---
# 🟡 Capsular Block syndrom

## 🟡CAPSULAR BLOCK SYNDROME (CBS)

## 🔹¿Qué es?

Complicación en cirugía de catarata debida a **acumulación de fluido en el saco capsular**, causando **distensión** y aumento súbito de presión.

## 🔹

## Tipos

- **Intraoperatorio (agudo):** durante hidrodissección
- **Postoperatorio (tardío):** fluido retenido detrás del LIO

## 🔹

## Signos intraoperatorios

- Prolapso del iris
- Cámara anterior estrecha
- Ojo muy duro
- Núcleo no rota
- Riesgo de rotura de cápsula posterior

## 🔹

## Factores de riesgo

- **Capsulorrexis pequeña**
- **Núcleo duro**
- Hidrodissección sin vía de escape
- Tensión zonular o cristalino voluminoso
