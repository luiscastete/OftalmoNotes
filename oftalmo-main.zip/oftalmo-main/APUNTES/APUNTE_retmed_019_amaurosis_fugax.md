---
categoria: apuntes
area: retina-medica
emoji: 🩸
seccion: Ret Med y coroides
orden_seccion: 19
orden: 19
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-08-09
---
# Amaurosis fugax

## Description

Amaurosis fugax (AF) refers to transient vision loss (TVL).

AF can either be monocular (TMVL) or binocular (TBVL). It most commonly occurs monocularly, secondary to ischemia in the retina, choroid, or optic nerve. The most common cause of TMVL is: an ipsilateral carotid artery disease (e.g., internal carotid artery dissection or atherosclerosis) with secondary thromboemboli, but it can also be a symptom of vasculitis (e.g., giant cell arteritis).

AF can be a harbringer of impending stroke and thus merits urgent evaluation. TBVL is less common than TMVL and may be due to cortical lesions (e.g. migraine, seizure, or vertebrobasilar ischemia).[2]

AF caused by ischemia is considered a form of transient ischemic attack (TIA) and usually lasts from seconds to minutes, followed by full visual recovery.[1] AF should be differentiated from structural optic disc and intraocular causes of TMVL (e.g., impending central retinal vein occlusion, optic disc drusen, or papilledema).

## Symptoms

Patients usually report negative visual symptoms, typically lasting from seconds to minutes; however, longer episodes have been reported, and positive visual symptoms (though more rare) do not rule out an ischemic etiology.[3] Transient visual loss precipitated by gaze (i.e., gaze evoked AF) may suggest an orbital lesion.

## STATUS

A complete ophthalmologic exam is mandatory (e.g., Hollenhorst plaque: , angle closure glaucoma). Additionally, special attention should be given to the temporal artery region, examining for tenderness or erosions. A complete cardiovascular exam may also be performed with an emphasis on the presence of arrhythmias or a carotid bruit.

## Most patients with AF, however, have normal eye exams.
