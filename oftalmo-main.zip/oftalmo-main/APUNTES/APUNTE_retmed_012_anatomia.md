---
categoria: apuntes
area: retina-medica
emoji: 🩸
seccion: Ret Med y coroides
orden_seccion: 19
orden: 12
fuente: OneNote del Dr. Castilla Martí
---
# Anatomia

Vamos a abordarlo con claridad quirúrgica, clínica y fisiológica.

## 🔷ORIENTACIÓN GENERAL DE LA RETINA

En histología y en OCT, la retina se describe de **afuera hacia adentro** respecto al **globo ocular**:

- **Capas externas** = **más cerca de la coroides/RPE**
- **Capas internas** = **más cerca del vítreo**

## 📚LAS 10 CAPAS DE LA RETINA (deexterna a interna)

| **Nº** | **Nombre de la capa** | **Función principal** | **Localización en OCT** |
|---|---|---|---|
| 1 | **Epitelio pigmentario retinal (RPE)** | Soporte metabólico, fagocitosis de fotopigmentos | Línea densa hiperreflectiva externa |
| 2 | **Capa de fotorreceptores (segmentos externos)** | Captación de luz | Hipo-hiperreflectiva entre EPR y IS/OS |
| 3 | **Membrana limitante externa (ELM)** | Unión estructural entre células de Müller y fotorreceptores | Línea fina |
| 4 | **Capa nuclear externa (ONL)** | Núcleos de conos y bastones | Hipo-eco |
| 5 | **Capa plexiforme externa (OPL)** | Sinapsis entre fotorreceptores y bipolares | Intermedia |
| 6 | **Capa nuclear interna (INL)** | Núcleos de bipolares, amacrinas, horizontales | Hipo-eco gruesa |
| 7 | **Capa plexiforme interna (IPL)** | Sinapsis con ganglionares | Eco intermedia |
| 8 | **Capa de células ganglionares (GCL)** | Procesamiento visual, vía a nervio óptico | Visible en mácula como banda fina |
| 9 | **Capa de fibras del nervio óptico (NFL)** | Axones → nervio óptico | Hiperreflectiva, prominente cerca del disco |
| 10 | **Membrana limitante interna (ILM)** | Límite frente al vítreo | Línea más interna |
