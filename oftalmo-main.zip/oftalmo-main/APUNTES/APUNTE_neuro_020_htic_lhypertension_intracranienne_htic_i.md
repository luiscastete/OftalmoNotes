---
categoria: apuntes
area: neuro
emoji: 🧠
seccion: Neuro-Ophta
orden_seccion: 8
orden: 20
fuente: OneNote del Dr. Castilla Martí
---
# HTIC-L’hypertension intracrânienne (HTIC) idiopathique

Résumé

https://doi.org/10.1016/j.praneu.2013.12.007

L’hypertension intracrânienne idiopathique se développe sur le terrain particulier des patientes jeunes en surcharge pondérale et se manifeste par des céphalées et un œdème papillaire. Les causes sont multiples et leurs mécanismes restent inconnus. Ils conduisent à un dérèglement de l’équilibre entre la pression intracrânienne, la compression des sinus veineux intracrâniens et la résorption du liquide cérébrospinal, en un cercle vicieux que la dérivation du LCS ou le stenting d’un sinus latéral peut interrompre. Dans la majorité des cas, le traitement médical et la réduction pondérale réussissent à contrôler l’évolution qui reste bénigne.

Le terme d’idiopathique a remplacé de nos jours celui de bénin en raison de l’existence dans certains cas de problèmes visuels sévères. Depuis quelques années, l’attention est attirée sur deux points :

Section snippets
