---
categoria: apuntes
area: pediatria
emoji: 👀
seccion: Strabo-logie
orden_seccion: 22
orden: 7
fuente: OneNote del Dr. Castilla Martí
---
# Hypermetropie enfante

Enfante 6 ans avec cephalées et faticge visuelle

Faire cyclo

Et diminuer 0.5 de sfere – normalment tu met pas tout car posibllemnete surcorrigée - ne tolerara

Add OCT mac et NO ( CAR CEPHALEE)

Add PC dans 2-3 mois
