---
categoria: apuntes
area: pediatria
emoji: 🧸
seccion: Pediatrie
orden_seccion: 9
orden: 4
fuente: OneNote del Dr. Castilla Martí
---
# Miyosmart – indications

MiYOSMART – Indicaciones prácticas (IMI)

Candidato ideal

✅ Miopía en progresión documentada:

Edad

## Evidencia fuerte

## 18–25 años

Graduación

Indicado en:

La magnitud de la miopía **no contraindica** el tratamiento.

Antes de indicar

✓ Refracción ciclopléjica (niños cuando esté indicada).

✓ Historia de progresión.

✓ Longitud axial si es posible.
