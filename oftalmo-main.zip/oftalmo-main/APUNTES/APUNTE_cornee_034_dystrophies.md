---
categoria: apuntes
area: cornea
emoji: 👁️
seccion: Cornée
orden_seccion: 4
orden: 34
fuente: OneNote del Dr. Castilla Martí
---
# Dystrophies

1 - ✓ Distrofias Epiteliales y Subepiteliales:

- ■ Distrofias de la membrana basal del epitelial (EBMD). En mapa-punto-huella dactilar o distrofia microquística de Cogan.
- ■ Distrofia con erosión epitelial recurrente (ERED).
- ■ Distrofia corneal subepitelial mucinosa (SMCD).
- ■ Distrofia corneal de Meesmann (MECD).
- ■ Distrofia corneal epitelial de Lisch (LECD).
- ■ Distrofia corneal gelatinosa en gotas (GDLD).

2 - ✓ Distrofias de la Capa de Bowman:

- ■ Distrofia corneal de Reis–Bücklers (RBCD).
- ■ Distrofia corneal de Thiel–Behnke (TBCD).

3 - ✓ Distrofias Estromales:

- ■ Distrofias corneales TGFBI:

- Distrofia corneal lattice:

  - ♦ Distrofia corneal lattice, tipo TGFBI (LCD):
    - Distrofia corneal lattice clásica (LCD1) variantes
  - ♦ Distrofia corneal lattice de tipo gelsolin (LCD2).

- Distrofia corneal granular.
  - ♦ Distrofia corneal granular, tipo 1 (clásica) (GCD1).
  - ♦ Distrofia corneal granular, tipo 2 (granular-lattice (GCD2) **(Avellino).**

- ■ Distrofia corneal macular (MCD).
- ■ Distrofia corneal de Schnyder (SCD).
- ■ Distrofia corneal estromal congénita (CSCD).
- ■ Distrofia corneal moteada (FCD).
- ■ Distrofia corneal posterior amorfa (PACD).
- ■ Distrofia corneal central nubosa de François (CCDF).

- ■ Distrofia corneal pre Descemet (PDCD).

4 - ✓ Distrofias de la Membrana de Descemet y Endotelio:

- ■ Distrofia corneal endotelial de Fuchs (FECD).
- ■ Distrofia corneal posterior polimorfa (PPCD).
- ■ Distrofia corneal endotelial congénita hereditaria 1 (CHED1).
- ■ Distrofia corneal endotelial congénita hereditaria 2 (CHED2).
- ■ Distrofia corneal endotelial ligada a X (XECD).

## 👁️Corneal Dystrophies – Epithelial Subtypes

## ✅Definición general

• Grupo de **trastornos bilaterales, progresivos y primarios** de la córnea.

• Afectan **una capa específica** (epitelio, Bowman, estroma, Descemet o endotelio).

• Muchos son de origen **genético** (autosómicos dominantes o recesivos).

• Asociados a **opacidad corneal, molestias o pérdida visual** (según el tipo).

📌 **Regla general**: afectan una sola capa, son lentamente progresivas y bilaterales.

## 🧬Clasificación según la capa afectada

| **Capa afectada** | **Ejemplos principales** |
|---|---|
| **Epitelio** | Distrofia de Cogan, Meesmann |
| **Membrana de Bowman** | Reis–Bücklers, Thiel–Behnke |
| **Estroma** | Granular, Lattice, Macular |
| **Membrana de Descemet / Endotelio** | Fuchs, CHED |
|  |  |

## 🔬Epithelial Dystrophies

- **🌐1. Cogan (epithelial basement membrane) dystrophy -map-dot-fingerprint** dystrophy

  - **📌Características clave**
  - También conocida como **map-dot-fingerprint** dystrophy.
  - En la mayoría de los casos es **esporádica**, aunque existen formas **AD familiares**.
  - Clínicamente puede simular erosiones corneales traumáticas.

  - **🔬Histología**
  - Engrosamiento de la membrana basal.
  - Depósito fibrilar entre epitelio y membrana de Bowman.
  - **Déficit de hemidesmosomas** basales.

  - **👁️Clínica**
  - Inicio en la **2.ª década**.
  - ~10% desarrolla **erosiones corneales recurrentes** en la 3.ª década.
  - Muchos casos son asintomáticos.

  - **🔎Signos**
  - Visualización con **retroiluminación o scatter escleral**.
  - Lesiones variables:
    - 🟣 Microquistes y puntos epiteliales.
    - 🗺️ Mapas subepiteliales con halo difuso.
    - 🌀 Líneas en espiral tipo “huella dactilar”.
    - 🍇 Patrón “vidrio esmerilado” subepitelial.

  - **💊Tratamiento**
  - Igual que para las **erosiones corneales recurrentes**: lubricación, antibióticos tópicos, lentes de contacto terapéuticas en casos persistentes.

- **🔬2. Meesmann Epithelial Dystrophy**

  - **📌Características clave**
  - Enfermedad **rara y no progresiva** del metabolismo epitelial.
  - Mutaciones en genes de **queratina epitelial corneal**.
  - Transmisión **autosómica dominante (AD)**.

  - **🔬Histología**
  - Engrosamiento de la membrana basal epitelial.
  - Quistes intraepiteliales.

  - **👁️Clínica**
  - La mayoría es **asintomática**.
  - En algunos casos: visión borrosa leve, erosiones ocasionales.

  - **🔎Signos**
  - Múltiples **microquistes intraepiteliales**:
    - Distribución central, **no alcanzan el limbo**.
    - Cornea ligeramente **adelgazada**, sensibilidad reducida.

  - **💊Tratamiento**
  - Solo lubricación. No suele requerir tratamiento adicional.

## 🧿Corneal Dystrophies – Bowman Layer / Anterior Stromal

## ✅Generalidades

• Son distrofias que afectan la **membrana de Bowman** y la **zona más anterior del estroma corneal**.

• Se heredan de forma **autosómica dominante (AD)**.

• Ambas están asociadas a **recurrentes erosiones cornealesen la infancia**.

• Causadas por mutaciones en el gen **TGFB1** (comparten vía con algunas estromales como la granular).

- **🧬Comparativa rápida**

| **Característica** | **Reis–Bücklers** | **Thiel–Behnke** |
|---|---|---|
| Otro nombre | CBD1 (corneal basement dystrophy type 1) | CBD2 (type 2) / Honeycomb dystrophy |
| Gen asociado | TGFB1 | TGFB1 + otro no definido |
| Gravedad | Más severa | Más leve |
| Histología | Sustitución de Bowman por tejido fibroso | Fibras “curly” en Bowman (EM) |
| Clínica | Erosiones severas desde la infancia | Erosiones más leves |
| Opacidades | Grises, geográficas, densas, reticulares | Subepiteliales, en anillo tipo panal |
| Distribución | Central, densa | Central, más difusa |
| Sensación corneal | Reducida | Variable |
| Tratamiento | Lubricación, excimer en casos graves | Frecuentemente no necesario |

- **🔍Detalles individuales**

  - **1. Reis–Bücklers Corneal Dystrophy**

    - Variante anterior de la **granular tipo 3**.
    - También conocida como **CBD1** -(corneal basement dystrophy type 1).
    - 👨‍👩‍👧‍👦 **AD**, gen **TGFB1**.
    - 🔬 Histología: desaparición de Bowman → reemplazo por **bandas de tejido conectivo**.

    - **👁️Clínica**
    - **Erosiones corneales severas** desde la infancia.
    - Disminución progresiva de visión con los años.

    - **🔎Signos**
    - **Opacidades grises subepiteliales**, geográficas, densas en centro.
    - Evolucionan a un **patrón reticulado** con la edad.
    - Disminución de **sensibilidad corneal**.

    - **💊Tratamiento**
    - Similar al manejo de **erosiones corneales**.
    - **Queratectomía con excímer** útil en casos sintomáticos severos.

  - **2. Thiel–Behnke Corneal Dystrophy**

    - También llamada **“honeycomb dystrophy”**.
    - También **AD**, gen **TGFB1 + otro**.
    - 🔬 Histología: fibras en espiral o “curly fibers” en Bowman (visible en EM).

    - **👁️Clínica**
    - **Erosiones** durante la infancia, pero menos graves que en Reis–Bücklers.

    - **🔎Signos**
    - Opacidades menos definidas, en **red de anillos tipo panal**.
    - Involucra sobre todo la **córnea central**.

    - **💊Tratamiento**
    - No siempre necesario.

## 🌫️Corneal Stromal Dystrophies ( 7 !! )

## ✅Generalidades

• Afectan principalmente el **estroma corneal**, pueden extenderse a otras capas.

• Mayoría son de **herencia autosómica dominante (AD)**, excepto la **macular**, que es **autosómica recesiva(AR)**.

• Comunes: **TGFB1 mutado (mismo que en distrofias de membr.Bowman?)** en granular, lattice y Avellino.

• Suelen presentarse desde la infancia o adolescencia con:

- Opacidades progresivas.
- Disminución visual.
- A veces erosiones corneales recurrentes.

## 🧬Comparativa clínica por subtipo

| **Tipo / Nombre** | **Gen** | **Depósito** | **Clínica clave** | **Tratamiento** |
|---|---|---|---|---|
| **Lattice tipo 1 o clásica (TGFB1)** | TGFB1 | ✴️ Amiloide | Erosiones en infancia, opacidad filiforme central | Queratoplastia (penetrante o DALK) |
| **Lattice tipo 2 o Gelsolina (LCD2)** | GSN | ✴️ Amiloide | Leve ocular + neuropatía sistémica | Poco frecuente; sistémico progresivo |
| **Granular tipo 1 o pan rallado** | TGFB1 | 🧊 Hialino | Depósitos en “pan rallado”, erosiones raras | Queratoplastia; recidiva superficial |
| **Granular tipo 2 (Avellino estelar )** | TGFB1 | 🧊Hialino + ✴️  Amiloide | Estelar/anular; no cirugía refractiva | Evitar cirugía refractiva |
| **MaculAR** | CHST6 | 🔷 GAGs | AR; opacidades difusas, desde infancia | Queratoplastia; frecuente recurrencia |
| **Schnyder o lipidica** | UBIAD1 | 🧬 Lípidos | Haze central, arco corneal, 50% cristales | Excimer o trasplante si afecta visión |
| **François cloudy dystrophy o nubolosa** | No claro | — | Asintomática, similar a degeneración | No requiere tratamiento |

## 🔬Detalles por subtipo

**Lattice :** que tiene una **apariencia en red o rejilla** (de ahí el término “lattice” en inglés, que significa “entramado” o “rejilla”) aspecto de **líneas finas ramificadas**.

## 👁️¿Cómo se manifiesta?

• Líneas finas **blanco-grisáceas** en la parte central del estroma corneal

• Disposición **ramificada o entrecruzada** (como una malla o red)

## 1. Lattice Dystrophy (TGFB1) o tipo 1

- **AD**, gen **TGFB1**.
- Depósitos de **amiloide** (Congo red + birefringencia verde).
- Erosiones desde la 1.ª década, visión borrosa más tarde.
- **Filamentos refractiles** centrales → patrón en “lattice” (no afecta limbo).
- Queratoplastia frecuente; puede recidivar.

## 2. Lattice tipo Gelsolina / Meretoja (LCD2) o tipo 2

- **AD**, gen **GSN\*\*\***.
- Sistémica: **neuropatía craneal/periférica**, **cara rígida**, alteración autonómica.- **La tipo II se asocia a amiloidosis sistémica**
- Opacidad leve, líneas desde periferia → centro.
- Erosiones raras. Queratoplastia rara vez necesaria.

- **3. Granular tipo 1 (clásica)**
- **AD**, gen **TGFB1**.
- Depósitos **hialinos** (Masson trichrome rojo).
- Opacidades **bien definidas**: aspecto de **azúcar / pan rallado**.
- Comienzo central, se expande con el tiempo.
- Visión afectada progresivamente → queratoplastia 5.ª década.

## 4. Granular tipo 2 (Avellino)

- **AD**, gen **TGFB1**.
- Mezcla de **hialino y amiloide**.
- Opacidades superficiales → estelares / anulares + opacidades lineales profundas.
- ⚠️ **Contraindicado cirugía refractiva**: acelera progresión\*\*\*\*.
- Generalmente no requiere tratamiento.

## 5. MaculAR Dystrophy

- **AR**, gen **CHST6**.
- Depósitos de **GAGs - glycosaminoglycanos** (Alcian blue + colloidal iron).
- Desde infancia: opacidades mal definidas → **toda la córnea**, hasta el limbo.
- Asociada a **adelgazamiento temprano** y **edema tardío**.
- Muy recidivante tras queratoplastia.

## 6. Schnyder Dystrophy

- **AD**, gen **UBIAD1**.
- Depósitos de **lípidos (fosfolípidos y colesterol)**.
- **Haze central**, cristalina (solo 50%).
- Arco corneal → avanza hacia el centro.
- A veces asociado a **dislipidemia sistémica**.
- Tratamiento con excimer o trasplante si hay afectación visual.

## 7. François Central Cloudy Dystrophy O NUBOLOSA

- Sospechada como degeneración, no distrofia verdadera.
- Opacidades poligonales posteriores, **sin síntomas**.
- **No requiere tratamiento**.

## 🧿Descemet Membrane and Endothelial Corneal Dystrophies ( 3 )

## ✅Generalidades

• Grupo de distrofias que afectan el **endotelio** y/o la **membrana de Descemet**.

• Alteran la **función de bomba** del endotelio → **edema corneal progresivo**.

• Pueden ser **congénitas o adquiridas**, y muchas son **hereditarias** (AD o AR).

• Algunas pueden asociarse a **glaucoma, iris anómalo o sordera**.

## 🔬Subtipos principales

## 1. Fuchs Endothelial Corneal Dystrophy (FECD)

| **Característica** | **Detalles** |
|---|---|
| 🧬 Genética | Mayoría esporádica; casos AD por **TCF4** (adultos) o **COL8A2** (forma precoz) |
| 👩‍🦰 Epidemiología | Más frecuente en mujeres; aparece en **edad media o avanzada.** |
| 👁️ Clínica | Visión borrosa matutina por edema; dolor si hay bullas |
| 🔬 Signos histológicos | Guttata endoteliales (excrescencias), edema estromal y epitelial progresivo, “beaten metal” |
| 📈 Complicaciones | Glaucoma leve ↑ riesgo; bullous keratopathy en estadios avanzados |
| 💊 Tratamiento | Salina hipertónica, queratoplastia (DSAEK/DMEK/PK), Rho-kinasa (experimental) |
|  |  |

## ⚠️Catarata + Fuchs

→ Precaución: la cirugía puede empeorar el edema. Si CCT > 630–640 μm, considerar procedimiento triple.

## 2. Posterior Polymorphous Corneal Dystrophy (PPCD)

| **Característica** | **Detalles** |
|---|---|
| 🧬 Genética | AD. PPCD1: **VSX1** / PPCD2: **COL8A2** / PPCD3: **ZEB1** |
| 👁️ Clínica | Habitualmente asintomática |
| 🔬 Signos | Lesiones endoteliales en patrón vesicular, lineal o difuso |
| 🤝 Asociaciones | Glaucoma, iris anómalo, síndrome de Alport |
| 💊 Tratamiento | No suele ser necesario |
|  |  |

## 3. Congenital Hereditary Endothelial Dystrophy (CHED)

| **Subtipo** | **CHED1** | **CHED2** |
|---|---|---|
| Herencia | AD (locus en cromosoma 20) | AR (**SLC4A11**) |
| Aparición | 1er año de vida | Desde el nacimiento |
| Síntomas | Lagrimeo, fotofobia | Sin síntomas oculares frecuentes |
| Signos | Opacidad corneal difusa | Igual, pero más severa |
| Asoc. | ¿Misma entidad que PPCD? | Puede asociarse a sordera (Harboyan) |
| Nistagmo | Raro | Común |
| Tratamiento | Lamelar o PK | Lamelar o PK |
|  |  |  |

## Descemet membrane and endothelial Dystrophies

Fuchs endothelial corneal dystrophy

📘 1. Introducción

– **Definición**: Distrofia endotelial de Fuchs es una enfermedad corneal bilateral progresiva caracterizada por pérdida acelerada de células endoteliales y edema corneal.

– **Importancia**: Principal causa de queratoplastia endotelial en adultos mayores.

– **A quién afecta**: Predomina en mujeres, con inicio habitual en edad media o avanzada.

– **Paciente típico**: Mujer >50 años con visión borrosa matutina progresiva, antecedentes familiares variables.

🧬 2. Etiología

– **Genética**: La mayoría de los casos son esporádicos. Hay formas autosómicas dominantes (mutación en *COL8A2* en variantes de inicio precoz; *TCF4* en formas típicas).

– **Multifactorial**: Influencias genéticas y edad.

– **Iatrogénica**: Cirugía ocular (ej. facoemulsificación) puede precipitar descompensación endotelial.

👁 3. Síntomas

– **Síntomas típicos**:

• Visión borrosa matutina que mejora durante el día (edema corneal fluctuante).

• Disminución visual progresiva.

• Molestias oculares en estadios avanzados (ej. dolor por bullas rotas).

– ⚠️ **Alarma**: Dolor ocular agudo por ruptura de bullas; visión muy reducida.

🔎 4. Signos

– **Exploración física**:

• Guttata corneal: excrescencias en membrana de Descemet.

• Líneas radiales endoteliales periféricas.

• Reflejo especular: mosaico irregular → aspecto de “metal golpeado”.

• Edema estromal central → opacidad progresiva.

• Edema epitelial con microquistes y bullas (queratopatía bullosa).

• Casos crónicos: cicatrices subepiteliales, neovascularización periférica.

– ⚠️ **Alarma**: Signos de descompensación endotelial avanzada o dolor intenso por bullas.

🔬 5. Diagnóstico

– **Pruebas necesarias**:

• Biomicroscopía con lámpara de hendidura.

• Paquimetría central (>630–640 μm sugiere riesgo postoperatorio elevado).

• Microscopia especular (pérdida de células y guttata).

• OCT anterior si está disponible.

– **Diagnóstico diferencial**:

• Distrofias endoteliales congénitas (CHED).

• Queratopatía bullosa pseudofáquica.

• Edema corneal por hipertensión ocular o cirugía.

– ⚠️ **Red flags diagnósticos**:

• Córnea edematosa en paciente con faco reciente.

• CCT >640 μm prequirúrgico.

• Guttata extensa y pérdida celular avanzada.

💊 6. Tratamiento

– **Primera línea (conservador)**:

• Cloruro de sodio 5% en gotas o ungüento.

• Disminución de la PIO.

• Secado corneal (ej. secador de pelo a baja potencia).

– **Alternativas / paliativo**:

• Lentes de contacto terapéuticos.

• Cicloplegia, antibióticos tópicos, lubricantes.

• Punción estromal anterior (para bullas).

– **Cirugía**:

• DSAEK / DMEK (queratoplastias endoteliales): alta tasa de éxito.

• Queratoplastia penetrante en casos avanzados.

• Cirugías en ojos sin potencial visual: colgajos conjuntivales, membrana amniótica.

• Innovador: inhibidores tópicos de Rho-quinasa tras crioterapia endotelial.

– ⚠️ **Precauciones**:

• Cirugía de catarata puede empeorar función endotelial.

• Usar técnicas con mínima energía ultrasónica (torsional > longitudinal).

• Considerar cirugía triple (facoe+LIO+DSAEK/DMEK) en casos con edema.

• Paquimetría <630 μm → menor riesgo de edema post-faco.

📅 6.1 Seguimiento

– **Controles**: Según progresión clínica y tratamiento instaurado (mensual a semestral).

– **Evolución**: Lenta pero progresiva; buena respuesta quirúrgica si se trata a tiempo.

🧭 7. Protocolos / Algoritmos

– Sospecha clínica + biomicroscopía → confirmar con paquimetría y microscopia especular.

– Si córnea compensada → tratamiento conservador + seguimiento.

– Si córnea descompensada → valorar queratoplastia (DMEK/DSAEK).

– Previo a faco: medir paquimetría y evaluar riesgo → considerar cirugía triple si >630 μm.

📝 8. Notas personales / Tips clínicos

– Si visión borrosa matutina mejora durante el día, piensa en edema corneal por Fuchs.

– Siempre pedir paquimetría preoperatoria en pacientes >60 años antes de faco. Tambien recuendto celulas endotheliales no? Si tenemos la maquina, mas info, mejor para nosotros y el paciente no?

– No subestimar guttata aislada en ojos asintomáticos: pueden evolucionar.

💎 9. Puntos clave de la enfermedad

💎 Visión borrosa matutina progresiva en adultos mayores.

💎 Guttata corneal + paquimetría central >630 μm son claves diagnósticas.

💎 DMEK es el tratamiento de elección en córnea descompensada con buen pronóstico visual.

🔗 10. Recursos complementarios

– Imágenes clínicas: guttata, edema estromal, queratopatía bullosa.

– AAO Fundamentals & Kanski – capítulos de distrofias endoteliales.

– Revisión UpToDate sobre manejo actual y novedades terapéuticas (Rho-kinasa).

🧠 11. Flashcards / Preguntas tipo EBO

– ❓ ¿Cuál es el hallazgo inicial típico en Fuchs? → Guttata en membrana de Descemet.

– ❓ ¿Qué parámetro predice mayor riesgo de edema post-faco? → Paquimetría central >640 μm.

– ❓ ¿Cuál es el tratamiento quirúrgico más eficaz? → DMEK.

– ❓ ¿Por qué esta enfermedad es importante? → Es la distrofia endotelial más común y una de las principales indicaciones de queratoplastia.

– ❓ ¿Qué no debes olvidar nunca al verla? → Siempre evaluar paquimetría antes de cirugía intraocular.

✴️ 12. Mensaje clave final

– Fuchs es una distrofia endotelial progresiva que causa edema corneal y pérdida visual; requiere diagnóstico precoz, seguimiento paquimétrico y manejo quirúrgico oportuno con DMEK para preservar la visión.

## 👶🏻CHED – Distrofia Endotelial Hereditaria Congénita

📘 1. Introducción

– **Definición**: Enfermedad rara congénita caracterizada por engrosamiento difuso o focal de la membrana de Descemet y degeneración endotelial.

– **Importancia**: Causa importante de opacidad corneal desde la infancia.

– **A quién afecta**: Recién nacidos o niños pequeños, según el tipo.

– **Paciente típico**: Lactante con corneas opacas al nacimiento (CHED2) o con opacidad progresiva en la infancia (CHED1).

🧬 2. Etiología

– **Genética**:

• **CHED1**: Autosómica dominante, locus en cromosoma 20; posible solapamiento con distrofia corneal polimorfa posterior (PPCD).

• **CHED2**: Autosómica recesiva, mutación en *SLC4A11*; más frecuente y severa.

– **Asociaciones**: CHED2 puede asociarse con sordera neurosensorial de inicio tardío (síndrome de Harboyan).

👁 3. Síntomas

– **CHED1**: Fotofobia, lagrimeo, opacidad progresiva.

– **CHED2**: Generalmente asintomático al inicio, pero con opacidad presente desde el nacimiento.

– ⚠️ **Alarma**: Nistagmo (más común en CHED2), indica privación visual.

🔎 4. Signos

– **CHED2**:

• Opacidad corneal difusa y engrosamiento desde el nacimiento.

• Nistagmo frecuente.

• Discrepancia entre apariencia corneal y agudeza visual (puede ser mejor de lo esperado).

– **CHED1**:

• Opacidad aparece durante el primer o segundo año de vida.

• No suele presentar nistagmo.

– ⚠️ **Alarma**: Opacidad densa bilateral neonatal → sospechar CHED2.

🔬 5. Diagnóstico

– **Pruebas necesarias**:

• Evaluación oftalmológica neonatal/infantil.

• Paquimetría, OCT anterior si posible.

• Genética: estudio de *SLC4A11* (CHED2).

– **Diagnóstico diferencial**:

• Distrofias endoteliales (CHED vs PPCD).

• Edema corneal congénito no distrofias (glaucoma congénito, trauma de parto, infección intrauterina).

– ⚠️ **Red flags diagnósticos**:

• Opacidad corneal bilateral desde nacimiento.

• Historia familiar compatible con patrón autosómico.

💊 6. Tratamiento

– **Quirúrgico**:

• Queratoplastia lamelar o penetrante según el grado de afectación.

• En casos graves o con nistagmo → intervención precoz para evitar ambliopía.

– ⚠️ **Precauciones**:

• Manejo multidisciplinar si hay sospecha de síndrome de Harboyan (evaluación auditiva).

• Evaluar y tratar ambliopía postoperatoriamente.

📅 6.1 Seguimiento

– **Controles**: Frecuentes en la infancia para valorar desarrollo visual y evolución postquirúrgica.

– **Evolución**: Sin cirugía, la opacidad suele ser estable o progresiva. Con trasplante, buen pronóstico visual si se interviene a tiempo.

🧭 7. Protocolos / Algoritmos

– Opacidad corneal bilateral neonatal → evaluar espesor, presión intraocular, antecedentes familiares → descartar CHED2.

– Confirmación genética y seguimiento visual → queratoplastia según severidad.

📝 8. Notas personales / Tips clínicos

– En opacidad corneal neonatal bilateral sin hipertensión ocular, siempre considerar CHED2.

– CHED1 puede confundirse con otras distrofias → historia familiar es clave.

– El nistagmo en CHED2 sugiere privación visual → requiere intervención urgente.

💎 9. Puntos clave de la enfermedad

💎 CHED2 es más frecuente, grave y de inicio neonatal.

💎 CHED1 tiene herencia dominante y puede confundirse con PPCD.

💎 Queratoplastia precoz mejora el pronóstico visual y reduce ambliopía.

🔗 10. Recursos complementarios

– Imágenes clínicas: opacidad corneal neonatal, evolución post-trasplante.

– Referencias: Kanski, AAO, revisión en OMIM del gen *SLC4A11*.

– Asociación CHED y sordera (síndrome de Harboyan): recursos de genética clínica.

🧠 11. Flashcards / Preguntas tipo EBO

– ❓ ¿Qué tipo de CHED aparece al nacimiento? → CHED2 (AR).

– ❓ ¿Cuál es el gen asociado a CHED2? → *SLC4A11*.

– ❓ ¿Qué complicación neurológica puede asociarse a CHED2? → Sordera neurosensorial (síndrome de Harboyan).

– ❓ ¿Por qué es importante diagnosticar CHED temprano? → Para evitar ambliopía severa.

– ❓ ¿Qué hallazgo diferencia CHED1 de CHED2? → Nistagmo (presente en CHED2).

✴️ 12. Mensaje clave final

– CHED debe sospecharse ante opacidad corneal congénita bilateral; el diagnóstico precoz y tratamiento quirúrgico adecuado son esenciales para preservar la visión en el desarrollo infantil.

## 🧠Flashcards EBO – Corneal Epithelial Dystrophies

1. **¿Cuál es la distrofia epitelial más frecuente en adultos?**

→ Cogan (epithelial basement membrane) dystrophy.

2. **¿Qué hallazgo microscópico es típico en la distrofia de Cogan?**

→ Engrosamiento de la membrana basal + depósito fibrilar subepitelial.

3. **¿Qué patrón de lesiones se asocia a la distrofia de Cogan?**

→ Map-dot-fingerprint: mapas, microquistes, líneas en espiral.

4. **¿Qué distrofia epitelial es congénita y no progresiva?**

→ Meesmann epithelial dystrophy.

5. **¿Qué hallazgo clínico diferencia Meesmann de Cogan?**

→ Microquistes epiteliales uniformes que no llegan al limbo.

## 🧠Flashcards EBO – Bowman Layer Dystrophies

1. **¿Cuál es la distrofia más severa entre Reis–Bücklers y Thiel–Behnke?**

→ Reis–Bücklers.

2. **¿Qué patrón de opacidad es típico en la distrofia de Thiel–Behnke?**

→ Panal de abejas (honeycomb).

3. **¿Qué gen está mutado en ambas distrofias?**

→ TGFB1.

4. **¿Qué hallazgo histológico se observa en Reis–Bücklers?**

→ Sustitución de Bowman por tejido conectivo fibroso.

5. **¿Cuál es el tratamiento quirúrgico útil en Reis–Bücklers severo?**

→ Queratectomía con excímer láser.

6. **¿Cómo se diferencian histológicamente ambas distrofias?**

→ Reis–Bücklers: bandas de colágeno / Thiel–Behnke: fibras “curly” en EM.

## 🧠Flashcards EBO – Distrofias endoteliales

1. **¿Qué gen se asocia con la forma más común de Fuchs en adultos?**

→ *TCF4*.

2. **¿Qué hallazgo histológico define la distrofia de Fuchs?**

→ Guttata: excrescencias en membrana de Descemet.

3. **¿Cuál es el rango crítico de espesor corneal central que predice edema post-cirugía en Fuchs?**

→ > 630–640 µm.

4. **¿Qué tipo de trasplante se prefiere en Fuchs actualmente?**

→ DMEK o DSAEK (lamelares posteriores).

5. **¿Cuál es la forma de distrofia endotelial congénita más grave?**

→ CHED2 (AR, SLC4A11).

6. **¿Qué hallazgos se ven en PPCD?**

→ Lesiones vesiculares o en bandas en el endotelio; asintomático.

7. **¿Qué complicaciones puede tener la Fuchs avanzada?**

→ Bullas epiteliales, dolor, cicatrización subepitelial, neovascularización periférica.

8. **¿Qué mutación se asocia a la forma precoz de Fuchs y PPCD2?**

→ *COL8A2*.

## 🧠Flashcards EBO – Stromal Dystrophies

1. **¿Cuál es la única distrofia corneal estromal de herencia recesiva?**

→ MaculAR (gen CHST6).

2. **¿Qué tipo de depósito se encuentra en la distrofia granular tipo 1?**

→ Hialino.

3. **¿Qué patrón es típico en la distrofia de Avellino?**

→ Lesiones estelares o anulares + opacidades lineales profundas.

4. **¿Qué tinción es característica para confirmar amiloide en distrofias tipo lattice?**

→ Congo red + birefringencia verde con filtro polarizado.

5. **¿Qué distrofia estromal se asocia a neuropatía periférica sistémica?**

→ Lattice tipo Gelsolina (Meretoja / LCD2).

6. **¿Qué característica clínica contraindica cirugía refractiva en granular tipo 2?**

→ Riesgo de aceleración de la distrofia tras trauma corneal.

7. **¿Qué distrofia tiene aspecto de pan rallado y requiere queratoplastia en la 5.ª década?**

→ Granular tipo 1.

8. **¿Qué distrofia presenta depósitos lipídicos y puede asociarse a dislipidemia sistémica?**

→ Schnyder.

## DISTROFIADE FUCHS: distrophieENDOTHELIAL-Descemetique

Sporadique ou autosomique dominant

Début en generale >40 ans par: halos, éblouissement avec BAV intermittente avec prédominance matinale pour oedeme cornéen au reveil\*

## STADE

- **1- Cornea guttata**
- Vérrucosités de la membrane descemet-aspect d'argent battu et dépots pigmentes.

- **2-Oedeme cornéen +/- oedeme microkystique**

- **3-Fobrose sous-épithéliale**

## DYSTROPHIE POSTERIEURE POLYMORPHE

Autosom dom. À présentation précce dans la vie

Vesicules, lignes grises, anomalies endothéliales parfois géographiques.

Sympt très lentement progressive avec AV log-temps conservée

Epaississement localisé de la membrane Descemet avec endothélium pluristratifié multicouche pseudo-épithélial.

Diagnostique dd: ICE snydome ou snydrome iridocornéo-éndothélial par proliferation excessive de l'endothélium aux dépens de la face posterieur de a cornée de l'angle iridocornéen et de l'iris

## DYSTROPHIE ENDOTHELIAL CONGENITAL HEREDITAIRE – CHED

Débt périnatal

Absence d'endothélium cornéen focal ou diffus par desquamation endothélial

Symptomes pseudoglaucomateuses avec opacifications oedmemateuses bilaterales cornéens

Dx dd glaucome congenital.

TT:

Solution hyperosmolars: ODM5

Greffe endotheliales: DSAEK ou DMEK

Greffe transfixiantes

| **📊Tabla 1 – Resumen completo de todas las distrofias corneales (por capas)** |  |  |  |  |  |  |  |
|---|---|---|---|---|---|---|---|
| **Capa** | **Nombre** | **Herencia** | **Gen** | **Depósito / Lesión** | **Clínica** | **Signos clave** | **Tratamiento** |
| **Epitelio** | Cogan | Esporádica / AD | - | Engrosamiento MB, líneas | Erosiones leves | Mapa, huella, puntos | Lubricación |
| **Epitelio** | Meesmann | AD | Queratina epitelial | Quistes intraepiteliales | Asintomática | Quistes sin llegar al limbo | No requiere |
| **Bowman** | Reis–Bücklers | AD | TGFB1 | Membr. Bowman substituida por Tejido fibroso | Erosiones severas | Opacidades geográficas | Excimer |
| **Bowman** | Thiel–Behnke | AD | TGFB1 | Fibras curly en membrana Bowman tipo panal de abeja | Erosiones leves | Panal central | No requiere |
| **Estroma** | Lattice (TGFB1) | AD | TGFB1 | Amiloide | Erosiones tempranas | Líneas refractiles | Queratoplastia |
| **Estroma** | Lattice (gelsolina) | AD | GSN | Amiloide | Leve + neuropatía | Líneas desde periferia | Conservador |
| **Estroma** | Granular tipo 1 | AD | TGFB1 | Hialino | Glare, progresiva | Puntos como pan rallado | PK |
| **Estroma** | Avellino | AD | TGFB1 | Hialino + amiloide | Empeora post-cirugía | Lesiones estelares + lineales | Evitar cirugía refractiva |
| **Estroma** | Macular | AR | CHST6 | GAGs | Desde infancia | Difuso hasta limbo | PK |
| **Estroma** | Schnyder | AD | UBIAD1 | Lípidos | Dislipidemia | Haze central + arco | PK o excimer |
| **Estroma** | François cloudy | Posible AD | - | - | Asintomática | Opacidades poligonales | No requiere |
| **Endotelio** | Fuchs | Esporádica / AD | TCF4 / COL8A2 | Guttata | Visión borrosa matutina | Beaten metal, bullas | DMEK / DSAEK |
| **Endotelio** | PPCD | AD | VSX1 / ZEB1 | Lesiones vesiculares | Asintomática | Vesículas / bandas | No requiere |
| **Endotelio** | CHED2 | AR | SLC4A11 | Engrosamiento Descemet | Nistagmo, sordera | Opacidad neonatal | PK |

| **📌Tabla 2 – Lo esencial para diferenciar (conceptos clave)** |  |  |  |  |  |
|---|---|---|---|---|---|
| **Nombre** | **Gen** | **Capa** | **Patrón clave** | **Clínica distintiva** | **Tratamiento** |
| **Cogan** | - | Epitelio | Mapa-huella | Erosiones sin trauma | Lubricación |
| **Meesmann** | Queratina epitelial | Epitelio | Quistes | Asintomática | Ninguno |
| **Reis–Bücklers** | TGFB1 | Bowman | Geográfica | Erosiones severas | Excimer |
| **Thiel–Behnke** | TGFB1 | Bowman | Panal | Leve | Nada |
| **Lattice (TGFB1)** | TGFB1 | Estroma | Filamentos | Erosiones precoces | PK / DALK |
| **Lattice (gelsolina)** | GSN | Estroma | Periférico | Neuropatía sistémica | Conservador |
| **Granular tipo 1** | TGFB1 | Estroma | Pan rallado | Bien delimitada | PK |
| **Avellino** | TGFB1 | Estroma | Estelar + lineal | Post-cirugía empeora | Evitar cirugía refractiva |
| **Macular** | CHST6 | Estroma | Difuso | Infancia, AR | PK |
| **Schnyder** | UBIAD1 | Estroma | Haze + arco | Dislipidemia | PK / excimer |
| **Fuchs** | TCF4 | Endotelio | Guttata | Visión matinal borrosa | DMEK / DSAEK |
| **PPCD** | VSX1 | Endotelio | Vesículas | Asintomática | No requiere |
| **CHED2** | SLC4A11 | Endotelio | Opacidad neonatal | Sordera + nistagmo | PK |

| **🧠Tabla 3 – Mínimo para memorizar** |  |  |  |
|---|---|---|---|
| **Distrofia** | **Capa** | **Palabra clave** | **Qué la distingue** |
| **Cogan** | Epitelio | Mapa-huella | Erosiones sin trauma |
| **Meesmann** | Epitelio | Quistes | Infancia, sin síntomas |
| **Reis–Bücklers** | Bowman | Geográfica | Erosiones severas |
| **Thiel–Behnke** | Bowman | Panal | Leve |
| **Lattice TGFB1** | Estroma | Filamentos | Erosiones precoces |
| **Avellino** | Estroma | Estelar + lineal | Contraindicado excimer |
| **Macular** | Estroma | Difusa al limbo | AR, infancia |
| **Granular 1** | Estroma | Pan rallado | Bien delimitada |
| **Schnyder** | Estroma | Lípidos + arco | Dislipidemia |
| **Fuchs** | Endotelio | Guttata | Borrosidad matutina |
| **PPCD** | Endotelio | Vesículas | Asintomática |
| **CHED2** | Endotelio | Opacidad neonatal | Sordera, nistagmo |
