---
categoria: apuntes
area: retina-medica
emoji: 🩸
seccion: Ret Med y coroides
orden_seccion: 19
orden: 30
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-03-17
---
# Syndrome de Charles Bonnet (CBS)

Le syndrome de Charles Bonnet (CBS) consiste en des hallucinations visuelles complexes survenant chez des sujets âgés ne présentant pas de troubles mentaux. C'est le naturaliste genevois Charles Bonnet qui en donna la première description en 1760, la personne affectée étant son grand-père1. Il en fut lui-même atteint2, et le syndrome est nommé ainsi pour la première fois en 1967 par Georges de Morsier3.

Il s'agit d'hallucinations visuelles complexes survenant chez des sujets âgés ne présentant pas de troubles mentaux2. Charles Bonnet relate le cas de son grand-père de 87 ans atteint d'une cataracte des deux yeux responsable d'une cécité presque complète mais qui disait percevoir des personnages, des oiseaux, des voitures attelées, des bâtiments, des tapisseries et des motifs en échafaudages.

Dans la plupart des cas, les patients sont des personnes souffrant d'un déficit visuel lié au vieillissement, de lésions oculaires ou d'une atteinte des nerfs optiques. En particulier, l'association d'une perte de la vision centrale observée dans la dégénérescence maculaire liée à l'âge et d'une perte de vision périphérique consécutive à un glaucome est un facteur prédisposant au syndrome de Charles Bonnet, qui ne survient toutefois que rarement. Les troubles sont strictement visuels, n'affectant pas les autres sens4. D'ailleurs, on note une brève hyperactivité dans le cortex inferotemporal.

Aucun traitement n'est défini5.
