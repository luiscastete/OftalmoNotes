---
categoria: apuntes
area: glaucoma
emoji: 🟢
seccion: Glaucome
orden_seccion: 5
orden: 27
fuente: OneNote del Dr. Castilla Martí
---
# Mesure TIO goldmann

## Factores que Alteran la Tonometría — Entendiendo el Porqué

## Recordatorio del principio

El tonómetro mide la FUERZA necesaria para aplanar la córneaSi algo hace la córnea MÁS FÁCIL de aplanar → lee PIO falsamente BAJASi algo hace la córnea MÁS DIFÍCIL de aplanar → lee PIO falsamente ALTA

La pregunta que debes hacerte siempre es:

- **¿Este factor hace la córnea más fácil o más difícil de aplanar?**

## 1. Grosor corneal (CCT — Central Corneal Thickness)

## Córnea gruesa → PIO falsamente ALTA

Córnea normal = ~540 micras

Córnea gruesa = ~620 micras

Imagina que tienes que aplanar:

- Una lámina de **cartón fino** → poca resistencia
- Una lámina de **cartón doble** → más resistencia

Córnea gruesa     ↓Más material que comprimir/desplazar     ↓Necesitas más fuerza para aplanar     ↓Tonómetro lee fuerza alta     ↓Interpreta PIO ALTA     ↓Pero la PIO real es normal
