---
categoria: apuntes
area: glaucoma
emoji: 🟢
seccion: Glaucome
orden_seccion: 5
orden: 25
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-07-24
---
# GPAO -Glaucome primitif à angle ouvert

Maladie oculaire chronique, évolutive, potentiellement cécitante et irreversible causant une perte de l'ARN et des FRNLavec déficits du CV associé. L'aspect de l'angle est normal et les ppal FR sont la PIO et agé avancé.

ETIOLOGIE

Reste flou.

Multiples F génétiques et influences des comorbolités sont suscetibles de jouer une rôle. Hypothese sur déformation la lame criblée causée par des niveaux de PIO qui ne sont pa stoleres pour un oeil donnée. Atteinte axonal-mort cel ganglionaires + FRCV...

Toute augmentation de la PIO est causée par une résistance élévée à écoulement de HA dans le svoies d'écoulement du trabeculum.  un proportion importante develope une GPAO avec PIO dans la norme.

GPAO subdivisé en Glaucome avec PIO élevée et Glaucome avec PIO normale- GPN-

On premuse que les FR autre que PIO ont une importance plus grande dans GPN.

Tt est idem.

FR GPAO:

- age
- PIO élevée
- Race noire
- Ant fam glaucome
- Myopie forte
- Basse presion artériele diastolique
- ECC plus mince
- FRCV

## Juvenile-onset open-angle glaucoma

Has been linked to mutations in trab meshwork - TIRG/MYOC

OPTN - optineurin mutations have been linked to normal tension glaucoma

CYP1B1 mutations have been linked to congenital glaucoma
