---
categoria: apuntes
area: cornea
emoji: 💧
seccion: Conj + Episclere + Sclere
orden_seccion: 25
orden: 19
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-07-21
---
# Ptérygion

Néoformation fibrovasculaire, bénigne, d'évolution centrifuge vers l'apex cornéen.

Etymologiquement, ce terme vient du grec pteros, qui signie aile.

## SYMPTOMES

Peut etre asymptomatique

Symptomes fonctionnels de pathologie de surface: larmoiment, sensation de CE, gêne et prurit.

Gêne esthetique

+/- BAV: par envahissement direct de l'axe optique ou par l'astigmatisme induit.

## SIGNES

Localise préférentiellement sur la conj bulbaire en région interpalpebrale.

En nasale 90% des cas, arrement en temporal.

Souvent bilateral et asymetrique

+/- hyperhémie locale: souvent à répetition

+/- amincissement possibedur Dellen

+/- stocker line: ligne de fer en bout de ptérygion

## ETIOLOGIES

Exposition solaire +/- ultraviolets

Irritation chronique

## STATUS

AV-TIO

LAF, fluo, mesure de la taille du limbe à l'àpex

## BILAN

Photo: suivi l'évolution.

Topographie cornéenne:

- Mesure de l'astigmatisme induit ( généralement irregulier et conforrme à la règle).
- Suivi de l'évolution et de la régression de l'astigmatisme post-chirg.

## TT

## TT MEDICAL
