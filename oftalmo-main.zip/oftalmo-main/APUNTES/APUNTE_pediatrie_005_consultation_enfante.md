---
categoria: apuntes
area: pediatria
emoji: 🧸
seccion: Pediatrie
orden_seccion: 9
orden: 5
fuente: OneNote del Dr. Castilla Martí
---
# Consultation enfante

ENFANTE 5 ans

1er

- AV sc

- (AV avec E - plus facile pour enfante que desines - tu lui dones la lettre E)

2em

- AV avec nidek ( TU PEUX SUMER +0.50 PETITE BRUILLARD)

3em etape

- Lang - étoile toute le monde voit
- Bien - 2 sur 3

- Cover test

- Motilite

Après tu peut passer a faire le skya

(si premier fois optha TOUTE le monde doit avoir une cyclo

ou si symptomes biensur)
