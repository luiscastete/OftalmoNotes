---
categoria: apuntes
area: urgencias
emoji: 🚑
seccion: URGENCES---TRAUMATOLOGIE
orden_seccion: 2
orden: 3
fuente: OneNote del Dr. Castilla Martí
fecha: 2022-08-31
---
# Erosion cornéen

Lesion épithelial spontanée ou secondaire à un trauma ( mec vs chimique)

Physio de lesions récidivantes:

-diminution adherence épith. À la membrane basale.

-disparition focale de le membrane basale.

-sécretions aberrantes membrane basale ( intra-épith.)

-secretions anormales de gélatinase et neuopeptides.

## SYMPT

douleur ++, rougeur, sensation CE, photophobie, larmoiments, si recidivantes: surtout au reveil lors ouverture palpebrale.

## SIGNES

AV normal ou diminue, HC, lesion épithelial fluo +, +/- épithelium cornéen lâche ( instable)/ grisatre. +/- dystrophie cornéen sous-jacente ( à chercher dans oeil contralat. ) DYSTROPHIE DE COGAN freq ( maps dots, fingerprints.

SEMIOLOGIA:

## ETIOLOGIES

Si inaugural:

Traumatiques ( Mecanique, Chimique, thermique)

Si recidivantes:

Post trauma >50%

Distrophie de la membrane basale (COGAN) >30%

Autres distrophies: Meesman, Reis-Bucklers, lattice, granulaire et Fuchs.

Rosacée oculaire

## Chirg refractive ou ocualire.

## TTT

## de base

-Floxal collyre 4xj pendant 7j

-Optava collyre 8xj pendant 2 sem

--Fermavisc 1 goutte minimum 8x/j (ACID HYALURONIC – ROBIN AIME BIEN )\*\*\*

-Pommade vit A le soir 2 sem

+/- cycloplégie si douleurs intolérables : Scopolamine 2xj pdt 5j

+/- analgésie orale : Dafalgan 1g 3xj +/- Irfen 400mg 3xj pdt 1 sem.

+/- pansement oculaire occlusif jusqu'à lendemain avec floxal pommade +/- Harmatropine.

+/- LDC pansement N&D ( max 3 sem) + floxal gtt et LA ( pas pommades et pas si CE vegetal)

## TTT

- **Erosions recidivantes:**

1.débridement épith. Si flap épith. Avec bourrelet épith.

2. +/- ponction stromale ant: favorise adherence épith.

3.ttt de base ( jusq ré-épith. Complete).

Puis ttt longue court:

- 4.LA 6-8xj pdt 3-6m.
- 5. PVA le soir pdt 3-6m.
- 6.+/- Doxycycline 50-100mg 1XJ pdt 1 mois ou Doxycycline topique 0,0025% 3xj +/- Azyter topique cure sur 3m.
- 7.+/- add ODM 5, 2xj pdt 2 mois et suivi 2-4sem (recommendation Tim)

Si mauvaise evolution référe service cornée

## SUIVI

Érosion trauma:

Pas PC d'office.

Vs j2-j3 si érosion centrale importante

Érosion récidivantes:

PC dans 2-3j jusq ré-épithel complete.

PC dans 1-3mois suite instauration tt longue courts.

Cas VEAA

impre:

OD grande érosion cornéen fluo + post enlever LDC chez patiente avec overwear syndrome.

att:

pansement + floxal pommade fait ce jour

Floxal gtt 3xj + Floxal pommade la nuit

LA + viscotears + scopolamine 2xj

add Dafalgan 1g 3xj

PC 06.09.22

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

probable érosions récidivantes post erosions cornéen en janvier.

att:

explications

add ODM 5 3xj + PVA le soir

PC au besoin
