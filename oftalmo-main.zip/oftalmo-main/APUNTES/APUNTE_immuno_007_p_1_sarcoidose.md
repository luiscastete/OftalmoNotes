---
categoria: apuntes
area: uveitis
emoji: 🔥
seccion: Immuno-infectio
orden_seccion: 7
orden: 7
fuente: OneNote del Dr. Castilla Martí
fecha: 2024-05-15
---
# P.1- Sarcoïdose

Maladie **systémique granulomateuse** d'étiologie inconnue.

Caracterisée par des **granulomes histologiques épithéloides et gigantocellulaires sans nécrose caséeuse.**

Toutes les structures du globe oculaire et le contenu orbitaire peuvent etre atteintes.

Les manifestations ophtalmologiques sont polymorphes.

## EPIDEMIOLOGIES ET ETIOLOGIE

25-50% des patients atteintes sarcoidose présentent une atteint ophtalmologique. Et peuvent avoir que sarcoidose purement oculaire sans manifestations systémiques.

Maladie survient entre 20 et 40 ans avec un pic périménopausique.

Il n'existe pas de préponderance de la maladie en fonction du sexe.

## SIGNES OCULAIRES

- **EN DEHORS DE L'UVéE**
- Toutes structures oculaires peuvent etre atteintes, avec par ordre de freq en dehors de l'uvée:
  - la cornée: kératite sèche, kératite interstitielle, kératopathie en bandelette
  - La conjonctive: granulomes conjonctivaux
  - la sclère: sclérite, épisclérite
  - l'orbite: glande lacrymale, muscle...
  - les voies optiques: odeme papillaire, granulome, NORB.

- **SIGNES OPTHALMOLOGIQUES**
  - Précipites cornéen en graisse de mouton et petits précipitées cornéens granulomateux et (ou **nodules irienes du bord pupillaire – KOEPPE ou du stroma – BUSACCA**
  - Nodules trabéculaires et/ou synéchie antérieur en toile de tente
  - Opacites vitréennes: effet banquise, chapelet de perles
  - Choroidite périphérique multifocale - lésions actives ou cicatricielles
  - Périphlebites segmentaires ou nodulaires ( taches de bougies) et/ou nmacroanévrismes au sein d'un oeil inflammatoire
  - Nodules de la papille/ granulomes et/ou nodule solitaire choroidien
  - Bilateralité

- **SIGNES PARACLINIQUES**
  - Anergie tuberculinique chez patient un anterieurment vacciné par le BCG ou ayant anterieuremnt un test +
  - Elevation de l'ECA – enzyme de conversion de l'angiotensine - sérique et/ou lysozyme sérique
  - Adénopathies hiliares bilaterales sur la radiographie du thorax
  - Perturbation du bilan hépatique - 2 parmi test suivantes: phosphatases alcalines, ASAT, ALAT, LDH ou GGT.
  - Tomodensitométrie throracique +

- **UVEITE SARCOIDOSIQUE**

- C'est la manifestation ophtalmologique la plus freq

  - **UVEITE ANTéRIEUR - 50-70% des cas**
    - Chronique, granulomateuse, uni-ou bilaterale.
    - Précipites en graisse de mouton
    - Nodules irienes - **KOEPPE**
    - Tyndall de CA
    - Synéchies iridocristaliniennes post.
    - Hypertonie oculaire. Chercher avec Gonio si trabéculite secondaire présence des granulomes sarcoidosiques puis goniosynéchies et l'évolution vers glaucome secondaire

  - **UVEITE INTERMEDIAIRE – 10 à 20% des cas – la siege initial de l'inflammation est la base du vitré**
    - **Tyndall vitréen**
    - **Oefs de fourmise / snow balls  – banquise**
    - Périphlebites segmentaires et focales oéripheriques
    - Complications: OMC, cataracte secondaire, vascularite occlusive péripherique

  - **UVEITES POSTERIEURES – 10-30% des cas**
    - Tyndall vitréen central
    - Atteintes rétiniennes : tâches de bougie périveineuses, périphlébites segmentaires et focales du pôle posterieur, engainement artériels, forme pseudo-tunorale, occlusion de branches veineuses, néovascularisation prérétinienne ou prepapillaire
    - Atteintes chroidinennes: granulomes chroroidiens en l'absence d'inflammation vitréenne, cicatrise pigmentées sous forme de choroidite multifocale, néovascularisation, oedeme maculaire cystoide, hyperhemie papillaire, granulome du NO.
