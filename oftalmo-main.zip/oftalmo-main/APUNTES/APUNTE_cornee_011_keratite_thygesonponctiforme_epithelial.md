---
categoria: apuntes
area: cornea
emoji: 👁️
seccion: Cornée
orden_seccion: 4
orden: 11
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-10-02
---
# Kératite Thygeson ponctiforme épithélial de Thygeson

La queratitis superficial de Thygeson es un transtorno idiopatico, infrceuente, bilateral, caracterizado por reagudizaciones y remisiones. Suelée afectar con mayor frecuencia a los adultos jovenes, aunque se producre a cualquier edad, y las recurrencias oueden producirse durante decadas. Aunque existen informes de aislamiento de virus, no han sido confirmados.

## DX

Los sintomas son atauqes recurrentes de irritacion, fotofobia y lagrimeo.

## SIGNOS

Lesiones epitheliales elevadas, irregulares, evidentes, granulares y grisaceas.

Puede existir une leve turbidez subepithelial, especialmente si se han utilizado antiviricos topicos.

La conjuntiva no resulta afectada y la vascularizacion no es caract. El DD mas habitial est hypersensibilidad estafilococica, epiteliopatia punctiforme o queratitis por adenovirus.

## TTT

## TOPICO

En casos leves, LA puede ser suficiente

Cortis comme DX 2xj pdt 2 sem puis 1xj pdt 2 sem. En algunos casos puede ser necesarios tt en dosis bajas de larga duracion 1x sem.

Pueden considerarse LDC en caso de contraindicacion cortis.

La queratectomia proporciona alivio a corto plazo pero es probable que haya recidiva.
