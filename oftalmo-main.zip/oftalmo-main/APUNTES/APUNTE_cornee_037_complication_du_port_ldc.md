---
categoria: apuntes
area: cornea
emoji: 👁️
seccion: Cornée
orden_seccion: 4
orden: 37
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-08-10
---
# Complication du port LDC

## COMPLICATION INFECTIEUSE

## FR

GENERAUX: DM, corticoides, immunosupresses

LOCAUX: blépharite, oeil sec, hypoesthesie cornéene.

Non respecte des consignes d'hygiene et etretien, non respecte du temps de port.

## ETIOLOGIES

Bacterienne

Amibienne ( piscines, lac...)

Fongique ( diabete, alcoolisme, immunosupression...)

## TT

-------> Consulter kératite infectieuse.

## COMPLICATIONS ALLERGIQUES

- **1.Conjonctivite giganto-papillaire**

- **FR:**
- Jeuna age
- Temps de port très long.
- Lentillle couverte de dépots, renouvellement peu frequent, d egrand diametre.
- Systeme de nettoyage insufissante.

- **SYMPTOMES**
- Souvent avec port de LDC souples
- Intolerance progressive aux lentilles, obligeant un retrait prémature dans la journée.

- **SIGNES**
- (éversion paupieres sup)
- Stade 1: légère hyperemie
- Stade 2: Papilles bien visibles <0,5mm.
- Stade 3:Papilles de 1 mm de diametre.

- **TT:**
- Collyre antiallergique ex: Opatanol 2xj pdt 10-15j.
- Modification du type de lentille, changement de produitd'entretien.

- **2.Allergies aux produits de entretien ( conservateurs, enzymes, antiseptiques)**

- **TT:**
- Privilegier le port de LDC jOURNALIERS.

## COMPLICATION MECANIQUES

- **1.Syndrome 3 heures – 9 heures( specifiques aux lentilles rigides )**

- **ETIOLOGIES VARIABLES**
- Secheresse ocualire relative, mauvaise clignement, mauvaiuse géometrie de la lentille ( trop appui au  niveuadu bord).

- **SYMPTOMES**
- STADE 1: KPS à 3h et 9h sans coalecense des lésions.
- STADE 2: KPS avec coalescense mais sans diffusion de fluo dans les couches profondes
- STADE 3: KPS denses localisées.
- STADE 4: opacification ou néovascularisation localisée.

- **TT**
- Modifications de la géométrie de la lentille, du rayon ( dans le sens de l'applatissement), du diametre ( plus grande ou petit)

- **Consequences d'une deterioration de la lentille ( déchiure/dépots).**

- **SIGNES**
- Néovascularisation cornéene superficielle.

- **TT**
- Porter des LDC journaliers, plus fines et rapport DK/e plus grand, ou passer au port de LDC rigides.

## COMPLICATIONS INFLAMMATOIRES

- **ETIOLOGIES**
- Réaction immunologique
- Liée au port de LDC ou endotoxines des bacteris, ou combinaison des deux.

- **SIGNES**
- Infiltrats normalment péripheriques souvent sans déficit épithelial

- **TT**
- Dans un premier temps: antibiotique topiques, lubrifiantes
- Dans déûxieme temps: +/- cortis topiques.
