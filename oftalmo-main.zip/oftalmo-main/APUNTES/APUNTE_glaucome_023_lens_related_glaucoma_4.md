---
categoria: apuntes
area: glaucoma
emoji: 🟢
seccion: Glaucome
orden_seccion: 5
orden: 23
fuente: OneNote del Dr. Castilla Martí
---
# Lens-related Glaucoma (4)

## 1-PHACOLYTIC GLAUCOMA

Intro:

Is a secondary glaucoma OAG ocurring in assoc with a hypermature cataract. Trab obstruction is caudes by high molecular-weight lens prot that leak through the **intact** capsule through mircoscopic openings into aqueous humour leading to trb obtsruction. Macrophages containing lens prot may also contribute.

NOT TO CONFUSE WITH PHACOGENIC UVEITIS - an autoimmune granulomatous reaction to exposed lens proteins ocurring with compromised lens capsule.

DX

Presentation with pain + vision poor due to cataract long ago.

STATUS

Corneal oedeme + hypermature cataract and deep Ant chamber. Maybe floating white particules in AC - lens prot containing macrophages and can form psuedohypopyon.

Llack of keratic precipitates (which are present in phacoantigenic glaucoma)

Intact lens capsule (contrats to lens particle and phacoantigenic glaucomas)

GONIO: open angle with lens derived material and inflamm cells mostly inf.

TT:

After IOP is controlled medically and proteinpues mat is whased out from the AC and cataract is removed.

**LENS PARTICLE GLAUCOMA and PHACOANTIGENIC GLAUCOMA :** forerly known ans phacoanaphylactic both represent a inflammatory reaction to a violation of the capsular bag and large scale leakage of lens proteins.

## 2-LENS PARTICLE GLAUCOMA

-presents indolently

Macroscopic lens pieces - classically retaines lens fragments after catarcat surgery
