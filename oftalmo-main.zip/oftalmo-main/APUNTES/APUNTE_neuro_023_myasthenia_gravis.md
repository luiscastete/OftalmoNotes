---
categoria: apuntes
area: neuro
emoji: 🧠
seccion: Neuro-Ophta
orden_seccion: 8
orden: 23
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-08-24
---
# Myasthenia gravis

Maladie auto-immune rare ( incidence 15/million), caracterise par une faiblesse et fatigabilité musculaire en raison d'une anomalie de la plaque neuro-motrice avec etteinte des recepteure à l'acetylcholine post-synaptique.

## SYMPTOMES

## OCULAIRES

Diplopie variable

Ptosis variable

Troubles oculomoterus multiples sans pattern évocateur

## SYSTEMIQUES

Faiblesse musculaires

Atteintion en cas de signes bulbaires: risques vital avec changement de la voix, fausses routes, difficultes respiratoires.

## SIGNES

Troubles oculomoteurs ne correspondant pas à une atteinte classique d'une parésire d'un nerf cranien type III,IV,VI.

Importante variabilité des mesures et fatigabilité

Diplopie et ptosis variables avec péjoration à la fatigue, effort physique, chaleur.

Pas d'atteinte pupillaire

## ETIOLOGIES

Maladie auto-immune d^étiologie inconnue

Differentes formes, grandes heterogeneité des présnetataions cliniques

Signes oculaires comme présentetation initiale dans 70% des cas, devient généralisée dans 80% des cas dans 2 ans.

Clasiiquement distribution bimodale: pics vers 20 ans ( F>H) ET 60 ANS (H>F), plus de risque d'évolution vers une forme grave et génélralise dans les formes tardives.

Frequente anomalie thymique associé ( hyperplasie majoritairement, thymome dans 15% des cas) et autres maladies auto-immunes (4-10% de maladie de Basedow).

## STATUS
