---
categoria: apuntes
area: pediatria
emoji: 🧸
seccion: Pediatrie
orden_seccion: 9
orden: 29
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-03-29
---
# Cephalées+ENFANT

Cephalées de longue dure chez enfant:

REFLEX:

1.**Hypermetropie? pas compenes**e---faire NIDEK – add Lunnettes

2.HTIO? FO: oedeme papillaire? Mias tu ne peux pas ecarter HTIC sinon que cuando tu vois pouls veneus papillaire

Sino causes ophtalmiques
