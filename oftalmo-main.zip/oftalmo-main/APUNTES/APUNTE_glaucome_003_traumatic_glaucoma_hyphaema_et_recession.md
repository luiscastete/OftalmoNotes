---
categoria: apuntes
area: glaucoma
emoji: 🟢
seccion: Glaucome
orden_seccion: 5
orden: 3
fuente: OneNote del Dr. Castilla Martí
---
# Traumatic Glaucoma (Hyphaema et recession)

## 🩸Hyphaema

## ✅Definición

Presencia de sangre en cámara anterior, habitualmente post-trauma.

## ⚠️Riesgos asociados

• ↑ PIO por obstrucción trabecular con hematíes, incluso en hyphaema pequeño.

## 📊Pronóstico según tamaño

| **Tamaño del hyphaema** | **% Complicaciones** | **AV final > 6/18** |
|---|---|---|
| < 50% cámara anterior | 20% | 80% |
| > 50% cámara anterior | 80% | ~33% |

🧠 **Clave**: El pronóstico visual depende sobre todo del daño retiniano inicial.

## 🚨Complicaciones importantes

## 🔴Elevación de PIO

• PIO > 50 mmHg ➝ **riesgo de daño al nervio óptico**.

• Elevación mantenida ➝ daño estructural ocular.

## 🎯Tinción corneal

• Se produce cuando los hematíes penetran el **estroma corneal**.

• Suele ocurrir si el hyphaema es grande y **la PIO permanece elevada más de 4-5 días**.

• **Consecuencia**: coloración rojiza-marrón persistente de la córnea, potencialmente irreversible.

## 💥Hemorragia secundaria

• Aparece entre **días 3–5** tras el trauma inicial.

• Suele ser más severa que el sangrado primario.

• Asociada a peor pronóstico visual.

## 🧬Casos especiales: Hemoglobinopatía falciforme

• Mayor riesgo de ↑ PIO por:

• Obstrucción trabecular con hematíes deformados.

• Oclusión vascular.

## 🧠Flashcards rápidas

## ¿Qué PIO pone en riesgo el nervio óptico?

→ Más de 50 mmHg.

## ¿Cuándo puede aparecer hemorragia secundaria?

→ Entre 3 y 5 días tras el trauma.

## ¿Qué indica el tamaño del hyphaema?

→ Pronóstico visual y riesgo de complicaciones.

## ¿Qué pacientes tienen riesgo elevado de complicaciones?

→ Pacientes con hemoglobinopatía falciforme.

## ¿Qué es la tinción corneal y cuándo aparece?

→ Infiltración de hematíes en el estroma corneal. Aparece si hay ↑PIO mantenida > 4-5 días.

## Tratamiento

## 🧾General

• ❗ **Descartar trastornos de coagulación** (p. ej., hemoglobinopatías).

• 🔎 **Suspender anticoagulantes** previa evaluación por medicina interna.

• 🚫 **Evitar AINEs** como analgésicos.

• 🩺 Si hay hemoglobinopatía (ej. anemia falciforme): consultar con hematología antes de usar fármacos de riesgo.

• 🏥 **Ingreso hospitalario** si hyphaema es grande.

• 🚷 **Reposo absoluto innecesario**, pero limitar actividad.

• 🛌 Mantener posición **sentado/semiincorporado**, incluso al dormir.

• 🥽 Usar **protección ocular** (parche o escudo).

## 💊Tratamiento médico

| **Fármaco o medida** | **Indicación / Comentario** |
|---|---|
| **Antiglaucomatosos tópicos** | β-bloqueantes, prostaglandinas, ± CAI tópicos (según PIO). |
| **CAI sistémicos** | ❌ Evitarlos en hemoglobinopatías falciformes. |
| **Mioticos** | ❌ Contraindicados: ↑ bloqueo pupilar, ↑ inflamación. |
| **Hiperosmóticos sistémicos** | Uso restringido. Precaución en falciformes. |
| **Esteroides tópicos** | Reducen riesgo de sangrado secundario y controlan inflamación. |
| **Atropina** | Mantiene midriasis en hyphaema grande, ↓ riesgo de rebleed. |
| **Antifibrinolíticos sistémicos** | Ej: ácido tranexámico o ACA. Considerar si sangrado recurrente. |

## 🔬Procedimientos

• **Fotocoagulación con gonioscopio**: sobre puntos de sangrado angular (diferir 5–6 días).

• **Paracentesis o evacuación quirúrgica (5% casos)**:

• Indicado si:

• Hyphaema total.

• PIO > 50 mmHg por > 2 días.

• PIO > 35 mmHg por > 5 días.

• Objetivo: evitar tinción corneal, atrofia óptica, sinequias anteriores periféricas, glaucoma crónico.

💡 **Precaución especial** en:

• Sickle-cell: PIO moderadamente elevada → daño severo.

• Glaucomatosos previos.

• Niños pequeños (riesgo de ambliopía).

⚠️ En casos graves, puede ser necesario un procedimiento filtrante.

## 📤Alta y seguimiento

• 🕶️ Evitar cualquier riesgo de trauma ocular durante varias semanas.

• ⚠️ Reaparece el sangrado ➝ **revisión inmediata**.

## 🧠Flashcards rápidas

## ¿Qué medicamentos evitar en pacientes con hemoglobinopatía falciforme?

→ CAIs sistémicos, mioticos, hiperosmóticos (usar con mucha precaución).

## ¿Cuándo se indica cirugía en hyphaema?

→ Hyphaema total, PIO > 50 mmHg x 2 días o > 35 mmHg x 5 días.

## ¿Qué fármaco ayuda a evitar hemorragia secundaria?

→ Esteroides tópicos y atropina (en hyphaema grande).

## ¿Qué antifibrinolíticos se pueden usar?

→ Ácido tranexámico o ácido aminocaproico (en casos con riesgo alto de rebleed).

## 🔍Angle Recession (recesión angular)

## ✅Definición

Ruptura del **rostro del cuerpo ciliar** (entre raíz del iris y espolón escleral) secundaria a trauma contuso.

## 📊Epidemiología y Riesgo

| **Característica** | **Detalle** |
|---|---|
| Relación con hyphaema | Muy frecuente tras hyphaema traumático |
| Riesgo de glaucoma | <10% a los 10 años |
| Mecanismo de ↑ PIO | Daño trabecular (no por la recesión en sí) |
| Riesgo significativo si ≥ 3 cuadrantes | Recesión < 3 cuadrantes: raro que cause glaucoma |

## 🧪Diagnóstico

## 👁️Presentación clínica

• Glaucoma crónico **unilateral** en ojo con antecedente de trauma.

## 🔬Examen en lámpara de hendidura

• Signos de trauma previo: ej. ruptura de esfínter pupilar.

## 🔎Gonioscopia

• Fase inicial: **ensanchamiento irregular** de la banda del cuerpo ciliar.

• Casos tardíos: recesión puede quedar oculta por **fibrosis** y/o **hiperpigmentación**.

## 🩺Tratamiento

| **Opción terapéutica** | **Comentario** |
|---|---|
| Tratamiento médico | Como en glaucoma de ángulo abierto secundario. A menudo limitado. |
| **Trabeculoplastia láser** | ❌ Ineficaz. |
| **Trabeculectomía + antimetabolito** | ✅ Tratamiento quirúrgico principal. |
| **Shunt o ciclofotocoagulación** | Considerar si fracasa la trabeculectomía. |

## 📅Seguimiento

• Revisión **anual de PIO** si hay **> 2 cuadrantes afectados**.

• Reasegurar al paciente: **riesgo bajo** de desarrollar glaucoma secundario si recesión limitada.

## 🧠Flashcards rápidas

## ¿Qué estructura se rompe en la recesión angular?

→ Cara del cuerpo ciliar (entre raíz del iris y espolón escleral).

## ¿Qué porcentaje desarrolla glaucoma tras 10 años?

→ Menos del 10%.

## ¿Cuál es el hallazgo clave en gonioscopia inicial?

→ Ensanchamiento irregular de la banda del cuerpo ciliar.

**¿Cuál es el tratamiento quirúrgico de elección si el manejo médico falla?**

→ Trabeculectomía con antimetabolito.
