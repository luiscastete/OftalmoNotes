---
categoria: apuntes
area: urgencias
emoji: 🚑
seccion: URGENCES---TRAUMATOLOGIE
orden_seccion: 2
orden: 13
fuente: OneNote del Dr. Castilla Martí
fecha: 2022-08-31
---
# Lesions benignes conj

Kyste conjontivale

60% recidive

Att:

Add optava 3-5xj pdt 3 mois

PC si pejoration

Add debridement kyste?
