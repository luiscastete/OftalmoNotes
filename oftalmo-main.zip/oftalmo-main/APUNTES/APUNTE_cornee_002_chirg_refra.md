---
categoria: apuntes
area: cornea
emoji: 👁️
seccion: Cornée
orden_seccion: 4
orden: 2
fuente: OneNote del Dr. Castilla Martí
---
# Chirg Réfra

Discussion avec Dr Hardy

Stable depuis 2ans?

>60 ans – pas possible

40-50ans jeune prebyte – pas bonne candidate

Faire topo si tu veux pour t'amuser pas la facturer – noter si pas signes de contraindications directe

Coute

PKR- 2000 environ chaque oeil

LASIK 3000 environ chaque oeil

Livres bien

Sinjab pentacam

Chirurgie réfractive de la myopie - Volume 1 (Chirurgie réfractive) - Cati albou ganem
