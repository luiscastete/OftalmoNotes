---
categoria: apuntes
area: glaucoma
emoji: 🟢
seccion: Glaucome
orden_seccion: 5
orden: 33
fuente: OneNote del Dr. Castilla Martí
---
# Fármacos 2.0

📘 **Apuntes de Oftalmología – Fármacos para Disminuir la PIO**

Todos los tratamientos buscan reducir la Presión Intraocular (PIO) mediante dos vías principales:

- 1. Reduciendo la producción de humor acuoso
- 2. Aumentando su drenaje

1️⃣ **Fármacos que DISMINUYEN la PRODUCCIÓN de humor acuoso**

| **Grupo** | **Ejemplos** | **Mecanismo** |
|---|---|---|
| **Betabloqueantes** 🧊 | Timolol, Betaxolol | Inhiben receptores β2 en procesos ciliares |
| **Agonistas α2** 🔺 | Brimonidina, Apraclonidina | ↓ producción y ↑ drenaje uveoescleral |
| **Inhibidores anhidrasa carbónica** 💧 | Dorzolamida, Brinzolamida, Acetazolamida | Inhiben formación de humor acuoso |

2️⃣ **Fármacos que AUMENTAN el DRENAJE del humor acuoso**

| **Grupo** | **Ejemplos** | **Mecanismo** |
|---|---|---|
| **Prostaglandinas** 🌙 | Latanoprost, Bimatoprost | ↑ drenaje uveoescleral (remodelación M.E.) |
| **Colinérgicos (mióticos)** 🧠 | Pilocarpina | Contracción del músculo ciliar → ↑ drenaje trabecular |
| **ROCK inhibitors** 🚧 | Netarsudil | Relajan trabéculo → ↑ drenaje trabecular |

3️⃣ **Combinaciones frecuentes**

Se utilizan para mejorar la adherencia y potenciar efectos:

- Timolol + Dorzolamida
