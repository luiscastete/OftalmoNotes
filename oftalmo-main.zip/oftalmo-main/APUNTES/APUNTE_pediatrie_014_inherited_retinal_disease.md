---
categoria: apuntes
area: pediatria
emoji: 🧸
seccion: Pediatrie
orden_seccion: 9
orden: 14
fuente: OneNote del Dr. Castilla Martí
---
# Inherited Retinal disease

## FUNDUS FLAVIMACULATUS

## STARGARDT DISEASE

AR STGD1 AND abca4

Juvenile macular degenration with flecks

MOST COMMON HEREDITARY MACULAR DYSTROPHY

Onset on 2th decade with decrease vision

SYMPT: decreased vision and nictalopia.

FINDINGS: bilat, yellow-white flecks at level of RPE, chnage with time, foveal atrophy, bulls eye maculopathy, may have salt and peper pigmentary changes of peripheral retina.

PATHOLOGY: RPE massively thickened by accumulation of lipofuscin.

FA: dark choroid resulting from acumulation of lipofiscin in RPE.

AF: hyperautofluoroscence as a result of excessive lipofuscin accumulation in RPE, hypo in areas of RPE atrophy.

ERG and EOG: normal

TT: gene therapy + contraindication of VITAMIN A!!!!!

## BEST DISEASE - VITELLIFORM DYSTROPHY - AD

## FAMILIAL DRUSEN
