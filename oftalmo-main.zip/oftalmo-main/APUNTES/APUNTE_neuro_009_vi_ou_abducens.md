---
categoria: apuntes
area: neuro
emoji: 🧠
seccion: Neuro-Ophta
orden_seccion: 8
orden: 9
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-12-20
---
# VI ou Abducens

ATTEINTE NUCLEAIRE

N'entraine pas de diplopie car il y a une atteinte des deux yeux avec une paralyse horizontale du regarde – limitation de l'abduction ipsilaterale et de l'adduction contralaterale.

ATTEINTE INFRANUCLEAIRE

Deficit de l'abduction avec ésodéviation.

Diplopie plus marque en vision de loin qu'en vision de près.

DD: myasthenia oculaire, orbitopathie dysthyroidiwnnw, myosite, autres cause orbitaires: Tumeur, hématome, traumatisme...

Recherche des signes localisateurs: sinus caverneux – si atteinte associe de la chaine sympathetique, spouffle vasculaire- ou orbite
