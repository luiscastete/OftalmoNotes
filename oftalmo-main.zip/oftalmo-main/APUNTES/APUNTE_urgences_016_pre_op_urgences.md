---
categoria: apuntes
area: urgencias
emoji: 🚑
seccion: URGENCES---TRAUMATOLOGIE
orden_seccion: 2
orden: 16
fuente: OneNote del Dr. Castilla Martí
fecha: 2024-02-15
---
# PRE-OP URGENCES

Bonjour à tous,

Je me permets de vous rappeler la procédure que vous devez suivre pour les patients nécessitant une opération en urgence, durant et en dehors des heures ouvrables. En effet il y a eu quelques hésitations ces derniers temps. D’abord il existe des documents internes que vous pouvez (devez) consulter : 2102.DIR.507 et 3305\_DIR\_008

Pendant les heures ouvrables :

Une fois la décision opératoire prise :

- S’informer des **médicaments** du patient (anticoagulant ?), de son état de **jeûne**
- Faire signer un **consentement** au patient
- Lui donner un **questionnaire de santé** pour qu’il le remplisse aussitôt.
- Faire une d**emande opératoire** (rapidement car nécessaire pour les étiquettes et feuilles de facturation)
- La (le) chef(fe) de clinique appelle le **8585** (bloc op) pour fixer l’heure
- La (le) chef(fe) de clinique appelle le **8800** (anesthésiste de garde) pour l’informer
- L’assistant informe l’étage de l’existence du patient (8327)
- PUIS TOUS LES PATIENTS SONT CONDUITS à LA CPA, MÊME SI ALR, MAC, SÉDATION. C’est l’endroit où le dossier est constitué et contrôlé (étiquettes, facturation, demande opératoire imprimée, consentement signé, questionnaire de santé rempli complètement, feuille d’anesthésie)

Quand vous montez directement au 7 étage, les infirmières et les anesthésistes doivent courir un peu partout pour récolter les données manquantes. Perte de temps.

Hors des heures ouvrables et week-ends :

- S’informer des **médicaments** du patient (anticoagulant ?), de son état de **jeûne**
- Faire signer un **consentement** au patient
- Lui donner un **questionnaire de santé** pour qu’il le remplisse aussitôt.
- Faire une d**emande opératoire**
- L’opérateur appelle **l’anesthésiste de garde** (8800) pour fixer une heure d’intervention (coup de bistouri)
- L’opérateur appelle **l’instrumentiste de garde** (liste), l’informe de l’heure et la modifie si pas possible pour l’instrumentiste (habite trop loin…)
- L’opérateur rappelle l’anesthésiste pour la fixation définitive du coup de bistouri
- L’instrumentiste informe l’aide de salle et l’anesthésiste informe l’infirmier(e) de garde
- L’assistant informe l’étage (8327) puis monte le patient à l’étage, avec le dossier complet, sauf la feuille d’anesthésie.

Si l’opération est programmé le lendemain :

- S’informer des **médicaments** du patient (anticoagulant ?).
- Faire signer (ou donner pour qu’il le lise) un **consentement** au patient et qu’il le ramène le lendemain
- Lui donner un **questionnaire de santé** pour qu’il le remplisse et le ramène le lendemain
- Regarder le programme opératoire du lendemain pour estimer quand le patient pourra être pris
- Fixer l’heure de son arrivée en conséquence ou selon la demande de l’opérateur (rétine) (minimum 2 heures avant l’heure estimée de l’opération )
- Si le programme est complet, les opérations urgentes se font à la suite du programme. Donc laisser les patients en tout cas boire le matin avant de venir, sauf le lait et les jus de fruits.
- Au matin, informer l’anesthésiste de garde (8800) et le bloc opératoire (8585)

Je reste à votre disposition si ces quelques mots ne sont pas assez clairs pour tous.

André Vial

Anesthésiste

8853
