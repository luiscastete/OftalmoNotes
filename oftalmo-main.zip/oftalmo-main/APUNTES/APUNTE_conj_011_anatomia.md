---
categoria: apuntes
area: cornea
emoji: 💧
seccion: Conj + Episclere + Sclere
orden_seccion: 25
orden: 11
fuente: OneNote del Dr. Castilla Martí
---
# Anatomia

## 👁️Capas de la conjuntiva

La **conjuntiva** es una membrana mucosa **transparente y delgada** que recubre parte del globo ocular y el interior de los párpados. Se divide en:

- **🔹1. Epitelio conjuntival (más superficial)**

  - **Estratificado** (2 a 5 capas de células)
  - Contiene:
    - **Células caliciformes** → secretan mucina (parte de la película lagrimal)
    - **Células inmunes** (linfocitos, macrófagos)

  - Varía en espesor y número de células según la localización

- **🔹2. Estroma (lámina propia)**

  - **Tejido conectivo laxo**
  - Ricamente vascularizado y con linfáticos
  - Se divide en:
    - **Capa superficial adenoide** → contiene tejido linfoide (contribuye a la inmunidad ocular)
    - **Capa profunda fibrosa** → conecta con el tejido subyacente (Tarsos o esclera)

## 📍Localización anatómica de la conjuntiva
