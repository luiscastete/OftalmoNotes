---
categoria: apuntes
area: uveitis
emoji: 🔥
seccion: Immuno-infectio
orden_seccion: 7
orden: 21
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-07-24
---
# UP- Uvéite postérieure

## Definition

Inflammation oculaire pouvant être cécitante et touchant uen ou plusieurs dees structures suivantes: La choroide, la rétine, le vitré, les vssx rétinniens.

## Comment referer

Referer toute UP, avant investigations, immediantement en unite immuno.

## SYMPTOMES

- **OCULAIRES:**
  - Rougeur
  - Douleur profonde
  - Photophobie
  - Vision flou
  - Pas de secretions
  - Myodesopsies

- **Systemiques:**
  - +/- Cutanés
  - +/- respiratoires
  - +/- neurologiques
  - +/- digestifs
  - -toujours faire AA par systems

## SIGNES

Vitrite ( snowball tu chercher surtout en bas)

Cicatrice/ Foyer de chorioréthinite ( ex: toxoplasmose)

Vasculite ( engainement vasculaire, saut de calibre)

Periphlebite ( vasculite veineuse)

Hémorragies périvasculaires

Oedeme rétinien

Neurorétine: Bartonella dans 30% cas

Papillite
