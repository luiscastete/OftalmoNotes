---
categoria: apuntes
area: cornea
emoji: 💧
seccion: Conj + Episclere + Sclere
orden_seccion: 25
orden: 7
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-11-30
---
# C. VIRALES

## VIRALE

Inflammation de la conjonctive tarsale et bulbaire d'origine virale.

## SYMPTOMES

Oculaires:

- Brûlures,
- Sensation CE
- Photophobie
- Larmoiment

Generaux:

- Rhume
- Pharyngite récent.

## SIGNES

- HC ( aspect rose)
- secretionns claires
- **FOLLICULES au niveau tarse**
- Hémorragies sous-conj ( pétéchies)
- PSM à eversion
- Infiltrats cornéens sous-épitheliaux ISE ( nummuli, fluo – apres 1-2 sem debut)
- Oedeme/rougeur palpebrale
- Adenopathie pretragienne palpable.

## Etiologies

+ Freq:

-Adenovirus ( 52 sérotypes) :

- Viral conjunctivitis secondary to adenoviruses is highly contagious, and the risk of transmission has been estimated to be 10-50%.
- Conjonctivite à adenovirus 90% cas.
- Kératoconjonctivitis épidemique - serotype 3,8,19,37.
- Fievre pharyngoconjonctivale serotype 3,4,7
