---
categoria: apuntes
area: retina-quirurgica
emoji: 🪡
seccion: Ret Chirg
orden_seccion: 6
orden: 11
fuente: OneNote del Dr. Castilla Martí
---
# ASTEROID HYALOSIS vs SYNCHYSIS SCINTILLANS

## 🧠REGLA MAESTRA

## “ASTEROID = SKY FIXED — SCINTILLANS = SNOW GLOBE”

## 🌌ASTEROID HYALOSIS →SKY FIXED

💡 Piensa en el **cielo nocturno**:

- Las estrellas están **fijas**
- Son **blancas**
- No caen
- El cielo (ojo) sigue funcionando perfectamente

👉 Traducción clínica automática:

- Blanco = **calcio**
- Fijo = **adherido**
- Ojo bueno = **visión conservada**
- Usualmente unilateral
