---
categoria: apuntes
area: pediatria
emoji: 🧸
seccion: Pediatrie
orden_seccion: 9
orden: 3
fuente: OneNote del Dr. Castilla Martí
---
# CODE LIMA

POUR TOUS LES ENFANTE

En Suisse, le **Code LiMA** (ou Liste des moyens et appareils, LiMA) fixe les conditions de remboursement des aides visuelles (lunettes, lentilles) dans le cadre de l’assurance de base (LAMal).

Voici ce que j’ai pu vérifier concernant les âges limites et les conditions applicables — mais notez que **cela concerne le remboursement**, pas la légalité de prescrire des lunettes en tant qu’ophtalmologiste (ce qui vous est de toute façon permis, sauf disposition cantonale particulière) :

## Ce que dit la LiMA pour les lunettes / lentilles

- **Jusqu’à 18 ans révolus**
  - Les lunettes / lentilles correctrices (position 25.01.01.00.1 LiMA) sont remboursées jusqu’à l’âge de 18 ans révolus, **une fois par an**.
  - Il faut une **ordonnance d’un ophtalmologue** pour obtenir le remboursement.
  - Les adaptations (par exemple les changements minimes de correction pendant l’année) peuvent être faites par un opticien-optométriste, mais le montant remboursable reste limité.
- **Cas “spéciaux” après 18 ans**
  - Pour les modifications de la réfraction dues à une maladie, une opération, un trouble, etc., **quel que soit l’âge**, une prise en charge (position 25.02.01.00.1) est possible une fois par an par œil.
  - Le contrôle de la **myopie progressive** est désormais inclus dans la LiMA à partir du **1er juillet 2024** : les caisses maladie paient jusqu’à **850 CHF par an**, **jusqu’à l’âge de 21 ans révolus**, à condition que certaines conditions soient remplies (preuve de progression, indication de longueur axiale, etc.).
  - Cette disposition (position 25.02.04.00.1 LiMA) ne s’applique pas après 21 ans révolus.
