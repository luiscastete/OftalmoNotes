---
categoria: apuntes
area: neuro
emoji: 🧠
seccion: Neuro-Ophta
orden_seccion: 8
orden: 17
fuente: OneNote del Dr. Castilla Martí
---
# nystagmus

## 1. Definición

- **Nystagmus** = movimiento ocular **rítmico, repetitivo e involuntario**.
- Consta de dos fases:
  - **Slow phase** → el ojo se desvía (por un desequilibrio vestibular o por un movimiento de seguimiento).
  - **Fast phase** → el ojo corrige con una sacada rápida.
- Se nombra según la **dirección de la fase rápida** (ej. “nistagmo hacia la derecha”).

## 2. Tipos principales

- **a) Según la fisiología**

  - **Fisiológico**:
    - **OKN (optokinetic)** → al mirar un paisaje en movimiento.
    - **Vestibular (VOR)** → cuando giras la cabeza.

  - **Patológico**:
    - Aparece en enfermedades neurológicas, vestibulares, oftalmológicas.

- **b) Según la forma**

  - **Pendular**: no hay fase rápida, ambos movimientos son de igual velocidad → típico de nistagmos congénitos o sensoriales.
  - **Jerk (sacádico)**: con slow + fast phase → típico en vestibular o neurológico adquirido.

- **c) Según la dirección**

  - **Horizontal** (más común).
  - **Vertical** (ej. nistagmo hacia arriba en lesiones cerebelosas).
  - **Torsional** (rotatorio, ej. lesiones tronco/cerebelo).
  - **Mixto**.
