---
categoria: apuntes
area: retina-medica
emoji: 🩸
seccion: Ret Med y coroides
orden_seccion: 19
orden: 10
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-07-24
---
# OBVR

Interruption du retour veineux dans uen veine à son croisement artérioveineux (A-V). L'arteriole et le veine partagent une gaine adventincielle commune, l'arteriosclérose artériolle peut provoquer une écrasement de la veine rétinienne +/- important. Si c'est importante il crée occlusion de branche veineuse.

2 formes:

- Non-ischemique-forme plus frequente avec meilleur pronostic
- ischémique mauvaise pronostic,

## SYMPTOMES

BAV monoculaire variable en fonction du territoire atteint:

- Maculaire: BAV brutale, indolore, métamorphopsies.
- Péripherique: Scotome vs Asymtomatique.
- Hémiveine: deficit CV altitudinal

## SIGNES

## Similaires OVCR mais limitées au territoire de drainage veine.

Localisés au territoire atteint- en forme triangulaire:

- Hémorragies superficielles en flammèche et/ou profondes
- Tortuosite et dilatation veineuse – si étendu sur l'hémi-rétine: atteinte hémiveine.
- Nodules cottoneux

## ETIOLOGIES

Compression de la veinule par épaississement artériolosclérotique au niveau d'un croisement A-V.

>60 ans + FRCV artériosclérose ++

Facteurs de risque à recherche: identiques OVCR: age, HTA, FRCV ppal, tabac, DM, Hypercholesterolemis, hypertonie ocualire-rare, état prothrombotique-pilule contraceptive.

## STATUS-BILAN

AV-TIO

LAF-FO Dilaté

OCT maculaire: +/- oedeme maculaire.
