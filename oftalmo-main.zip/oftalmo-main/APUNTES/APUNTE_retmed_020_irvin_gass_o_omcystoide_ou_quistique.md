---
categoria: apuntes
area: retina-medica
emoji: 🩸
seccion: Ret Med y coroides
orden_seccion: 19
orden: 20
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-07-24
---
# Irvin Gass o OMCystoide ou Quistique

Acumulation de liquide extracellulaire dans la region maculaire avec formation d'espace cystoide caracteristiques dans la couche plexiforme externe suite chirg phako sans complication.

Typiquement dans les 3 premiers mois post-op avec ++ incidence entre 4-6sem.

Indicence tres variable entre 0-4% y augmente a 20% en case de complication pdt chirg.

## SYMPTOMES

BAV

Métamorphopsies

## SIGNES

Perte de reflet fovéolaire

Epaississement de la fovea avec ou sans présence de kystes

Plis fovéolaires

Exsudats profonds (selon origine)

D'autres signes peuvent être présnets et liés à l'étiologie

## ETIOLOGIES

- Post-op cataracte--appelé SYNDROME IRVINE-GASS: survient souvent dans les premiers mois.
- Post-op tout autre op.
- Cascade inflam. Pour trauma mecanique --liberation pontanglandinas ++ inflam--rupture barriere retiniene sanguin--acumulation liquide.
- Uveite
- Télangiectasies macualires ou rétinnienes
- Rétine pigmentaire
- DMLA neovasculaire
- Macroanevrismes
- Maculopathie radique
- CRSC
- Neovssx choroidiennes ( CNV) DE TOUTE ORIGINE
- Optic pit
- Rétinopathie hypertensive
- Rétinopathie diabetique
- Occlusion de la veine centrale de la rétine ou branche
- Membrane épiretinienne
- Médicaments: épinephrine, dipivefrine et analogue de la prostanglandine.
