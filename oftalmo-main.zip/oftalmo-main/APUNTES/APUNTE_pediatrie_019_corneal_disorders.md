---
categoria: apuntes
area: pediatria
emoji: 🧸
seccion: Pediatrie
orden_seccion: 9
orden: 19
fuente: OneNote del Dr. Castilla Martí
---
# Corneal Disorders

MEGALOCORNEA

Horizontal diameter of cornea >12mm in newborns (adults >13mm)

MICROCORNEA

Horizontal diameter <9mm in newborns (<10mm diameneter in adults)

## ANTERIOR SEGMENT DYSGENESIS - mesodermal dysgenesis syndromes

Bilateral, congenital, hereditary disorders afffecting anterior segment structures

AD - AUTO SOM DOMINANTE

Mutaciones freq- PITX2 y FOXC1

## 🔬Concepto

Grupo de anomalías congénitas por alteración en la **migración/diferenciación de células de la cresta neural**.

Pueden afectar córnea, iris, ángulo y trabéculo → predisposición a **glaucoma**.

Grupo de **anomalías del desarrollo del segmento anterior** por defectos en la **cresta neural**.

Se considera un espectro: **Axenfeld anomaly → Rieger anomaly → Rieger syndrome**.

- **AXENFELD ANOMALY**
  - 1.Posterior embryotoxon - anterior displacement Schwalbe line - found in 15% of healthy individuals -
  - 2. with iris processes to scleral spur - adherencias iridocorneales - iris adherido a trabeculo.
  - 50% develop glaucoma
  - AD

  - Banda de Schwalbe prominente y desplazada (posterior embryotoxon).
  - Adherencias iridocorneales (iris adherido a trabéculo).

  - **Hallazgo:** posterior embryotoxon (línea de Schwalbe desplazada anteriormente).
  - Con o sin sinequias iridocorneales.
  - Puede ser aislado o parte del espectro Axenfeld–Rieger.
  - Generalmente asintomático, pero puede asociar glaucoma.

- **RIEGER ANOMALY**
  - Axenfeld (post embryotoxon + adherencias iridocorneales)
  - Plus:
    - Iris hypoplasia with holes
    - Glaucoma

    - Todo lo anterior + alteraciones del iris: hipoplasia del estroma, corectopia, policoria.

    - Incluye lo anterior + **alteraciones iridianas**:
      - Hipoplasia del estroma.
      - Corectopia (pupila excéntrica).
      - Polycoria (pupilas múltiples).
    - Glaucoma en hasta 50%.

- **RIEGER SYNDROME**
  - Rieger anomaly
  - Plus:
    - Mental retardation and systemic abnormalities - dental, craniofacial, genitourinary , redundant periumbilical skin and skeletal.

  - Rieger anomaly + **alteraciones sistémicas**:
    - Hipodoncia, dientes cónicos.
    - Anomalías faciales (telecanto, hipoplasia maxilar).
    - Anomalías umbilicales.

  - Mutaciones **PITX2, FOXC1**.

- **ALAGILLE SYNDROME**
  - Axenfeld anomaly ( post embryotoxon + adherencias iridocorneales)
    - Plus:
      - pigmentary retonopathy
      - Corectorpia
      - Systemic abnormalities:
        - Absent deep tendon reflex, abnormal facies, pulmonic valvular stenosis, peripheral stenosis, biliar hypoplastia nad skeletal abnormalities.
        - ERG and EOG are abnormal.

  - Trastorno multisistémico (colestasis crónica por paucidad de conductos biliares + anomalías cardíacas + faciales).
  - Oculares:
    - Posterior embryotoxon en 95% de casos.
    - Anomalías adicionales del segmento anterior.

  - Mutación **JAG1**.

- **PETER ANOMALLY
  - Central corneal leukoma (opacity resulting from defect in post cornea stroma and descemet membrane with absence of endothelium )
  - With iris adhesions
  - Lens involvement - catracts
  - 50% develop glaucoma
  - May have: microcornea, aniridia, microphtalmia, persistent hyperplastic primary vitreous
  - Also assoc:
    - Cardiac, craniofacial and skeletal abnormalities

  - Defecto congénito corneal.
    - **Hallazgos:**
      - Opacidad central corneal congénita.
      - Ausencia de Descemet y endotelio en zona central.
      - Adherencias iridocorneales ± lenticorneales.
  - Asociado a microftalmos y glaucoma congénito.
  - Forma severa: **Peters plus syndrome** (alteraciones sistémicas + retraso mental).

  - Is due lozalized absence of corneal endothelium and descemets memebrane underneath a central corneal opacity.
  - Is due to a failure of lens vesicle to separate from the surface ectoderm

- **⚡Claves EBO**

  - Todas son **anterior segment dysgenesis** → cresta neural alterada.
  - **Axenfeld anomaly = solo embriotoxon + sinequias.**
  - **Rieger anomaly = embriotoxon + iris anómalo.**
  - **Rieger syndrome = + anomalías sistémicas (dientes, cara, ombligo).**
  - **Peters anomaly = opacidad corneal central congénita + adherencias.**
  - **Alagille = embriotoxon + enfermedad hepática y cardiaca sistémica.**

- SCLEROCORNEA

- DESCEMET TEAR / RUPTURE
