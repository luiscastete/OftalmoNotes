---
categoria: apuntes
area: glaucoma
emoji: 🟢
seccion: Glaucome
orden_seccion: 5
orden: 18
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-03-27
---
# Posner–Schlossman syndrome (PSS) also known as glaucomatocyclitic crisis (GCC)

INTRO:

Rare condition caract by recurrent attacks of UNILATERAL acute raised IOP associated with mild ant uveitis.

Mecanism is speculated to be acute trabeculitis and there is evidence that infection possibly by CMV or Helicobacter Pylori may play a role.

Porstaglandins are involved in the pathogenesis.

Typicaly affects YOUNG MIDDLE AGE ADULTS MALES.

UNILATERAL EPISODES although 50% of patients have involvements of other eye at dif times.

Intervals between attacks vary but ususally become longer with time.

Patients should be followed even after attacks have subsided, bcs a significant proportion will develop chronic IOP elevations.

DX

ACUTE RISE + demonstrable CMV or other viral ant uveitis.

Presentation: mild discomfort, haloes around lights ans slight blurring of vision in one eye ans sometimes redness.

SIGNS: few ant chamber cells + fine white central keratic precipitates + injections + mild corneal epithelial oedeme + MYDRIASIS + IOP >40mmHg out of proportion to irirtis to hours to weeks. Elevation precedes the inflammatory signs.

GONIOSCOPY: showns open angle without PAS.

Glaucomateis optic neuroptahy is uncommon.

TT:

Topical steroids are used to control inflammations (only in active inflamm not prophylacticaly) + aqueous supressants ( Bbloq or IAC or Alfa ag. ) +/- topical or oral non-steroids anti-inflammatory if necesary. BENEFICTS OF ANTIVIRAL TT IS UNCLEAR.
