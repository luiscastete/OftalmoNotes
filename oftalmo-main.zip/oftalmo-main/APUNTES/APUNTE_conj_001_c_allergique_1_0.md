---
categoria: apuntes
area: cornea
emoji: 💧
seccion: Conj + Episclere + Sclere
orden_seccion: 25
orden: 1
fuente: OneNote del Dr. Castilla Martí
fecha: 2022-08-31
---
# C. Allergique 1.0

**Conjonctivites allergiques saisonnieres (CAS) et perannuelles (CAP) sont les formes plus freq.**

## PHYSIOPATHOLOGIE

**ATOPIC KERATOCONJONCTIVITIS -AKC - affects both sup and inf conjonctiva with papilae scarring.**

## Afffects more males

**Akc OCCURS YEAR-ROUND INDIVIDUALS SUSCEPTIBLE TO ATOPY - ASTHME, ECZEMA, ATOPIC dermatitis…**

## AKC - always active vs VKC - variable during the year

## SYMPT

Rougeur, démangeaison, secretions claires, bilat, terrain atopique, rhinite associe freq.

## SIGNES

Oedeme palpebrale, HC, PAPILLES conj, Chemosis, secretions claires, muqueses, absence d'adenopathie pre-auriculaire.

## ETIOLOGIE

Perannuelle: poils animaux, acariens: bon pronostic

Saisonniere: pollen, graminées: bon pronostic, recrudescences saissonnieres.

Giganto-papillaire: ex intol aux prod entretien LDC: bon pronostic.

## STATUS

AV-TIO-LAF

## BILAN

Aucun

Si severe ou chronique: adresser chez allergoloque
