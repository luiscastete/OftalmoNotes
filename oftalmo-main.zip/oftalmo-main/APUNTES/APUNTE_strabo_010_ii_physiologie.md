---
categoria: apuntes
area: pediatria
emoji: 👀
seccion: Strabo-logie
orden_seccion: 22
orden: 10
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-09-26
---
# II.Physiologie

ACTIONS MUSCULAIRES ET CHAMP D'ACTION

Actions musculaires

L'action musculaire est definie comme la force musculaire exercée sur le globe. En fonction l'origine et de l'insertion du muscle sur le globe, une même muscle peut présenter des actions primaires, secondaires et tertiaire ainsi qu'un fonction orbitaire.

| MUSCLE | ACTION PRIMAIRE<br>(funcion fisiologica) | ACTION SECONDAIRE | ACTION TERTIAIRE | ACTION ORBITAIRE (efecto mecanico del musculo sobre el globo) |
|---|---|---|---|---|
| MEDIAL Rectus-MR | adduction | - | - | Rétraction (traccion globo ocular dentro de la orbita) |
| MEDIAL LATERAL-DL | Abduction | - | - | Retraction (traccion globo ocular fuera de la orbita) |
| DROITE SUPERIEUR-DS | élevation | incyclotorsion | adduction | retraction |
| DROIT INFERIEUR-DI | abaissement | excyclotorsion | adduction | retraction |
| OBLIQUE SUPERIEUR-OS | incyclotorsion | abaissement | abduction | protraction |
| OBLIQUE INFERIEUR-OI | excyclotorsion | elevation | Abduction | protraction |

\*\*\*la'ction d'abduction des obliques est un phenomene accesoire. En cas de section du mucle droite laterale, aucune mouvement d'abduction n'estreleve.
