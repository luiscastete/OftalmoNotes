---
categoria: apuntes
area: glaucoma
emoji: 🟢
seccion: Glaucome
orden_seccion: 5
orden: 32
fuente: OneNote del Dr. Castilla Martí
---
# Farmacos 1.0 b

Siguiendo orden regla nemotectica de "**B**eatriz **C**hef del **A**lfa **P**repara **C**ordero **M**edio **R**osa **HYPER**picante"

## 🧠Frase mnemotécnica

**“Beatriz, la Chef del Alfa, preparó cordero con Medio Rosa Hiperpicante.”**

## 📋Tabla resumen

| **Palabra clave** | **Grupo farmacológico** | **Medicamentos representativos** | **Mecanismo principal** |
|---|---|---|---|
| **Beatriz** | Betabloqueadores | Timolol, Betaxolol | ↓ Producción de humor acuoso |
| **Chef** | Inh. Anhidrasa Carbónica | Dorzolamida, Acetazolamida | ↓ Producción de humor acuoso |
| **Alfa** | Alfa-agonistas | Brimonidina, Apraclonidina | ↓ Producción + ↑ Drenaje uveoescleral |
| **Preparó** | Prostaglandinas | Latanoprost, Travoprost | ↑ Drenaje uveoescleral |
| **Cordero** | Colinérgicos | Pilocarpina, Carbacol | ↑ Drenaje trabecular |
| **Medio** | Mioticos |  |  |
| **Rosa** | ROCK inhibitors | Netarsudil, Ripasudil | ↑ Drenaje trabecular + ↓ Producción leve |
| **Hiperpicante** | Hiperosmóticos | Manitol, Glicerol | ↓ Volumen vítreo (osmótico, agudo) |

## 🔄Truco fonético (ordenado por frase)

| **Palabra clave** | **Grupo farmacológico** | **Terminación o raíz clave** | **Truco fonético** |
|---|---|---|---|
| **Beatriz** | Betabloqueadores | **“-lol”** | Si contiene **”-lol”** → Betabloqueador |
| **Chef** | Inh. Anhidrasa Carbónica | **“-zolamida”** | Si termina en **”-zolamida”** → Inh. anhidrasa |
| **Alfa** | Alfa-agonistas | **“-onidina”** | Si termina en **”-onidina”** → Alfa-agonista ✅ |
| **Preparó** | Prostaglandinas | **“-prost”** | Si termina en **”-prost”** → Prostaglandina |
| **Cordero** | Colinérgicos | – | No tienen patrón fonético fijo (se memorizan directo: *pilocarpina*, *carbacol*) |
| **Rosa** | ROCK inhibitors | **“-sudil”** | Si contiene **”-sudil”** → ROCK inhibitor |
| **Hiperpicante** | Hiperosmóticos | – | Si suena raro y es urgente → Hiperosmótico 😅 |
