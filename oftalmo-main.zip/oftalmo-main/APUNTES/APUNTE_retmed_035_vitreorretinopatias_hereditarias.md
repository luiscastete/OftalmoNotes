---
categoria: apuntes
area: retina-medica
emoji: 🩸
seccion: Ret Med y coroides
orden_seccion: 19
orden: 35
fuente: OneNote del Dr. Castilla Martí
---
# Vitreorretinopatias hereditarias

## 🧬2. VITREORRETINOPATÍAS HEREDITARIAS

Estas enfermedades comparten:

- Anomalías congénitas del vítreo.
- Catarata progresiva de inicio temprano.
- Alto riesgo de desprendimiento de retina (DR) regmatógeno.

## 🔹2.1. Síndrome de Stickler

- **Gen afectado**: COL2A1 (tipo 1, más común) y COL11A1 (tipo 2).
- **Clínica sistémica**: hipoplasia facial, paladar hendido, alteraciones articulares.
- **Vítreo**:
  - COL2A1: vítreo membranoso.
  - COL11A1: vítreo fibrilar.

- **Ocular**:
  - Catarata en cuña desde la infancia.
  - DR regmatógeno en >50%.
  - Degeneración lattice, roturas gigantes.

- **Tto**:
  - Crioterapia profiláctica.
  - Vitrectomía si DR o hemorragia vítrea.
  - Phaco con fluidos bajos.

## 🔹2.2. Síndrome de Wagner
