---
categoria: apuntes
area: pediatria
emoji: 👀
seccion: Strabo-logie
orden_seccion: 22
orden: 13
fuente: OneNote del Dr. Castilla Martí
---
# Strabisme accomodatif

En **estrabología para el EBO**, aparte de síndromes raros tipo **Duane/Brown/Möbius**, lo que más suele caer son los **estrabismos infantiles comunes y acomodativos**. Te resumo lo esencial que debes tener en tu radar para el examen:

## 1.

## Esotropia acomodativa

- **Clásica en niños hipermétropes**.
- **Mecanismo**: exceso de convergencia por esfuerzo acomodativo.
- **AC/A ratio** (accommodation–convergence / accommodation):
  - **Normal AC/A**: endotropía igual de lejos y cerca → corrige con gafas hipermetropía.
  - **Alto AC/A**: endotropía solo de cerca → gafas + bifocales (add +2.50/+3.00).
  - **Mixta**: ambas componentes.
- **Tratamiento**: corrección completa hipermetropía + bifocales si necesario. Cirugía si hay componente residual.
- **EBO pearl**: “Hipermétrope + endotropía + mejora con gafas = esotropía acomodativa”.

## 2.

## Esotropia congénita (infantile esotropia)

- Aparece < 6 mois.
- Angle large (>30Δ), constant.
- Signes associés: nystagmus latent, DVD (dissociated vertical deviation), surélévation adduction.
- **Pas liée à la réfraction** → lunettes ne corrigent pas.
- **TTT**: chirurgie (avant 2 ans idéalement pour binoculaire).
