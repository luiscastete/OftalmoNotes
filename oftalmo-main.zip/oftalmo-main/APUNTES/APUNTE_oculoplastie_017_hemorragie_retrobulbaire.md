---
categoria: apuntes
area: oculoplastica
emoji: 🫥
seccion: Oculo-Plastie
orden_seccion: 3
orden: 17
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-08-16
---
# Hémorragie rétrobulbaire

Hémorragie dans l'espace rétrobulbaire ( derriere l'oeil)

## SYMPT

Douleurs oculaires/rétrobulbaires sévères, d'apparition aigue

BAV

## SIGNES

Exophtalmie avec réssistnace à la retropulsion

Tumefaction palpebrale

HTIO

Troubles de la vision des couleurs ( dyschromatopsie)

Pupilles hyporéactives/aréactives/RAPD

Limitation oculomotricite +/- douleurs

## ETIOLOGIES

Trauma: contusion orbitaire +/- fracture orbitaire

Malformation arterio-veineuses, varicosités orbitaires.

Iatrogene:

- Chirurgie oculoplastique: blépharoplastie sup ou inf ( plus probable avec lipectomie).
- Chirurgie ORL ou maxilo-faciale: tt au niveau des sinus paranasaux ou de fractures maxillaires et orbitaires.
- Anesthesie péri-ou rétrobulbaires.

## PHYSIOPATHOLOGIE

Hémorragie rétro-orbitaire---augmentation de la TIO ( syndrome du compartiments = urgence médicale)----ischémie du nerf optique et blocage de la perfusion oculaire----processusocclusif veineux ou arteriel—perte visuelle permanente.

## STATUS

AV-ISHIHARA

TIO pupilles-oculomotilité-Hertel

Inspection des paupieres: rougeur? Tuméfaction? Tension des tissus mous?

Rétropulsion douleurs?

FO: myosis: pulsation artere centrale de la rétine-procede l'occlusion?

Oedeme papillaire? Plis choroidiens?

## BILAN

DX clinique

Si menace visuelle ou fonction du NO: Traiter avant de faire des investigations complementaires (imageries)

## TT

Si signes de neuropathie optique---URGENCE

- Si s/p chirurgie palpebrale ou orbitaire: ablation des sutures cutanées pour permettre le drainage du sang accumulé.
- Décompression orbitaire chirugicae avec canthotomie laterale et catholyse inferieure.

Si présence d'hémorragie active: coagulation/cautérisation.

- Si HTIO mais absence de neuropathie optique compressive: taritement conservateur pour faire baisser la pression.

## SUIVI

Hopitalisation
