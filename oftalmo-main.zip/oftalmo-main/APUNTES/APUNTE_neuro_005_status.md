---
categoria: apuntes
area: neuro
emoji: 🧠
seccion: Neuro-Ophta
orden_seccion: 8
orden: 5
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-09-05
---
# STATUS

## Systeme afférent: Fonction

AV

Ishihara

Pupille: iso-iso, RAPD?

Grille Amsler

CV par confrontation + interpretation examens

## Systeme éfferent: structure

FO: NO

OCT

## Systeme éfferent: moteur

Fixation: stable ou inestable

Saccades: rapide-précise vs lente-imprecise

Poursuite: Lise vs pas lise

Refelex vestibulo-occulaire:

Convergence

Anisocorie
