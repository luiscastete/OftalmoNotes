---
categoria: apuntes
area: cornea
emoji: 👁️
seccion: Cornée
orden_seccion: 4
orden: 36
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-01-30
---
# Overwear syndrome

AA LDC:

Type LDC?

Combien heures LDC?

Dorm avec LDC?

Port LDC dans la douche/Bains thermaux/piscine/sauna ce dernier temps? Baigne sur le lec ce dernier temps?

Épisode similaire dans le passée?

Dernier porte LDC?

A changer boite LDC quand?

Ttt:

Add floxal gtt 4-8xj 48h

Add optava 4-8xj

PC dans 48h si fluo – add DF 3xj schema deressif.

Att:

Floxal gtt 4xj

FML 4xj

Optava au besoin

PVA le soir

2 controle

Si va bien

Stop F

FML 3xj pt 4j puis 2xj pdt 4j puis 1xj pdt 4j

Poursuivre optava et PVA

PC dans 3-4 sem car bcp de FML et va bien controle.

Si 2FML alors tu peut diminuer 1xj pft 5j et pas controle mais
