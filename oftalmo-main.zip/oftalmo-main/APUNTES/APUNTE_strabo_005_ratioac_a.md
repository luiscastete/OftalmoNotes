---
categoria: apuntes
area: pediatria
emoji: 👀
seccion: Strabo-logie
orden_seccion: 22
orden: 5
fuente: OneNote del Dr. Castilla Martí
---
# ratio AC/A

## 🔎¿Qué es el ratioAC/A?

**AC/A** = **Convergence Accommodation / Accommodation**

(o en español: **Relación Convergencia Acomodativa / Acomodación**)

Mide cuánta **convergencia ocular** (en prismas) se produce por cada **dioptría de acomodación**.

## 🧠¿Por qué importa?

Cada vez que enfocamos un objeto cercano, ocurren **tres cosas a la vez** (reflejo acomodativo):

- **Acomodación**: se ajusta el cristalino para enfocar.
- **Convergencia**: los ojos giran hacia adentro (aducción) para mirar el mismo punto.
- **Miosis**: se contrae la pupila.

👉 El **AC/A** nos dice **cuánto se mueven los ojos hacia dentro por cada dioptría de enfoque (acomodación)**.

## 🧮¿Cómo se expresa?

\\text{AC/A} = \\frac{\\text{convergencia (prismas Δ)}}{\\text{acomodación (dioptrías)}}

Por ejemplo:

- Si por cada 1 D de acomodación hay 4Δ de convergencia → **AC/A = 4:1**
