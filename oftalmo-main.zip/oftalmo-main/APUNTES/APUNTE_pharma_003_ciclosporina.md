---
categoria: apuntes
area: general
emoji: 💊
seccion: Pharmacologie Farma
orden_seccion: 23
orden: 3
fuente: OneNote del Dr. Castilla Martí
---
# Ciclosporina

## 🧪Ciclosporina – Conceptos Clave

## 📌¿Qué es?

- Es un **inmunosupresor** derivado de un hongo (*Tolypocladium inflatum*).
- Se clasifica como **inhibidor de la calcineurina**.
- Disponible por vía **oral, intravenosa y tópica (colirio)**.

## ⚙️

## ¿Cómo funciona?

- Inhibe la **activación de linfocitos T**, especialmente los CD4+.
- Se une a una proteína intracelular llamada **ciclofilina** → este complejo inhibe la **calcineurina**.
- La calcineurina es una fosfatasa que activa el factor **NFAT** necesario para producir **IL-2** → al inhibirla:
  - ↓ producción de **interleucina-2 (IL-2)**
  - ↓ proliferación y activación de **linfocitos T**
  - ↓ **respuesta inmune e inflamatoria**

## 👁️

## Usos en oftalmología
