---
categoria: apuntes
area: uveitis
emoji: 🔥
seccion: Immuno-infectio
orden_seccion: 7
orden: 13
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-07-24
---
# UI- Uvéite intermédiare

## Definition

**UVEITE INTERMEDIARIE:** Uvéite dont le site d'inflammation primaire est le vitré ou la rétine périphérique (SUN). Peut être associe ou non à une cause infectieuse ou une pathologie inflammatoire systémique.

- **PARS PLANITE** ( synonyme **uvéite intermédiaire idiopathique du sujet jeune**):  entité UI spécifique.
- Définie par l'association de: SNOWBALLS + de SNOWBANKING  et absence de d'étiologie.
- 15% des uvéite des adulte et 20% uvéite de l'énfant.

UI DOIVENT ETRE REFEREES UNITE IMMUNO afin de décider investigations et du ttt. SI WE référer a CDC de garde qui contactera l'équipe de immuno-.

## SYMPTOMES

Myiodésopsies ++

Flou visuel progressif ( rarement brutale)

Diminution AV si OMC.

## SIGNES

Souvent bilatérales  même si asymétrique

## Cellules inflam dans vitre (surtout base inf).

**Haze vitréen** ( concentration forte de proteines plasmatiques, rupture de barriere hémato-retinniene).

SNOWBALLS- œufs de fourmi-nodules de cellules inflammatoires

SNOWBANKS-banquise en regard de la pars plana indentation de la pas plana

Périphlébite périphérique ( pas de gros troncs)

- COMPLICATIONS:
  - Œdème maculaire
  - Œdème papillaire
  - Cataracte sous-capsulaire
  - Déchirure/ décollement de la retine
  - Hémorragie intravitréenne
  - Néovascularisation prepapillaire ou préretinienne
