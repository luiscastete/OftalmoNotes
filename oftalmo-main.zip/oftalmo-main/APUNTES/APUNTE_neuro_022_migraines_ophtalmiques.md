---
categoria: apuntes
area: neuro
emoji: 🧠
seccion: Neuro-Ophta
orden_seccion: 8
orden: 22
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-03-06
---
# Migraines ophtalmiques

## Presentation clinique

## Auras visuelles

- Épisode récurrentes, completement réversibles.
- Apparition progressive >5min.
- Symptomes <1h, souvents 30 min.
- Accompagnes ou suivis dans les 60 mins d'un cephalées.
- Manifestations binocolaires.
- Phenomens visules positifs:
  - scotome scintillant (typique),
  - phosphenes,
  - lignes scintillantes.
  - vision caleidoscopique
- Phénomens visuels negatifs:
  - vision flou,
  - brumeusem hémianopsie laterale homonyme.
- Hallucinations visueles ( enfants )
- Persistent les yeux fermes.

## Céphalées

- Surviennent avant, pdt ou après ( 90% cas ) aura visuelle.
- Les auras visuelles peuvent etre accompagnes de :
  - Cephalées migraineuses\*\*\*
  - Cephalées non migraiuneuses
  - Abscense de cephalées.

## Cephalées migraineuses ( criteres ICHD-3)

- Typiquement unilaterale, mais peut etre bilaterale.
- Siege souvent temporal.
- Douleurs pulsatiles, intensité moderée à sévere, agravée par activité physique, accompagnées de nausées et ou vomissement, photophobie et phonophobie. Elle dure 4-72h.
