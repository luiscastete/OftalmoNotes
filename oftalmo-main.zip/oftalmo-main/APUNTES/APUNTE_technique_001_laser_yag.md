---
categoria: apuntes
area: general
emoji: 🛠️
seccion: Technique-Procedures
orden_seccion: 13
orden: 1
fuente: OneNote del Dr. Castilla Martí
fecha: 2022-11-23
---
# Laser YAG

## CAPSULOTOMIE

## Procedure

## -Defocus posterieur P300.

## Preparation dilatateur et hypotenseur

## Régler l'appareil

## -Puissance: 0.6-1.0mj

## -Mode: single burst.

1 goutte Oxybuprocaine ou Tetracaine + placer verre capsulo.

Technique de découpe: en cercle ou en croix.

Ttt:

Dexafree UD 2xj 1 sem + Indophtal 2xj 1 sem + Optava 3xj 1sem.

Ou

Dexafree UD 4xj 1 sem + Dexafree UD 2xj 1 sem + Dexafree UD 1xj 1 sem +  Optava 3xj 1sem.

PC dans 1 mois avec AV et FO dilaté. (10-14j SELON ROBIN - BON DILATATION POUR EXAM PERIPHERIE - dech? )

Complications rares:

-inflamm modère.

-HTIO (exceptionnel)

-complications rétiniens indirectes: OMC < 1% - IRVIN GASS, DPV, péjoration maculopathie sous-jcente, DRR - regarder peripherie.

Luxations IOL-sac capsulaire ( exceptionnel: si prédisposition PEX, trauma, myopie forte).

!!! EVITER CAPSULO 3M après Chirg IOL car risk deplacement IOL !!
