---
categoria: apuntes
area: uveitis
emoji: 🔥
seccion: Immuno-infectio
orden_seccion: 7
orden: 8
fuente: OneNote del Dr. Castilla Martí
fecha: 2024-05-22
---
# Tâches blanches au FO

## CHORIORETINOPATHIE DE BIRDSHOT

La Choriorétinite de Birdshot est un uvéite posterieur bilaterale qui touche 1% des patients avec uvéite et 7% patients avec uvéite posterieur.

Atteint sujets caucasiennes entre 15-79 ans.

Symptomes: flou visuelle, myodesopsies, nyctalopie, photopsies, restriction de CV ainsi d'anomalies de la vision des couleurs.

On observe typiquement des lésions de BIRDSHOT qui cicatrisent comme des traces de plomb de chasse – origine du nom de cette pathologie- "tir au pigeon" XD.

Ce sont des taches chroidiennes bilaterales, oblongues ou rondes- ou de formes irréguliers ou linéaires-, hypopigmentées au pôle postérieur et en péripherie rétro-équatorielle. Les lésions mésurent ¼ à un ½ diametre papillaire. Elles sont localisées autour du nerf optique et au niveau des arcades vasculaires; elles sont plus nombreuses en rétine nasale.

Le SA este le siege dûne infammation modérée, les synéchies posterieurs et les précipitées rétrocornéens sont absents.

Une hyalite modérée- absent lésion de type banquise ou oefs de fourmi- est présnete avec un oedeme de papille et une vascularite - périphlebite au pole post-

Une OMC en OCT est présente chez 30-35% des patients. C'est la cause la plus freq de BAV.\*\*

## ANGIOGRAPHIE A LA FLUORESCEINE ET AU VERT D'INDOCYANINE

AF montr généralement des lésions hypofluorescents dans la phase initiale. Dans le temps plus tardifs, les lséions deviennet souvent hyperfluorescentes. L'af est utile ppour montrer les fuites pariétales provennat des vssx rétinnienes et l'hyperfluorescence papillaire qui est quasi tjsr présent. Elle montre aussi un OMC et peut retrouver une néovvs choroidienne.

LAngio au vert indocyanine (ICG) est plus utile que AF pour localiser les lesion BRIDSHOT qui aparaisent plus nombreuses qu'a l'examen du FO ou à AF. Ces lesions hypocyanescentes, rondes-ovalaires, sont surtout visibles pdt la phase intermédiare de l'ICG.

## DIAGNOSTIC

**Dx d'abord clinique et par la présence de l'antigen leucocytaire humain HLA-A29.**
