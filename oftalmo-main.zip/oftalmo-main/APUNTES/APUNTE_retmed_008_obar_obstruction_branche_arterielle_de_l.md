---
categoria: apuntes
area: retina-medica
emoji: 🩸
seccion: Ret Med y coroides
orden_seccion: 19
orden: 8
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-04-24
---
# OBAR – Obstruction Branche arterielle de la retine

## DEFINITION

Occlusion branche arterielle retinniene est revele par examen qui revele une oedeme retiniene en secteur dans territoire vasculaire irrigue par artere.

Le pronostic visuele est meilleure que pour OACR avec deficits du CV resideules dans territoire concervne par OBAR. BAV variable selon territoire concerne. La macula peut ne pas etre atteinte

## SYMPTOMES

- BAV monoculaire variable en fonction du territoire atteint:
- Maculaire: BAV brutale, indolore, métamorphopsies.
- Peripherique: scotome vs asymptomatique
- Hemiveine: déficit CV altitudinal.

## SIGNES

- Similaires OACR

## STATUS-BILAN

- AV-TIO
- LAF-FO dilaté
- OCT mac: +/- oedeme maculaire
- ANGIOGRAPGIE FLUORESCEINE: precise le site l'obstacle.

## MALADIE HORTON: ne peut pas donner OBAR car artere trop petites.

- BILAN SANGUIN DE BASE:
- FSC, VS, CRP, electrolytes ( NA et K ), créatinine.
- Cholesterol, triglycerides, Glycemie à jeun, HbA1c, Electrophorese des proteines plasmatiques, Fibrinogene.

## OCCLUSION D'UNE ARTERIOLE RETINNIENE

- Se revele par presence de nodules cotonneux, lesion blanc jaunatre au niveau de la retine superficielle.
- Provienent de obstruct d'une arteriole et donc d'ischemie resultant dans couches fibres nerveuses. Cette atteinte ne s'accompagne pas de BAV.
