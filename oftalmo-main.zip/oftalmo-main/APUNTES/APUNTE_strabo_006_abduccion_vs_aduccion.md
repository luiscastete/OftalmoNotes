---
categoria: apuntes
area: pediatria
emoji: 👀
seccion: Strabo-logie
orden_seccion: 22
orden: 6
fuente: OneNote del Dr. Castilla Martí
---
# 🔄 Abducción vs Aducción

## 🔄Abducción vs Aducción (movimientos oculares y musculares)

## 📌

## Definiciones básicas

## 

| **Término** | **Significado** | **Etimología** | **Ejemplo ocular** |
|---|---|---|---|
| **Abducción** | Movimiento **hacia fuera** del eje medio del cuerpo | *ab-* = lejos de | El ojo se mueve hacia la **oreja** |
| **Aducción** | Movimiento **hacia dentro**, hacia la línea media | *ad-* = hacia | El ojo se mueve hacia la **nariz** |

## 👁️Aplicación en oftalmología (movimientos oculares)

- **Abducción ocular** → El ojo gira **hacia temporal**.
  - Músculo implicado: **recto lateral**
  - Inervado por el **VI par (nervio abducens)**
- **Aducción ocular** → El ojo gira **hacia nasal**.
  - Músculo implicado: **recto medial**
  - Inervado por el **III par (nervio oculomotor)**
