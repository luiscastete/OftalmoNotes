---
categoria: apuntes
area: cornea
emoji: 👁️
seccion: Cornée
orden_seccion: 4
orden: 38
fuente: OneNote del Dr. Castilla Martí
---
# Keratite toxique

Ulcere chronique quand duration > 3 sem

Allergies plutôt aux conservateurs que au principe actifs!

Poser la question si cobsomation de drogues recreatives.
