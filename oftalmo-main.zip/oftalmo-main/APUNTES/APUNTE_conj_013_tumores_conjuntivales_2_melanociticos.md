---
categoria: apuntes
area: cornea
emoji: 💧
seccion: Conj + Episclere + Sclere
orden_seccion: 25
orden: 13
fuente: OneNote del Dr. Castilla Martí
---
# Tumores Conjuntivales 2.Melanociticos

- Clasificación rápida al inicio
- Detalles histopatológicos del melanoma
- Tabla comparativa final para facilitar el repaso

## 🧠

## 5.2. Tumores melanocíticos conjuntivales – RESUMEN CLAVE

## 📊

## Clasificación rápida

| **Tipo** | **Elevación** | **Pigmentación** | **Riesgo de malignización** |
|---|---|---|---|
| **Nevus** | Sí | Variable | Bajo (1%) |
| **Melanosis adquirida primaria (PAM)** | No | Sí | Variable (0–90%) |
| **Melanosis adquirida secundaria** | No | Sí | Nulo |
| **Melanoma conjuntival** | Sí | Variable | Alto (15–30% metástasis) |

## 🟤

## 5.2.1. Nevus conjuntival

- **Tumor melanocítico benigno más frecuente.**
- Tipos histológicos: **juncional**, **compuesto**, **subepitelial** (depende de la edad).
- **Aparición**: infancia o adolescencia.
- **Localización**: bulbar, limbo, plica, carúncula.
- **Pigmentación variable** (30% amelanóticos).
- **Quistes intralesionales** en 50% (dato típico).
- Factores de sospecha: crecimiento en adultos, localización inusual, vasos prominentes, sin quistes.

- **Riesgo de malignización**: bajo (1%).
- 🩺 **Manejo**: observación si no hay signos de sospecha.

## ⚫

## 5.2.2. Melanosis conjuntival

## ➤

## Congénita

- **Epitelial (efélides)**: aumento de pigmento, sin proliferación. Estables, sin malignización.
- **Subepitelial (melanosis oculi)**: afecta epiesclera/esclera. Asociada a nevus de Ota (± afectación meníngea, uveal, orbitaria). Riesgo bajo de malignización (1/400).

## ➤

## Adquirida

📍 **PAM (Melanosis adquirida primaria)**

- Proliferación intraepitelial de melanocitos. Análogo al lentigo maligno.
- Clínica: parche pigmentado plano, unilateral, en caucásicos de edad media/avanzada.
- ⚠️ Puede progresar a **melanoma** en 13–46% si hay **atipia**.

🔬 **Histopatología**:

- **PAM sin atipia**: sin riesgo de malignización.
- **PAM con atipia**:
  - Atipia basal → 20% progresión.
  - Células epitelioides → 75%.
  - Extensión pagetoide → 90%.

🩺 **Manejo**:

- <2 h del reloj → seguimiento.
- Biopsia + crioterapia si signos de alarma o extensión.

📍 **Melanosis adquirida secundaria**

- Aumento de melanina **sin proliferación** melanocítica.
- No tiene potencial maligno. Típico en razas oscuras, bilateral, perilímbica.

## ⚠️

## 5.2.3. Melanoma conjuntival

## 🔬

## Histopatología

- Invasión del **estroma** por melanocitos atípicos.
- Tipos celulares:
  - **Poliédricas pequeñas**.
  - **Fusiformes**.
  - **Epitelioides** (peor pronóstico).
  - **Balonizadas**.
- Tinción inmunohistoquímica: S100, HMB-45, Melan-A.

## 📋

## Clínica

- Masa elevada pigmentada (o amelanótica), con vasos nutricios.
- 74% surgen de PAM, 7% de nevus, 19% de novo (más agresivos).
- Localización más frecuente: bulbar interpalpebral.

## ⚠️

## Factores de mal pronóstico

- De novo, no bulbar, grosor >2 mm, ulceración, recidiva, BRAF+.

## 📉

## Pronóstico

- Metástasis: 15% (5 años), 25% (10 años).
- Mortalidad: 30% a 10 años.
- Sitios metastásicos: pulmón, hígado, cerebro.

## 🩺

## Tratamiento

- **Cirugía no-touch** + crioterapia de márgenes.
- **Radioterapia adyuvante**: estroncio, rutenio o yodo.
- **MMC**: adyuvante o en PAM extensa.
- **Inmunoterapia**: inhibidores BRAF/MEK, anti-PD-1 (nivolumab, pembrolizumab).

## 📑Tabla comparativa resumen

| **Característica** | **Nevus** | **PAM** | **Melanosis secundaria** | **Melanoma conjuntival** |
|---|---|---|---|---|
| Origen | Melanocitos | Melanocitos intraepiteliales | Epitelio pigmentado | Células melanocíticas malignas |
| Elevación | Sí | No | No | Sí |
| Pigmentación | Variable | Sí | Sí | Variable (hasta 20% amelanótico) |
| Frecuencia | Alta | Media | Alta en razas pigmentadas | Baja |
| Riesgo maligno | Bajo (1%) | Variable (13–90%) | Nulo | Alto (30% mortalidad a 10 años) |
| Localización típica | Bulbar/limbar | Bulbar ± multifocal | Perilímbica bilateral | Bulbar interpalpebral |
| Hallazgos típicos | Quistes, móvil | Placa pigmentada plana | Pigmentación estable | Masa elevada, vasos nutricios |
| Tratamiento | Observación ± cirugía | Seguimiento ± cirugía | Ninguno | Cirugía + crioterapia + radioterapia |
