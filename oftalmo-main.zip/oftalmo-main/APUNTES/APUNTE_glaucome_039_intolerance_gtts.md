---
categoria: apuntes
area: glaucoma
emoji: 🟢
seccion: Glaucome
orden_seccion: 5
orden: 39
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-11-10
---
# Intolerance gtts

Add wash-out:

Add rinçages nacl 3xj + optava gtt 8xj + FML gtt 2xj pdt 5-7j

PC add une autre antui-HTA:

Change a sans conservaterus ou type.
