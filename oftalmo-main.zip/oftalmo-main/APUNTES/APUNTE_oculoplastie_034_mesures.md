---
categoria: apuntes
area: oculoplastica
emoji: 🫥
seccion: Oculo-Plastie
orden_seccion: 3
orden: 34
fuente: OneNote del Dr. Castilla Martí
fecha: 2024-08-09
---
# mesures

Medidas más importantes a considerar durante el examen clínico en oculoplastia, junto con sus referencias estándar:

## MEDIDAS OJO ABIERTO

- **Hendidura Palpebral (HP)**
- Definición: Distancia entre el margen palpebral superior e inferior.
- Medida Normal: 9-12 mm.
- Evaluación: Observa si hay retracción palpebral, ptosis o lagoftalmos.

- El **PRDI / HERTEL**
- se refiere a la **Posición Relativa del Ducto Intraorbitario** o **Índice de la Posición Relativa del Conducto Intraorbitario**. Es un parámetro que se utiliza en la evaluación de la posición del globo ocular en relación con las estructuras óseas de la órbita, particularmente en el contexto de cirugías orbitarias, evaluación de exoftalmos o en casos de fracturas orbitarias.
- Aplicaciones del PRDI:
  - **Exoftalmos**: Determinar si existe protrusión del globo ocular (exoftalmos) midiendo la distancia entre la parte más anterior de la córnea y el reborde orbitario lateral.
  - **Endoftalmos**: Evaluar si el ojo está hundido en la órbita, especialmente útil en el diagnóstico de fracturas del suelo orbital o de la pared medial.
  - **Asimetría Orbitaria**: Comparar la posición del globo ocular entre ambas órbitas, útil en la planificación de cirugías reconstructivas.
- Evaluación:
  - **Normalmente**: El globo ocular debería estar centrado en relación con la apertura orbital.
  - **Anormalidades**: Cualquier desviación significativa del PRDI puede indicar la necesidad de intervenciones quirúrgicas, como la descompresión orbitaria o la corrección de fracturas.
- El PRDI es esencial en oculoplastia, ya que ayuda a cuantificar la posición del ojo dentro de la órbita, orientando tanto el diagnóstico como el tratamiento quirúrgico.

3.  **Margen Reflexo Corneal (MRD1 y MRD2)Margin reflex distance**

- MRD1: Distancia entre el centro del reflejo corneal y el margen del párpado superior.
- MRD2: Distancia entre el centro del reflejo corneal y el margen del párpado inferior.
- Medidas Normales:
  - MRD1: 4-5 mm.
  - MRD2: 4-5 mm.
- **Evaluación**: Determina la severidad de la ptosis o retracción.

- **Superior platform show:** distancia entre pliegue palpebrale sup. Y borde libre parpebrale

- **Lateral hooding:** distancia entre borde cil inf. Y borde libre palpebrale.

## MEDIDAS OJO CERRADO

6.  **Lid Crease** se refiere al **pliegue palpebral** o **pliegue del párpado superior**. OJO CERRADO

- Lamelle anterieur: distancia antre borde palpebrale libre y borde inf. Cejas.

se refiere al pliegue visible en el párpado superior y se mide como la distancia desde el margen palpebral superior hasta el pliegue, delimitando la parte móvil del párpado de la parte inmóvil.

- **Anatomía Normal**:
  - **Hombres**: La posición normal del pliegue palpebral superior suele estar entre 7-8 mm por encima del margen palpebral.
  - **Mujeres**: Se encuentra normalmente entre 8-10 mm por encima del margen palpebral.
  - Esta diferencia se debe a las variaciones anatómicas y estéticas entre los sexos.
  - **Variabilidad Étnica**:
    - En individuos de origen asiático, el pliegue palpebral puede estar más cerca del margen del párpado o, en algunos casos, puede no ser visible ("monolid"), lo que es un factor a considerar en cirugías de blefaroplastia o procedimientos estéticos.
    - **Indicador Clínico**:
      - Un pliegue palpebral alto o bajo puede indicar diferentes condiciones. Por ejemplo, un pliegue muy elevado puede sugerir una ptosis aponeurótica, donde el músculo elevador se ha desinsertado de su fijación en la piel.

4. **Función del Elevador del Párpado**

- **Definición**: Medida de la excursión del párpado superior al mirar hacia abajo y luego hacia arriba.
- **Medida Normal**: 12-15 mm.
- **Evaluación**: Es crucial para evaluar la función del músculo elevador, especialmente en casos de ptosis.

5. **Exceso de Piel (Dermatochalasis)**

- **Evaluación**: Mide el exceso de piel en el párpado superior e inferior. Puede interferir con el campo visual y requiere evaluación para blefaroplastia.

6. **Distancia Intercantálica (DIC)**

- **Definición**: Distancia entre los cantos medial y lateral.
- **Medida Normal**: 28-34 mm.
- **Evaluación**: Útil en la planificación de cirugías reconstructivas y en el diagnóstico de telecanto o distopia.

7. **Índice Cantometrico**

- **Definición**: Relación entre la distancia intercantal y la longitud de la hendidura palpebral.
- **Medida Normal**: Aproximadamente 1:1.
- **Evaluación**: Alteraciones pueden sugerir distopias o anomalías en la posición palpebral.

8. **Prueba de Snap-back y Distracción**

- **Definición**: Evaluación de la laxitud palpebral inferior.
- **Snap-back**: Tiempo que tarda el párpado inferior en volver a su posición original tras estirarlo.
- **Distracción**: Capacidad de separar el párpado inferior del globo ocular.
- **Evaluación**: Indica la necesidad de corrección quirúrgica en casos de ectropión o laxitud excesiva.

El **RPS** se refiere a la **Retracción Palpebral Superior**, una condición en la que el párpado superior se encuentra más elevado de lo normal, exponiendo más la esclera y creando un aspecto de "ojo sorprendido". Es comúnmente asociada con enfermedades tiroideas, especialmente la oftalmopatía tiroidea (enfermedad de Graves), aunque también puede ser secundaria a cicatrices, cirugías previas, o enfermedades neuromusculares.

Evaluación del RPS:

- **Hendidura Palpebral**: Se mide la hendidura palpebral (distancia entre los márgenes del párpado superior e inferior) en la posición primaria de la mirada.
- **MRD1 (Margen Reflexo Corneal 1)**: Mide la distancia desde el reflejo corneal hasta el margen del párpado superior. En el caso de retracción palpebral superior, el MRD1 es mayor de lo normal (normalmente 4-5 mm).
- **Exposición Escleral**: Evaluación del grado de exposición de la esclera sobre la córnea.
- **Función del Elevador**: Se evalúa la función del músculo elevador del párpado superior, que puede estar hiperactivo en estos casos.

Causas Comunes de RPS:

- **Oftalmopatía Tiroidea (Graves)**: La causa más frecuente de retracción palpebral superior, debido a la inflamación y fibrosis de los músculos extraoculares, especialmente el músculo recto superior y el elevador del párpado.
- **Postquirúrgica**: Puede ocurrir después de una blefaroplastia, ptosis o cirugía de estrabismo.
- **Traumatismos**: Secundario a cicatrización o retracción del tejido.

Tratamiento:

- **Manejo Médico**: Incluye lubricantes oculares para evitar la sequedad ocular y en casos de enfermedad tiroidea, tratamiento específico de la enfermedad subyacente.
- **Cirugía**: La corrección quirúrgica puede implicar la liberación del músculo elevador, resección de la conjuntiva y del músculo de Müller, o en casos severos, la descompresión orbitaria.

El RPS es un hallazgo clínico importante en oculoplastia, ya que no solo afecta la apariencia estética del paciente, sino que también puede causar síntomas oculares como irritación, sequedad y diplopía, que requieren un manejo adecuado.
