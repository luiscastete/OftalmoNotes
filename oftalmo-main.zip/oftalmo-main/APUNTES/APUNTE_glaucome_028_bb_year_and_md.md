---
categoria: apuntes
area: glaucoma
emoji: 🟢
seccion: Glaucome
orden_seccion: 5
orden: 28
fuente: OneNote del Dr. Castilla Martí
---
# bB/year and MD

## ENTENDIENDO -0.36 dB/year Y MD EN GLAUCOMA

## CONCEPTOS BÁSICOS PRIMERO

## ¿Qué es dB (decibelios)?

- 📊 Unidad de medida de **sensibilidad visual** en campimetría
- 📊 Mide la **intensidad de luz** que el paciente puede percibir
- 📊 **Valores ALTOS = mejor sensibilidad** (ve mejor)
- 📊 **Valores BAJOS = peor sensibilidad** (ve peor)

## MD (Mean Deviation) - DESVIACIÓN MEDIA

## ¿QUÉ ES MD?

## MD = Desviación Media (Mean Deviation)

Es un **índice global** que mide:

- ✅ La **diferencia promedio** entre la sensibilidad del paciente y la sensibilidad esperada para su edad
- ✅ Si el campo visual **está peor de lo normal** globalmente
- ✅ El **grado de daño** del campo visual total

## ¿Cómo se interpreta MD?

MD NORMAL:         0 dB a -2 dB    → Campo visual NORMALMD LEVE:           -2 a -6 dB      → Defecto LEVEMD MODERADO:       -6 a -12 dB     → Defecto MODERADOMD SEVERO:         < -12 dB        → Defecto SEVEROMD MUY SEVERO:     < -20 dB        → Daño avanzado

## Ejemplo

- MD = -5 dB → Campo visual está **5 decibelios más oscuro** que lo normal para su edad
- MD = -15 dB → Campo visual está **15 decibelios más oscuro** (daño más severo)
