---
categoria: apuntes
area: retina-quirurgica
emoji: 🪡
seccion: Ret Chirg
orden_seccion: 6
orden: 14
fuente: OneNote del Dr. Castilla Martí
---
# OM

Literature dis que il y a  effets benefiques de retirer le vitre. Augmentation de oxigenation. Et peut faire diminuer le risque de OM. Woow.
