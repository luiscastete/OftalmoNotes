---
categoria: apuntes
area: uveitis
emoji: 🔥
seccion: Immuno-infectio
orden_seccion: 7
orden: 16
fuente: OneNote del Dr. Castilla Martí
---
# P.3 -Oftalmia simpatica

**5.3. Oftalmía simpática (o mejor dicho empática no? Tanto que se pone enfermita también)**

## Definición

Uveítis granulomatosa bilateral secundaria a un traumatismo perforante o cirugía intraocular en un ojo (*ojo excitador*), que afecta posteriormente al otro ojo sano (*ojo simpatizante*).

## Epidemiología y causas

- Incidencia: ~1/1000 tras trauma ocular penetrante.
- Actualmente, la causa más común es la **cirugía vítreo-retiniana**.
- Afecta por igual a ambos sexos. Menor incidencia en niños.
- 1/3 ocurre en los **primeros 3 meses**, <50% durante el **primer año** tras el evento.

## Clínica

- **Panuveítis granulomatosa bilateral**, más severa inicialmente en el ojo excitador.
- **Signos típicos**:
  - Precipitados queráticos en grasa de carnero.
  - Engrosamiento iridiano con sinequias posteriores.
  - **Nódulos de Dalen-Fuchs**: blanco-amarillentos, ecuatoriales.
  - Desprendimiento seroso de retina (DR exudativo).
  - Cataratas, EMQ, NVC peripapilar/macular, atrofia óptica.
