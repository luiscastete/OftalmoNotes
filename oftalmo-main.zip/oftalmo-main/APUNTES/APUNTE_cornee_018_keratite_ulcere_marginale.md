---
categoria: apuntes
area: cornea
emoji: 👁️
seccion: Cornée
orden_seccion: 4
orden: 18
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-01-30
---
# Kératite/ulcere Marginale

Reaction hypersensibilite de type III contre exotoxine staphylococcique.

Depots complet immuns AC-AG dans la cornée peripherique. AVEC BORDES DE SEPARATION entre cornàe et bordes conj.

Lesions cornéens - à la culture mais S.aureiûs freq isole sur marge palpebrale.

**SYMPT:** rougeur, sensation CE, larmoiments, photophobie, inconfort visuel, BAV, parfois Bilat.

## SIGNES

INFILTRATS CATARRHAUX

INFILTRAT CATARRAL

Infiltrats sous-épith. Peripheriques separes du limbe par un espace sain ( loc à 1-2mm du limbe).

Avec rupture épith ( fluo +) = **ulcere marginal**

Sans rupture épith ( fluo -) = **kératite marginale**

Taille defect épith < taille infiltrat

Infiltrats arrondis parfois coalescents.

Loc. Typique: 4-8h (inf ++ typique) et 1'-2h. ( zone contacte paupieres )

HC zone adjacent infiltrats

Freq assoc blépharite chronique

Manif precos: Epitheliopathie ponctuée inf.

Pas reaction CA

## EVOLUTION

Sans ttt resolution spontanée 1-4 sem.

Ocass. Laisse une cicatrice superf. Resideul et un leger aminicissement cornéen dans zone infiltrat avec leger pannus parfois.

Neovasc iriens peuvents se developer si large leions persistantes mais resolution quand inflam dispare.

Recurrences sont communes.

## DX

Clinique: pas bilan necesaire.

## TTT

Obj: reduire inflam locale et reduir stimuli pour recurrences futures.
