---
categoria: apuntes
area: oculoplastica
emoji: 🫥
seccion: Oculo-Plastie
orden_seccion: 3
orden: 1
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-03-28
---
# QUAND RéFéRER OCULOPLASTIE

## Suivi en policlinique

- Blépharite
- Chalazion

## Réferere OCULO-PLASTIE sans urgence

- Nouevau cas ou 2eme avis Ophtalmo
- Patient étranger
- Pathologies orbithaires
- Tumeurs paupieres
- Indication Chirurgie palpebrale: Ptosis, Dermatochalasis, Ectropion, Entropion...
- Requête du patient

## Réferere OCULO-PLASTIE avec urgence

- Exophtalmie inflammatoire
- Exophtalmie che l'enfant
- Cellulite orbitaire
- Cellulite préseptale
- Plaies des voies lacrymales

## Cas particulier

- Fracture du cadre orbitaire---efectuer imagier CHUV avec prise en charge chirurgie maxilo-facial.
