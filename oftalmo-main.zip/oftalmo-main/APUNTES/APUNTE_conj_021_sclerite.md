---
categoria: apuntes
area: cornea
emoji: 💧
seccion: Conj + Episclere + Sclere
orden_seccion: 25
orden: 21
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-10-04
---
# Sclérite

Inflammation de la sclére

Pathologie peu frequente

F>H 40-60 ans

>50%atteinte bilateral

50% associe à atteinte systemique:

- >50% des sclérites ant nodulaires
- 25% de sclérites ant diffuses
- 70-95% des sclérites nécrosantes ( PR +)
- 30% des sclérites posterieurs

## CLASSIFICATION

- **Sclérite antérieure:**
  - Non-necrosante:
    - Diffuse 50%
    - Nodulaire 25%
  - Nécrosante:
    - Avec inflammation 10%
    - Sans inflammation  5%

- **Sclérite posterieur:** 10%

**REFERER TOUT SCLéRITE avant investigations immediatement en unité spécialise!!!**

## Symptômes

## Sclérite ant

- **Non-Nécrosante ( diffuse et nodulaire) et nécrosante avec inflammation.**
- Apparition aigue ou subaigue
- Douleur >6/10, insomniante, avec irradiation vers la mâchoire, les tempes et le cuir chevelu.
- Globe sensible au toucher
- **Nécrosante sans inflammation (Scléromalacia perforans et noninflamorans).**
- Irritation lègére, pas douleur, vision conservée.

## Sclérite postérieure

- Douleur 6/10, péjorée à la motilité oculaire
- Photophobie
- BAV, diplopie

## SIGNES

Sclérite ant:

## Non nécrosante ( diffuse et nodulaire)

- Rougeur sectorielle ou diffuse, avec dilatation des vssx scléraux profonds.
- Nodule scléral isole ou multiples (sclérite nodulaire)
- Examnen LAF: Nodule non mobilisable au coton tige ( sclérite nodulaire), surface ant. De la sclére suréeleve ( par opposition à l'épisclerite)
- Chemosis, oedeme palpebrale
- Autres: HTIO, UAA, cataracte, atteinte cornéene secondaire ( PUK, kératitesclérosante), astigmatismesecondaire à lamincissement scléral.

## Necrosante avec et sans inflammation (scléromalacia perforans)

- Amincissement lentement progressif de la sclére, avec exposition de l'uvée sous-jacente: aspect bleuté de la sclére, mieux visible à la lumiere naturelle.
- Plaques nécrotiques sclérales près du limbe, qui s'élargissent et deviennent coalescents. Diminution ou disparition de la vascularisation sur la zone de nécrose.
- Perforation du globe = rare mais possible. Urgence!!

## Sclérite postérieure

- Oedme papillaire, plis choroidiens, DR exsudatifs, effusion uvéale avec décollement choroidiene, oedeme maculaire, granulomes sous retinien +/- vitrite, hémorragies rétinnienes.
- Hypermétropie d'apparition rapide
- Myosite avec restrictions de la motilité oculaire
- +/- associée à une sclérite antérieure.
- +/- HTIO, oedeme périorbitaire, exophtalmie, ptosis, Chémosis.

## Etiologies

- **Associe à maladies systemiques  >50%**

  - Maladie inflammatoires – par ordre freq:
  - Polyarthrite rhumatoide - PR
  - Vasculite systémique:
    - Granulomatose avec polyangéite - maladie de Wegener, PAN, Takayasu, Horton, Behçet.
    - Lupus érythémateux systémique - LED
    - Polychondrite atrophiante
  - Spondylarthropathis:
    - Spondylarthrite ankylosante, arthrite réactionelle- syndrome de Reiter, Arthrite psoriasique.
    - Sarcoidose, syndrome de IgG4...
  - Infections- 7% patients:
    - Herpes simplex, VZV, Tuberculose, Syphilis, Borréliose, Bartonella, Lepre...
  - Troubles métaboliques-rares: Goutte, pophyrie.

  - Causes locales:
  - Traumatismes, chirurgie-surgery-induced necrotizing scleritis
  - Infection locale: Oseudomonas, Aspergillus, Fusarium, Sporontrichose- souvent scxlero-kératitis.

## STATUS

AV-TIO-LAF-FO dilaté

## BILAN

DX CLINIQUE

Test à la phényléphrine 2.5%: persistance de la rougeur oculaire.

AUTRE BILAN:

- **AA par systémique:**

Voici un ordre typique utilisé dans de nombreuses pratiques médicales :

## Généralités

- Fatigue
- Perte de poids involontaire
- Fièvre, frissons
- Sudation nocturne

## Peau

- Eruptions cutanées
- Prurit (démangeaisons)
- Plaies ou ulcères
- Changements dans les grains de beauté

## Tête et cou

- Céphalées
- Vertiges
- Douleurs au cou
- Masse ou enflure

## Yeux

- Troubles de la vision
- Douleurs oculaires
- Rougeur des yeux
- Sécrétions

## Oreilles, nez, gorge (ORL)

- Acouphènes
- Perte d'audition
- Rhinorrhée (écoulement nasal)
- Mal de gorge

## Appareil respiratoire

- Toux
- Dyspnée (difficulté à respirer)
- Expectoration (crachats)
- Douleur thoracique

## Appareil cardiovasculaire

- Douleur thoracique
- Palpitations
- Œdème des membres inférieurs
- Syncope (évanouissement)

## Appareil digestif

- Douleur abdominale
- Nausées, vomissements
- Diarrhée, constipation
- Jaunisse

## Appareil urinaire

- Dysurie (douleur à la miction)
- Hématurie (sang dans les urines)
- Pollakiurie (envie fréquente d'uriner)
- Incontinence urinaire

## Appareil génital

- Pertes vaginales ou péniennes
- Douleurs pelviennes
- Troubles menstruels
- Dysfonction sexuelle

## Système musculo-squelettique

- Douleurs articulaires
- Faiblesse musculaire
- Gonflement des articulations
- Raideur

## Système neurologique

- Convulsions
- Troubles de la mémoire
- Paresthésies (engourdissements)
- Tremblements

## Système psychiatrique

- Troubles de l'humeur
- Anxiété
- Troubles du sommeil
- Hallucinations

## Système endocrinien

Intolérance à la chaleur ou au froid

Polyurie (miction excessive)

Polydipsie (soif excessive)

Changement de poids soudain

- En suivant cet ordre, vous pouvez garantir une évaluation complète et systématique de l'état de santé du patient.

Rechercher maladie associe:  completer bilan après discussion avec unité immuno

2.Laboratoire

FSC, VS, CRP, acide urique, Na, K, créatinine,urée, facteur rhumatoide, anti-CCP, anticorps anti-phsopholièides, p et c-Anca, antigen HBV-PAN, ANA , anti-DNA, natifs, HLA B27, HLA  B51.

ACE, lyzozyme, Ca2+ corrigé, dosage IL2-R- SARCOIDOSE?

TPHA/VDRL-SYPHILIS, TB spot, Sérologie pour Borreliose, Bartonela henselae si sclérite post et neurorétin. - non rembourse\*\*\*

Necesite souvent une immunosupression: prevoir sérologie HIV, HBV, HCV, ASAT, ALAT, Urée, créatinine, FSC, VS, CRP.

- Si suspicion de sclérite postérieure:
  - Photo panomarique
  - OCT, OCT –EDI
  - US: recherche de T-SIGN, épaissement scléral, DR, plis choroidiens- US de bonne qualité necessaire- referer onco pour mesure precise de la lame de liquide.
- +/IRM/CT cérébrale orbitaire coupes fines:
  - Epaississement scléral, exophtalmie.
- ICG externe
  - Permet de differencier la sclérite de l'épisclerite par visualisation de la vascularisation de la sclère, determine la presence de nécrose et les signes d'active inflammatoire- vasculite?
- Biopsie
- Rarement contributive sauf dans les cas infectieux- attenton car risque de perforation augmente si inflammation.
- Imagerie:
- RX-CT thorax- sarcoidose-TB?
- Referer au MT ou rhumatologue pour évaluation systémiqe.

TT

Selon severite et étiologie

Douleur: excellent indice du controle de la sclérite

- Principes de tt pour les sclérites ant non-nécrosantes:

- Tt local:
  - LA 4-6xj
  - AINS: Nevanac 0.1% 3xj ou steroids topiques si formes legere – DF 4xj.
  - Attention\* steroids à éviter si risque perforation et attention si sclérite herpetique

- Tt systémique à discuter avec unite immuno:
  - 1er intention AINS systemiques- ibuprofène 400-600mg 3xj ou indométacine 75mg 2xj. + IPP pantoprazole 20mg 1xj
- C-I: insuffisnace renale, ulcere gastrique, troubles d ela crase...

  - 2em intention Prednisone 1mg/Kg en dose initial puis schéma dégressif IV si cas graves

  - 3em intention
    - Tt d'épargnes des stéroids: immunosupresseurs systemiques. +/- tt biologique.

- Tt antimicrobien ciblé dans origine infectieuse-tjrs exclure avant tt steroides.

- ATTENTION!
- Pas injection parabulbaire de steroides car risque de perforation dans cas sclérite nécrosantes.
