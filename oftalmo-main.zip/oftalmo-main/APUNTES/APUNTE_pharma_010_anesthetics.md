---
categoria: apuntes
area: general
emoji: 💊
seccion: Pharmacologie Farma
orden_seccion: 23
orden: 10
fuente: OneNote del Dr. Castilla Martí
---
# Anesthetics

**Mechanism:** reversible blockade of nerve fiber conduction (block sodium channels); pH dependent (less effective at low pH [inflamed tissue])

**Structure:** two classes; do not necessarily have allergic cross-reactivity

- ***Ester:*** hydrolyzed by plasma cholinesterase and metabolized in liver; cocaine, tetracaine, proparacaine, procaine, benoxinate

- ***Amide:* longer duration and less systemic toxicity; metabolized in liver; lidocaine, mepivacaine, bupivacaine

**TOPICAL:** disturb intercellular junction of corneal epithelium (increase permeability)

- *Proparacaine* (Alcaine, Ophthetic, Ophthaine): duration 10–30 minutes, corneal toxicity; may cause allergic dermatitis (also common with atropine and neomycin); does not necessarily have allergic cross-reactivity with tetracaine
- *Tetracaine* (Altacaine, TetraVisc, Pontocaine): similar to proparacaine but longer onset and duration and more toxic to corneal epithelium
- *Benoxinate* (oxybuprocaine): similar to proparacaine
- Cocaine: greatest epithelial toxicity; excellent anesthesia,
- sympathomimetic effect (test for Horner syndrome).

- Less to more corneal toxicity and also less to more anesthetics
- Proparacaine > Benoxinate (oxybuprocaine) > Tetracaine > Cocaine
