---
categoria: apuntes
area: pediatria
emoji: 🧸
seccion: Pediatrie
orden_seccion: 9
orden: 16
fuente: OneNote del Dr. Castilla Martí
---
# Glaucoma in childhood

CLASSIFICATION

- **PRIMARY CHILDHOOD GLAUCOMA:**

- **PRIMARY CONGENITAL GLAUCOMA - PCG :**

  - Neonatal or newborn onset < 1months until lateonset >24months BUPHTHALMOS

  - ETIOLOGY: developmental abnormality of angle - goniodysgenesis with faulty clevage and abnormal insertion of ciliary muscle.
  - Hereditary in 10-40% AR

  - SYMPTOMES; tearing, photophobia, blepharospasm - clasic triad PCG-  also red and rubbing.  If <3months cornea clowding.

  - FINDINGS: IOP>20mmHg (often 30-40mmHg) + C/D ratio >0.3 or assymetry >0.2 betwwen eyes suggestive. BUPHTHALMOS - bulls eye occurs in PCG not JOAG\*\*\*\*\*
  - BUTHPHTALMOS: horizontal corneal diameter >13mm, limbal ectasia,, corneal clouding-edema-haab striae- corneal edema, scarring and myopia

- **JUVENILE OPEN-ANGLE GLAUCOMA - JOAG:**
  - AD
  - Onset >4 years old
  - NO BUPHTHALMOS
  - Usually normal angles.

- **SECONDARY CHILDHOOD GLAUCOMA:**

  - Caused by others ocular anomalies congenital or adquired or associated with syst diasease

  - ASSSOCTIATED WITH NONACQUIRED OCULAR ANOMALIES
    - Microcornea, cornea plana, sclerocornea, Axenfeld/Rieger/Peter anomaly 50%, Aniridia50-75% develop glaucoma by teens as a result of invreased episcleral venous pressureand iris stump blocking trabecular meshworks, angle malformation or agenesis, …

  - ASSOCIATED WITH NONACQUIRED SYSTEMIC DISEASE OR SYNDROME
    - Lowe syndrome (oculocerebrorenal) 50%, Sturge-Weber syndrome 50% specially if nevus flammeus involves upper lid, NF-1 , congenital Rubella, Mrfan syndrome, Homocystinuria…

  - ASSOC. WITH ACQUIRED CONDITIONS
    - Steroid-induced, lens induced, trauma, tumors ar RB…

  - FOLLWING CONGENITAL CATARACT SURGERY
    - Aphakic glaucoma develops in 15-50% weeks, mechanism unclear…

- DX:
  - Examination under anesthesia + IOP mesurements + Gonioscopy: landmrsks are often porrly recognized

- TT
  - Definitive treatmemnt is surgical, medication is temporizing measure, treta refractive error and amblyopia if present.

  - 1-TOPICAL MEDICATION:
    - attention secondary effects in children.
    - Brimobidine contraindicated in <2years children bcs respiratory depression.

  - 2-GONI**OTOMY (apertura)**  x2-Puedes repetir cirugia hasta 2 veces-: Perform in children <1.5 years  Trabecular meshowrk is incised - 77% succes rate.

  - 3-TRABE**CULOTOMY (apertura)** - ab externo if cornea hazy-cloudy-borrosa and if goniotomy fails twice x2 . 77% succes rate.

  - If goniotomy and trabectulotomy fail consider --- trabe**CULECTOMY (extirpacion)** with mitomycon C, drainage implant…

  - PROGNOSIS:
  - Variable, best osnset between 3-12 months (90%controlled with tt), worse for neonatal (50% legal blindness) and in patiente with corneal diamater >14mm in moment of dx.
