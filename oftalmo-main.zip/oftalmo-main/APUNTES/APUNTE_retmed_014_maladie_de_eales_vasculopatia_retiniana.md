---
categoria: apuntes
area: retina-medica
emoji: 🩸
seccion: Ret Med y coroides
orden_seccion: 19
orden: 14
fuente: OneNote del Dr. Castilla Martí
---
# Maladie de EALES (vasculopatia retiniana oclusiva primaria) - Otras retinopatias proliferativas 2.0

## 🧠6.2. ENFERMEDAD DE EALES

## 🧾Definición

Vasculopatía retiniana oclusiva idiopática, **bilateral** y **primaria**, caracterizada por:

- **Mínima inflamación vascular retiniana**
- **Oclusiones venosas periféricas**
- **Neovascularización** secundaria
- **Hemorragias vítreas recurrentes**

## 📈Epidemiología

- Afecta principalmente a **hombres jóvenes** (20–40 años).
- Especial prevalencia en países endémicos de tuberculosis (TB).
- Asociaciones descritas:
  - **Hipersensibilidad tuberculínica** (reacción a PPD positiva)
  - **Homocisteína sérica elevada** (estrés oxidativo vascular)
  - Detección de **ADN micobacteriano** en humor vítreo por PCR (sin microorganismo viable).
