---
categoria: apuntes
area: pediatria
emoji: 🧸
seccion: Pediatrie
orden_seccion: 9
orden: 21
fuente: OneNote del Dr. Castilla Martí
---
# Lacrimal disordres

## Dacryocystocele

Cystic swelling of lacrimal san accompanies obstruction of lacrinal drainage system aboeve and below the sac

Presents at borth as bluish swelling inf and nasale to medial canthus

TT: digital massages, lacrimal probing or surginal decompression for dacryocistitis - develops if condition does not resolve

## NASOLACRIMAL DUCT OBSTRUCTION - NLDO

5% have NLDO as result of membrane covering valve of Hasner

Most open spontaneouusly within 4-6weeks

FINDINGS: tears, discharge, may develop dacryocistitis or conjontivitis.

Digital pressure over sac producing mucoid reflux indicates obstruction NLD

TT: lacrimal sac massage (CRIGLER), topical antibiotic, probing and irrigation by 13 months -95% cure rate- consider turbine infracture and silicone intubation if probing unsucccessfull - dacryocystorhinostomy DCR after multiple failures is rarely needed.
