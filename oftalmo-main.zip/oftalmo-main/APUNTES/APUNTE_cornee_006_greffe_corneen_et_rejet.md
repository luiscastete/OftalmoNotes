---
categoria: apuntes
area: cornea
emoji: 👁️
seccion: Cornée
orden_seccion: 4
orden: 6
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-05-26
---
# Greffe cornéen et rejet**

Reaction immunologique de type IV des cellules de l^hote contre les cellules du donneur

Apparait entre 2 semaines à plusieurs années ( >30 ans) après la kératoplastie\*\*\*\*

Période la plus à risque: durant les 18 premiers mois après la greffe.

## RAPPEL

## Types de greffe cornéenne

- **TRANSFIXIANTE**
  - PK-Penetrating Keratoplasty

- **Greffes LAMELLAIRE ANTERIEURE**
  - ALTK-Anterior lamellar therapeutic keratoplasty - superficielle
  - DALK- Deep Anterior Lamellar keratoplasty - profonde

- **Lamellaire posterieure/ endothéliales**
  - DMEK- Descemet membrane endothelial Keratoplasty –  que couches endoth descemetiques
  - DSAEK- Descemet Stripping Automated Endothelial Keratoplasty - couches endoth descemetiques + stroma posterior

  - Kate infos:
  - DSAEK more easy surgery. So comorbilities. DSAEK
  - DMEK more complicated surgey and more complicated to have Donors, only accepted <50 years.

  - Simple fuchs DMEK. DMEK pour patientes avec bonne potentiele visuelle. Car moins haze.
  - Existe aussi UT-DSAEK <100 ,Avantages of <100. Surgery is more easy and sticks better, has less haze post-op, has the advantages of the 2.

## Facterus pronostics de rejet
