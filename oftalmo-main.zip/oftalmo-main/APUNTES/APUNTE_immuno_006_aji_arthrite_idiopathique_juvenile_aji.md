---
categoria: apuntes
area: uveitis
emoji: 🔥
seccion: Immuno-infectio
orden_seccion: 7
orden: 6
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-09-23
---
# AJI - Arthrite idiopathique juvénile (AJI)

L'uvéite est l'une des manifestations extra-articulaires les plus courantes de l'arthrite juvénile idiopathique (AJI). Le tableau clinique classique est celui d’une uvéite antérieure chronique non granulomateuse , qui reste généralement asymptomatique jusqu'à la survenue de complications pouvant engager le pronostic visuel de ces enfants.

Le but de notre travail est d'évaluer la corrélation entre la survenue de l’atteinte oculaire et la fome clinique de l’AJI.

## Discussion

L’arthrite juvenile idiopathique constitue la principale étiologie des uveites chez l’enfant. L’atteinte est bilatérale dans ¾ des cas.

Les facteurs de risque d’uvéite chez l’enfant atteint d’AJI sont : le sexe féminin, l’age < 6ans, la forme oligo-articulaire, la positivité des anticorps anti-nucléaires et la négativité du facteur rhumatoide.

Les principales complications sont : la cataracte, synéchies, glaucome secondaire, kératopathie en bandelettes.

## Conclusion

L'atteinte oculaire associée à l'arthrite juvénile idiopathique est le plus souvent asymptomatique mais susceptible d’entrainer des complications dramatiques, d’où l’interet d’un dépistage systématique et d’une prise en charge rapide et adapatée ( Rhumatologe qui decide mais normalment 3-6-12 mois)

## BUT écarte UAA NG asymptomatique.

## Uvéites de l'enfant et AJI

Uveites en enfants répresentent environ 10% de l'ensemble des inflamm intraoculaires.

Les uveites pédiatriques sont majoritarirement bilaterales et non infectieuses.

Est important de définir si l'uveite est isolée ou alors associe à : AJI, Sarcoidose, ou Behçet.

Patients très compliques a gerer, composante très emotionelle par parents\*\*\*
