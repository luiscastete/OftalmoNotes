---
categoria: apuntes
area: retina-medica
emoji: 🩸
seccion: Ret Med y coroides
orden_seccion: 19
orden: 38
fuente: OneNote del Dr. Castilla Martí
---
# Enfermedad de Stargardt

## 9. Enfermedad de StARgARdt el ojo de Buey

## Definición y epidemiología

- Es la **distrofia macular hereditaria más frecuente** en adultos jóvenes y niños.
- Prevalencia: 1/8.000 – 1/10.000.
- Herencia **autosómica recesiva**, causada por mutaciones en el gen **ABCA4**, que participa en el transporte de retinoides desde los fotorreceptores al EPR.

## Presentación clínica

- Inicio variable: infancia, adolescencia o adultez joven (cuanto más tardío, mejor pronóstico).
- **Síntomas clave**:
  - Pérdida bilateral de agudeza visual central
  - Escotoma central
  - Discromatopsia (alteración en percepción del color)
- **Signo característico**: lesiones blanquecinas-amarillentas (“**flecks**”) a nivel del epitelio pigmentario en el polo posterior.
- **Fondo de ojo**: atrofia macular + flecks en retina posterior.

## Diagnóstico y pruebas complementarias

- **OCT**: pérdida de la arquitectura foveal y alteraciones precoces como engrosamiento de la membrana limitante externa.
  - Se monitoriza progresión mediante:
    - Espesor retiniano total
    - Espesor ONL (capa nuclear externa)
    - Segmentos internos de fotorreceptores

- **Autofluorescencia (AF)**:
  - Patrón típico: hipofluorescencia central + anillo hiperAF (aspecto de “ojo de buey”).
  - Ha sustituido a la angiografía fluoresceínica (antiguamente usada para detectar el “silencio coroideo”).

- **Campimetría estática automatizada**: útil para detectar escotomas pericentrales.
- **ERG multifocal y de campo completo**: clasifica a los pacientes según el patrón de afectación funcional:

| **Grupo** | **ERG patrón** | **ERG campo completo** |
|---|---|---|
| 1 | Afectado | Normal |
| 2 | Afectado | Afectación de conos |
| 3 | Afectado | Afectación de conos + bastones |
