---
categoria: apuntes
area: oculoplastica
emoji: 🫥
seccion: Oculo-Plastie
orden_seccion: 3
orden: 12
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-03-28
---
# Cellulite préseptale

Infection orbitaire des tissues sous-cutanées situes ***en avant septum orbitaire***

## SYMPTOMES

- Douleurs moderes
- Pas douleur à la oculomotricite°°°°°°°
- AV conservé
- Pas diplopie
- État génerale conserve

## SIGNES

- Oedeme palpebrale
- Tissu cutanée sous tension
- Chemosis rare
- Pas exophtalmie
- Pas ophtalmoplégie-ou paralysie oculomotrice est une paralysie du mouvement de l'œil. Elles sont souvent signes d'une atteinte d'un nerf crânien.
- Apyrexie-absence de fievre

## ETIOLOGIES

- Infection locale de la paupiere/conjonctives/des structure adjacentes: Chalazion infecte, orgolet, dacryocystite aigue, conjontivite.
- Traumatisme ou infections cutanées

GERMES:

Adultes😖 pneumonaie et staph aureus

Enfants😖.pneumonieua, S.pyogenes ( beta-hémolytique du group A)

Streptocoques du group viridians, staph aureus, Hinfluenzae type B

## STATUS

- Recherche de traumatisme ou infection cutanée,sinusite, des problemes dentaires recents, des FR de immunosupression: Cortisone, ttt immunodepresseuR...

## Status ophta

- AV-Ishihara-TIO-Pupilles-Oculomotricite
- LAF-FO
- Status orbitopalpebrale ( exophtalmos? Hertel)

## BILAN

CT orbitaire si suspition cellulite orbitaire/retroseptale orbit ( BAV, Diplopie, exophtalmie) ou des complications ( collection/abces)

## TTT

**AMBULATOIRE**-stop AINS-délimitation zone inflam cutanée-controle de imunite au tetanus (si trauma)

+ ATB minimum 10j.

- **ENFANTS:**
- AMOX/CLAV 90mg/kg/j en 2xj ( max 875mg/prise = comme adult)
- Si allergies aux B-lactamines:
- LEVOFLOXACINE:
- enf >6mois et <5ans: 20mg/kg/j en 2xj
- Enf >5ans: 10mg/kg/j en 1xj ( max 750mg mg/j)
- ALTERNATIVE: Cefotaxime 200mg/kg/j en 3xj ( doses max 12g/j)

- **ADULTES:**
- Amox/Clav 875/125 mg 2xj pdt 10j
- Si allergies aux B lactimines: Triméthoprime/sulfamethoxazole 800/160mg 2xj
- Alternative: Clindamycine 600mg 3xj

## HOSPITALISATION et tt similaire à cellulite orbitaire/retroseptale si

Comorbidites: DM, immunosupression...

Péjoration sous antibiotique peros

Complications

## TTT TOPIQUE SI

Chalazion: Tobradex/Maxitrol pommade 3XJ PDT 7-14J + rinçages 3xj + massages 3xj + LA

Conjnctivite: Floxal gtt 4xj pdt 7j

## COMPLICATIONS

- Cellulite rétroseptal ( obitaire)
- Collection: Driange sous AG et mise en place d'une mèche.
- Thrombophlébite du sinus caverneux.

## SUIVI

Suivi 24-48h

Si évolution favorable: continuer le ttt peros pdt 10j sur total

Si évolution défavorable: prise en charge similaire à une cellulite orbitaire!
