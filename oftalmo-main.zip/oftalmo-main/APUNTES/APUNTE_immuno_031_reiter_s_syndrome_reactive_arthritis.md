---
categoria: apuntes
area: uveitis
emoji: 🔥
seccion: Immuno-infectio
orden_seccion: 7
orden: 31
fuente: OneNote del Dr. Castilla Martí
---
# Reiter's Syndrome - reactive arthritis

Chlamydia trachomatis, salmonella, shigella, yersinia and campylobacter are assoc with developping reactive arthitis.
