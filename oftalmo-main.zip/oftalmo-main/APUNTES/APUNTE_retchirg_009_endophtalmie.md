---
categoria: apuntes
area: retina-quirurgica
emoji: 🪡
seccion: Ret Chirg
orden_seccion: 6
orden: 9
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-03-12
---
# ENDOPHTALMIE

Inflammation purulente intraoculaire en general due a une infection.

## SYMPT

BAV

Rougeur oculaire

Douleurs ++

## SIGNES

BAV severe: PL/MM/CLD

Tumefaction palpebrale

HC

Reaction severe en CA: hypopion, +/- fibrine

Milleux troubles a opaques empechant la visualisation du FO

## ETIOLOGIES

POST-OP aigue 3-5j

POST-OP chronique >6mois

Traumatique

Associe a bulle de filtration ( Bleb-associated)

Endogene.

## STATUS

AV-TIO

LAF

FO Dilate

USB si FO non visible

## TTT

En fonction de AV:

Si AV > PL: Ponction de CA (PCA)+ VITRECTOMIE DX ( selon délais) + IVT de 2 antibiotiques:
