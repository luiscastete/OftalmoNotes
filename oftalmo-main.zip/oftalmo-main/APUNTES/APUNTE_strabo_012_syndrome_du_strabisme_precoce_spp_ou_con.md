---
categoria: apuntes
area: pediatria
emoji: 👀
seccion: Strabo-logie
orden_seccion: 22
orden: 12
fuente: OneNote del Dr. Castilla Martí
---
# Syndrome du strabisme précoce -SPP ou congenital esotropia

Apparu  lors de premiers 6 mois de vie

Signes pathognimiques

- Sensorialite : CRA- correspondance Retiniene Anormal
- Divergence vertical associe -DVD-
- Une elevaltion involontaire, lente et progress de l'oeil occlus - accompagne une extorsion de l'oeil.
- Nystagmus manifest latent

Autres signes:

Caracterise par esodeviation de grande angle superior a 30 -signe triangle-- 80% strabismes precoses.

-Fixation en addcution: enfante adopte un torticolis de fixation, tete tourne vers l'oeil fixateur.

-incocomitants alphabetiques

-elevation en adduction ou Upshoot.

-Hypermetrie de refixation

Prise en charge

-Correction optique totale -COT sous cycloplegie

-Prevention de l'amblyopie - occlusion oeil sain.

-TT chirurgicale: Toxine botulinique sur 2 droits mediaux ou chirg oculomotricite.
