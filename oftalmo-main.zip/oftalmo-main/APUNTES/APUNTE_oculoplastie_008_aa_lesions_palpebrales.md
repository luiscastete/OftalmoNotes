---
categoria: apuntes
area: oculoplastica
emoji: 🫥
seccion: Oculo-Plastie
orden_seccion: 3
orden: 8
fuente: OneNote del Dr. Castilla Martí
fecha: 2024-08-08
---
# AA Lesions palpebrales

AA:

Depuis combien de temps lésion?

Exposition solaire? Vecu tjrs en suisse?

Atcd cancer cutanée?

AAS cardio ou anticoag?

Autres maladies?

Ant fam?

STATUS

Lesion localisation, taille?

Madarose?

Lesion palpebrale

Lesion conj?

Autres lesions palpebrales?

Eversion possible?

CARCINOME BASOCELLULLAIRE
