---
categoria: apuntes
area: retina-medica
emoji: 🩸
seccion: Ret Med y coroides
orden_seccion: 19
orden: 5
fuente: OneNote del Dr. Castilla Martí
fecha: 2024-03-04
---
# Roth Spots

Roth Spots - EyeWiki (aao.org)

Roth Spots are defined as a white centered retinal hemorrhage and are associated with multiple systemic illnesses, most commonly bacterial endocarditis. Originally described by Moritz Roth in 1872 while at the University of Basel, Roth spots were first seen in individuals with bacteremia secondary to subacute bacterial endocarditis.[1][2] The retinal findings Roth made in 1872 were described as round, oval or flame-shaped hemorrhages with a central white spot.

## Pathophysiology

A series of investigations beginning in the 1960’s demonstrated that the white center of Roth spots represent a fibrin thrombus, platelet aggregates, and infiltrating red blood cells at the site of a previous vessel rupture. These findings resulted in a more coherent understanding of the pathogenesis of Roth spots. Specifically, rupture of retinal capillaries results in the extrusion of whole blood and subsequent platelet adhesion to the damaged endothelium. The resulting coagulation cascade then results in a platelet-fibrin thrombus, which results in the pale lesion appearing at the center of hemorrhage red lesion.

A common thread found in the conditions associated with Roth spots (Table 1) is a predisposition for endothelial dysfunction allowing for retinal capillary disruption. Histological examination reveals that the white centered lesions are composed mostly of fibrin, which represents extravasation and a fibrin-platelet plug at the site of vessel rupture. [2]

## Physical examination

Roth spots are signs of systemic illness and the patient's vital signs and overall hemodynamic stability should be assessed.

On fundoscopic exam Roth spots will appear **as round flame shaped hemorrhage with a white/pale center (variable in size), commonly in the posterior pole.** Full dilated exam with scleral depression evaluating for other retinal abnormalities that may accompany Roth spots may give insight to the underlying disease process (e.g., other signs of diabetic retinopathy).

**If suspicious for endocarditis,** additional possible ophthalmic findings on complete eye exam include:

- conjunctival hemorrhage,
- retinal hemorrhage,
- cotton-wool spots,
- retinal infarction,
- chorioretinitis,
- and rarely endophthalmitis. Non-ophthalmic exam findings include Janeway lesions, Osler nodes, splinter hemorrhages, petechiae, and cardiac murmurs.[13]
