---
categoria: apuntes
area: neuro
emoji: 🧠
seccion: Neuro-Ophta
orden_seccion: 8
orden: 29
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-08-24
---
# Oedeme papillaire bilatéral

## SYMPTOMES

Asymtomatique

Symtomatique:

- Épisodes d'amaurose trasitoire (posture) Transitoire visiol opacifications? TVOs?\*\*
- Diplopie horizontale
- Nausées et/ou vomissements
- Cephalées
- Tinnitus pulsatile\*\*

## SIGNES

Turgescence papillaire bilaterales

+/- Hémorragies du NO

+/-Drusens du NO

+/-Lésions rétinnienes

## DD

- Pseudo-oedeme papillaire
- Oedeme papillaire de stase
- HTA maligne
- Toxique ( amiodarone)
- Drusen du NO

## BILAN

- CV computérise\*:
  - Normal ou anormal ( notamment élargissement de la tacheaveugle, nasal-step)\*\*\* en urgence, ce seulemnt ici on av avoir si perd la vision!!

  - Autofluoresceine du nerf optique (drusen)
  - OCT: RFNL,RGCL,lignes EDI sur le NO
  - +/- echographie B scan
  - Controle TA
  - +/-angiographie rétinienne
