---
categoria: apuntes
area: urgencias
emoji: 🚑
seccion: URGENCES---TRAUMATOLOGIE
orden_seccion: 2
orden: 7
fuente: OneNote del Dr. Castilla Martí
fecha: 2022-09-08
---
# Contusion oculaire

Traumatisme oculaire avec objet contundant

## SYMPT

- Douleur
- BAV
- Rougeur oculaire
- Hématome périorbitaire

## SIGNES

## SAnterieur

- Ptose
- Oedeme palpebrale
- Echymose periorbitaire
- Hémorragie sous-conjonctivale
- Injection conjonctivale
- Atteintes cornéens
- Inflamm CA
- Hyphema
- Mydriase post-traumatique
- **Phacodonesis** ( Phacodonesis is **the tremulousness or vibration of the lens with eye movement.** This is often due to lens subluxation, the incomplete or partial dislocation of the lens, caused by an injury to the eye in which some or most of the zonular fibers are broken.)
- **Iridonesis** (Iridodonesis is the vibration or agitated motion of the iris with eye movement. This may be caused by lens subluxation, the incomplete or partial dislocation of the lens; or by aphakia, the absence of a lens. The term originated from irido- (Latin: iris) + doneo (Greek: δονεο, to shake to and fro).
- **Iridodyalise-**(**Iridodialysis** is a localized separation or tearing away of the iris from its attachment to the ciliary body.)
- Rupture du sphincter de l'iris
- Cyclodialyse-La cyclodialyse est un détachement focal du corps ciliaire de sa fixation à l'éperon scléral.
- Cristallin: luxation/subluxation, cataracte
- Recession angle

## SPosterieur

- Hémorragie vitréenne
- Commotio retinae ( peripherie rétinnienne) oedeme de Berlin – pole postrerior.
- DPV, déchirure de rétine, DR.
- Hémorragie intraretinniene
- Dialyse retinniene
- Trou maculaire
- Rupture choroidienne
- Neuropathie optique traumatique

## SIGNES ORBITAIRES ( DRAPEAUX ROUGES)

- **RAPD**
- **DEFICIT CV**
- **Limitation oculomotricite**
- **Exophtalmie**

## STATUS

- AV-TIO (perforation oculaire)
- examen neuro-ophtalmo
- LAF-FO
- Examen orbitopalpebrale: palpation du cadre osseux orbitaire.  exophtalmomètre de Hertel. : marche d'escalier ou enphyséme sous cutané sensible à la palpation de l'arcade sourcilliere? Rebord orbitair normale?
- Gonio dans 4 sem.

## BILAN

- OCT si BAV

- Bilan orthopsptique si diplopie ou suspition fracture orbitaire.

- CT-SCAN orbitaire si signes orbitaires +/- CT scan cérébral si imp traumatisme ou perte connaissance.

## TTT

- compresses froids si tumefaction imp.
- ttt atteints concominants:
  - UAA reactionel: Dexafree/ Predforte 4-6xj + Tropi/Scopolamine +/- hypotenseur (si HTIO).
  - Commotio retinae/oedeme de Berlin: pas tt resolution spontanée. .

## SUIVI

- en fonction atteintes PC dans 2-4j.
- Add GONIO dans 4 sem.

## AA

Ttt: nihil

Neuro-ophta:

- Ishihara 13/13
- Iso-iso pas RAPD
- CV par confrontation 4/4
- Oculomotricite eo sans limitation, indolore pas diplopie
- Hertel

Impre:

Examen ophtalmique dans les limites de la norme suite à une agression

Dans contexte de probable fracture.. ( CT scan pas fait pour l'instant)

Att:

Add

Explication signes alarme
