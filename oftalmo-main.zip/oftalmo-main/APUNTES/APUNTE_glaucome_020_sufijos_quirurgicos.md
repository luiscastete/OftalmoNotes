---
categoria: apuntes
area: glaucoma
emoji: 🟢
seccion: Glaucome
orden_seccion: 5
orden: 20
fuente: OneNote del Dr. Castilla Martí
---
# Sufijos quirúrgicos

## 📑Sufijos quirúrgicos – Vocabulario clave (EBO style)

| **Sufijo** | **Significado** | **Ejemplo en oftalmología** | **¿Qué implica?** |
|---|---|---|---|
| **-plastia** | **Reparación / remodelación** de un órgano o tejido | **Trabeculoplastia** (ALT, SLT) | No se extirpa, sino que se **modifica** para mejorar función |
| **-tomía** | **Incisión / corte** en un tejido u órgano | **Iridotomía** (incisión en iris con láser) | Apertura de un orificio, no se retira tejido |
| **-ectomía** | **Extirpación total o parcial** | **Trabeculectomía**, **Iridectomía** | Se retira tejido (ej. colgajo de iris o trabecular) |
| **-ostomía** | **Crear una abertura / comunicación** permanente | **Iridostomía** (creación de un orificio en iris), **Goniostomía** | Genera un paso artificial para fluidos |
| **-desis** | **Fijación / unión** | **Tarsodesis** | Se fija un tejido a otro |
| **-scopía** | **Visualización / exploración** | **Oftalmoscopía**, **Endoscopía** | Usar un instrumento óptico para observar |
| **-lisis** | **Liberación / destrucción** de adherencias | **Sinequiolisis** | Se rompen sinequias o membranas |
| **-pexia** | **Fijación quirúrgica** | **Retinopexia**, **Iridopexia** | Se fija una estructura en su lugar |
| **-tripsia** | **Fragmentación por presión o energía** | **Facotripsia** (técnica antigua de catarata) | Se rompe un tejido (hoy reemplazado por facoemulsificación) |
