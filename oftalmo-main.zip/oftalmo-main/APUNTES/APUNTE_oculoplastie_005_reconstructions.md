---
categoria: apuntes
area: oculoplastica
emoji: 🫥
seccion: Oculo-Plastie
orden_seccion: 3
orden: 5
fuente: OneNote del Dr. Castilla Martí
---
# Reconstructions

## Expected answer

Candidates must know how to describe at least one eyelid reconstruction technique:

a. For lower eyelid defects affecting less than 50% of the total eyelid: direct defect closure or direct closure in association with canthotomy / cantholysis to achieve eyelid advancement and a tension-free closure.

b. The following can be performed for defects of more than 50%: semicircular Tenzel flap, Hughes tarsoconjunctival flap to reconstruct the posterior lamella with a free skin graft in the anterior lamella; free tarsal graft plus myocutaneous flap for anterior lamellar reconstruction, etc. It is important that candidates recognise that one should never attach two grafts, as one of the two lamellae must always provide vascularisation.

## 🧵¿Qué es un colgajo?

Un **colgajo** es un **trozo de tejido vivo** que se **desplaza** desde una parte sana hacia otra que ha perdido tejido. **Sigue conectado** a su base (como una bisagra), para que **mantenga su riego sanguíneo** y cicatrice bien.

## 🛠️TIPOS DE COLGAJOS MÁS USADOS (explicados fácil)

## 🔹Colgajo de Tripier

- Se **toma del párpado superior** y se **gira hacia el inferior**.
- Contiene **piel + músculo orbicular**.
- Útil para **reconstruir la parte delantera del párpado inferior**.
- Imagina cortar una cortinita de arriba y coserla abajo.

## 🔹Colgajo de Tenzel (semicircular)

- Se hace un **corte semicircular en la piel cerca del ojo (zona temporal)**.
- Se **rota y estira** ese trozo para cubrir el defecto.
- Ideal cuando el hueco es **moderado**.
- Como girar un pedazo de tela lateral hacia el hueco.

## 🔹Colgajo tarso-conjuntival

- Se **toma una parte del tarso y la conjuntiva** del párpado superior o del otro ojo.
- Se usa para **reconstruir la parte interna del párpado** (lámina posterior).
- A veces se **cubre con piel** o un **injerto cutáneo**.

## 🧩Para defectos GRANDES (>50%)

## 🔹Cuttler-Beard

- Para reconstruir **el párpado superior** usando **un colgajo de espesor completo del inferior**.
- Se “presta” tejido de abajo hacia arriba, dejando los ojos cerrados temporalmente (¡como un parche que luego se corta!).

## 🔹Hughes

- Al revés: se usa **la parte interna del párpado superior** para **reparar el inferior**.
- Se reconstruye primero la **parte de dentro** (tarso y conjuntiva), luego se cubre con piel.
- También se cierra temporalmente y **se abre tras ~1 mes**.

## 🔹Mustardé

- Se usa **piel de la mejilla**, girándola hacia el párpado inferior.
- Es como **rotar piel desde la cara** para cubrir el párpado.
- Se necesita algo extra (injerto) para reconstruir la parte de dentro (lámina posterior).

## 🧠Truco para entenderlo

- 🧩 Piensa en el párpado como un **sándwich de dos capas**:
  - **Lámina anterior**: piel + músculo
  - **Lámina posterior**: tarso + conjuntiva
- 🔧 Si falta una capa, la **reconstruimos con tejido similar**.
- 💉 Si falta mucho, a veces **cerramos el ojo durante unas semanas** y luego **volvemos a abrir**.

La clave es el **porcentaje de párpado afectado** y si es **párpado superior o inferior**.

## 1. Principio general

- El objetivo es **resecar la lesión con márgenes oncológicos seguros** y luego **reconstruir respetando la función** (protección ocular, párpado móvil, estética).
- La estrategia de reconstrucción depende de:
  - Tamaño del defecto (% de longitud del párpado).
  - Capa afectada (lamela anterior, posterior o ambas).
  - Párpado superior vs inferior.

## 2. Defectos pequeños (≤ 25–30% de longitud palpebral)

- Se pueden **cerrar directamente** con sutura de los bordes → *primary closure*.
- Técnica: “pentagonal excision” (resección en cuña) y cierre directo.

## 3. Defectos moderados (≈ 30–50%)

- Cierre directo con **cantólisis lateral** (liberar canto lateral para ganar longitud).
- Si no alcanza, se usan **colgajos locales**:
  - **Colgajo de avance en semicircunferencia (Tenzel flap)** → muy clásico para párpado inferior hasta el 50–60%.
  - Colgajos de rotación o avance locales según localización.

## 4. Defectos grandes (> 50–60%)

- Requieren técnicas **reconstructivas mayores**:
  - **Párpado inferior**: colgajos de transposición (Mustardé rotation flap, colgajo nasolabial).
  - **Párpado superior**: colgajo de Hughes (tarso-conjuntival advancement flap, en 2 tiempos).
  - **Párpado superior reconstrucción**: colgajo de Cutler-Beard (trasposición de lamela posterior del párpado inferior al superior, en 2 tiempos).

## 5. Defectos lamelares

- **Si falta una sola lamela** (anterior = piel/músculo o posterior = tarso/conjuntiva) → se puede injertar directamente:
  - Lamela anterior → injerto cutáneo (retroauricular, supraclavicular).
  - Lamela posterior → injerto de mucosa oral o palatina.
- **Si faltan ambas lamelas** → una debe venir de colgajo vascularizado y la otra puede ser injerto.

## 6. Perlas EBO

- **Defecto ≤ 30% → cierre directo.**
- **30–50% → cierre directo con cantólisis o colgajo semicircular (Tenzel).**
- **> 50% → colgajos más complejos (Hughes, Cutler-Beard, Mustardé).**
- **Siempre: al reconstruir, una lamela debe tener vascularización propia.**

👉 Mnemonic:

## “30–50–70 rule”

- < 30% → cierre directo.
- 30–50% → colgajos locales (Tenzel).
- 50% → reconstrucción compleja (Hughes / Cutler-Beard).
