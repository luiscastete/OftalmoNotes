---
categoria: apuntes
area: oculoplastica
emoji: 🫥
seccion: Oculo-Plastie
orden_seccion: 3
orden: 2
fuente: OneNote del Dr. Castilla Martí
---
# Blépharoplastie

POST – OP BLéPHAROPLASTIE

DRE.CAYETTE

## ORDONNANCE POST-OP -Paupieres 

BLEPHACLEAN

Nettoyer les cicatrices matin et soir pdt 15 jours

FLOXAL POMMADE

1 application sur les cicatrices matin et soir pdt 15 jours

Recommandations post opératoires pour les paupières :

-Le jour de l'opération ne pas toucher au pansement il vous sera retiré le lendemain de l'intervention

-Un  saignement léger peut survenir sous le pansement le jour de l'intervention

-Le pansement sera retiré le lendemain de l' intervention

-Pour le nettoyage des paupières avec les lingettes ne pas frotter d'eventuelles croutes juste les tamponner puis appliquer la pommade antibiotique (une noisette) à l'aide d'un coton-tige sur les cicatrices

-En cas de douleur vous pouvez prendre 1g de paracetamol ( type Dafalgan)

- Un gonflement et un hématome des paupières sont très fréquents en post opératoire qui se résorbent en quelques semaines.

-Les fils seront retirés par Dr Cayette entre 5 et 10 jours après l'intervention.

-Le sport n'est pas recommandé durant 1 mois après l'întervention

-Ne pas mettre d'eau sur les cicatrices  durant 1 mois après l'intervention

-Pour le lavage des cheveux : chez le coiffeur ou la tête en arrière

-Pour le lavage du visage: lingettes ou gant de toilette

-Les cicatrices ne doivent pas être exposées au soleil durant 1 année après l'intervention , vous devez porter lunettes de soleil et chapeau en cas d'exposition solaire.

-En cas de problème URGENT vous pouvez contacter Dr Cayette au 079.137.50.46

Merci de ne pas utiliser ce numéro pour une prise de RDV ou une question au secrétariat.
