---
categoria: apuntes
area: glaucoma
emoji: 🟢
seccion: Glaucome
orden_seccion: 5
orden: 29
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-07-24
---
# Syndrome de dispersion pigmentaire et glaucome pigmentaire

Correspond à une liberation de pigments iriens par frottement chronique de épith de iris sur la face ant. du cristallin. Il peut etre responsable du glaucome pigmentaire par accumulation secondaire de pigments dans trab. Et pousses hyppertonie oculaires.

## MECANISMES PHYSIOPATHOLOGIQUES

1er étape- bloc pupillaire inverse: presence d'un iris concave avec inversion du gradient de pression entre la partie ant. Et la partie post. De l'iris.

2-étape-relargage pigmentaire en CA par frottement chronique de face post. Iris contre face ant. Du cristallin et la zonule.

3-étape-accumulation pigments dans trab. Puis hypertonie oculaire secondaire.

4-étape-dévelop. Un glaucome secondaire

## EPIDEMIOLOGIE ET FR

Adulte 20-40 ans – myopie –3/-4.

Glaucome pigmentaire: predom masculine 80% 30-50 ans

## PARTICULARITES DIAGNOSTIQUES

Logtemps asymptomatique: rares crises HTIO avec vision trouble transitoire, halos, douleurs oculaires lor exercise physique.

Examen clinique:

- Transilumination irirnne périphérique
- **FAISCEAU DE KRUCKENGBERS\*\*\*\*- dispostion en faisceau vertical de pigments sur la face post cornée + depots pigments sur zonule.**
- iris concave
- rare tyndal pigmente
- Gonio: angle iridocornéen ouvert + pigmentation anormale en grade 3-4  selon scheie
- OCT SA ou UBM: iris concave frottement observé lors un examen.

## TT
