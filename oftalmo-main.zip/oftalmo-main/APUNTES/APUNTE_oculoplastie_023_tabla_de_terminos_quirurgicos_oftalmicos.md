---
categoria: apuntes
area: oculoplastica
emoji: 🫥
seccion: Oculo-Plastie
orden_seccion: 3
orden: 23
fuente: OneNote del Dr. Castilla Martí
---
# Tabla de términos quirúrgicos oftálmicos (palpebrales)

## 📋Tabla de términos quirúrgicos oftálmicos (palpebrales)

| **Término** | **Acción** | **Propósito** | **Ejemplo clínico** |
|---|---|---|---|
| **Excisión** | Corte y retirada parcial o total de tejido | Remodelar, eliminar porciones | Excisión de conjuntiva, piel o grasa |
| **Exéresis** | Extirpación **completa** de una estructura | Eliminar una lesión o masa | Exéresis de chalazión, tumor |
| **Resección** | Corte y **eliminación parcial** para acortar | Reforzar o potenciar función | Resección del elevador del párpado |
| **Recesión** | **Desinserción o retroposición** de tejido | Disminuir fuerza o tensión | Recesión del recto inferior en retracción |
| **Plicatura** | Pliegue/sutura sin cortar | Acortar funcionalmente sin resecar | Plicatura del músculo de Müller |
| **Suspensión** | Anclaje con material al músculo frontal | Sustituir función perdida | Sling frontal en ptosis con mala función |
| **Canthopexia** | Refuerzo del canto sin seccionarlo | Estabilizar canto | Canthopexia en blefaroplastia |
| **Canthoplastia** | Corte y reconstrucción del canto | Reposicionar o acortar párpado | Canthoplastia lateral en ectropión |
| **Blefaroplastia** | Resección estética/funcional de piel y grasa | Corregir exceso tisular o funcionalidad | Blefaroplastia superior con retiro de piel/grasa |
