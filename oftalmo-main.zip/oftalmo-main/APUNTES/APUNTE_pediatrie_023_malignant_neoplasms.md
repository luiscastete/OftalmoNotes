---
categoria: apuntes
area: pediatria
emoji: 🧸
seccion: Pediatrie
orden_seccion: 9
orden: 23
fuente: OneNote del Dr. Castilla Martí
---
# MALIGNANT NEOPLASMS

## RHABDOMYOSARCOMA

MOST COMMON PRIMARY ORBITAL MALIGNANCY OF CHILDREN

MOST COMMON SOFT TISSUE MALIGNANCY OF CHILDHOOD

MOST COMMON MESENCHYMAL TUMOR OF ORBIT

Malignant spindle cell tumor

Average age dx is 8 years - 90% before age 16y.

Cell origin is an undeferentiated pluriptent cell of soft tissue - not muscles.

Unilaterale, tends to involve superonasal portion orbit

More common in males 5:3

Aggresive local spread through orbital bones, hematogenous spread to lungs and cervical lymph nodes- most common metastatse is chest.

FINDINGS: rapidly progressive propotosis (sobresale)\*\*\*\*, reddish discoloration of eyelid, may have proptosis- later develop tortuos retinal veins and choroidal folds and ON edema.

Types:

- EMBRYONAL: most common 70%.
- Pathology: elongated spindle cells with central hyperchromatic nucleous.

- Hay mas tipos que no pongo- pg 109

- ALVEOLAR: poorest diagnosis, found in inferior orbit, generally arises in extremiies.
