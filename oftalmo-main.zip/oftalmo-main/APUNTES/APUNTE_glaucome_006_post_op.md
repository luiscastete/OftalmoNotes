---
categoria: apuntes
area: glaucoma
emoji: 🟢
seccion: Glaucome
orden_seccion: 5
orden: 6
fuente: OneNote del Dr. Castilla Martí
---
# POST-OP

TRABECULOTOMIE

Normale saignement pdt 7-10j.

Si BAV pour vision flou (hyphema) avec TIO eo et CA bien forme – normal rassure patiente et poursuivre tt idem

Eviter dilatation pour eviter incarcelation iris sur trab – si besoin USB pour exminr si HV
