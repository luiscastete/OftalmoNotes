---
categoria: apuntes
area: uveitis
emoji: 🔥
seccion: Immuno-infectio
orden_seccion: 7
orden: 28
fuente: OneNote del Dr. Castilla Martí
---
# Eyeknow

U HLA B27+

En cas recidive precos < 3 mois.

Add 1gtt cortis xj

Consideres crotis peros si corticodepensande >2gtt cortis par jour
