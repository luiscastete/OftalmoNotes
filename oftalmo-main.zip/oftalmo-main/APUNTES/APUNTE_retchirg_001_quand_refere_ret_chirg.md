---
categoria: apuntes
area: retina-quirurgica
emoji: 🪡
seccion: Ret Chirg
orden_seccion: 6
orden: 1
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-03-16
---
# Quand refere ret chirg

## Suivi policlinique

- DPV
- MER avec AV >0.8 et sans métamorphopsies geants
- STVM sans diminution de AV et sans metamorphopsies geants.
- SUIVI post-op:
- DR
- MER
- STVM-syndrome de traction vitreomaculaire
- TM-Trou maculaire
- RDP-retinopathie diabetique proliferative avec traction vitreoretinniene
- HV-
- Opacites vitreennes
- IC-inflammation chroniques
- Trauma segment posterieur

## Référer ret chirg SANS urgence

- Nouveau cas ou 1er avis de OT
- Patient étranger
- MER
- STVM
- TM
- RDP
- HV
- OV
- IC
- IOL subluxe
- Cortex ou noyau luxe dans vitré post-phako sans inflamm et sans hypertension oculaire
- Cataracte avec denesis imp
- Requete du patient

## Référer Ret chirg  AVEC urgence

- Nouveau cas, étranger, 2eme avis
- DR
- HV avec suspicion de déchirure rétinnienne
- CE intraoculaire
- Décollement chorodienne appositionenel
- Glaucome malin
- Cortex/ noyau luxé dans le vistre post phako avec inflamm et avec hypertension oculaire
- IOL subluxe avec contact endothelial
- IOL luxé dans vitré
- Uveite post aigue demandant un dxpar bx intravitréenne
- Endophtalmie qui necessite une vitrectomie complète
