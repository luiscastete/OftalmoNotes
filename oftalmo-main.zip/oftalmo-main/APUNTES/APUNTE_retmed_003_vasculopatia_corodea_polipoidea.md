---
categoria: apuntes
area: retina-medica
emoji: 🩸
seccion: Ret Med y coroides
orden_seccion: 19
orden: 3
fuente: OneNote del Dr. Castilla Martí
---
# Vasculopatia corodea polipoidea

https://www.laboratoriosthea.com/medias/theainfo\_79\_0.pdf

Vasculopatia coroidea polipoidea Thea pdf.pdf
