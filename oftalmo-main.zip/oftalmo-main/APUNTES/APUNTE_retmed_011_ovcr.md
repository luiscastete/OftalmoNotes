---
categoria: apuntes
area: retina-medica
emoji: 🩸
seccion: Ret Med y coroides
orden_seccion: 19
orden: 11
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-07-24
---
# OVCR

Frequente. 2eme patho retinnienne vasculaire après retino diabetique.

Affection grave suite ralentissement brutal du courant veineux rétinien.

Interruption du retour veineux dans la veine centrale de la retine.

2 formes:

- Non ischemique ( forme la plus frequente, meilleur pronostic)
- Ischemique ( mauvaise pronostic)

## SYMPTOMES

BAV monoculaire variable

Indolore, brutale

Formes ischemique: AV < o egal CLD

## SIGNES

## Tretrade suivante

- **Dilatation et tuosites veineuses rétiniennes**
- **Hémorragies rétinniennes disséminées superficielles – en flameches ou profondes en taches**
- **oedeme papillaire**
- **Nodules Cottoneux, témoins de la non perfusion de scapillaires et donc du degre de l'ischemis rétinienne**

RAPD si formes ischémiques +/- non-ischemiques

Oedeme papillaire et/ou macullaire

Hémorragies superficielles en flammèche et/ou profondes sur 360°

Tortuosité et dilatation veineuse sur 360°

Nodules cotonneux

## FORMES OEDEMETEUSES – NON ISCHEMIQUES

Ce sont plus freq. Avec caracteristique suivantes:

-AV >0.2

-Reflexe afferent pupillaire direct conserve, **pas RAPD**

-Hémorrages en flameches superficielles dissemines. Une disposition radiare à partir du NO et un extension péripherique dans les 4 quadrants rétiniens:

-peu ou pas nodules cotonneux

## -oedeme maculaire importate

- ANGIO: retrouve des dilatations capillaires importantes avec peu territoire de non perfussion - ichémie rétinniene. Ily a une retarde de remplisage veineux modere.
- L'oedeme macualire est visible aux temps tardifs de l'angio et s emanifeste par hyperfluorescence liée à la difussin pathologique du colorant au niveau de scapillaires dilates.
