---
categoria: apuntes
area: cornea
emoji: 👁️
seccion: Cornée
orden_seccion: 4
orden: 7
fuente: OneNote del Dr. Castilla Martí
---
# 🏥 BANCO DE OJOS

## 🏥BANCO DE OJOS – Resumen estructurado

## 🎯Objetivo

Garantizar la **disponibilidad de tejido ocular** con la **máxima calidad y seguridad**, respetando principios legales y éticos. En caso de escasez, asegurar una **distribución equitativa**.

## 🏛️Legislación

• Basada en la **Directiva Europea 2004/23**.

• Transpuesta en España por **RD 1301/2006** → sustituido por **RD-ley 9/2014**.

• La **autorización de los bancos** está transferida a las **CCAA**.

## 🌍Datos clave

• España es **líder mundial en donación y trasplante de tejidos**.

• La **edad del donante no es contraindicación absoluta**: se valora la calidad del tejido.

## 🧪Extracción del tejido

• En instalaciones apropiadas, pero **no es obligatorio quirófano estéril**.

• Tipos:

- **Globo ocular completo**.
- **Casquete corneoescleral aislado**.
- Tiempo máximo tras el fallecimiento: **6–12 h**.

## 🔬Evaluación de la córnea

• **Biomicroscopía con lámpara de hendidura**.

• **Microscopía especular endotelial**: se evalúa:

• Densidad celular ≥ 2000–2500 células/mm².

• Pleomorfismo y polimegatismo bajos.

## 💉Serologías obligatorias del donante

• HIV 1 y 2 (Ac)

• Hepatitis C (Ac)

• Hepatitis B (HBs Ag y Ac core)
