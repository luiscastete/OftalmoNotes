---
categoria: apuntes
area: oculoplastica
emoji: 🫥
seccion: Oculo-Plastie
orden_seccion: 3
orden: 11
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-03-28
---
# Cellulite orbitaire infectieuse/rétroseptal

Infection orbitaire située en arrière du septum orbitaire

**URGENCE OPHTALMIQUE: cause possible de cecite!! voire de mortalite en cas de complication!!**

## SYMPT

Douleurs sévères ( surtout à l'oculomotricite)

BAV

Diplopie

Alt de l'état général

## SIGNES

Oedeme palpebrale

Tissu cutanée sous tension

Chemosis

Exophtalmie

Ophtalmoplegie

## SURTOUT UNILATERAL

État febrile

## ETIOLOGIES

Sinusitis aigue-ethmoidale, maxilare

Evolution d'une cellulite préseptale

Dacryocystite aigue

Dacryoadenite

Infection cutanée ( érysipele, furoncole, plaie...)

Inoculation post-trauma ou post-chirurgicale

Endophtalmie

Abcés dentaire

Tumeur surinfecte

Dissemination hématogene

## Germes

ADULTES: S.paneumoniae et staph aureus

ENFANTES: S.Pneumoniae, S.pyogenes, Streptococus du group viridians, Staph aureus, Hinfluenza type B

## STATUS

**Recherche un trauma ou une infection cutanée,une sinusite, des problemes dentaires recents,des FR immunosupression.**

## STATUS OPHTALMIQUE

- AV-ISHIHARA-TIO-PUPILLES
- OCULOMOTRICITE
- LAF-FO
- Status orbitopalpebrale--Hertel

## BILAN

Bilan sanguine: FSS +/- Hémocultures si >38°/ frissons

CT orbitaire-sinus-cérébral: évaluation des sinu, extension de inflamm orbitaire.

IRM cérébrale si complication intracranien suspecte.

Evaluation ORL urgente si suspicion d'origine sinusale

## TTT

**HOSPITALISATION-**stop AINS-délimitation zone inflamm cutanée- controle de immunite au tetanus di trauma.

ATB I.V EMPIRIQUE-MIN 10J

\*\*\*dès que possible adapter therapie atb i.v. à étiologie à antibiogramme\*\*\*

## ENFANTS

Amox/Clavulanate 150mg/kg/j en 3xj

Si allergies aux B-lactamines: Levofloxacine: enf >6mois et < 5ans: 20mg/kg/j en 2xj. Enf >5 ans: 10mg/kg/j en 1xj ( max 750mg/j)

Alterantive: céfotaxime 200mg/kg/j 3xj ( max 12g/j)

Si doute pour infect des germes anaerobes: Metronidazole, 40mg/kg/j en 2xj ( max 1.5g/j) à rajouter.

## ADULTES

Amox/Clavulanate 2.2g 3xj

Si Portage MRSA connu: Vancomycine 15-20mg/kg/12h à RAJOUTER DANS TOUS LES CAS.

Si sepsis: Vancomycine 15-20mg/kg/12h + Piperaciline/Tazobactam 4.5mg/8h.

Si allergies aux Beta-lactamines ( immediate, anaphylaxie): Vancomycine 15-20mg/kg/12h + Moxifloxacine 400mg/24h

Si allergies aux B-Lactamines+ sepsis: Vancomycine 15-20mg/kg/12h + Impenème 1g 4xj.

## +/- Add Cortis I.V

**ENFANTS:** add avis ORL pédriatique

**ADULTS:** solumedrol 250mg/j -selon protocle CHUV, 48h après stabilisation de infection + IPP(pantoprazol) 20mg/j.

## REMARQUES

**ATB I.V. jusqua obtention apyrexie et diminution de oedeme palpebrale puis relais p.o. par amox/clav pdt min 10j.**

**ADULTES:** 875/125 mg 2xj

- Alternatives si allergies penicilline: Clindamycine 600mg/8h
- Bactrim forte 800/160mg 1x/12h

**ENFANTS:** 80mg/kg/j 2-3xj doses max 90mg/kg/j

## COMPLICATIONS

Neuropathies optique ( BAV, RAPD, dyschromatopsie)

Trombophlébite du siuns caverneux

Collection: traitement chirurgicale: ponction de l'abces ou ouverture-drainage dela collection par orbitomie par voie ant ou par voie endonasale.

## SUIVI

Evaluation clinique systemique toutes les 4h ( contants vitales: TA-FC-FR-Ta)

Ealuation cléinique ophtalmique toutes les 12h (AV-pupilles-TIO)

En cas de complication:

Evaluation clinique sytemique et ophtalmique toutes les heures +/- prise en charge chirurgicale
