---
categoria: apuntes
area: cornea
emoji: 👁️
seccion: Cornée
orden_seccion: 4
orden: 31
fuente: OneNote del Dr. Castilla Martí
---
# Dellen

El **signo de Dellen** es una **adelgazamiento localizado del estroma corneal periférico**, no inflamatorio, que se presenta típicamente **adyacente a una lesión elevada o una alteración del relieve ocular** (como una pinguécula, pterigión, injerto, o edema conjuntival).

## 🔬

## Fisiopatología

- Se produce por **desecación local** de la superficie corneal, secundaria a **interferencia con el flujo normal de la película lagrimal**.
- La zona deprimida **no capta fluoresceína** (a diferencia de una úlcera), pero puede parecer erosionada.
- La epitelización está preservada o ligeramente alterada, **sin infiltrado**, **sin neovascularización**.

## 👁️

## Características clínicas

- Adelgazamiento corneal **paracentral o periférico**.
- Aparece como una **depresión clara**, seca, adyacente a una elevación (pinguécula, injerto escleral, sutura, etc.).
- **Asintomático o con leve sensación de cuerpo extraño**.
- Reversible si se trata la causa mecánica o de exposición.
