---
categoria: apuntes
area: catarata
emoji: 🔍
seccion: Cristallin - Lens
orden_seccion: 21
orden: 2
fuente: OneNote del Dr. Castilla Martí
---
# POST-OP PHAKO

ORDONNACE POST-PHAKO DRE.CAYETTE

## Post phaco

TOBRADEX

1 goutte 3 fois par jour pdt 1 mois

NEVANAC

1 goutte 3 fois par jour pdt 1 mois

Port de la coque uniquement la nuit pdt 7 jours
