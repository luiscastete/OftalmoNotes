---
categoria: apuntes
area: retina-quirurgica
emoji: 🪡
seccion: Ret Chirg
orden_seccion: 6
orden: 12
fuente: OneNote del Dr. Castilla Martí
---
# Terson´s syndrome

## 🔍Resumen: Síndrome de Terson

El **síndrome de Terson** se define como la presencia de **hemorragia intraocular (vítrea, subhialoidea o intrarretiniana)** asociada a **hemorragia subaracnoidea (HSA)** u otras formas de **hipertensión intracraneal aguda**.

## 📌Características clínicas

- Puede ser unilateral o bilateral.
- La hemorragia vítrea es la más común.
- Frecuentemente asociado a ruptura de aneurismas (especialmente de la comunicante anterior) que provocan HSA.
- El daño visual puede ser severo y persistente si no se resuelve la hemorragia vítrea.

## 🧠Fisiopatología

Se cree que la presión intracraneal elevada se transmite a través de la vaina del nervio óptico → congestión de la vena central de la retina → ruptura de pequeños vasos → hemorragia intraocular.

## 🔬Diagnóstico
