---
categoria: apuntes
area: neuro
emoji: 🧠
seccion: Neuro-Ophta
orden_seccion: 8
orden: 33
fuente: OneNote del Dr. Castilla Martí
fecha: 2022-09-17
---
# Problème fonctionnelle

neuro-ophtalmo:

-Pas RAPD

-pas alt ni douleur à la mobilisation oculaire

-Ishihara 0/13

-CV par confrontation 4/4

Mojon test + 6/8.
