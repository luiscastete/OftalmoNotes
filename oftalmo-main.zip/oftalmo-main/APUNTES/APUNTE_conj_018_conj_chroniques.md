---
categoria: apuntes
area: cornea
emoji: 💧
seccion: Conj + Episclere + Sclere
orden_seccion: 25
orden: 18
fuente: OneNote del Dr. Castilla Martí
---
# Conj chroniques

Los agentes infecciosos que pueden causar **conjuntivitis crónica** (≥4 semanas de duración) son menos comunes que los agudos, pero importantes por su evolución prolongada o recurrente. Aquí tenés los principales:

🔴 **1. Chlamydia trachomatis**

🟠 **2. Neisseria gonorrhoeae**

🟡 **3. Virus (menos frecuente en cronicidad)**

🟢 **4. Mycobacterium tuberculosis**
