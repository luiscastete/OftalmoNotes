---
categoria: apuntes
area: glaucoma
emoji: 🟢
seccion: Glaucome
orden_seccion: 5
orden: 9
fuente: OneNote del Dr. Castilla Martí
fecha: 2024-01-28
---
# PEX's o PXF syndrome

## PEX's ou PEC

Le syndrome de pseudo-exfoliation capsulaire (PEC) est une atteinte systémique d’étiologie inconnue, liée à l’âge, définie par la production et le dépôt anormal de matériel fibrillaire pseudo-exfoliatif dans le segment antérieur. La PEC est la première cause identifiable de glaucome chronique à angle ouvert.

Pseudoexfoliation syndrome (PXF or PEX) is an age-related systemic syndrome that targets mainly ocular tissues through the gradual deposition of fibrillary white flaky material from the lens, mainly on the lens capsule, ciliary body, zonules, corneal endothelium, iris and pupillary margin.   There is a higher prevalence of open angle glaucoma in about 50% of these patients.

Caract:

The disease may be **bil**ateral and **asy**mmetric.

Peripupillary atrophy with transillumination at the pupillary margin is typical. Vs Peripheral iris transilumination defects are much more typical of pigment dispersion szndrome.

It has been associated with myocardial infarction, cerebrovascular events and systemic hypertension.

## Primary prevention

- Routine annual eye exam by an ophthalmologist for patients over age 50.
- Biomicroscopic examination (slit lamp) by an eye doctor to examine the anterior lens capsule, pupillary dilation, intraocular pressure and optic nerve.
- Treatment of elevated eye pressure with eye drops, laser or surgery.
- Special precaution and awareness is essential prior and during cataract surgery.
  - Anterior chamber depth less than 2.5mm centrally could be an indication of zonular instability
  - Poor pupillary dilation
  - Zonular dialysis
  - Phacodonesis

All of the above may pose a significantly higher risk for intraoperative complications.
