---
categoria: apuntes
area: oculoplastica
emoji: 🫥
seccion: Oculo-Plastie
orden_seccion: 3
orden: 9
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-01-29
---
# Blépharite

Les blépharites correspondent à une inflamm des paupieres  et peuvent etre subdivises en bléph ant et post selon les zones ateintes bien qu'il y ait un chevauchement entre ces deux entites.

Pathologie très frequente: 30-50% des patients ont signes de blépharite.

- **Blépharite ANTERIEURE:**

Bord ant des paupieres et de la racine des cils, plus souvents pour accumulation bactéries sur la partie externe paupiere.

- **Blépharite POSTERIEUR:** (Dysfonct. Glande meibomius)

atteint glande de meibomius avec obstrc ou secretions anormlaes de leur contenu.

## SYMPT

irritation, démangeaison, sensation sable, larmoiments, rougeur ocul, croutes et secretions autour yeux le matin.

## SIGNES

## B.ANT

- HC, oedeme bords palpebrale, croutes au tour cils, desquamation en collerettes sutour des cils, madarose ( chute des poils-alopecie ciliar), trichiases, ulceration cutanée (severe), signes secherese ocualire.

## B.POST

- assoc ROSACEE?
- HC, telangiectasies (surtout si rosacée), oedeme paupieres, obstruc glande et expression contenu à la digipression. Secretions épaisses, signes secheresse oculaire.

## STATUS

- LAF: Paupieres: rebord palpebrale: croutes? Télangiectasies? Aspect abouchement glandes meib?
- Conj: HC? Phlyctenes? Papilles?
- Cornée: BUT? KPS?
- Atteinte dermatologique associe? Rosacé? Acné? Demodex?

## TTT

## 1.Simple

-Hygiene des paupieres avec compresses chaudes sur les paupieres pdt 5-10 min et massage +/- lingettes nettoyantes stériles blephaclean 3xj

-Optava 4 -8xj pdt 2-3 sem

## 2.Si ANT

Fucithalmic gel 2xj pdt 3 sem ( à repeter si besoin)

## 3.Si sévère

-Maxitrol / Tobradex pommade 2xj 10j.

## 4.TTT DE FONDE à considere

Azyter gtt 2xj (matin et soir) pdt 3j de suite  1 à 3 fois par mois pdt 1 à 3 mois puis espacer ou arreter.

Ou consecutifs tous les 15j pdt 3mois.

## 5.Autres options

Doxycicline p.o. 100 mg 1xj pdt 2 sem puis 50mg 1xj pdt 2-3 mois.

Ciclosporine gtt 0,05% 2xj pdt 3 mois

## Tratamiento fórmula magistral papa&mama

- Champu phneutro de bebe (johnson&johnson) 100ml
- +
- Aceite esencial de arbol de té 5ml (mindbreaker)

- Lavados pestañas y parpados ( no dentro del ojo) 1xdia durante 2 semanas.

- Champu ph neutre pour bebe (johnson&johnson) 100ml
- +
- Huile essentielle d'arbre à thé 5ml

- 1er lavage avec champu et ensuite huille essentielle
- Lavage des cils et des paupières (pas à l'intérieur de l'œil) 1x par jour pendant 2 semaines.

Champu neutro + gotas de arbol de the lo mejoraito segun el Paa

## SUIVI

PC pas systematique

Controle 1-3 mois en fonction severite.

## Common foundation (all three)

- **Lid hygiene** — warm compresses, lid scrubs
- **Artificial tears** (MGD-related dry eye)
- **Oral doxycycline** (or azithromycin in young) — indicated in all three when moderate-severe

## Rosacea-associated blepharitis

- Oral **doxycycline** is the **cornerstone** — most evidence-based indication
- Sub-antimicrobial dose (40mg modified-release) well validated here
- **Topical metronidazole / ivermectin** (for facial rosacea skin component)
- **Cyclosporine 0.1%** eye drops (Ikervis) if secondary dry eye/inflammation
- Avoid triggers (UV, heat, alcohol, spicy food)
- **Longer treatment courses** needed — tends to be chronic/relapsing
- Refer to dermatology for systemic rosacea management

## Seborrheic dermatitis-associated blepharitis

- **Antifungal** component important (*Malassezia* role) — **not needed in rosacea/MGD**
  - Topical **ketoconazole** or **selenium sulfide** for facial/scalp SD
  - **Tea tree oil** lid scrubs (also anti-*Demodex*)
- **Low-potency topical steroids** short-term for facial SD flares
- Doxycycline less central here unless significant posterior component
- Treat **scalp seborrhea** simultaneously (antifungal shampoos)
- **Demodex** infestation often co-exists → **ivermectin** (topical or oral) or tea tree oil scrubs

## Meibomian gland dysfunction (primary MGD)

- **Physical treatments** are most important here:
  - **Warm compresses** (≥10 min) + **meibomian gland expression**
  - **LipiFlow** / thermal pulsation devices
  - **Intense Pulsed Light (IPL)** — growing evidence, especially rosacea-associated MGD
- **Omega-3 fatty acid** supplementation (evidence moderate)
- Doxycycline — useful when inflammatory component present
- **Topical azithromycin** on lid margins
- Cyclosporine / lifitegrast for associated dry eye disease

## Summary table

| **Treatment** | **Rosacea** | **Seborrheic** | **MGD** |
|---|---|---|---|
| Lid hygiene | ✅ | ✅ | ✅ |
| Oral doxycycline | ✅✅ | ✅ (if posterior) | ✅ (if inflamed) |
| Antifungals | ❌ | ✅✅ | ❌ |
| IPL | ✅✅ | ➖ | ✅✅ |
| LipiFlow | ➖ | ➖ | ✅✅ |
| Topical steroids (short) | ➖ | ✅ | ➖ |
| Cyclosporine drops | ✅ | ➖ | ✅ |
| Anti-Demodex (ivermectin/TTO) | ➖ | ✅✅ | ➖ |
| Omega-3 | ➖ | ➖ | ✅ |

**Key principle:** identify the **primary etiology** and **layer affected** (anterior vs posterior lid), then tailor accordingly — often these conditions **co-exist**, requiring a combined approach.
