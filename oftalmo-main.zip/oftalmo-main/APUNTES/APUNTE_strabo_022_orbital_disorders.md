---
categoria: apuntes
area: pediatria
emoji: 👀
seccion: Strabo-logie
orden_seccion: 22
orden: 22
fuente: OneNote del Dr. Castilla Martí
---
# Orbital Disorders

## Congenital anomalies

## Buphtalmos

Large eye as a result of increased intraocular pressure (IOP) in congenital glaucoma

Microphtalmos

Small, disorganized eye – pathologique

Nanophtalmos

Small eye with normal features – not pathologic

Associated with hyperopia and angle-closure glaucoma
