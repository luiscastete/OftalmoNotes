---
categoria: apuntes
area: neuro
emoji: 🧠
seccion: Neuro-Ophta
orden_seccion: 8
orden: 15
fuente: OneNote del Dr. Castilla Martí
---
# Aberturas del ápice orbitario

## Aberturas del ápice orbitario

En el **ápice de la órbita** hay **tres aberturas principales**:

1️⃣ **Optic canal**

2️⃣ **Superior orbital fissure (SOF)**

3️⃣ **Inferior orbital fissure (IOF)**

Cada una conecta la órbita con regiones distintas del cráneo.

## 1️⃣Optic canal

- Conecta:

- **órbita ↔ fosa craneal media**

- Contiene solo **dos estructuras importantes**:

  - **nervio óptico (II)**
  - **arteria oftálmica**

- 💡 **Muy preguntado:**
- la arteria oftálmica **no entra por la SOF**, entra por el **optic canal**.

## 2️⃣Superior orbital fissure (SOF)

- Conecta:

- **órbita ↔ seno cavernoso / fosa craneal media**

- Estructuras principales:

- **Dentro del anillo de Zinn**

  - **III**
  - **VI**
  - **nasociliar (V1)**

- **Fuera del anillo**

  - **IV → oblicuo superior**
  - **frontal (V1)**
  - **lagrimal (V1)**

- **Vasos**

  - **vena oftálmica superior**

- 💡 Esto explica el **síndrome de la fisura orbitaria superior**.

- **Fisura orbitaria superior y anillo de Zinn (visión clínica para examen)**

- La **fisura orbitaria superior (SOF)** comunica la **órbita con la fosa craneal media**.
- Se divide clínicamente según su relación con el **anillo tendinoso común (anillo de Zinn)**, que es el origen de los **músculos rectos extraoculares**.

- **1️⃣Estructuras por encima del anillo de Zinn (extraconales)**

- No atraviesan el anillo.

- **Nervios:**

  - **nervio lagrimal (V1)**
  - **nervio frontal (V1)**
  - **nervio troclear (IV)** → **inerva el músculo oblicuo superior**

- **Vasos:**

  - parte de la **vena oftálmica superior**

- **2️⃣Estructuras dentro del anillo (intraconales)**

- Este grupo es **muy importante para examen** porque corresponde al **espacio intraconal**.

- **Nervios:**

  - **división superior del III** →
    - **recto superior**
    - **elevador del párpado**
  - **división inferior del III** →
    - **recto medial**
    - **recto inferior**
    - **oblicuo inferior**
  - **nervio nasociliar (V1)**
  - **nervio abducens (VI)** → **inerva el músculo recto lateral**

## 3️⃣Estructuras por debajo del anillo

- **vena oftálmica superior o inferior (variable)**
- **fibras simpáticas del plexo carotídeo**

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## Regla rápida para recordar

## Fuera del anillo

- IV
- frontal
- lagrimal

## Dentro del anillo

- III
- VI
- nasociliar

## Síndromes importantes

## 1️⃣Síndrome de la fisura orbitaria superior

Afecta:

- III
- IV
- VI
- V1

Clínica:

- oftalmoplejía
- ptosis
- midriasis
- hipoestesia V1

Causas:

- trauma
- tumores
- trombosis seno cavernoso
- **Tolosa-Hunt**

## 2️⃣Síndrome del ápice orbitario

Es como el anterior **pero con afectación del nervio óptico**.

Afecta:

- II
- III
- IV
- VI
- V1

Clínica:

- **pérdida visual**
- oftalmoplejía
- anestesia V1

Causas frecuentes:

- mucormicosis
- tumores orbitarios
- inflamación
- trauma

## 3️⃣Inferior orbital fissure (IOF)

Conecta:

## órbita ↔ fosa pterigopalatina + fosa infratemporal

Estructuras:

- **nervio infraorbitario (V2)**
- **nervio cigomático (V2)**
- **arteria y vena infraorbitaria**
- **vena oftálmica inferior**
- ramas del **ganglio pterigopalatino**

## ¿Existe síndrome de la fisura orbitaria inferior?

Sí, pero **es mucho menos clásico y menos preguntado**.

## Fisura orbitaria inferior

Estructuras:

- **nervio infraorbitario (V2)**
- **nervio cigomático (V2)**
- **vasos infraorbitarios**
- **vena oftálmica inferior**

Lesión produce:

- **hipoestesia mejilla**
- **hipoestesia párpado inferior**
- hipoestesia del **labio superior**

Frecuente en:

- fracturas **blow-out**

## Comparación rápida (muy útil para examen)

| **Abertura** | **Estructuras** |
|---|---|
| **Optic canal** | II + arteria oftálmica |
| **SOF** | III, IV, VI, V1 |
| **IOF** | V2 |
|  |  |

Muchos profesores lo resumen así:

## 2 – 3,4,5,6 – V2

## Perlas EBO que suelen preguntar

## 1️⃣LR6 SO4 R3

- **recto lateral → VI**
- **oblicuo superior → IV**
- **resto → III**

## 2️⃣Nervio más vulnerable en seno cavernoso

👉 **VI**

porque está **dentro del seno**, no en la pared.

## 3️⃣Blow-out fracture

Afecta:

- **suelo orbitario**
- **infraorbital nerve (V2)**

Clínica:

- diplopía
- hipoestesia mejilla

## 4️⃣Bloqueo retrobulbar

Se realiza en el **espacio intraconal**.

Bloquea:

- III
- VI
- ganglio ciliar

Puede **no bloquear IV**.

## 5️⃣Síndrome del ápice orbitario

Afecta:

- **II**
- **III**
- **IV**
- **VI**
- **V1**

Diferencia clave con SOF syndrome:

👉 **hay pérdida visual**.

\_\_\_-

## Preguntas típicas del EBO sobre esta zona

## 1️⃣Anestesia retrobulbar

La aguja entra en el **espacio intraconal**.

Bloquea:

- **III**
- **VI**
- **ciliar ganglion**

No siempre bloquea:

- **IV** (porque está fuera del anillo)

Por eso a veces **queda movimiento del oblicuo superior**.

## 2️⃣Anestesia peribulbar

La aguja queda **extraconal**.

Ventajas:

- menor riesgo de:
  - perforación ocular
  - lesión del nervio óptico

Desventaja:

- efecto más lento.

## 3️⃣Estructura más vulnerable en seno cavernoso

El **VI**.

Porque está **libre dentro del seno cavernoso**, mientras que III, IV y V1 van en la pared.

## 4️⃣Fractura blow-out

Afecta:

- **suelo orbitario**
- nervio **infraorbitario (V2)**

Clínica:

- hipoestesia mejilla
- diplopía por atrapamiento del **recto inferior**

## Mnemotecnia rápida de músculos extraoculares (EBO clásico)

## LR6 SO4 R3

- **recto lateral → VI**
- **oblicuo superior → IV**
- **resto → III**

**Localización de lesiones orbitarias (intraconal vs extraconal vs ápice)**

En los **casos clínicos del EBO**, muchas preguntas intentan que **localices dónde está la lesión en la órbita**.

La órbita se divide en **tres compartimentos clave**:

1️⃣ **Extraconal**

2️⃣ **Intraconal**

3️⃣ **Ápice orbitario**

La referencia anatómica es el **cono muscular formado por los rectos extraoculares** (anillo de Zinn).

## 1️⃣Espacio extraconal

Ubicación:

Entre:

- hueso orbitario
- músculos extraoculares

Es decir **fuera del cono muscular**.

## Lesiones típicas

- **dermoid cyst**
- **lacrimal gland tumors**
- hemangioma extraconal
- absceso orbitario

## Clínica típica

- **proptosis con desplazamiento del globo**
- desplazamiento **no axial**

Ejemplo:

tumor de glándula lagrimal →

## globo desplazado inferomedialmente

💡 **Regla EBO**

## Extraconal = proptosis no axial

## 2️⃣Espacio intraconal

Ubicación:

**dentro del cono muscular**, alrededor de:

- nervio óptico
- vasos oftálmicos
- ganglio ciliar

## Lesiones típicas

- **cavernous hemangioma** (más clásico)
- schwannoma
- meningioma del nervio óptico
- metástasis

## Clínica típica

- **proptosis axial**
- pérdida visual progresiva
- alteración de motilidad tardía

💡 **Regla EBO**

## Intraconal = proptosis axial

## 3️⃣Ápice orbitario

Ubicación:

Zona posterior donde convergen:

- **optic canal**
- **superior orbital fissure**

Estructuras:

- II
- III
- IV
- VI
- V1

## Síndrome del ápice orbitario

Clínica:

- **pérdida visual**
- oftalmoplejía
- anestesia V1
- ptosis

Causas clásicas:

- **mucormicosis**
- tumores
- inflamación
- trauma

## Caso 1

Proptosis **axial**, progresiva, sin dolor.

👉 **Cavernous hemangioma intraconal**

## Caso 2

Proptosis con **desplazamiento inferomedial del globo**.

👉 **Tumor glándula lagrimal (extraconal)**

## Caso 3

Visión ↓ + oftalmoplejía.

👉 **Orbital apex syndrome**

## Tabla rápida para examen

| **Compartimento** | **Hallazgo típico** |
|---|---|
| **Extraconal** | proptosis no axial |
| **Intraconal** | proptosis axial |
| **Ápice orbitario** | pérdida visual + oftalmoplejía |

💡 **Perla muy preguntada**

El **tumor orbitario benigno más frecuente en adultos** es:

👉 **cavernous hemangioma**

y suele ser **intraconal**.

## Proptosis axial

La **proptosis axial** significa que el **globo ocular se desplaza directamente hacia adelante**, **sin desviarse hacia arriba, abajo, medial o lateral**.

Es decir:

👉 el ojo **sale recto hacia delante siguiendo el eje visual**.

Esto ocurre típicamente cuando la lesión está **dentro del cono muscular orbitario (espacio intraconal)**.

## Por qué ocurre

Los **cuatro músculos rectos** forman un **cono muscular** alrededor del nervio óptico.

Si una masa aparece **dentro de ese cono**, empuja el globo **simétricamente hacia adelante**.

Por eso el desplazamiento es **recto (axial)**.

## Lesiones típicas que producen proptosis axial

Las más clásicas:

- **hemangioma cavernoso orbitario** (muy típico de examen)
- tumores del **nervio óptico**
- schwannoma intraconal
- metástasis intraconales

## Diferencia con proptosis no axial

## Proptosis no axial (excéntrica)

Aquí el ojo **no sale recto**, sino que se **desplaza en una dirección específica**.

Esto ocurre cuando la lesión está **fuera del cono muscular (extraconal)**.

Ejemplo clásico:

## tumor de glándula lagrimal

- está **superolateral**
- empuja el ojo **inferomedialmente**

## Regla rápida de examen (muy usada en EBO)

| **Tipo de proptosis** | **Localización probable** |
|---|---|
| **Axial** | intraconal |
| **No axial** | extraconal |

💡 **Perla muy preguntada**

El **tumor orbitario benigno más frecuente en adultos**:

👉 **hemangioma cavernoso**

y produce típicamente **proptosis axial lenta y progresiva**.

\_\_\_\_

**Cómo diferenciar proptosis tiroidea, tumoral y vascular (clave para casos clínicos EBO)**

En los **casos clínicos del EBO**, muchas veces describen **proptosis** y debes deducir la causa según **clínica + evolución + signos acompañantes**.

Las tres causas más preguntadas son:

- **tiroidea (Graves orbitopathy)**
- **tumoral**
- **vascular**

## 1️⃣Proptosis tiroidea (orbitopatía tiroidea)

Causa: enfermedad de Graves.

Características típicas:

- **bilateral (frecuente)**
- **axial**
- evolución **lenta**
- retracción palpebral
- **lid lag**
- limitación de motilidad (sobre todo **recto inferior**)
- exposición corneal

En imagen:

- **engrosamiento de músculos extraoculares**
- **respeto de los tendones**

💡 Frase clásica de examen:

## “muscle belly enlargement with tendon sparing”

## 2️⃣Proptosis tumoral

Generalmente causada por **masa orbitária**.

Características:

- **unilateral**
- progresiva
- **indolora**
- puede ser **axial o no axial**

Ejemplo típico del EBO:

## hemangioma cavernoso

Hallazgos:

- adulto
- proptosis **axial lenta**
- pérdida visual tardía

## 3️⃣Proptosis vascular

Aquí la clave es que la proptosis **cambia con el flujo sanguíneo**.

## Fístula carótido-cavernosa

Características:

- **proptosis pulsátil**
- **quemosis**
- **arterialización conjuntival**
- soplo orbitario
- aumento presión intraocular

Signo clásico:

## “red eye + pulsatile proptosis”

## Variz orbitária

Características:

- proptosis **intermitente**
- aparece con **Valsalva**
- aumenta al inclinar la cabeza

Esto ocurre porque se **llenan las venas orbitarias**.

## Tabla comparativa (muy útil para examen)

| **Tipo** | **Características** |
|---|---|
| **Tiroidea** | bilateral, axial, músculos engrosados |
| **Tumoral** | unilateral, progresiva |
| **Vascular** | pulsátil o intermitente |

## Pistas que suelen aparecer en preguntas EBO

## Si dicen

## proptosis bilateral + retracción palpebral

👉 orbitopatía tiroidea

## Si dicen

## proptosis pulsátil + quemosis

👉 fístula carótido-cavernosa

## Si dicen

## proptosis que aparece con Valsalva

👉 variz orbitária

## Si dicen

## proptosis axial lenta en adulto

👉 hemangioma cavernoso

💡 **Perla muy preguntada**

El **músculo más afectado en orbitopatía tiroidea** es:

👉 **recto inferior**

Orden clásico:

## I’M SLOW

- **I**nferior rectus
- **M**edial rectus
- **S**uperior rectus
- **L**ateral rectus
- **O**bliques (raros)

\_\_\_
