---
categoria: apuntes
area: cornea
emoji: 👁️
seccion: Cornée
orden_seccion: 4
orden: 12
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-01-30
---
# Kératite ultraviolet ( photokératite + ophtalmie des neiges )

Causée par exposition des yeux rayons ultraviolets (UV) sans lunettes de protection.

\*\*Cornée transmets spectre 400nm-700nm MAIS absorbe longuers d'one dans spectre UV 10nm-400nm.  Cette absortion va créer des dégats cornéens. La douleur provient de l'éxposition du plexus nerveux sous-épithélial.

Sympt: bilat et péjoration à 6-12h après expos. Douleur sévère, sensation CE, blépharosphasme, photophobie, larmoiments, BAV.

SIGNES:

Oedeme palpebrale modéré. HC, KPS, peu o pas oedeme cornéen, +/- reac CA.

Etiologie:

Activite montagne + sur la neige

Soudure (coup d'arc C'est utilise lorque UV provienent de l'arc electrique d'un poste de soudure)

Solarium

TTT:

Floxal ou Tobrex 4xj 5-7j

LA: optava ou Celluvisc 5-8xj pdt 2 sem

+/- Cyclopejie  Hamartropine avant le depart

+/- NACl 0,9% + Compresses froids et humides sur les yeux

+/- isolement lumiere ou lunettes de soleil

+/- Dafalgan 1g 3xj 1 sem

SUIVI:

Pas suivi d'emblée mais si grave dans 3-4j.
