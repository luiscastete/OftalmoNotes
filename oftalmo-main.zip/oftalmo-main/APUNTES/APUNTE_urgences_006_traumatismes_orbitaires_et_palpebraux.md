---
categoria: apuntes
area: urgencias
emoji: 🚑
seccion: URGENCES---TRAUMATOLOGIE
orden_seccion: 2
orden: 6
fuente: OneNote del Dr. Castilla Martí
fecha: 2024-03-14
---
# Traumatismes orbitaires et palpébraux

## EVALUATION GENERALE

Tout traumatisme de la fec doit etre considere comme un traumatisme cranien potentiel.

Toute perte de connaisance impose une examen neuro + scanner cerebrale + surveillance hospit 24h

Il faut eliminer une plaie ou une contusion du globe oculaire.

Si FO impossible faire USB

Tjrs vérifier status antitétanique VAT+/- SAT

Faire examen maxilo faciale- troubles de l'articule dentaire: fracture maxilo faciale, fracture mandibulaire, disjonction cranio.faciale-Fracture de Lefort?

## FRACTURE DE L'ORBITE

Elles comprenents:

- principalement les fractures **blow out** + souvent du plancher orbitaire et de la paroi ethmoidale.
- les fractures **en trappe** du plancher orbitaire.
- les fractures **blow in** du plafond orbitaire et du pilier externe, bcp plus rares.

## FRACTURE BLOW OUT

Elles comprennent aux traumatismes avec déplacement externe des murs orbitaires.

- **Fractures blow out de la paroi interne duplancher orbitaire**

  - Elle fait le plus souvent suite à un traumatisme ayant entraine une surpression brutale dans l'orbite par recul de l'oeil.

  - Cliniquement:
  - Énophtalmie initialement masquée par oedeme ou l'hématome.
  - Une anéesthesie ou hypoesthésie dans le territoire du nerf infra-orbitaire-joue gencive et levre sup.
  - Une diplopie verticale caracteristique avec limitation de l'élevation. Mais l'incarcelation du muscle droit inferieur n'est pas systemique. La diplopie es plus souvent d'origine neurogene-lesion du nerf innervant les mucle droit inf- que d'origine mecanique-incarcelation musculaire dans le foyer de fracture.

- **Fracture blow out dela paroi interne–lame papyracée**

  - Dans sa forme la plus freq. Pas diplopie ni énophtalmie, tout au plus un emphyseme sous-cutanée péeri-obitaire. Normalement tt conservateur. Si énoph ou incarcelatio add chirurgie.

- **Fracture Blow out du plancher et de la paroi interne associe**

- **Ces deux fractures sont freq. Associes.**

PERSISTANCE DIPLOPIE/éNOPHTALMIE AU 15em jour: indication chirurgicale avant le 30 jour.

## FRACTURE EN TRAPPE DU PLANCHER ORBITAIRE

L'originalite et la gravite de cette fracture en font une urgence ophtalmnologique.

Essentiellement en enfant et adolescent.

A l'inverse que blow out ou le plancher reste effondré, dans la fracture en trappe le plancher s'emtrouve et se referme spontanément piegant les éléments anatomiques herniées.

Le deficit oculomoteur est immédiat et majeur: oeil fixe et douleureux, particulariment dans le regarde en haut at souvent dans le regarde en ba. Le test de Lancaster et test de duction force confirment l'atteinte verticale.

Scanner: classique image en goutte du tissue hernie dans le foyer de fracture.

## TTT

## MEDICALE

- 1er intention.
- Ne pas se moucher.
- ATB augmentin 500mg 3xj pdt 7j.
- Anti-inflammatoire non steroidien- permet reduir l'oedeme et la diplopie et mieux apprécier une éventuelle énophtalmie.
- Anti-inflammatoire non steroidienes.
- Prevoir controle dans 7j + bilan orthoptique

## CHIRURGICALE

- Inseres un implant ou greffe ouseuse par voie conjonctivale ou palpebrale pour le plancher  afin de reconstruir le cadre orbitaire.
- En cas d'emphyseme ou d'hématome associé entrainant une exopht avec BAv ou occlusion ACR une indication de drainage de l'emphyseme chirurgicale  ou hématome en urgence se pose.

URGENCE CHIRURGICALE DANS LES 48H.
