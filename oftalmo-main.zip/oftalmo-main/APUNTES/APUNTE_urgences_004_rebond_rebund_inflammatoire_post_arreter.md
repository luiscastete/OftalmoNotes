---
categoria: apuntes
area: urgencias
emoji: 🚑
seccion: URGENCES---TRAUMATOLOGIE
orden_seccion: 2
orden: 4
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-02-11
---
# Rebond- rebund inflammatoire post arrêter cortis OD

Patiente post-op ou post ttt avec cortiseone qui a arreter du coup le corti ou antiinflammatoire.

Dans 1 mois post operation

Savoir quand est arreter le tobradex et combien de fois

>1 mois se posser des questions

Si rebond inflammatoire

Selon Cellules en CA DX 4xj

Suivi dans 5-7j et si bonne évolution

PC dans 1 avec schema degressif

PF 4xj pdt 5-7j puis 3xj pdt 5-7j, 2xj pdt 5-7j et 1xj pdt 5-7j
