---
categoria: apuntes
area: neuro
emoji: 🧠
seccion: Neuro-Ophta
orden_seccion: 8
orden: 35
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-05-26
---
# Suivi Plaquenil/Hydroxychloroquine

## Definition

Toxicite maculaire: dependante de la dose et la dure du ttt.

Presentation possibles: rétinopathie infraclinique ou maculopathie symtomatique en oeil de bouef.

## Mechanism of Toxicity

The mechanism of hydroxychloroquine retinal toxicity has yet to be fully elucidated. Studies have shown that the drug affects the metabolism of retinal cells and also binds to melanin in the RPE, which could explain the persistent toxicity after discontinuation of the medication. However, these findings do not explain the clinical pigmentary changes causing a bull’s-eye maculopathy.

## Recomendation dosage

## Dose maximale recommande: <5mg/kg/j

A verifie à chauqe consultation de controle.

Risque toxicite ret si dose <5mg/kg:

<1% après 5 ans

<2% après 10 ans

20% après 20 ans de tt

## FR

**Although it is not possible to predict which patients will develop retinal toxicity, high-risk characteristics include the following:**

## Dose journalier >5mg/kg; cumulative >1000g ou

## Durée de tt >5 ans

## Rétinopathie préexistante

## Insuffisance rénale +/- hepatopathie ( car clearence by both routes)

## Age >60ans

## Traitament concominant par tamoxiféne (Ca.sein).

## SYMPTOMES

Asymtomatique

Paracentral scotoma

Diminution perception couleurs

## SIGNES

- Changements en EPR maculaire ou perimaculaire
- Bilaterale tjrs! - si changements unilaterals investiguer autres causes

- **FAF:** maculopathie en oeil de boeuf avec dysautofluorescence périfovéolaire étendue au pôle posterieur (stade avance).
- **OCT maculaire:** atteinte sévère des photorecepteurs parafovéolaires et migration de l'épithélium pigmentaire.
- **CV 10°:** Scotomes annulaires, épargne centrale. \*\*raison AV 1.O et dangereuse!
- **Mf-ERG:** Diminution des amplitudes centrales.

## RECOMMENDATIONS

## AAO 2016

- **Examen de base-dans 1er an tt:**
- AV+FO
- Si suspicion de rétinopathie préexistante:
- SD-OCT maculaire
- CV Octopus 10°-30° si asiatique

- **Evaluation annuelle après 5 ans de tt:**
- AV+FO+SD-OCT maculaire
- FAF maculaire
- CV octopus 10°-30° si asiatique

- **Evaluation annuelle dès le début si:**
- Facteurs de risque
- Dose >5.0mg/kg/j

- Si examens pathologiques ou doute:
- add Mf-ERG

## HOJG

- **Examen de base, au debut du tt\*\*\*\***
- AV+FO+Photo FO
- SD-OCT maculaire
- FAF maculaire
- CV Octopus 10°-30° si asiatique
- Mf-ERG

- **Evaluation annuelle sous tt**
- AV+FO+Photo FO
- SD-OCT maculaire
- FAF maculaire
- CV Octopus 10°-30° si asiatique
- Mf-ERG

- Mf-ERG à répeter:
- Apres 5 ans de tt.
- Si suspicion de toxicité retinnienne ( anomalies présentes sur les autres examens)\*
- Patients asiatiques: examen également de la rétine péripherique, car pattern de rétinopathie toxique peripherique.

## Tt

Pas de tt. Est irreversible et peut progresser même après arret plaquenil.

-DD of Bull's-Eye Maculopathy

- Age-related macular degeneration
- Benign concentric annular dystrophy
- Central areolar choroidal dystrophy
- Chloroquine/hydroxychloroquine retinal toxicity
- Chronic macular hole
- Cone and cone-rod dystrophies
- Stargardt disease

Analyse des résultats:

SD-OCT:

- Précoce: Amincissement localisé de la rétine en région périfovéolaire ou extramaculaire, proche des arcades en asitiques.
- Possibles, précoce: Interruption focale de la couche externe des PHotorecepteus.

FAF

- Précoce: hyperfluorescence de EP en région périfovéolaire/extramaculaire. Peut préceder l'atteinte OCT.
- Tardive: hypofluorescence.

CV

- Atteinte initiale la plus frequente : rétino inf-temporale----deficit CV sup-nasal.

Analyse des résultats:
