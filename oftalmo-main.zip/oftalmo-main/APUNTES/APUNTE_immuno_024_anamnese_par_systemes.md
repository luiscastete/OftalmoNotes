---
categoria: apuntes
area: uveitis
emoji: 🔥
seccion: Immuno-infectio
orden_seccion: 7
orden: 24
fuente: OneNote del Dr. Castilla Martí
fecha: 2024-06-10
---
# Anamnese par systemes

Voici un ordre typique utilisé dans de nombreuses pratiques médicales :

## Généralités

- Fatigue
- Perte de poids involontaire
- Fièvre, frissons
- Sudation nocturne

## Peau

- Eruptions cutanées
- Prurit (démangeaisons)
- Plaies ou ulcères
- Changements dans les grains de beauté

## Tête et cou

- Céphalées
- Vertiges
- Douleurs au cou
- Masse ou enflure

## Yeux

- Troubles de la vision
- Douleurs oculaires
- Rougeur des yeux
- Sécrétions

## Oreilles, nez, gorge (ORL)

- Acouphènes
- Perte d'audition
- Rhinorrhée (écoulement nasal)
- Mal de gorge

## Appareil respiratoire

- Toux
- Dyspnée (difficulté à respirer)
- Expectoration (crachats)
- Douleur thoracique
