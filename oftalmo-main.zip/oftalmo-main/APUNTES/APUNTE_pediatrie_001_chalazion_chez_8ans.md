---
categoria: apuntes
area: pediatria
emoji: 🧸
seccion: Pediatrie
orden_seccion: 9
orden: 1
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-01-27
---
# Chalazion chez <8ans

<1a:

1er intention: HDP avec massages compresses chaudes 2xj+ rinçages nacl 2xj. Pdt 2 sem

2em intention: ttt simple + add maxitrol pommade exterieur.

<8a:

Ttt:

HDP + massages compresses chaudes 2xj + rinçages nacl 2xj + Maxitrol pommade externe 2xj 10-14j

EVITER TOBRADEX car contien aminoside avec risk toxicite rénal et auditive.
