---
categoria: apuntes
area: neuro
emoji: 🧠
seccion: Neuro-Ophta
orden_seccion: 8
orden: 1
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-08-24
---
# Quand référer en unité de neuro-ophta

Prise en charge en urgence des problémes neuro-ophta:

- Tout probleme neuro-ophta se présentant aux urgences de la policlinique est investigue par le MA/CDC de la policlinique.
  - perte de vision, diplopi, oscillopsies...
- Tout probleme neuro-ophta chez un pèatient hospitalisé au CHUV est examine par MA du CHUV.
- Tout patient posant probleme peut etre discute dans l'unité neuro-ophta

Suivi des patients examinées en urgences (HOJG-CHUV)

- Prise en charge non rugente des problemes neuro-ophta
- Tout patient référé par un ophta installé pour un 2em avis ( examen non urgnet) doit etre examiné directament dans l'unité neuro-ophta:
  - Neuropathie optique
  - Diplopie
  - Nystagmus
  - Atteinte du CV
  - Perte de vision inexpliqué
- Les patients examinés à la consultation ophta du CHUV qui nécessitent un suivi neuro-ophta doivent être référes directamnt en unité de neuro-ophta.
