---
categoria: apuntes
area: glaucoma
emoji: 🟢
seccion: Glaucome
orden_seccion: 5
orden: 8
fuente: OneNote del Dr. Castilla Martí
fecha: 2024-04-05
---
# Steroid-induced Glaucoma

The timeline over which the IOP will rise depends on the potency of the glucocorticoid, the dose, as well as the route of administration.

**With topical steroid use, the IOP rise most commonly occurs between three to six weeks from initial use, and typically normalizes within two weeks of the cessation of therapy**.[3]

HTIO suite 3 sem tt topique.

Donc avant 3 sem pas possible etre corticorespondeur.

Et normnalise suite 2 sem de arreter.

However, though three to six weeks is the most common time to see an IOP increase, patients can “respond” to steroids well after six weeks[4], and before three weeks, from initial use.[3] In one series, 2.8% of eyes that experienced an IOP elevation in the setting of steroid use converted to glaucoma. Interestingly, all of these patients had a family history of glaucoma.[5] The duration of steroid treatment may play a role in the IOP elevation as well, as indicated by one study in which the IOP was found to remain elevated in patients being treated with steroid for more than four years.[6]

https://eyewiki.aao.org/Steroid-Induced\_Glaucoma
