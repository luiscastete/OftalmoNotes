---
categoria: apuntes
area: uveitis
emoji: 🔥
seccion: Immuno-infectio
orden_seccion: 7
orden: 5
fuente: OneNote del Dr. Castilla Martí
fecha: 2024-03-20
---
# Conjonctivite à inclusión - Chlamydia

Infection de la conj tarsale et bulbaire d'origine bacterienne – Chlamydia trachomatis.

## SYMPTOMES

## OCULAIRE

- Les pls souvents: conj chronique >4 sem.
- Secretions mucupurulentes
- Hyperemie conjonctivale marquée

## GENEREAUX

Homme: urétrite +/- symptomatiques

Femme: cystite, vaginite (ecoulements) +/- maladie inflammatoire pelvienne i.e. annexite – risque d'infertilite et de syndrome de Fitz-Hugh-Curtis.

## SIGNES

- **Grand follicules – tarse inferieur +/- superieur**
- **Signes normalement unilaterales.**
- Si chronique: papilles
- Secretions muqueses et collantes
- **Adenopathies pétragienne palpable**
- **infiltrats sous-épithéliaux gris-blancs péripheriques**
- **Associe pannus précoce.**
- Kératite ponctiforme superficielles –KPS
- A longue terme :
- Cicatrices conjonctivales
- Pannus cornéen

## ETIOLOGIE

Chlamydia: bacteries intracellulars obligatoires – Frottis doit saigner\*\*

Chlamydia:

- C.Pneumoniae
- C.Trachomatis
- C.Psitacci
