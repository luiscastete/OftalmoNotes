---
categoria: apuntes
area: cornea
emoji: 👁️
seccion: Cornée
orden_seccion: 4
orden: 40
fuente: OneNote del Dr. Castilla Martí
---
# Eucornea Paris 24

Keratitis infectieus

Frottis

Atb + valaciclovir

Cortis après min 48h avec bonne ant

Add membrane amniotique

Sinon insulin drops

Wait 2 months: add keratoplastie?
