---
categoria: apuntes
area: cornea
emoji: 💧
seccion: Conj + Episclere + Sclere
orden_seccion: 25
orden: 4
fuente: OneNote del Dr. Castilla Martí
---
# C. Alergica 2.0

## 🟣4. Alergia y superficie ocular

## 4.1. Conjuntivitis alérgica estacional (CAE) y perenne (CAP)

## Patogenia

- Hipersensibilidad tipo I mediada por IgE.
- **Fase temprana** (20-30 min): degranulación de mastocitos MCTC → liberación de histamina, leucotrienos, prostaglandinas → vasodilatación y edema.
- **Fase tardía** (6h): infiltrado inflamatorio (eosinófilos, neutrófilos, linfocitos, macrófagos).

## Presentación clínica

- *CAE*: brotes en primavera-verano. Picor ocular bilateral, hiperemia, lagrimeo, estornudos y rinorrea.
- *CAP*: síntomas más leves y perennes, con reagudizaciones.

## Signos

- Hiperemia conjuntival, quémosis, edema palpebral, reacción papilar leve.

## Diagnóstico

- Clínico + antecedentes atópicos.
- Prick-test útil.
- Citología conjuntival: eosinófilos ↑.
