---
categoria: apuntes
area: pediatria
emoji: 👀
seccion: Strabo-logie
orden_seccion: 22
orden: 4
fuente: OneNote del Dr. Castilla Martí
---
# La ciclopléjia es esencial para medir la refracción en niños de forma fiable ya que la acomodación produce una infraestimación de la hipermetropía y una sobreestimación de la miopía.

La ciclopléjia es esencial para medir la refracción en niños de forma fiable ya que la acomodación produce una infraestimación de la hipermetropía y una sobreestimación de la miopía.
