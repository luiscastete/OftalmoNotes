---
categoria: apuntes
area: cornea
emoji: 👁️
seccion: Cornée
orden_seccion: 4
orden: 22
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-08-04
---
# PUK - kératite ulcérante périphérique (PUK)

Kératite ulcérante périphérique compliquant une polyarthrite rhumatoïde | SFO-online - Société Française d'Ophtalmologie

Peripheral Ulcerative Keratitis - StatPearls - NCBI Bookshelf (nih.gov)

https://www.ncbi.nlm.nih.gov/books/NBK574556/

Lien de arthur

La **recesión de la conjuntiva limbar** en el contexto de una **queratitis ulcerativa periférica (PUK, por sus siglas en inglés)** es un hallazgo clínico importante que indica un proceso inflamatorio crónico y autoinmune, con riesgo de perforación corneal y daño ocular permanente. A continuación, te explico el cuadro y las posibilidades terapéuticas.
