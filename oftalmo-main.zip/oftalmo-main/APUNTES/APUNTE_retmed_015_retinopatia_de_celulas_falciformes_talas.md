---
categoria: apuntes
area: retina-medica
emoji: 🩸
seccion: Ret Med y coroides
orden_seccion: 19
orden: 15
fuente: OneNote del Dr. Castilla Martí
---
# RETINOPATÍA DE CÉLULAS FALCIFORMES, TALASEMIA O DREPANOCÍTICA

## 🧠6.3. RETINOPATÍA DE CÉLULAS FALCIFORMES, TALASEMIA O DREPANOCÍTICA

## 🧾Definición

Retinopatía secundaria a **hemoglobinopatías hereditarias** (especialmente Hb SC y Hb SS), caracterizada por **isquemia retiniana periférica**, depósito de hierro y complicaciones proliferativas.

## 📈Epidemiología

- Afecta más frecuentemente a **población negra**.
- La **forma SC** es la que con **más frecuencia causa retinopatía proliferativa**.
- Otras formas: Hb SS, S-Thalassemia.

## 🔬Fisiopatología

- Obstrucción microvascular por **eritrocitos falciformes deformables**, que causan:
  - Isquemia periférica
  - Vasoproliferación secundaria
  - Depósitos férricos por hemólisis (exacerbados por transfusiones)
- Fármacos como **deferoxamina** (quelante de hierro) también pueden generar toxicidad ocular.
