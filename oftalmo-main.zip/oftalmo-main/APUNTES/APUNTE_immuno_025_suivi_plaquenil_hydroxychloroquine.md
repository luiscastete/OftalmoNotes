---
categoria: apuntes
area: uveitis
emoji: 🔥
seccion: Immuno-infectio
orden_seccion: 7
orden: 25
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-05-26
---
# Suivi Plaquenil/Hydroxychloroquine

## Definition

Toxicite maculaire: dependante de la dose et la dure du ttt.

Presentation possibles: rétinopathie infraclinique ou maculopathie symtomatique en oeil de bouef.

## Mechanism of Toxicity

The mechanism of hydroxychloroquine retinal toxicity has yet to be fully elucidated. Studies have shown that the drug affects the metabolism of retinal cells and also binds to melanin in the RPE, which could explain the persistent toxicity after discontinuation of the medication. However, these findings do not explain the clinical pigmentary changes causing a bull’s-eye maculopathy.

## Recomendation dosage

## Dose maximale recommande: <5mg/kg/j

A verifie à chauqe consultation de controle.

Risque toxicite ret si dose <5mg/kg:

<1% après 5 ans

<2% après 10 ans

20% après 20 ans de tt

## FR

**Although it is not possible to predict which patients will develop retinal toxicity, high-risk characteristics include the following:**

## Dose journalier >5mg/kg; cumulative >1000g ou

## Durée de tt >5 ans

## Rétinopathie préexistante

## Insuffisance rénale +/- hepatopathie ( car clearence by both routes)

## Age >60ans

## Traitament concominant par tamoxiféne (Ca.sein).

## SYMPTOMES

Asymtomatique
