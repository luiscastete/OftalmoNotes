---
categoria: apuntes
area: cornea
emoji: 👁️
seccion: Cornée
orden_seccion: 4
orden: 21
fuente: OneNote del Dr. Castilla Martí
---
# Ectasias Corneales- Queratocono

## 🧿Queratocono (QC)

*Ectasia corneal bilateral, asimétrica y progresiva caracterizada por adelgazamiento corneal, protrusión apical y astigmatismo irregular.*

## 🧬Etiopatogenia y características generales

• Degeneración progresiva del **estroma corneal** con adelgazamiento **central/paracentral**.

• Protrusión apical, astigmatismo irregular y miopización progresiva (claro mas curva+mas potencia).

• Afectación inicial unilateral, luego bilateral (topográfica).

• Edad de inicio típica: **10–30 años**.

• Factores asociados:

-Sistémicos: *Síndrome de Down, Marfan, Ehlers-Danlos, osteogénesis imperfecta*.

-Oculares: *frotamiento ocular crónico, aniridia, escleróticas azules, QC vernal, amaurosis congénita de Leber*.

• Herencia **autosómica dominante** con penetrancia incompleta (6–8% casos familiares).

## 🔍Clínica

## Síntomas

• Disminución visual progresiva por astigmatismo irregular.

• Halos, deslumbramientos, visión borrosa.

• Puede debutar con **hidrops corneal agudo**.

## Signos según estadio

| **Estadio** | **Signos clave** |
|---|---|
| **Precoz** | Reflejo en gota de aceite (oftalmoscopía),<br>reflejo en tijera en retinoscopía - signo de Rizzutti |
| **Intermedio** | Estrías de Vogt son VERTICALES (desaparecen con presión),<br>anillo de Fleischer (depósitos de hierro Fleischer-Fe++),<br>nervios corneales visibles -*los nervios corneales se hacen más prominentes,* |
| **Avanzado** | Signo de Munson (deformación en V del párpado-*consiste en la distorsión del párpado inferior cuando el paciente con queratocono avanzado mira hacia abajo,*),<br>hidrops corneal agudo (rotura de Descemet) |
|  |  |
