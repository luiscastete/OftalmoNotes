---
categoria: apuntes
area: pediatria
emoji: 👀
seccion: Strabo-logie
orden_seccion: 22
orden: 19
fuente: OneNote del Dr. Castilla Martí
---
# Ocular Aligment

## HORIZONTAL DEVIATIONS

-CONGENITAL ESOTROPIA

-ACCOMODATIVE ESOTROPIA

-NONACCOMODATIVE ACQUIRED ESOTROPIA

-INTERMITTENT EXOTROPIA

-CONGENITAL EXOTROPIA

-CONVERGENCE INSUFFICIENCY

-CONVERGENCE PARALYSIS SECONDARY TO INTRACRANIAL LESION

-SENSORY EXOTROPIA

## VERTICAL DEVIATIONS

-DISSOCIATED VERTICAL DEVIATIONS (DVD) ; DISSOCIATED HORIZONTAL DEVIATION (DHD) ; DISSOCIATED TORSIONAL DEVIATIONS (DTD)

-INFERIOR OBLIQUE OVERREACTION (IOOA)

-INFERIOR OBLIQUE OVERACTION

-INFERIOR RECTUS PALSY

-DOUBLE-ELEVATOR PALSY (MONOCULAR ELEVATION DEFICIENCY)

-BROWN SYNDROME (SO TENDON SHEATH SYNDROME)

-A- and V- PATTERNS

## SPECIAL FORMS OF STRABISMUS

## -DUANE RETRACTION SYNDROME

Type 1 : -limited aBduction - hypoplasia of abducens (CN VI) nucleus and absence of the abducens nerve.the LR is instead innervated by the CN III. 2 ppal findings: Limited aBduction and co-contraction of the Medial and Lat recti.

Co-contraction causes globe retraction + narrowing of the palpebral fissure "transients endophtalmos". Unilateral in 72% cases.

Surgery is exhibit:

- Primary position deviation
- Abnormal head posture
- Marked uo/downshoot in adduction
