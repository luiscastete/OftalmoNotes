---
categoria: apuntes
area: general
emoji: 💊
seccion: Pharmacologie Farma
orden_seccion: 23
orden: 11
fuente: OneNote del Dr. Castilla Martí
---
# Autonomic System

## Sympathetic

Extensive system for mass response (“fight or flight”)

Synapses near cord (superior cervical ganglion)

Long postganglionic nerves

## Adrenergic receptors

- ***α**1***: smooth muscle contraction (arteries **[decrease aqueous production by reducing ciliary body blood flow]**, iris dilator, Müller muscle)
- ***α**2***: feedback inhibition, ciliary body (decreases production and/or increases outflow)
- ***β**1***: cardiac stimulation
- ***β**2***: pulmonary and gastrointestinal (GI) smooth muscle relaxation,
