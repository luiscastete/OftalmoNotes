---
categoria: apuntes
area: oculoplastica
emoji: 🫥
seccion: Oculo-Plastie
orden_seccion: 3
orden: 10
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-08-16
---
# Canaliculite

## DEFINITION

Infection ou inflammation du canalicule lacrymal

## SYMPT

Gêne ou douleur au niveau du canalicule supeieur ou infeieur

Larmoiment

## SIGNES

Rougeur/tumefaction palpebrale en regard du point lacrymal

Hyperhémie conjonctivale en nasal

Larmoiment

Sécretions purulentes ( reflux à la pression du sac lacrymal)

## ETIOLOGIES

Infectieux: bacterien: actinormyces israelii 8 le plus freq)

Viral: HSV, VZV

Fongique: Candida, Fusarium, aspergillus.

Mécanique: CE ex: bouchons méatiques ou traumatismes.

Iatrogenes: dilatation, sondage, mise emn place bouchon lacrymal/clou trou ( plus souvent associé àpsudomonas aeruginosa).

## DX DIFFéRENTIELES

Chalazion

Dacryocystite

Obstrucction du canal lacrymo-nasal

## STATUS

AV-TIO

LAF: inspection paupieres, en particulier en regard des points lacrymaux: rougeur? Tuméfaction? Sténose point lacrymal? Sécretions?

Avec coton-tige, applique une pression sur le sac lacrymal et faire rouler vers le point lacrymal: reflux muco-purulent? Concretions?

## BILAN

Culture du materile prélevé ( rechercher examen direct, cultures)

## TT

## Tt médical ineficace

Tt chirurgical nécessaire: Curetage sous anethesie locale au bloc operatoire.

+/- canaliculotomie

Risque: Récidive

## Suivi

Cô 5-7j
