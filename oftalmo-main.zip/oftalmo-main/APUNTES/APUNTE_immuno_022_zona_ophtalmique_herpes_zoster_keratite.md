---
categoria: apuntes
area: uveitis
emoji: 🔥
seccion: Immuno-infectio
orden_seccion: 7
orden: 22
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-02-15
---
# ZONA ophtalmique (Herpes Zoster) / Kératite à VZV

## ZONA OPHTALMIQUE

**Correspond à une récurrence du virus VZV suite à une primo infection dans l'enfance- VACRICELLE.**

Après la phase de prodromes- cephalées, dysesthésies, fièvre.. L'éruption vésicules douloureuses puis crouteuses se produit dans le dermatome du ganglion sensitif concerne, le plus souvent le territoire d'inervation du nerf frontal, branche du nerf opthalmique V1- branche du nerf trijumeau V.

Le ZONA ( Herpes zoster) est in infection qui apparait lorsque le virus VARICELLE-ZONA (VZV) à l'état latent se réactive dans un ganglion nerveux sensitif de la racine rachidienne posterieur.

Le zona (herpès zoster) ophtalmique résulte de l'atteinte du ganglion de Gasser.

La VARICELLE et le zona ( herpes zoster) sont provoques par le virus varicelle-zona ( Herpes virus humain 3)

Varicelles est la phase aigue primaire de la maladie virale.

Zona ( herpes zoster) est la réactivation du virus de la phase latente.

infection virale de l'oeil et ses annexes qui se manifeste initialment par éruption cutanée et douleur impliquant le dermatome du nerf V1.

## QUAND REFERER A IMMUNO?

Si atteinte ocualire, UAA, Défect afferent, hyalite, atteinte oculomotricite, nécrose retinniene aigue.

## SYMPT

- **Prodromes:**
- (3-5j avant le rash) malaise, état fébrile, céphalées, douleurs +/- paresthesie le long du dermatome V1, douleur ocualire.

- **Cutanées:** éruption cutanée unilaterale et douleurese sur le trajet du nerf V1 ( bord palpebral inf épargné).

- **Oculaires:** BAV, sensation pression ocualire, sensation sable ou CE, douleur, larmoiment, photophobie et rougeur oculaire.
