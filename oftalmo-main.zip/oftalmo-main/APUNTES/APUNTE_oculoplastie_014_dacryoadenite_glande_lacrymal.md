---
categoria: apuntes
area: oculoplastica
emoji: 🫥
seccion: Oculo-Plastie
orden_seccion: 3
orden: 14
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-08-06
---
# DACRYOADENITE ( glande lacrymal)

## DEFINITION

Inflammation de la glande lacrymal

AIgue ou chronique uni o bilaterale

Plus freque chez les enfants/ jeunes adultes

## SYMP

Douleur et inflammation localisées dans la paertie supero-temporale de l'orbite

## SIGNES

Deformation en S de la paupiere superieur

Tumefaction de la glande lacrymale

Hyperemie de la conjonctive qui recrouve la glande lacrymal ( visible à l'éversion )

Secretions purulentes ( origene bacterienne)

Dystopie oculaire ( Downward & inward-deplacement du globe oculaire

Adénopathie prétragienne

Rare: état fébrile

## ETIOLOGIES

## AIGUE

Virale: RBV, adénovirus, rhinovirus, oreillons, CMV: les plus freq en enfants/junes adultes.

Bacterienne: staphylococus aureus, streptocoques

Idiopathique

## CHRONIQUE

Sarcoidose, syndrome de sjogren, granulomatose avec polyangeite, infection: TBS rare

Iidiopathique

Lymphome

## STATUS

**Status ophta:** AV-TIO-LAF-FO-OCULOMOTRICITE

**Status orbitopalpebrale:** Hertel, état des paupieres ( rougeur, tumefaction)

## BILAN

Si dacryoadénite aiguie + symptomes grippaux:

------> pas de bilan nécessaire car origine virale le plus probable.

Si dacryoadenite aiguie + élements atypiques ( patient âge, présentation bilaterale, symptomes systemiques suggérant u processus auto-immun systemique ou malin, persistance malgré le tt):

Bilan necessaire:

- Bilan sanguien: FSS, ANA, ANCA, ACE, Ac anti RO/SSA et anti-LA/SBB (sjogren).
- imagerie: IRM orbitaire
- Biopsie de la glande lacrymal 8 dans les cas atypiques, d'étiologie incertaine ou qui ne répondent pas de maniere appropriée au tt)

## TT

## Selon étilogie suspectée

## VIRALE

- résolution spontanée en 4-6sem.
- Lavage ocualire avec nacl 0,9% 2-3xj
- AINS p.o. ( irfen 400mg, 2xj pdt 5j chez adulte): bénefice incertain.

## BACTERIENNE

Tobradex pommade 4xj pdt 7j.

- **ADULTE:** Amox-clav 875/125mg 2xj pdt 7j.
- Aletrnative si allergie: Bactrim 1x/12h ou clindamycine 600mg/8h.
- **ENFANTS:** amox-clav 80-90mg/kg/j 2xj pdt 7j 8 dose max 875mg amoxiciline par prise, ce qui correspond à la dose adulte).
- **Si secretions purulentes:** add cultuzre avec antibiogramme pour addapter atb.
- **Si abcès:** +/- DRAINAGE CHIRURGICAL
- **Si maladie systemique ou lymphome:** adapter le tt

## SUIVI

Cô pdt 5-7j

Si réponse au tt mais persistnace d'une masse lacrymale >3mois: envisager une imagerie +/- biopsie
