---
categoria: apuntes
area: retina-medica
emoji: 🩸
seccion: Ret Med y coroides
orden_seccion: 19
orden: 27
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-08-21
---
# Maladie de Coats (dilatations vasculaires - telangiectasias retinianas) - Otras retinopatias proliferativas 1.0

La maladie de Coats (connu aussi sous les appellations rétinite exsudative, télangiectasie rétinienne primaire et télangiectasie rétinienne congénitale) est une rétinopathie idiopathique, congénitale, non-héréditaire, caractérisée par un développement anormal des vaisseaux de la rétine (télangiectasie) avec progressivement des dépôts d'exsudats intra- et sous-rétiniens, qui peuvent provoquer un décollement exsudatif de la rétine, des hémorragies vitréorétiniennes, un glaucome néovasculaire et finalement la perte de la vision.

La maladie est généralement unilatérale et affecte le plus souvent des garçons dans la première décennie.

Coats disease is a telangiectatic neovascular disease of the retina of unknown etiology that frequently affects unilateral eyes of young males.

George Coats[1] in 1908 described the histopathological features of enucleated eyes with massive exudation. He divided the morphology into 3 groups:

- "Group I demonstrated massive subretinal exudate alone,

- group II consisted of eyes with massive subretinal exudate, intra and subretinal hemorrhage, and retinal vascular dilatations, and

- group III included eyes with subretinal exudate and retinal arteriovenous malformations."[2] Later, Von Hippel recognized group 3 as a separate entity called angiomatosis retinae.
- A large study of 117 patients[3] took the definition of Coats disease as 'idiopathic retinal telangiectasia and intraretinal or subretinal exudation without appreciable signs of vitreoretinal traction.
