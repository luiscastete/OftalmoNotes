---
categoria: apuntes
area: retina-medica
emoji: 🩸
seccion: Ret Med y coroides
orden_seccion: 19
orden: 13
fuente: OneNote del Dr. Castilla Martí
---
# ERG vs EOG

## 🔷1.ERG (Electrorretinograma)

**Registra la respuesta eléctrica de la retina** ante estímulos luminosos.

## 🧬¿Qué mide?

- La actividad de:
  - **Fotorreceptores** (conos y bastones)
  - **Células bipolares**
  - (en parte) células amacrinas y Müller

## 🔍Tipos

| **Tipo de ERG** | **Evalúa principalmente…** |
|---|---|
| **ERG escotópico** | Bastones (visión nocturna) |
| **ERG fotópico** | Conos (visión diurna y colores) |
| **ERG patrón** | Células ganglionares y vía macular |
| **ERG multifocal (mfERG)** | Retina central en topografía |

## 🩺¿Para qué sirve?

- Diagnóstico de:
  - **Distrofias retinianas generalizadas** (retinosis pigmentaria, achromatopsia)
  - **Toxicidad por fármacos** (cloroquina)
  - **Retinopatías isquémicas difusas** (diabetes severa, CRVO)
- Detección de **función retiniana en ojos opacos** (media turbias)

## 🔷2.EOG (Electrooculograma)

**Mide el potencial eléctrico entre la córnea y la retina en condiciones de reposo** y **movimiento ocular lento**, en respuesta a ciclos de luz y oscuridad.

## 🧬¿Qué mide?

- **Función del epitelio pigmentario de la retina (RPE)**
- Refleja la salud del **acoplamiento neurosensorial-retinal**

## 🔍Parámetro clave

- **Índice de Arden** = relación entre potencial en luz/potencial en oscuridad
  - Normal: **>1.8**
  - Patológico: **<1.6**

## 🩺¿Para qué sirve?

- Diagnóstico de:
  - **Enfermedad de Best (vitelliforme)**: ERG normal, pero **EOG anormal**
  - **Enfermedad de Stargardt**
  - Algunas formas de **retinopatía oculta o disociada**

## 🎯RESUMEN COMPARATIVO

| **Característica** | **ERG** | **EOG** |
|---|---|---|
| ¿Qué mide? | Respuesta eléctrica de retina | Potencial entre retina y córnea |
| ¿Qué evalúa? | Fotorreceptores y células bipolares | RPE |
| ¿Requiere luz-flash? | Sí | Luz/oscuridad cíclica |
| ¿Indicaciones típicas? | Retinosis, toxicidad, isquemia | Best, distrofias maculares |
