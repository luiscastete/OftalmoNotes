---
categoria: apuntes
area: pediatria
emoji: 👀
seccion: Strabo-logie
orden_seccion: 22
orden: 8
fuente: OneNote del Dr. Castilla Martí
---
# Post/pre-op

POST-OP

Pas besoin dilate que si il y a signes d'inflammation u autre

PRE-OP

Dilat pour examiner si cicatrises avant intervention

STATUS

plaies chirirgicalae scalmes et point de suture en place

impre:

examen post op J1 ODG sans complication

att

tobradex gtt 3xj + pommade le soir + LA au besoin + antalgie

PC dans 1 sem

En myosis

Calme

impre:

examen post op J1 ODG sans complication

att

tobradex gtt 3xj + pommade le soir + LA au besoin + antalgie

PC dans 1 sem
