---
categoria: apuntes
area: cornea
emoji: 💧
seccion: Conj + Episclere + Sclere
orden_seccion: 25
orden: 15
fuente: OneNote del Dr. Castilla Martí
---
# C. Neonatorum

## 👶🏻OPHTHALMIA NEONATORUM – Conjuntivitis del recién nacido

## 📌Definición

Conjuntivitis que ocurre durante los **primeros 28 días de vida**. Es una de las infecciones más comunes del recién nacido. Su incidencia varía según la prevalencia de ETS y los cuidados perinatales.

## 🧬Fisiopatología

- El RN tiene una **conjuntiva inmadura**:
  - Ausencia de tejido linfoide → **no hay folículos hasta 6–8 semanas**.
  - **Baja producción de lágrimas**, menor actividad de lisozima y ausencia de IgA secretora.
- La flora conjuntival refleja la **flora vaginal materna**, de la que suele derivarse la infección durante el parto.
- **Vías de infección**:
  - **Durante el parto vaginal** (lo más común).
  - **Intraútero**: en caso de rotura prematura de membranas.
  - **Postnatal**: por manos, personal, fómites.

## 🚨Factores de riesgo
