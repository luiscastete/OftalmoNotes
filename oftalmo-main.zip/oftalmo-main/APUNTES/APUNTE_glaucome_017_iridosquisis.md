---
categoria: apuntes
area: glaucoma
emoji: 🟢
seccion: Glaucome
orden_seccion: 5
orden: 17
fuente: OneNote del Dr. Castilla Martí
---
# 🌿 Iridosquisis

## 🌿Iridosquisis – Detalles completos

## ✅¿Qué es exactamente?

**Iridosquisis** significa literalmente *“división del iris”* (del griego *iris* + *schisis* = “separación”).

• Se trata de una **degeneración segmentaria** del estroma anterior del iris.

• La capa **anterior se rompe en fibrillas** que flotan en la cámara anterior.

• La capa posterior (más próxima al epitelio pigmentado) permanece intacta y adherida al esfínter.

## 🔍Características clínicas ampliadas

| **Característica** | **Descripción** |
|---|---|
| 📍 Localización | Más marcada en el **iris inferior** (por gravedad + posible circulación acuosa) |
| 🔘 Pupila | Generalmente normal, aunque en casos avanzados puede haber **corectopia** |
| 👁️ Cámara anterior | **Poco profunda**, predispone al **cierre angular** |
| 🧪 Gonioscopía | Ángulo **estrecho/ocluido**, **PAS** frecuentes |
| 🧬 Bilateralidad | Común, pero puede ser asimétrica |
| 📈 Glaucoma asociado | Hasta **90% tiene PACG** (primary angle-closure glaucoma) |
|  |  |

## ❗Diagnóstico diferencial – ¿Con qué se puede confundir?

| **Entidad** | **Diferencias clave** |
|---|---|
| **Atrofia iridiana** | Iris delgado, pero sin fibrillas flotantes |
| **Iridodonesis** | Iris tembloroso (floppy) por ausencia de soporte zonular → no hay separación fibrilar |
| **Iris flácido (IFIS)** | Relajación intraoperatoria → no fibrillas libres, ocurre en cirugía |
| **Uveítis crónica** | Puede haber atrofia, sinequias, pero no fibrillas flotantes |
| **Iridodiálisis** | Ruptura de la base del iris, típicamente post-trauma |
| **Trauma sectorial** | Puede parecerse si hay laceración del iris, pero suele ser unilateral y con historia clara de trauma |
| **Pseudoexfoliación (PEX)** | Puede producir degeneración iridiana, pero acompañada de material blanco fibrilar típico en zónula y pupila |
