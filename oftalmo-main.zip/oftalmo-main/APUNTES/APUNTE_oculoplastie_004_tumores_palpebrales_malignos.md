---
categoria: apuntes
area: oculoplastica
emoji: 🫥
seccion: Oculo-Plastie
orden_seccion: 3
orden: 4
fuente: OneNote del Dr. Castilla Martí
---
# Tumores palpebrales malignos

## ⚠️Factores de riesgo comunes

- ☀️ Exposición solar crónica
- 🧬 Antecedentes personales de carcinoma cutáneo
- 🚬 Tabaquismo
- 👩‍🦳 Fototipo bajo
- 💉 Inmunodepresión (VIH, tratamientos inmunosupresores)
- ☢️ Radioterapia previa
- 👪 Síndromes genéticos: Gorlin-Goltz, xerodermia pigmentosa, Muir-Torre, Bazex

## 🔬Sospecha clínica de malignidad

- Lesión **pigmentada irregular**
- **Crecimiento lento** e indoloro
- **Úlceras**, **costras**, **sangrado**
- **Fijación a planos profundos**
- Pérdida de pestañas

## 📘3.1 Carcinoma basocelular

- **+ Frecuente (90%)**
- Predomina en **párpado inferior >canto medial > superior > externo**
- Crecimiento **lento**, **no metastatiza**
- Se origina en **células basales** epidérmicas

## Subtipos

- **Nodular**: nódulo perlado con telangiectasias.
- **Nodulo-ulcerativo (ulcus rodens)**: necrosis central.
- **Morfeico/esclerosante**: placa indurada, agresiva, márgenes imprecisos, pérdida de pestañas.
- **Otros**: pigmentado, superficial múltiple, quístico.

✅ **Tratamiento**: cirugía con márgenes. La forma esclerosante puede requerir técnicas como Mohs.

## 📘3.2 Carcinoma epidermoide (espinocelular)

- **Menos frecuente que el basocelular**, pero **mucho más agresivo**
- Tiene capacidad de **metástasis linfática, hemática o perineural**
- Se origina en **células escamosas** de la epidermis

🧬 **Factores de riesgo**:

- Edad avanzada
- Exposición solar
- Inmunodepresión

🧪 Puede surgir sobre:

- **Queratosis actínica**
- **Carcinoma in situ (enfermedad de Bowen)**

🔍 **Clínica**:

- Similar al basocelular, pero sin telangiectasias
- Nódulo con **costras, ulceración**
- Puede crecer rápidamente y ulcerarse

✅ **Tratamiento**: resección quirúrgica con control histológico exhaustivo por riesgo de metástasis.

## 📘3.3 Enfermedad de Bowen

- **Carcinoma epidermoide in situ**
- Células atípicas en epidermis sin invadir dermis

🔍 **Clínica**:

- Placa eritematosa con descamación
- Aspecto de eccema que no desaparece

⚠️ **Riesgo de progresión** a carcinoma epidermoide invasivo (~5%)

✅ **Tratamiento**: resección completa.

## 📘3.4 Queratoacantoma

- Tumor de **crecimiento rápido**, a menudo en semanas
- Más frecuente en **párpado inferior**
- Puede involucionar espontáneamente

🔍 **Clínica**:

- Nódulo rosado con **cráter central lleno de queratina**
- Puede confundirse con carcinoma escamoso

🔬 **Histología**: cavidad central con queratina, arcén celular en la periferia

✅ **Tratamiento**: biopsia incisional + resección completa.

## 📘3.5 Adenocarcinoma sebáceo

- **Tumor muy agresivo**, alta mortalidad (5-10%)
- Más frecuente en **mujeres mayores**
- Se origina en glándulas de **Meibomio**, Zeis o sebáceas de carúncula/piel

🔍 **Clínica**:

- Similar a chalazión o blefaritis, pero:
  - Coloración **amarillenta**
  - **Pérdida de pestañas**
  - Lesión **recidivante**
  - **Orificios glandulares ausentes**

🧪 Típico crecimiento **pagetoide** (intraepidérmico)

✅ **Tratamiento**: resección amplia + control histológico

## 📘3.6 Léntigo maligno (peca de Hutchinson)

- **Melanoma in situ**
- Proliferación radial de **melanocitos atípicos** intraepidérmicos

🔍 **Clínica**:

- Mancha pigmentada de bordes irregulares en piel fotoexpuesta (malara/párpado)
- Crecimiento lento

✅ **Tratamiento**: resección amplia con control de márgenes

## 📘3.7 Melanoma palpebral

- Muy raro, pero **muy agresivo y mortal**
- Puede aparecer de **novo** o sobre un nevo / léntigo

🔍 **Clínica**:

- Lesión pigmentada (aunque puede ser amelanótica)
- Úlceras, sangrado, crecimiento

🔬 **Histología**: proliferación de **melanocitos atípicos** en dermis

## Subtipos clínicos

- **Léntigo maligno melanoma**: sobre léntigo previo
- **Superficial extensivo**
- **Nodular**: nódulo pigmentado o amelanótico

✅ **Tratamiento**: resección amplia con control histológico

## 📘3.8 Carcinoma de células de Merkel

- Tumor muy raro pero **altamente metastásico**
- Nódulo **rojo**, bien delimitado, crecimiento **rápido**

🔍 **Clínica**:

- Localizado en **párpado superior**
- Telangiectasias visibles

🔬 Origen: **células neuroendocrinas dérmicas**

✅ **Tratamiento**: cirugía + radioterapia/quimioterapia

## 📘3.9 Sarcoma de Kaposi

- Tumor **vascular maligno** asociado a **VIH/SIDA**
- Lesión rojiza subconjuntival o palpebral

✅ **Tratamiento**:

- Observación
- Resección quirúrgica
- Radioterapia o crioterapia si progresivo

## 📘3.10 Tratamiento general tumores palpebrales

| **Técnica** | **Indicaciones** | **Notas clave** |
|---|---|---|
| **Biopsia** | Diagnóstico (incisional o por resección) | Siempre marcar zona |
| **Cirugía** | Gold standard: resección con control histológico | Márgenes: ≥2-4 mm, más en tumores agresivos |
| **Mohs** | Tumores recurrentes o infiltrativos | Preserva tejido sano |
| **Crioterapia** | Alternativa si contraindicación quirúrgica | No permite control histológico |
| **Radioterapia** | Tumores radiosensibles, Kaposi, o rechazo cirugía | Riesgo de estenosis, ojo seco, cicatrices |

## 🧾Tabla comparativa: Carcinoma Basocelular vs. Carcinoma Epidermoide

| **Característica** | **Carcinoma Basocelular (CBC)** | **Carcinoma Epidermoide (CEC)** |
|---|---|---|
| **Frecuencia** | ≈ 90% de los tumores malignos palpebrales | ≈ 5% de los tumores malignos palpebrales |
| **Edad y Fototipo** | Ancianos, fototipos I–II | Ancianos, inmunodeprimidos, fototipos bajos |
| **Localización típica** | Párpado inferior > canto medial > párpado superior | Párpado inferior o superior |
| **Crecimiento** | Lento, localmente invasivo, sin metástasis | Rápido, agresivo, con potencial metastásico |
| **Clínica típica** | **Nódulo perlado** con telangiectasias, puede ulcerarse **(ulcus rodens)** | Nódulo con costras, ulceración, sin telangiectasias |
| **Histología** | Nidos de células basaloides con palisado periférico, escaso pleomorfismo | Células escamosas atípicas con queratinización y puentes intercelulares |
| **Formas clínicas** | Nodular, ulcerativo, morfeiforme (esclerosante), pigmentado, superficial, quístico | In situ (enfermedad de Bowen), invasivo, queratoacantoma |
| **Tratamiento** | Cirugía con márgenes de 2–4 mm; Mohs en casos recurrentes o morfeiformes | Cirugía con márgenes amplios; control histológico riguroso |
| **Pronóstico** |  | Peor pronóstico; riesgo de metástasis y recurrencia |

## 🧠Anatomía e Histología del Párpado

El párpado es una estructura compleja que protege el globo ocular y participa en la distribución de la película lagrimal. Está compuesto por varias capas, desde anterior a posterior:

- **Piel**: Delgada y sin tejido subcutáneo significativo.
- **Músculo orbicular**: Responsable del cierre palpebral.
- **Tabique orbitario (septo)**: Lámina fibrosa que separa el contenido orbitario del párpado.
- **Lámina tarsal (tarso)**: Estructura de tejido conectivo denso que da forma y soporte al párpado.
- **Glándulas**:
  - **Glándulas de Meibomio**: Sebáceas modificadas dentro del tarso; su obstrucción puede llevar a chalazión.
  - **Glándulas de Zeiss y Moll**: Asociadas a los folículos pilosos; pueden ser origen de orzuelos.
- **Conjuntiva palpebral**: Mucosa que recubre la superficie interna del párpado.

Esta disposición anatómica explica la diversidad de tumores que pueden originarse en el párpado, dependiendo de la capa o estructura afectada.

## 📌Tumores Palpebrales Relevantes para el Examen EBO

Además del carcinoma basocelular y epidermoide, es importante prestar atención a:

- **Adenocarcinoma sebáceo**: Tumor agresivo originado en las glándulas de Meibomio; puede simular un chalazión recurrente.
- **Melanoma**: Aunque raro en párpados, es altamente agresivo y puede derivar de un léntigo maligno.
- **Carcinoma de células de Merkel**: Tumor neuroendocrino de crecimiento rápido y alto potencial metastásico.
- **Sarcoma de Kaposi**: Tumor vascular asociado a inmunosupresión, especialmente en pacientes con VIH.
