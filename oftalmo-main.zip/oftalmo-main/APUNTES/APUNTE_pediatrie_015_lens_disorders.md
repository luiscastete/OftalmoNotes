---
categoria: apuntes
area: pediatria
emoji: 🧸
seccion: Pediatrie
orden_seccion: 9
orden: 15
fuente: OneNote del Dr. Castilla Martí
---
# Lens Disorders

Pg 121

## MITTENDORF DOT

## CHICKEN TRACKS - EPICAPSULAR STAR

## CONGENITAL CATARACTS

ETIOLOGY 1/3 HEREDITARY, 1/3 ASSOCIATED WITH SYYSTEMIC SYNDROMES, 1/3 UNKNOWN ORIGIN.

- **BILATERAL:** AD, consider DM, galactosemia, or lowe syndrome, require metabolic workout and tt by <3 months or irreversible nystagmus with poor vision acuite (20/200) occurs.
- Opacities >3mm can be visually significant. Surgery in better seen eye firts: lensectomy, ant vitrectomy, contact lens fitting and post capsulotomy is necessary becaiuse significant posterior inflammation - post lenses opacofication.

- **UNILATERAL:** generally non metabolic or genetic, therefore, not laboratory testing needed. Usually local dysginesia. Often present with leokocoria and strasbismus. Require treatment with 6-8weeks of like.

- TYPES: classification by location and etiology.

- POLAR- subcapsular cortex and capsule:
  - POLAR ANTERIOR: small, bilateral, symetric, non progressive - good visual prognosis - 90% are idiopathic.
  - POLAR POSTERIOR: larger, stable but may progress - more visually significant - often associated with eakness of posterior capsule

- **ETIOLOGY OF BILATERAL CATRACTES:**
  - Idiopathic 60%
  - Intrauterine infection 3%: ***TORCH-ES SYNDROME***: ***TO***xoplasmosis, ***R***ubella, ***C***MV, ***HE***rpes simplex***, S***yphilis.
  - Associated with ocular disorders: ….pg122
  - Metabolic: Galactosemia, hypocalcemia, Lowe syndrome…
  - Hereditary 30% …
  - Maternal drug ingestion/malnutrition
  - Trauma

- **SPECIFIC ENTITIES**

  - **GALACTOSEMIA**
  - Defect in 1 of 3 enzymes of galactose metabolisation that causes inability to convert galactose into glucose.
  - FINDINGS: oild-droped cataract
  - OTHER FINDINGS: mental retardation, hepatoesplenomegalia, jaundice, diarrhea, cirrhosis, malnutrition and failure to thrive - desarrollarse normalmente -
  - TT: eliminate lactose from diet: fatal if untreated.

  - **FABRY DISEASE**

  - **LOWE SYNDROME - OCULOCEREBRORENAL - X LINKED**
  - Defect of aminoacid metabolism
  - FINDINGS: congenital catraracte 100%, usually bilateral and glaucoma in 50%
  - Female carriers have white white punctiuate cortical opacities and subcapsular plaque like opacities.
  - OTHER FINDINGS: renal tubular acidosis, aminoaciduria, renal rickets, mental retardation, muscular hypotonia and failure to thrive.

  - **ALPORT SYNDROME - X linked**
  - TRIADE OF:
    - 1-anterior lenticonus
    - 2-deafness
    - 3-hemorrhagic nephropathy - renal failure
  - OTHER FINDINGS: conjonctival calcium crystals, corneal endothelium pigment, juvenile arcus…
  - DX: renal or skin biopsy.

  - **HALLERMANN-STREIFF SYNDROME- MANDIBULO OCULOFACIAL DYSMORPHIA**
  - Hypoplasia of mandibule with birdlike facies\*\*\* cara pajaro\*\*\*
  - One of few syndrome with combined catract and glaucoma\*\*\*\*
  - FINDINGS: microphakia, microcornea, glaucoma and catract - can develo fisrt weeks of life -

  - DX OF BILATERAL CATARACTS
    - Urinalysis
    - Blood test
    - Karyotyping
    - Bilateral audiograms
    - B-scan ultrasound

  - **ETIOLOGY UNILATERAL CATARACTES**
    - Idiopathic 80%
    - Ocular abnormalities 10% - PHPV, Posterior lenticone 90% unilateral.
    - Trauma 9%
    - Intrauterine infection - Rubella 33%

  - DX OF UNILATERAL CATARACTES:
  - Rule out accident traumatic child abuse, TORCHES tiers.

  - DDX OF CONGENITAL CATRACTS AND GLAUCOME:
  - Lowe syndrome, rubella, Hallermann-Streiff syndrome.

  - **RUBELLA**
  - Results from matrnal infection late in the firts trimester of pregnancy.
  - FINDINGS: cataracts in 50% - bilateal pearly white nuclear opacifications, sanlt and peper fundus with normal ERG, glaucoma.
  - OTHER FINDINGS: cardiac disease-patent ductus arteriosus-, deafness and mental retardation.
