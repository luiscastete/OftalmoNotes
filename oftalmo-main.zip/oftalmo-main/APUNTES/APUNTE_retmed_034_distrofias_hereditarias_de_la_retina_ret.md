---
categoria: apuntes
area: retina-medica
emoji: 🩸
seccion: Ret Med y coroides
orden_seccion: 19
orden: 34
fuente: OneNote del Dr. Castilla Martí
---
# Distrofias hereditarias de la retina -  Retinosquisis juvenil ligada al X (RJLX)

## 1.1. Retinosquisis juvenil ligada al X (RJLX)

## 🧬Etiología y genética

- **Herencia**: Recesiva ligada al **cromosoma X** → afecta exclusivamente a **varones**.
- **Gen afectado**: **RS1**, que codifica **retinosquisina**, una proteína que estabiliza la retina al unirse a fotorreceptores y células bipolares.
- **Penetrancia**: completa; **expresividad variable**.
- **Portadoras femeninas**: asintomáticas.

## 🧪Fisiopatología

- **Disfunción en células de Müller**.
- Histológicamente: **material filamentoso fusionado a membranas celulares** y **división de capa de fibras nerviosas**.
- Afectación:
  - **Foveal** en el 100% de los casos → principal causa de pérdida visual.
  - **Periférica** en <50% → riesgo de complicaciones (hemorragia vítrea, DR).

## 👁️Clínica

- Inicio: **edad escolar**.
- **Pérdida visual** bilateral, simétrica, leve a grave.
- Funduscopia:
  - Foveal: **pliegues radiales en forma de rueda**.
  - Periférica: “**velos vítreos**” si degeneración de capa interna.
- **Complicaciones**:
  - **Agujeros retinianos**
  - **Desprendimiento de retina periférico**
  - **Hemorragia vítrea** → puede causar pérdida visual severa.
