---
categoria: apuntes
area: cornea
emoji: 💧
seccion: Conj + Episclere + Sclere
orden_seccion: 25
orden: 16
fuente: OneNote del Dr. Castilla Martí
---
# C. generalidades

## 👁️‍🗨️CONJUNTIVITIS – GENERALIDADES

La **conjuntivitis** es una inflamación de la **conjuntiva**, caracterizada por:

- **Hiperemia conjuntival** (dilatación vascular)
- **Infiltrado celular**
- **Exudación**

La **clasificación clínica** se basa en:

- **Tiempo de evolución**:
  - **Aguda**: < 3 semanas
  - **Crónica**: ≥ 3 semanas
- **Tipo de secreción**
- **Morfología de la respuesta conjuntival**
- **Zona más afectada**

## 💧TIPOS DE SECRECIÓN

| **Tipo de secreción** | **Indicativo de:** |
|---|---|
| **Serosa** | Conjuntivitis **vírica** o **alérgica aguda** |
| **Mucoide** | Alergia **crónica**, **ojo seco** |
| **Mucopurulenta (catarral)** | **Bacteriana**, **clamidia** |
| **Purulenta** | **Conjuntivitis hiperaguda** (e.g., *Neisseria*) |
