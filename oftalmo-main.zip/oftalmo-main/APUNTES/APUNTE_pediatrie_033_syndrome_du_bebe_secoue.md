---
categoria: apuntes
area: pediatria
emoji: 🧸
seccion: Pediatrie
orden_seccion: 9
orden: 33
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-08-24
---
# Syndrome du bébé secoué

Lesions craniocerebrales sur traumatisme cranien severe de survenue non accidentelle – maltraitance infantile- par secourement avec ou sans impact direct.

EPIODEMIOLOGIE

Sous diagnostique. Incidence variable 10-20 cas/100.000 naissances.

Tous les milieux socio-economiqques

FR: isolement social de la famille, conflicts conjugaux, grossesse complique.

Touche enfantes < 5ans en majorite en majorie >1 ans, M>F, 1er enfante de la famille, prematures, qui pleurent bcp.

En majorite cause par adult masculi-puis mere ou babz sitter.

Mortalite: 10-30% selon sequelles neurologiques graves tres frequentes.

SYMPTOMES

Changmenet de comportement, convulsions, troubles de l'alimentation, irritabilite, lethargie.

SIGNES

SA

Lacerations cornenne, hzphema, prolapsus irien, catracte.

SP

AA:

AA Detaille accident.

Attention si hist incompatible avec atteintes se referer au pediatre en charge.

Examen

**IMPORTANTE FAIRE LE FO EN AIGUE pour evaluer si hemorragies car en 48h hemorragies peuvent se reabsorber. Selon histoire organiser l'examen en urgence.**

Controle signes vitaux: si doute referer immediate dans service urgence pediatre.

Examen neuro-ophta:

Refelx pupillaires-ucolomotricite-LAF portable-FO dilate au casque.
