---
categoria: apuntes
area: cornea
emoji: 👁️
seccion: Cornée
orden_seccion: 4
orden: 20
fuente: OneNote del Dr. Castilla Martí
fecha: 2024-02-14
---
# Degenerations Dégénérescences Cornéennes

## 🧿Degeneraciones corneales (Corneal Degenerations)

*No hereditarias, adquiridas y más frecuentes con la edad o por daño ambiental/inflamatorio.*

## 🔹1. Arcus senilis (gerontoxon / arcus lipoides)

• **Frecuente en ancianos**, bilateral, periférico.

• **Asociación con dislipidemia** si ocurre en jóvenes (arcus juvenilis).

• **Signos**:

- Depósito lipídico estromal en polo superior/inferior → circunferencia (1 mm ancho).
- Borde periférico nítido separado del limbo por zona clara.
- Borde central difuso, patrón vertical > horizontal.

• **Tratamiento**: ninguno.

## 🔹2. Vogt limbal girdle

- Muy común (>60% >40 años), más en mujeres.
- **Creciente blanquecina** en el limbo, 3 y 9 h, más nasal.
- **Tipo I**: patrón tipo queso suizo con zona clara (similar a band keratopathy).
- **Tipo II**: más común, sin agujeros ni zona clara.
- Histología parecida a pingüécula/pterigión.
- **Tratamiento**: ninguno.

## 🔹3. Cornea farinata

- **Depósitos microscópicos** en estroma profundo central.
- **Fluor-like**, bilateral, no afecta visión.
- **Tratamiento**: ninguno.

## 🔹4. Crocodile shagreen

- **Opacidades poligonales grises** separadas por estroma claro.
- **Localización**: anterior (más común) o posterior.
- **Asintomático**, simula distrofia central de François.
- **Tratamiento**: ninguno.
