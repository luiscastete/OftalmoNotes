---
categoria: apuntes
area: glaucoma
emoji: 🟢
seccion: Glaucome
orden_seccion: 5
orden: 47
fuente: OneNote del Dr. Castilla Martí
---
# SLT

Buena primera opción

Revisar técnica
