---
categoria: apuntes
area: catarata
emoji: 🔍
seccion: Cristallin - Lens
orden_seccion: 21
orden: 9
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-03-28
---
# Chirg. de la myopie par ICL

La chirurgie de la myopie par implants est envisageable quand une myopie forte ne peut bénéficier du Lasik avec laser femtoseconde.

## AVANTAGES

Les avantages des implants sont : la précision, la qualité visuelle, la réversibilité (en cas d’implant phake), la bonne tolérance.

## POURQOUI IMPLANTS PHAKES?

Il faut se poser la question des implants phakes en cas de :

Myopie supérieure à -10.

Cornée trop fine pour un laser.

Cicatrice de cornée contre-indiquant toute chirurgie laser.

D’astigmatisme trop irrégulier pour un traitement laser.

## DANS QUELS CAS/ELEGIBILITE

L’implant est envisageable dans les cas non opérables par laser:-une myopie trop forte non corrigible par un Lasik femtoseconde >10/12 dioptries-cornée est trop fine pour être creusée par le laser.

-La première est de ne pas être éligible à une technique laser.

-Être âgé de 25 ans minimum.

-L’espace entre votre cornée et votre cristallin doit être suffisant pour laisser passer l’implant.

-Votre cornée ne doit pas présenter de signes de vieillissement prématuré type dystrophie de Fuchs.

-Vous ne devez pas avoir de glaucome ou d’hypertonie oculaire.

-Vos attentes doivent être en adéquation avec les résultats finaux et espérés.

-Vous devez comprendre les suites postopératoires et accepter de respecter les traitements et contrôles prévus.

INCONVENIENTS:

– Il s’agit d’une opération plus risquée que la chirurgie par laser,  endoculaire.  Elle nécessite une surveillance régulière de l’état de l’oeil. En cas d’intolérance, l’implant doit être retiré avec retour à la myopie initiale.
