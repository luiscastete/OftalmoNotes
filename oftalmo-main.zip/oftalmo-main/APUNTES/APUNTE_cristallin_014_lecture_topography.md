---
categoria: apuntes
area: catarata
emoji: 🔍
seccion: Cristallin - Lens
orden_seccion: 21
orden: 14
fuente: OneNote del Dr. Castilla Martí
fecha: 2024-01-22
---
# Lecture topography

Ordre selon Kate:

KM

Astig

K max

Pachy min

+/- indices KC
