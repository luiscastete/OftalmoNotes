---
categoria: apuntes
area: glaucoma
emoji: 🟢
seccion: Glaucome
orden_seccion: 5
orden: 2
fuente: OneNote del Dr. Castilla Martí
---
# Intro

Key Points on Aqueous Humor Production:

- **Source:** Plasma, produced by ciliary epithelium (pars plicata).
- **Mechanisms:**
  - **Active & Passive Secretion:**
    - **Ultrafiltration:** High-protein filtrate from fenestrated capillaries → stroma of ciliary processes.
    - **Active Transport:** Solutes cross dual-layered ciliary epithelium.
    - **Osmotic Gradient:** Drives passive water flow into posterior chamber.
- **Regulation:**
  - **Sympathetic Nervous System:**
    - **Beta-2 Receptors:** Increase secretion.
    - **Alpha-2 Receptors:** Decrease secretion.
  - **Key Enzyme:** Carbonic anhydrase.

Key Points on Aqueous Outflow

## Anatomy of Trabecular Meshwork

- **Function:** Primary exit route for 90% of aqueous humor.
- **Structure:**
  - **Uveal Meshwork:**
    - Innermost layer.
    - Cord-like strands from iris and ciliary body stroma.
    - Large intertrabecular spaces → minimal resistance.
  - **Corneoscleral Meshwork:**
    - Middle layer, thickest portion.
    - Layers of connective tissue strands with smaller spaces → moderate resistance.
  - **Juxtacanalicular Meshwork:**
    - Outer layer, links to Schlemm canal endothelium.
    - Dense extracellular matrix with narrow spaces → major resistance.

## Schlemm Canal

- **Location:** Circumferential channel in perilimbal sclera.
- **Inner Wall:**
  - Endothelial cells with **giant vacuoles** → form transcellular pores for aqueous movement.
- **Outer Wall:**
  - Smooth cells with collector channel openings connecting to episcleral veins.
- **Lumen:** Divided into 2–4 channels by septa.
