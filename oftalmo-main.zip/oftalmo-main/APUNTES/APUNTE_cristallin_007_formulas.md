---
categoria: apuntes
area: catarata
emoji: 🔍
seccion: Cristallin - Lens
orden_seccion: 21
orden: 7
fuente: OneNote del Dr. Castilla Martí
---
# Formulas

## 🧠Evolución Histórica de las Fórmulas de Cálculo de LIO (IOL)

## ⚙️1. Primera Generación –Años 70–80s

- **Fórmulas**: SRK (Sanders-Retzlaff-Kraff), Binkhorst I y II
- **Características**:
  - Muy básicas.
  - Se basan solo en **queratometría (K)** y **longitud axial (AL)**. No estimacion de la profundidad de la camara anterior - si nop que se utiliza un valor constante.
  - No ajustan bien en ojos extremos (muy largos o muy cortos).
  - Ecuación lineal para predecir la **posición efectiva del lente (ELP)**.

## ⚙️2. Segunda Generación

- **Fórmula**: SRK II
- **Características**:
  - Introduce correcciones empíricas según la longitud axial (AL). NOVEDOSO: Se realiza una estimacion de la camara anterior.
  - Mejora el rendimiento frente a la SRK original, pero sigue siendo limitada en extremos.
