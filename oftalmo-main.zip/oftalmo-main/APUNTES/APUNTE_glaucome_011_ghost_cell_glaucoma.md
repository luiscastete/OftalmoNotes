---
categoria: apuntes
area: glaucoma
emoji: 🟢
seccion: Glaucome
orden_seccion: 5
orden: 11
fuente: OneNote del Dr. Castilla Martí
---
# 👻 Ghost Cell Glaucoma

## 👻Ghost Cell Glaucoma

## ✅Definición

Glaucoma secundario por **obstrucción trabecular** causada por **eritrocitos degenerados** (“ghost cells”) tras hemorragia vítrea.

## 🔬Patogenia

• ~2 semanas tras hemorragia vítrea:

• Hemoglobina sale de los eritrocitos → se transforman en **ghost cells**.

• Estas células atraviesan un **defecto en la cara anterior de la hialoides** y entran en la cámara anterior.

• Al perder su flexibilidad → quedan atrapadas en la **malla trabecular**, obstruyendo el drenaje del humor acuoso → ↑PIO.

## 📌Situaciones clínicas asociadas

| **Situación** | **Comentario** |
|---|---|
| Cirugía de catarata con hemorragia vítrea previa | Ghost cells migran tras cirugía. |
| Ojo afáquico o pseudofáquico con HV | Ghost cells pueden pasar libremente al segmento anterior. |
| Cirugía de catarata complicada por HV e hyphaema | Hyphaema desaparece, pero ghost cells persisten. |
|  |  |

## 🔍Manifestaciones clínicas

• **Córnea edematosa** por ↑PIO.

• Cámara anterior con **ghost cells**:

- Apariencia: **partículas marrón rojizas o caqui** en el humor acuoso.
- ⚠️ No confundir con leucocitos → evitar tratamiento incorrecto para uveítis.
