---
categoria: apuntes
area: uveitis
emoji: 🔥
seccion: Immuno-infectio
orden_seccion: 7
orden: 9
fuente: OneNote del Dr. Castilla Martí
fecha: 2024-05-22
---
# Uvéites infectieuses

**ELLE SSONT A RECHERCHER EN PRIORITE CAR ELLES PERMENT UN TT SPECIFIQUE. IL EST NECESSAIRE DE LES ELIMINER AVANT D'ENVISAGER UN TT PAR CORTIS.**

## LE INTERROGATOIRE EST ELEMENT CLE POUR DX.

- **CANDIDOSE**
- Sourvient ppalment patients toxicomans IV- independant des lymphocytes TCD4+ et aussie chez patients en réanimation.

- **Etiologie**
- L'atteinte ophtalmique se fait pour embole infectieux.

- **SIGNES**
- Uvéite antérieur variable
- Asscocie foyer choriorétinien du pôle postérieur blanc, duveuteux et des abcès intravitréens blancs – en boule de neige-

- **TT**
- Medico-chirurgicale:
- tt antimycotique par voie generale: amphotéricine B, Fluconazole/Triflucan
- +/- intravitréenne: interet d'un bipsie vitréenne pour dx biologique

- **CMV**
- C'est l'infection + freq et ppal cause de cécité chez patient VIH.
- Elle témoigne d'une infection systémique par CMV.
- La rétinite par CMV survient lorsque le num Lt CD4+ est <50/mm3 et la charge virale est élevée.

- **SIGNES**
- L'aspect classique est un plage blanche, oedemateuse, hémorragique, paravasculaire, à progression centrifuge, réalisant une image cocarde.
- Le centre de la lesion est cicatrise, la courone intérmediare est oedemateuse et la couronne périphérique est formée de petits foyers satellites en rétine saine qui vont confluer pour former le front de progression virale, NO peut etre atteint.

- Risque de DR!

- **DX**
- certitute par ponction en CA à la recherce du génome CMV par PCR.

- **TT**
- Generale +/- local.
- D'abord une phase d'attaque à fortes doses jusqu'au cicatrisation des plages de rétinite et une phase d'entretien pour éviter récidives.
- Ganciclovir ou Foscarnet par voie IV en tt attaque par IV.

- Le tt d'entretien peut etre arrete lorsque le taux de lymphocite T CD4+ est >100/mm3 et la charge virale est indetectable ddepuis 6 mois.

- CMV retinitis

- Images:
- CMV Retinitis - EyeWiki (aao.org)

- **Disease Entity**
- Cytomegalovirus (CMV) Retinitis is an acquired immunodeficiency syndrome (AIDS)-related opportunistic infection that can lead to blindness. CMV retinitis occurred with higher frequency prior to the advent of antiretroviral therapy, but has since been decreasing in well-developed countries, although still remains a prevalent condition in developing countries. It is a viral retinitis that can also be seen in patients who are immunosuppressed for other reasons aside from AIDS.

- **Disease**
- Cytomegalovirus (CMV) retinitis is an important ocular AIDS associated illness. It is a full thickness retinal infection that can lead to necrosis and retinal breaks and detachments.

- **Physical examination**

- Physical exam shows yellow white retinal lesions that often start in the periphery and follow the vasculature centripetally. However, it can start in the posterior segment. The classic findings are retinal hemorrhages with a whitish, granular appearance to the retina. Each lesion has the most activity in the borders. Vitreous signs of inflammation may be minimal as most patients are severely immunosuppressed. Very early CMV may resemble cotton wool spots, but with lesions larger than 750 µm, CMV must be considered. Three typical patterns have been described: a granular pattern, a fulminant/hemorrhagic appearance, or "frosted branch" angiitis.

- Rhegmatogenous retinal detachment occurs in approximately one-third of patients when greater than 25% of the retina is involved. The presence of concurrent keratic precipitates in a stellate fashion can also suggest CMV uveitis.

- **Signs**
- CMV retinitis can present as:
- 1. Fulminant - hemorrhagic necrosis on white/yellow cloudy retinal lesions. They may be centered around vasculature.
- 2. Granular - Found more often in the retinal periphery with little to no necrosis and hemorrhage.
- 3. Perivascular - The classic "frosted branch" angiitis showing white lesions surrounding the retinal vessels.

- **Symptoms**
- **Most patients are asymptomatic,**
- but may have floaters, flashes (photopsias), blind spots (scotomata). Pain and photophobia are uncommon.

- **Clinical diagnosis**
- The clinical diagnosis is made on history and classic retinal findings.

- **Differential diagnosis**
- Early CMV can resemble cotton wool spots. It may be confused with HIV retinopathy, which is actually more common the CMV retinitis. HIV retinopathy occurs in 50-70% of patients and is characterized by intraretinal hemorrhages, cotton wool spots, and microaneurysms. For small lesions that are hard to differentiate from cotton wool spots, serial exams should be performed, which will show enlargement of the CMV lesions. Immunosuppression should be treated like a spectrum; some patients are more immunosuppressed than other individuals. For cases of minor immunosuppression, CMV retinitis may present as acute retinal necrosis (ARN) syndrome but follows a chronic course similar to CMV retinitis, which may cause misdiagnosis.[1][2]

- Syphilitic hemorrhagic necrotizing retinitis can mimick CMV retinitis; all patients should undergo treponemal testing.[3]

- **Management**
- Management is largely medically based with intravenous (IV), oral, and intravitreal anti-viral medications. Topical corticosteroids can be used to treat anterior chamber inflammation. Management also hinges on HAART in HIV positive patients.
- Patients should be started on high dose induction therapy, which is followed by continuous maintenance therapy until CD4 counts increase, HAART is therapeutic, and CMV retinitis shows no progression

- **Medical follow up**
- Depending on the medication used, complete blood counts, chemistries, and intraocular pressure checks will be needed. **Dilated eye exams should be performed at least weekly initially,** then 2 weeks after induction therapy, followed by monthly thereafter while the patient is on anti-CMV treatment. Fundus photographs can be helpful to detect early relapse.

- Patients should be followed in an appropriate HIV clinic with CD4 counts and viral load studies.

- **Complications**
- The most serious complication of therapy for CMV retinitis, besides those listed above due to medications is **immune recovery uveitis (IRU)**. As the CD4 counts rise with HAART, it is presumed that reactions to CMV antigens cause anterior or intermediate uveitis. Cystoid macular edema and epiretinal membranes are also potential complications of IRU. Posterior capsular cataracts, proliferative vitreoretinopathy, and optic nerve neovascularization are possible complications as well. HAART therapy can also unmask CMV retinitis in a patient without prior CMV disease (unmasking CMV-immune recovery retinitis (IRR)) or can cause worsening of known CMV retinitis (paradoxical CMV-IRR).
- CMV retinitis that involves > 25% of the retina can lead to rhegmatogenous retinal detachments from breaks that occur near thin, necrotic retina. Peripheral anterior retinal lesions are associated with increased risk of retinal detachment, due to the anterior adherence of the vitreous base.

- **Prognosis**
- The prognosis was almost uniformly fatal prior to the advent of HAART. Now it carries a much better prognosis, but even with HAART and anti-CMV therapy, mortality is still increased after diagnosis of CMV retinitis.

- Prognosis for patients with or without HIV infection, corticosteroid immunosuppression, and other risk factors all have similar visual outcomes. The strongest factor associated with poorer visual outcomes for all patients is retinal detachment.

- **HERPES – Atteintes antérieures**

- **\_\_MALADIE DES GRIFFES DU CHAT- BARTONELLA HENSELAE**

- **\_\_MALADIE DE LYME – BORRELIOSE**

- **NECREOSE RETINNIENE AIGUE – ARN**

- **PNEUMOCYSTOSE**

- **PREGRESSIVE OUTER RETINA NECROSIS – PORN OU RETINITE A VZV**

- **\_\_SYPHILIS**

- **TOXOCAROSE**

- **TOXOPLASMOSE OCULAIRE**
- VOIR NOTE SEPARE

- **TUBERCULOSE**

- **VIH**
