---
categoria: apuntes
area: uveitis
emoji: 🔥
seccion: Immuno-infectio
orden_seccion: 7
orden: 1
fuente: OneNote del Dr. Castilla Martí
fecha: 2022-09-08
---
# UAA 1.0 - Uvéite Antérieur Aigue

Quand réfère à unité immuno:

-Uvéite sévère:

- CA 3+ cellules ou hypopion.
- FO non visualisable
- Hyalite associe

-AV <0.8 ( faire OCT)-référer si OMC.

-HTIO >25mmHg.

-Formes récidivantes.

-Ttt systemique : immunosupresseur ou antiviral.

-Péjoration ou non réponse au ttt depuis 48-92h

-Necesite introduire ttt systemique ou inj périoculaire.

-Situation peu claire.

-HIV +.

-UAA de l'énfant: UAA + œil blanc: pensez arthrite juvenile idiopathique et neceite prise en charge raèpide et spcécialise. TTT: PF 1% 3-6xj max + Scopo 0,25 si >6ans, tropi 0,5% si >

TOUJOURS!

Exclure atteinte posterieur: vitrite, foyer chorioretinien, vasculite peripherique, snowballs et snowbaking de la pars plana.

## STATUS-bilan

- AV Corrigée
- TIO
- Evaluation CA
- Evaluation du vitré
- FO dilate bilatéral.--si tu n'arrives pas voir FO contacter CDC.
- OCT pôle post.

| TYPE UAA | **-Non Granulomateuse**,<br>Et Unilatéral<br>Et Premier épisode<br>Et Clinique simple | -**Granulomateuse**<br>Et/ou bilateral<br>Et/ou récidivante<br>Et/ou clinique severe<br>( est plus corticorespondeur ) | **-Granulomateuse hérpetique ( HSV ou VSV)** |
|---|---|---|---|
| BILAN | HLA-B27<br>OCT bilaterale si AV<0,8<br>+/- add questionnaire immuno | FSC, VS, CRP, Ca2+ corrigé, lysozyme, ECA, IL-2R.<br>VDLR, TPHA.<br>TB-Spot/ quantiferon.<br>Bartonella (non remboursée)<br>Borreliose<br>+/- RX Thorax vs TC-scan thoracique<br>+/- OCT bilateral si AV <0,8.<br>+/- -add questionnaire immuno | Pas bilan herpetique car + dans 99% de la population. : NB peut etre utile chez l'énfant.<br>OCT bilaterale si AV <0,8.<br>+/- -add questionnaire immuno |
| TTT | PF 1% aux heures + Scopolamine gtt 0,25% 3xj + Ultracortenol pommade 1xj le soir<br>\*François: préfer Tropi car ça bouche + et évite synechies plus large? )<br>Pred Forte gtt opht<br>aux heures pendant 2j<br>8x/j pendant 5 jours puis<br>6x/j pendant 5 jours puis<br>4x/j pendant 5 jours puis<br>3x/j pendant 5 jours puis<br>2x/j pendant 5 jours puis<br>1x/j pendant 5 jours.<br>Tropicamide<br>2x/j pendant 7 jours<br>Ultracortenol pomamde<br>1xj le soir avant dormir pendant 7j | PF 1% 3xj + Scopolamine 0,25% 3xj | Valtrex cpr per os 500mg 3xj pdt toute la durée des cortis.( si VZV suspecté: Valtrex 1g 3xj) + PF 3xj + Scopolamine 3xj<br>Si HTIO >25mmHg: add Cosopt 2xj + +/- Iopidine 0,5% 3xj +/- Diamox per os ( 250 vs 500mg selon poids et fonction renale ) selon degrée d HTIO et des CI ( Allergies sulfamides, asthme, IR, syndrome de stevenson-Johnson... |
| SUIVI | Dans 48h ( en consultations uveites?) | Dans 24h ou 48h | Dans 48h |
| TTT | Si évolution favorable:<br>PF 1% aux heures + scopolamine 3xj + UCP le soir | Si évolution favorable:<br>PF 1% 3xj+ scopolamine 3xj | SI évolution favorable:<br>Valtrex cpr per os 500mg 3xj pdt toute la durée des cortis.( si VZV suspecté: Valtrex 1g 3xj) + PF 3xj + Scopolamine 3xj |
| SUIVI | Cô à 96h-J4 | Cô à 96h-J4 | Cô à 96h-J4 |
| TTT | Si évolution favorable:<br>PF 8xj pdt 3-7j, 6xj pdt 3-7j, 4xj pdt 3-7j, 3xj pdt 3-7j, 2xj pdt 3-7j, 1xj 3-7j puis STOP.<br>Si CA calme:<br>STOP UCP<br>STOP scopolamine et add Tropi 0,5% 2x/soir<br>\*\*tropi vers 18-21h, induisant une mydriase moins longe et moins gênant. Attention car la tropi n'induit pas une cyclopegie don n'enleve pas les douleur secondaires au spasme ciliare. | Si évolution favorable:<br>PF 3xj pdt 2-3 sem, 2xj pdt 2-3 sem, 1xj pdt 2-3 sem puis STOP.<br>Si CA calme:<br>STOP scopolamine 0,25%  et add Tropi 2xj/soir | SI évolution favorable:<br>Valtrex 500mg ( 1g si VZV ) 3xj pdt toute durée cortis + PF 3xj pdt 2-3 sem, PF 2xj pdt 2-3 sem, PF 1xj pdt 2-3 sem puis STOP.<br>Si CA calme:<br>STOP scopo et add Tropi 2xj pdt le soir |
| SUIVI | Cô à 1-2 sem. | Cô à 1-2 sem. | Cô à 1-2 sem.<br>\*\*L'arret de PF ou du tt antiviral depene du risque de récidive et de la localisartion de léa lésion en cas atteint disciforme. Une tt par Valtrex peut etre mantenu à vie. L'utilisation des cortis nécesite le maintien d'un tt antiviral topique ou systemique. |
