---
categoria: apuntes
area: cornea
emoji: 👁️
seccion: Cornée
orden_seccion: 4
orden: 10
fuente: OneNote del Dr. Castilla Martí
---
# Epithelial (EI) - Fibrous ingrowth (FI) /downgrowth

Epithelial (EI) - Fibrous ingrowth (FI) /downgrowth

domingo, 14 de septiembre de 2025

18:44

## 📑Epithelial vs Fibrous Ingrowth – Resumen EBO

## 🔬Definición

- **Epithelial ingrowth:** proliferación de células epiteliales dentro de la cámara anterior a través de heridas quirúrgicas/corneales.
- **Fibrous ingrowth:** proliferación de tejido fibroso (fibroblastos y colágeno) en heridas quirúrgicas o incisiones oculares.
