---
categoria: apuntes
area: oculoplastica
emoji: 🫥
seccion: Oculo-Plastie
orden_seccion: 3
orden: 13
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-03-28
---
# Chalazion

## DEFINITION

Kyste palpébrale bénin d'origine inflammatoire provoque par obstruction d'une glande de meibomius.

Sterile inflammatori process, whereby meibum remains trapped within a meibomiam gland- resulting granulomateous inflammation.

Indeed a chalazion is simply the opthalmologic term for a meibomiam gland granuloma.

## SYMTOMES

Inconfort ou tension au niveau de la paupiere.

Kyste palpebrale d'apparition aiguie ou chronique

Tumefaction palpebrale

## SIGNES

Nodule palpebrale sous cutané visible/palpable

Dilatation de l'abouchement de la glande meibomius obstruée.

+/-tumefaction et/ou rougeur palpebrale

+/-blépharite associée.

## DX DIFFERENTIELS

**ORGOLET:** Infection de la racine d'un cil ( folliculite)

## Cellulite préseptal

- Extension périoculaire plus large

## Carcinome sébacé

- Suspecte chez patients ages avec Chalazions persistants +/- blépharite unilaterale chronique +/- induration palpebrale +/- madarose

## FR

Blepharite

Rosacée oculaire

Dermatites séborrhaique

## AA

Épisodes précedents?

## STATUS

AV-TIO

Examen soigneise de la peau et palpation ( nodule?) si besoin éverse la paupiere.

LAF: paupiere: ulceration palpebrale? Madarose? Marge pallpebrale: blépharite? Dysfonctionmente glandes meibomius? Conjonctivite, cornée?

## TTT

## CONSERVATEUR

-Massages avec compresses chaudes ( 5-10 min) 3xj

-Rinçages nacl 3xj pdt 2-3sem

-Optava gtt 4-8xj (larmes artificielles)

-Maxitrol pommade sur borde interne et externe pdt  10-15j

+ Tobradex pommade sur la lesion pdt 10-15J

## CHIRURGICALE

Si échec de tt conservateur bien conduit.

-sous Anesthesie Local, en salle de soins de la policlinique.

-si <15 ans, discuter une intervention sous AG en bloc.

-materiel requis: Gants et blouse stériles, masque, désinfectant cutané (betadine ou Hibidil), set de désinfection, anesthesiant local et tropique ( ex: Rapidocaine 2% avec epinephrine et oxybuprocaine collyre ), boite à ablation de chalazion, lame de bistouri 1l, marqueur stérile, tube de formol ( pour analyse histopathologique- systematique si >40ans) maxitrol ou tobradex pommade, 2 compresses oculaires stériles, micropore.

**PROCEDURE: incision & curetage par voie interne ( document explicatif dans intranet)**

1.Anesthesie topique de l'oeil

2.désinfection conjonctivale et cutanée

3.mise en place du champ percé stérile.

4.+/- marquage du rebord palpébral au nievau du chalazion.

5. Anesthesie locale de la paupiere ( aiguille jaune **30G**).

6.Mise en place de la pince à chalazion ( le chalazion doit se trouver au centre de l'ouverture de la pince) et éversion de la paupiere.

7.Incision à la lame de bistouri 11 par voie interne au sommet de la lésion on se dirigeant en profondeur vers la tarse ( incision perpendiculaire au rebord palpebrale). Conserver >1mm de bord libre avec la marge palpebrale.

8.pression avec cotton tige et curetage ( avec curette) du contenu de la glande----mettre dans tube pour analyse anatopatho.

9.Tobradex/maxitrol pommade dans l'oeil et pansement compressif à garde jusqua'àu lendemain matin.

10. Tt post-op: maxitrol ou tobradex pommade 3xj pdt 10j.

Rdv co post

**Inyeccion intralesional de traimcinolona acetonida – KENACORT o KENALOG**

Dosis 0.1-0,2ml de una solucion cde 10-40mg/mL

Via transcutanea

Efectividad 80% de résolucion en 1-2sem

COMPLICACIONES: despigmentacion cutanea, aumento de la presion intraocular (raro), necrosis grasa.

## SUIVI

Tt conservateur: cô au besoin. Si persistance kyste après 2-4 sem d'un  tt bien conduit. Envisager une prise en charge chirurgicale.

Si persistance gros cicatrise add UCPommade 1xj avec passage paupiere.

Tt chirurgicale: au besoin.

Enfants >10 ans tu peut doner Maxitrol/tobradex 2xj + PC

Si DM on peut donner sans problemes.
