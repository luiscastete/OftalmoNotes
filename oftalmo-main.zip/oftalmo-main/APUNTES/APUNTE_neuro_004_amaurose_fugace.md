---
categoria: apuntes
area: neuro
emoji: 🧠
seccion: Neuro-Ophta
orden_seccion: 8
orden: 4
fuente: OneNote del Dr. Castilla Martí
fecha: 2024-08-07
---
# AMAUROSE FUGACE

att:

add protocole chalazion

PC dans 2 jour avec CV 30°,  si - add consultation chez son MT  pour FRCV + eco-doppller carotide, si + add IRM cérébrale et cou en urgence.

explication signes alarme
