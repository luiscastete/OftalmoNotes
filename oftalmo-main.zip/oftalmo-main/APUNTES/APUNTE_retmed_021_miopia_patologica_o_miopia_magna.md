---
categoria: apuntes
area: retina-medica
emoji: 🩸
seccion: Ret Med y coroides
orden_seccion: 19
orden: 21
fuente: OneNote del Dr. Castilla Martí
---
# MIOPÍA PATOLÓGICA o miopia magna

## 5. MIOPÍA PATOLÓGICA

## 5.1. Epidemiología

- Definición: equivalente esférico >6 D o longitud axial >26,5 mm.
- Afecta especialmente a población asiática (hasta 3% en China).
- Mayor prevalencia en mujeres.
- Asociada a múltiples complicaciones retinianas que pueden llevar a ceguera legal.

## 5.2. Fisiopatología

- Factores genéticos (herencia AD, AR, recesiva ligada al X) + ambientales.
- Asociaciones sindrómicas: Stickler, Ehlers-Danlos, Marfan, Down, Noonan, etc.
- La elongación axial produce estiramiento retiniano → adelgazamiento coroideo y escleral.
- Señales desde retina (células amacrinas) modulan grosor coroideo y crecimiento escleral.

## 5.3. Clínica y diagnóstico

**Lesiones iniciales**:

- Cono miópico, supertracción, fondo teselado.

**Estafiloma posterior**:
