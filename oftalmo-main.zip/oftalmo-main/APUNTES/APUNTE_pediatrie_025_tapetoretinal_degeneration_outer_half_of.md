---
categoria: apuntes
area: pediatria
emoji: 🧸
seccion: Pediatrie
orden_seccion: 9
orden: 25
fuente: OneNote del Dr. Castilla Martí
---
# Tapetoretinal Degeneration - outer half of retina (photoreceptors and RPE)

Photoreceptos and RPE - tapetum nigrans - black carpet.

LEBER CONGENITAL AMAUROSIS - AR

RETINITIS PIGMENTOSA - RP

CENTRAL AREOLAR CHOROIDAL DYSTROPHY - AD

BIETTI CRYSTALLINE RETINOPATHY - AR

CONGENITAL STATIONARY NIGHT BLINDNESS - CSNB

CHOROIDEREMIS - X LINKED RECESSIVE

Gyrate atrophy - ar
