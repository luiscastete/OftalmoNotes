---
categoria: apuntes
area: urgencias
emoji: 🚑
seccion: URGENCES---TRAUMATOLOGIE
orden_seccion: 2
orden: 1
fuente: OneNote del Dr. Castilla Martí
fecha: 2022-08-31
---
# Brûlures oculaires

## De cause thérmique ou chimique??

- Thermique/electrique: peu risque complic. Long cours

- ***Chimique: URG OPHTALMIQUE!***

- Necessitant irrigation oeil sans delai. 15-30 avec l'eau robinet ou nacl.
- Cause plus freq. Par projection accidentelle. Gravite des lésions en fonction de la nature du produit, de la concentration, du Ph et de la durée d'exposition.

## Etiologies

## Brûlure chimnique

- **BASE FORTE pH > 10:** Ciment, chaux, béton, ammoniaque (NH3), soude castique, eau de Javel...
- Atteintes severes car LIPOPHILE + SAPONIFICATION des acids gras des membranes cellulaires, destruction cellules épithelium du stroma et endot.  Penetration possible en CA en 5-15 min.

- **ACID FORT pH < 4:** Acid chlorhydrique (HCI), liquide batterie, produit entretien de piscines...

- Autres: Agent oxydant, réducteur ou corrosif, antirouille, nettoyants, fertilisants, produit vaisselle, lessive...

## Sympt

Douleur ++, BAV, sensation CE, blépharospasme, photophobie, larmoiment.

## SIGNES

- HC + cercle périkératique
- Chemosis
- Ischemie ou necrose conj bulbaire / limbique
- Anesthesie cornéen
- KPS jusqua perte complete de l'épithélium.
- Ulceration cornéen
- Oedeme cornéen
- Reaction inflam CA
- HTIO

**Si évolution chronique possible:** Dystrichiasis, entropion, ectropion, symblepharon, pannus cornéen, opacification, perforation cornéen, Cataracte.

## STATUS

Examen après réalisé RINçAGES AUX URG!! Meme si déjà rinçe chez lui, on fait une autre aux urgence.

AV et TIO

LAF:

- Palpebrale: eversión paupieres. -Symblepharon? Des adderances
- Point lacrymaux, permeables?
- Conj, cornée, limbe avec fluo? +/-
- CA

## PRISE EN CHARGE

**-Brûlure thermique :** pas irrigation oculaire.

- Si douleures: pansement oculaire + floxal pommade jusqu'au endemain, puis floxal pommade 3xj + optava gtt 3-6xj + PVA le soir pdt 1 sem

**-Brûlure chimique:** irrigation oculaire en urgence sans délai.

- eliminer tout produit chimique ou toxique de la surface de oeil
- évacuer des petits CE
- Nettoyer d'éventuelles sécretions purulentes.
- Effectuer le lavage de oeil.

- RINçAGES pdt 10 min

- Collyre anesth.: oxy ou tétracaine.
- Si présence de débris solides, les retirer avant rinçages car possibilite de dissoudre ces élements et aggraver la situation.
- Produit de rinçage: sérum physiologique à 0,9%: 500ml à plusieurs litres.
- Eau du robinet.
- Diphotérine ( chélateur)everser les paupieres sup et inf.
- Retirer tout CE
- Pas de phénylephrine ( constriction sur terrain ischemique)\*\*\*\*\*

- Mesure du pH ( après 5-10 min)

- Si pH <7.0 ou >7.2 --------de nouveau rinçages!

- Si pH 7.0 à 7.2---- Examen initial

| DUA GRADE I-II ou ROPER-HALL grade I-II<br>Ou <50% de perte épithélial | DUA GRADE III ou ROPER-HALL grade I-II ou <50% de perte épithélial | DUA GRADE IV-V-VI ou ROPER HALL grade III-IV ou >50% de perte épithéliale |
|---|---|---|
| Ttt simple:<br>-Floxal SDU 4xj 1 sem<br>-Dexafree 4xj pendant 5j, 2xj pendant 5j, 1xj pendant 5j et STOP.<br>-Optava 8xj<br>-Pommade Vitamin A le soir avant dormir | Ttt simple:<br>-Floxal SDU 4xj 1 sem<br>-Dexafree 4xj pendant 5, 2xj pendant 5j, 1xj pendant 5j et STOP.<br>-Optava 8xj + PVA le soir<br>+<br>PC dans 24h | Tt intensif:<br>-Floxal SDU 4xj<br>Prophylaxir conte infections.<br>-Dexafress 0,1% % SDU ou Predforte 1% tous les 1-2h .<br>Reduit l'inflamm. Et les enzymes protéolytiques.<br>-Ascorbate gtts 10%tous les 1-2 heures + comprimes p.o. 2xj.<br>Cofacteur pour la synthese de collagéne, protection contre le sulcerations et les perforations cornéennes.<br>-CITRATE gtts tous les heures.<br>Diminue l'activite des PMN et effet inhibiteur sur les collagénases.<br>-Cycloplégie ( ex: homatropine).<br>-Doxycycline comprimes p.o. 100mg 2xj.<br>Propietes anti-inflammatoires, diminue l'action des enzyms protéolytiques 8 métalloprotéinases et collagénaes).<br>-Lubrifiants: lacrycon/optava aux heures + PVA le soir.<br>-Hypotonisant collyre ( en fontion du degré d'hypertonie).<br>+/- omnilenz + membrane amniotique ( cas portugues brulure chimique avec beton liquide)<br>+/- Sérum autologue<br>+/- hospi +/- chirurgie? |

## TT CHIRURGICALE

Débridement du tissu nécrotique ( surtout si encorer produite ou CE impactes)

Anneau anty-symblepharon

Greffe conjonctivale

Greffe de membrane amniotique

Greffe de cellules souches limbiques

Greffe cornée

## Remarques

En cas de lesion chimique severe avec perte complete de épithelium et ischemie complete:

- Aspect blanc de l'oeil ( ischemique ++)
- Absence de prise focale de fluo ( la perte épithelial complete peut etre difficile à deceler à cause de -l'impregnation diffuse et hogene de la fluo)
- Patient confortable ( absnece de douleur car atteinte du plexus nerveux cornéen)

Agents conservateurs: à éviter pour diminuer la toxicité en surface.

Tt topique par citrates et acides ascorbique: brûluredans >40% des cas donc faible complianc. Bien éduquer le patient.

Estimation de l'ischemie limbique: difficile même pour experts.

## EVOLUTION

Deux phases inflammatoires:

- Immediate 24h

- Retardé jusqu'au 3 sem:
  - Donc diminution progressive des cortis sur 3 sem en cas atteinte severe.
  - Si atteinte legere, les cortis peuvents etre stoppés après 7-10j.

## SUIVI

En fonction de le severite, ambulatoire vs hospi

Controle 24-48h puis 5-7j jusqu'au re-épithélisation complete.

Si brulure chimique faire pH tous les suivis

Ablation de microparticules si restent avec hockey

Photo pour evaluer suivi
