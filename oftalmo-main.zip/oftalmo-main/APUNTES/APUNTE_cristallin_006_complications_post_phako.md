---
categoria: apuntes
area: catarata
emoji: 🔍
seccion: Cristallin - Lens
orden_seccion: 21
orden: 6
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-12-28
---
# Complications post phako

## ENDOPHTALMIE AIGUE ET SUBAIGUE

## ENDOPHTALMIE CHRONIQUE

## OPACIFICATION CAPSULAIRE POSTERIOR

## SYNDROME DE CONTRACTION DE LA CAPSULE ANTERIEUR

## DECENTREMENT DE L'IMPLANT

## DECOLLEMENT DE LA RETINE

## OEDEME MACULAIRE CYSTOIDE OU SYNDROME IRVINE GASS

FR: rupture capsulaire avec issue de vitré, incarceration de vitre dans l'incision, implant de CA, DM, Uveite.

Délai d'apparition moyen de 6-10 sem apres chirurgie parfois plus.

TT:

1er intention:

Cortis collyre: DX ou PF 3-4xj ?

Diamox ½ cpr 3xj + suplemeent potassium.

Alternative:

AINS collyre kétorolac 0,5%- ACULAR 3xj

2em intention:

Injection inravitréene de cortis ou injection subconjonctivale cortis, anti –VEGF, vitrectomie de 'pars plana.

## OEDEME DE CORNEE
