---
categoria: apuntes
area: cornea
emoji: 👁️
seccion: Cornée
orden_seccion: 4
orden: 23
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-01-30
---
# Kératocône

Dystrophie conéenne la plus fréquente, touchant 1 personne sur 2000.

La cornée devient progressivement plus fine et plus convexe donnant un astigmatisme irrégulier.

Diagnostiquc complique surtout dans les formes débutantes, et généralement posé durant l'adolescence.

Evolution lente et imprévisible

## SYMTOMES

BAV progressive, bilatérale mais asymétrique, commençant habituellement à l'adolescence.

Si Hydrops:

- BAV soudaine
- Douleurs
- Rougeur oculaire
- Photophobie
- Larmoiment

## SIGNES

Astigmatisme irrégulier lentement progressif

Aspect conique de la cornée

Amincissement de la cornée en région centrale ou infériure

- +/- Anneau de Feischer ( dépot de fer à la base du cone)
- +/- Stries de Vogt (lignes de tension sur la Descemet)
- +/- Cicatrice cornéene
- +/- Signes de Munson ( protrusion de la paupiee inf lors du regard vers le bas).
- +/- Hydrops ( oedeme cornéen soudain sur rupture de la Descemet, forme avancée).

## REMARQUES

Suspecter KC si:

- Autoféfractometre: cylindre >1.5D, progression du cylindre dans le temps, asymétrie du cylindre, kératométrie >45D.
- Réfraction subjective difficile à éffectuer chez un jeune patient.
- Changement fréquent de correction optique.
- Plainte de la qualité visuelle ou une baisse de la vision inexpliquée.
