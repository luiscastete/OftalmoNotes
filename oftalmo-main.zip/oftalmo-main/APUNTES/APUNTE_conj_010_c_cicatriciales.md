---
categoria: apuntes
area: cornea
emoji: 💧
seccion: Conj + Episclere + Sclere
orden_seccion: 25
orden: 10
fuente: OneNote del Dr. Castilla Martí
---
# C. Cicatriciales

## 🧠3. CONJUNTIVITIS CICATRICIALES

## 🔷3.1. Penfigoide de membranas mucosas (PMM)

**Definición**: Enfermedad ampollosa crónica, autoinmune, que afecta principalmente mucosas → fibrosis progresiva. Puede ser ocular aislado o multisistémico.

**Epidemiología**:

- Mujeres > varones (2–3:1)
- Edad media: 65 años
- 75% con afectación oral, solo 15% cutánea

**Patogenia**:

- Hipersensibilidad tipo II
- Autoanticuerpos (IgG, IgA, C3) contra:
  - Laminina 332
  - Integrinas α4, α6
- Asociación con HLA-DR4
- *Pseudopenfigoide ocular*: fenotipo clínico similar, asociado a colirios tópicos (timolol, pilocarpina…) → NO progresivo

**Presentación clínica**:

- **Inicio insidioso**: conjuntivitis crónica de repetición
- **Signos bilaterales y progresivos** (asimétricos):
  - Estadio I: fibrosis tarsal, hiperemia, queratinización carúncula
  - Estadio II: acortamiento fórnix
  - Estadio III: simbléfaron
  - Estadio IV: anquilobléfaron, queratinización de la SO
- **Complicaciones**:
  - Triquiasis, entropión
  - Ojo seco grave (por alteración glándulas de Meibomio y lagrimales)
  - Úlceras, vascularización corneal periférica
