---
categoria: apuntes
area: pediatria
emoji: 👀
seccion: Strabo-logie
orden_seccion: 22
orden: 23
fuente: OneNote del Dr. Castilla Martí
---
# Cirugia estrabismo

## 🟦Principio básico de la cirugía de estrabismo

Los músculos extraoculares pueden ser **debilitados** o **fortalecidos** modificando su **longitud, inserción o tensión**.

- **Debilitar = disminuir su fuerza de tracción.**
- **Fortalecer = aumentar su fuerza de tracción.**

## 🟦1. Técnicas de

## debilitación

👉 El músculo tira **menos fuerte**.

## 🔹Recesión

- **Definición:** se **desinserta** el músculo de la esclera y se vuelve a fijar **más atrás** en el mismo eje.
- **Efecto:**
  - El músculo queda más **largo y flojo** → pierde fuerza.
- **Ejemplo:**
  - Recesión de recto medial en **esotropia** (reduce su tracción hacia adentro).
