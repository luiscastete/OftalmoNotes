---
categoria: apuntes
area: oculoplastica
emoji: 🫥
seccion: Oculo-Plastie
orden_seccion: 3
orden: 30
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-05-11
---
# Maquillaje

Recomendaciones maquillaje poco irritante ou anti allergico:

Anti allergica - Cosmeticos – poca oferta

Cosméticos la Clinique (comercial no farmacia)

De farmacia ( tiene productor médicos también) : Roche possay

Para evitar Orzuelos/Chalazions:

2x/j Masajes et lavados de los bordes de los parpados con:

Fórmula magistral: champu de bebe Johnson&Johnson 100mL + 5mL de aceite esencial de arbol de té

Sino Champu de bebe ya funciona bien.

Crema hidratante ojo:

LIPOLAC durante dia – densa.

VITAPOS mas densa duarnte la noche.
