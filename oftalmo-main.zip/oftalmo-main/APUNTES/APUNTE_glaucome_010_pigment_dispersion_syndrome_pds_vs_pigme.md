---
categoria: apuntes
area: glaucoma
emoji: 🟢
seccion: Glaucome
orden_seccion: 5
orden: 10
fuente: OneNote del Dr. Castilla Martí
---
# Pigment Dispersion Syndrome (PDS) vs Pigmentary Glaucoma (PG)

## 🔬Fisiopatología

- **Liberación de pigmento**
  - En ojos con **iris cóncavo posterior** (miopes jóvenes sobre todo).
  - El roce entre la **cara posterior del iris** y las fibras zonulares produce **desprendimiento de gránulos de pigmento** del epitelio pigmentario iridiano.
- **Dispersión pigmentaria**
  - El pigmento se deposita en:
    - **Endotelio corneal** (spindle de Krukenberg).
    - **Trábeculum** (obstrucción).
    - **Zonulares, cápsula anterior de cristalino**.
- **Obstrucción trabecular**
  - El pigmento fagocitado por células trabeculares o acumulado directamente **reduce la filtración del humor acuoso**.
  - Resultado → **↑ PIO** intermitente o sostenida.
- **Glaucoma**
  - La PIO elevada crónica causa **daño del nervio óptico glaucomatoso**.

## 👁️Clínica
