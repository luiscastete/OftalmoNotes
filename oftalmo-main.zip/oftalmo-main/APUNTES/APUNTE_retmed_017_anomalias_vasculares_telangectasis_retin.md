---
categoria: apuntes
area: retina-medica
emoji: 🩸
seccion: Ret Med y coroides
orden_seccion: 19
orden: 17
fuente: OneNote del Dr. Castilla Martí
---
# 🩸Anomalias Vasculares: Telangectasis retinienenes - Mac Tel y macroaneurismas

## 🩸3. ANOMALÍAS VASCULARES DE LA RETINA

## 3.1.Telangiectasias retinianas (MacTel)

**Definición**: Dilataciones anómalas de capilares retinianos perifoveales (idiopáticas si no se encuentra causa específica).

## 🧬Clasificación (Yannuzzi)

| **Tipo** | **Características** | **Hallazgos clave** | **Tratamiento** |
|---|---|---|---|
| **Tipo 1** | Telangiectasias unilaterales, aneurismas visibles, edema macular, exudados duros | Fuga angiográfica, sin NVSR ni placas pigmentadas | Anti-VEGF, corticoides intravítreos, láser |
| **Tipo 2** | Bilateral, pérdida progresiva de transparencia foveal, vénulas en ángulo recto, NVSR tardía | OCT: espacios intrarretinianos, Angio-OCT: pérdida plexo capilar profundo | No tratamiento eficaz en estadio no proliferativo. Anti-VEGF útil si hay NVSR |

**Diagnóstico diferencial**: Edema macular diabético, enfermedad de Coats, maculopatía tóxica, hemangioma capilar retiniano, entre otros.

**EBO Key**:

- Tipo 1: unilateral, con exudados y edema macular.
- Tipo 2: bilateral, progresiva, afecta plexo profundo, con NVSR en estadios avanzados.
- Angio-OCT útil para estadios precoces.
