---
categoria: apuntes
area: pediatria
emoji: 🧸
seccion: Pediatrie
orden_seccion: 9
orden: 17
fuente: OneNote del Dr. Castilla Martí
---
# Uveitis

ANTERIOR UVEITIS

- DDX: juvenile idiopathic arthitis - JIA -, trauma, infcetion, tumor, sympathetic ophtalmia, sarcoidosis, familial juvenile systemic granulomatosis, phacoantigenic.

- **JUVENILE IDIOPATHIC ARTHITIS - JIA**
  - Arthitis in children <16years lasting >6months with no identifiable cause.

  - TYPES:
    - SYSTEMIC - STILL DISEASE
    - OLIGOARTICULAR
    - POLYARTICULAR
    - SPONDYLOARTHITIS

- RISK FACTOR FOR CHRONICAL UVEITIS: Female + oligoarticular + ANA+.

- FINDINGS:chronic anterior uveitis, , fine KP, band keratophaty,, catract, glaucoma,

- TT:

INTERMEDIATE UVEITIS

- PARS PLANITIS

POSTERIOR UVEITIS

  - **FAMILIAL JUVENILE SYSTEMIC GRANULOMATOSIS - BLAU SYNDROME**
  - Similar to sarcoidosis with granulomatous arthritis, uveitis, rash but no lymphadenopathy or pulmonary involvelment.

  - **TOXOPLASMOSIS**
  - En immuno
