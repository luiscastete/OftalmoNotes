---
categoria: apuntes
area: neuro
emoji: 🧠
seccion: Neuro-Ophta
orden_seccion: 8
orden: 8
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-09-26
---
# IV - Pathétique ou Throchléaire

En cas isolé, acquise---

Chez l'adulte---ppal causes ischémiques, traumatiques

Chez enfants—congenitals. Peut se révéler plus tard dans la vie pour décompensation et faire croire à une atteinte acquise.

## SIGNES

Diplopie oblique, torsionelle, dans le regard vers le bas ( à la lecture ou descente des escaliers)

Limitation de l'ocumotricité vers le bas et adduction

Excyclotorsion:

- Torsion subjective-verre de Maddox, paroi de Harms, synoptophore et torche Kratz.
- Torsion objective- rltinophotographies

Hypertropie de oeil atteint

Torticolis avec tête penchée et menton incliné du côte oppose (position compensatoire)

Test de Bielschowsky + : augmentation de l'hypertropie lorsque la tête est penchée du côte de la paralysie.

Test de Hess-Lancaster

## DISTINCTION FORME ACQUISE-FORME CONGENITAL

Les paralysies trochléaires sont souvent d'origine congénitale. Les patients deviennent symptommatiques à partir de 40-50 ans car leur emplitud de fusion verticale diminue, provoquantz alors une diplopie.

## En faveur origen congenitale

Torticolis ancienne – photographies

Amplitud de fusion verticale superieur à 4-6 D.

Diplopie plutot en verticale- le spatients se sont adaptes au trouble torsionelle.

Hyperaction de l'oblique inf. Apparente mais limitation de l'oblique sup. Modérée.

Vision stéréoscopique souvent bonne mais capacité de supression.

Asymétrie faciale, regarder la ligne interincisive

Atrophie de l.oblique sup à IRM- visible cependnat aussi dans les pathologies acquises.

## En faveur d'une atteinte bilaterale
