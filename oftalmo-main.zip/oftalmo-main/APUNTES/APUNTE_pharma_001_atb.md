---
categoria: apuntes
area: general
emoji: 💊
seccion: Pharmacologie Farma
orden_seccion: 23
orden: 1
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-01-05
---
# ATB:

ATB:

AZYTER gtt ( macrolide)

ANTIHISTAMINIQUES:

ZADITEN gtt (Ketotifenum (ut Ketotifeni hydrogenofumaras).

TTT POST-OP

PROF.WOLFENSBERGER:

Add tobradex gtt 5xj + Tobradex pommade 1xj le soir + Scopolamine gtt 2xj + coque protectrice la nuit

Pas douche complet 1 sem

Pas sport pdt dans 3 sem

AT 2 sem

OPOIDS

Tous les dif opioid son également efficace ( simplement change le dosage)

Jamais surajouter un autre opioid.

Monter la dose jusqu’à qu’il ny a plus de douleur

Monitorise: freq respiratoire.

Douleur neuropathique

Attention avec interactions avec autres medicaments

Labo:

VS tu calcules l'age et tu la divises par 2. VS normale.

Homme divise par deux

Femme divise par 2 + 10,

CONSIGNES PRE-OP

Remplir consetiment chirurgie

Donner patient feuille CPA à remplir

Jeûne pre-op:

-manger normalmente jusqu'à 6h avant la convocation

-boire de l'eau ou café sans lait jusqu^'à 2h avant convocation

-sucer ou macher des bonbons ou des chewing-gums jusqu'à 2h avant convocation

Laisser dossier patient chez la dame au bureau information avec un post-it pour lui signaler de le monter à l'étage des son arrive directemanet.

Andre Vial
