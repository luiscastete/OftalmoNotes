---
categoria: apuntes
area: retina-quirurgica
emoji: 🪡
seccion: Ret Chirg
orden_seccion: 6
orden: 2
fuente: OneNote del Dr. Castilla Martí
---
# Viscoelastic's

## 1️⃣¿Qué son los viscoelásticos?

Sustancias usadas en cirugía intraocular (principalmente catarata y segmento anterior) para:

- Mantener espacio
- Proteger el endotelio corneal
- Facilitar maniobras quirúrgicas

👉 Derivan sobre todo de **ácido hialurónico** o **celulosa (HPMC)**.

## 2️⃣Clasificación fundamental (CLAVE EBO)

## 🔹A. Viscoelásticoscohesivos

## Alta viscosidad – alto peso molecular – made from hyaluronic acid

**They tend to clump more – high surface tension- easily removed from eye – higher in molecular weight – if left in the eye pressure much more than dispersive agents bcs of their higher molecular weight and trab meshwork clogging ability.**

## Características
