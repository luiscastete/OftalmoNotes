---
categoria: apuntes
area: retina-medica
emoji: 🩸
seccion: Ret Med y coroides
orden_seccion: 19
orden: 24
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-07-24
---
# RD - rétinopathie diabétique -

HbA1c

RD-Rétinopathie diabétique: atteinte ischémique vasculaire rétinniene liée au diabète.

OMD-Oedeme maculaire diabétique: oedeme maculaire d'origine ischémique sur atteinte vasculaire diabétique.

## SYMPTOMES

## SYMPTOMES OCULAIRES

- Vision flou (si OMD) ou fluctuante ( si myopisation par intumescence du cristallin sur hyperglycémie).
- Scotome ou métamorphopsies (si OMD)
- Douleur ( si glaucome néovasculaire)
- Perte visuelle (si OVCR/OBCR/OACR)

## SYMPTOMES SYSTEMIQUE

- Polidipsie
- Polyurie
- Baisse d'état général

## SIGNES

Microanévrismes

Hémorragies rétiniennes superficielles RFNL , en flammèches.

Micro ou hémorragies intrarétinnienes moyennes – dot blot.

Hémorragies intrarétiniennes profondes en tache

Exsudats durs et mous- cotton wool spots.

Anomalies veineus: tortuosité, dilatation diffuse, aspect boudiné - en chapelet.

Anomnalies microvasculaires intraretiniennes – IRMA: Shunt artérioveineux.

+/- dilatation artériolaire et autres anomalies- signes d'une dysfonction ischémique.

## CLASSIFICATION
