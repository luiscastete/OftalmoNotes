---
categoria: apuntes
area: uveitis
emoji: 🔥
seccion: Immuno-infectio
orden_seccion: 7
orden: 14
fuente: OneNote del Dr. Castilla Martí
fecha: 2024-05-13
---
# P.2 -VOGT-KOYANAGI-HARADA / VKH

Est un uvéo-méningite inflammatoire d'origine autoimmune ( contre les tyrosine-related proteins).

Elle associe une atteinte:

- Neurologique
- Ophtalmologique
- Dermatologique

## ETIO ET EPIDEMIO

Patient mélanodermes

Entre 20-50ans

Typage HLA-DR4, DRw53 et Dqw7

## SYMPTOMES

Ils sont en fonction de la phase de la maladie:

- -Phase prodromique:
  - Syndrome méningé - 80%
  - Dysacousie
  - Vertiges

- -Phase d'uvéite aigue:
  - BAV bilaterale et rapide
  - Décollement séreux rétinien -DSR
  - Hyalite
  - Papillite
  - Vasculite rétinienne
  - UAA
  - Décollement des corès ciliaires

- -Phase chronique – en absence tt:
  - Dépigmentation du FO: aspect en coucher de soleil
  - Taches de choroidite arrondies
  - migrations pigmentaires
  - Fibreose sous-rétinniene
  - Vitiligo périlimbique- SIGNE DE SUGIURA
  - Signes extra-ophtalmologiu^ques : alopecie, vitiligo, poliose

- -Phase chronique récurrente:
  - Uvéite antérieure chronique granulomateuse synéchiante

  - récurrence postérieure rare
