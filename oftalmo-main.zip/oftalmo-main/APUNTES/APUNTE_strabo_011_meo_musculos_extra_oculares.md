---
categoria: apuntes
area: pediatria
emoji: 👀
seccion: Strabo-logie
orden_seccion: 22
orden: 11
fuente: OneNote del Dr. Castilla Martí
---
# MEO - Musculos Extra Oculares

## 🟦Los 6 músculos extraoculares + elevador del párpado

Cada ojo tiene **6 músculos** que controlan su posición, más el **elevador del párpado superior** (no se incluye en estrabología porque no mueve el globo).

## 📌Músculos rectos

- **Recto medial (RM):**
  - Acción: **aducción** (lleva el ojo hacia la nariz).
  - Inervación: **NC III (oculomotor)**.
- **Recto lateral (RL):**
  - Acción: **aBducción** (lleva el ojo hacia la sien).
  - Inervación: **NC VI (aBducens)**.
- **Recto superior (RS):**
  - Acción primaria: **elevación**.
  - Acción secundaria: **intorsión** (inciclotorsión).
  - Acción terciaria: **aducción**.
  - Inervación: **NC III**.
- **Recto inferior (RI):**
  - Acción primaria: **depresión**.
  - Acción secundaria: **extorsión** (exociclotorsión).
  - Acción terciaria: **aducción**.
  - Inervación: **NC III**.
