---
categoria: apuntes
area: retina-quirurgica
emoji: 🪡
seccion: Ret Chirg
orden_seccion: 6
orden: 4
fuente: OneNote del Dr. Castilla Martí
---
# MER

Avis Dr DESMANGLES: quand tu vois une MER qui progresse et a alteration des EPR et photoprecepteurs avec kystes intraret – signes d einflammation et soufrfrance – add ACULAR collyre 3xj + controle avec OCT pour evaluer progression

Meeting 25

ATTENTION PATIENTES QUI DOIT S’OPÉRER DE PHAKO ETVIL Y A UNE MER… se poser la question à chirg ret si vaut la peine enlever MER…

Car facteur de risque de irvin gass c’est la MER.

Retinoptahies inhabitueles

Borruat
