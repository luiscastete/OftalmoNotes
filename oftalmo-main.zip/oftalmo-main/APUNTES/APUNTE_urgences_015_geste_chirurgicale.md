---
categoria: apuntes
area: urgencias
emoji: 🚑
seccion: URGENCES---TRAUMATOLOGIE
orden_seccion: 2
orden: 15
fuente: OneNote del Dr. Castilla Martí
fecha: 2022-08-30
---
# Geste chirurgicale

## Geste 

-Désinfection, champhage. Anesthesie en bague à la Rapidocaine . Rinçage à l'eau stérile. Ablation de l'ongle dans sa tonlite, exploration du lit de l'ongle qu'est lésé. suture du lit de l'ongle par es points simple de Vicryl 4-0.Application de l'ongle sur le lit, suture de l'ongle par 2 points de Proléne 4-0, suture de la plaie cutanée pour 1 point simple de Proléne. Betadine onguent, doiglier adalic, compresses, bande auto-adhesive.

-Désinfection, champhage. Anesthésie en bague à la Rapidocaine et bicarbonate. Rinçage à l'eau stérile. Exploration de la plaie. Suture de la plaie cutanée pour 3 point simple de Prolene/vycril  4-0. Bétadine onguent, compresses, bande auto-adhesive.

Steri strips

\_\_\_\_\_\_

## Geste 

-Désinfection, champhage. Anesthesie en bague à la Rapidocaine. Rinçage à l'eau stérile.  Examination via lacrymal avec sondage via lacrymal, palpation osesuse, via permeable sans reflux ni douler.  Suture de la plaies palpebrales pour 3 points simple de Prolene non reabsorbable  6-0. Suture de la plaie canthus medial pour 1 points simple de Prolene non reabsorbable  6-0.  Betadine onguent.

-Désinfection, champhage. Anesthésie en bague à la Rapidocaine et bicarbonate. Rinçage à l'eau stérile. Exploration de la plaie. Suture de la plaie cutanée pour 3 point simple de Prolene/vycril  4-0. Bétadine onguent, compresses, bande auto-adhesive.

Steri strips
