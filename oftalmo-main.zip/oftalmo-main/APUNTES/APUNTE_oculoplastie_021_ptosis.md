---
categoria: apuntes
area: oculoplastica
emoji: 🫥
seccion: Oculo-Plastie
orden_seccion: 3
orden: 21
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-08-16
---
# Ptosis

Position anormalemnt basse de la paupiere superieur

## ETIOLOGIE

## CONGENITAL

Isolé ou simple. Unilateral 2/3 ou bilateralaysymetrique 1/3.

Associé à des anomalies oculomotrices (NC III, fobrose oculomotrice, syncinésie de Marcus Gunn)

Syndrome de blépharphimosis.

Syndrome de Horner. ( heterochromie irienne)

## ACQUIS

- **Aponévrotique/involutionnel:** déhiscence et/ou désinsertion du faisceau musculo-aponevrotique du releveur de la paupire superieur avec fibres striés normales.
- **Neurogène:**
  - Atteinte du NC III.
  - Syndrome de Horner.
- **Myogène-Neuromusculaire: :**
  - Ophtalmoplegie externe chronique progressive (CPEO)
  - Dystrophiemyotonique de Steinert.
  - Myasthénie
- **Traumatique**
- **Mécanique:** caused by gravitional effect of a mass processus malin orbite/paupiere superieur.

## DD

## Pseudoptosis

- Lack of support of the lids by the globe due to and orbital volume deficit: microphtalmos, pthysis bulbis ipsilateral, enophtalmie ipsilaterale,
- Contralateral lid retraction
- Ipsilateral hypotropia - pg 75
- Brown ptosis
- Dermatochalasis,
- ptose du sourcil,
- rétraction palpebrale ou exophtalmie contralaterale,
- **Dermatochalasis:** overhanging skin on the upper lids may be mistaken for ptosis, but may also cause mechanical ptosis.

## STATUS

## Clinical evaluation

Age of onset nd duration sill distinguish congenital from acquired.

If history is ambiguous -- old photographs are helppfull.

Ask also about:

- Other symp - underlying systemic disease?
- Assoc diplopia?
- Variability of ptosis during the day and excesive fatigue?

MEASUREMENTS
