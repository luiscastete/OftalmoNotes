---
categoria: apuntes
area: cornea
emoji: 👁️
seccion: Cornée
orden_seccion: 4
orden: 30
fuente: OneNote del Dr. Castilla Martí
---
# Queratitis no infecciosa / Inflamatoria

## 🔥4. Queratitis No Infecciosa / Inflamatoria

## 🧱4.1. Trastornos estructurales y exógenos

## 🧊4.1.1. Queratopatía por exposición

💡 Cierre incompleto de los párpados (lagoftalmos) → desecación corneal a pesar de lágrima normal.

**Etiología**:

- Neuroparálisis: parálisis facial, Parkinson.
- Mecánicas: cicatrices, blefaroplastia.
- Dermatológicas: Stevens-Johnson, xeroderma pigmentoso.
- Proptosis.

**Clínica**:

- 👁️ Ojo seco, erosiones punteadas interpalpebrales.
- Ulceración, lisis estromal, perforación si grave.
- Cambios crónicos: degeneración de Salzmann.

**Tratamiento**:

- Lágrimas artificiales sin conservantes + pomada nocturna.
- Lentes de contacto terapéuticas.
- Tarsorrafia / injertos de membrana amniótica / pesa de oro en párpado.
