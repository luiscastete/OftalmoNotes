---
categoria: apuntes
area: cornea
emoji: 👁️
seccion: Cornée
orden_seccion: 4
orden: 15
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-07-22
---
# Kératite filamenteuse

Es una patologia habitial que puede causar molestias importantes. Se supone que un area suelta de épitelio actua de foco para el deposito de moco y restos celulares. Entre las causas se incluyen:

- El ojo seco por deficiencia aquoasa es la mas freq.
- Inestabilidad de épithelio corneal ( sindrome erosion recurrente, injerto corneal, cirugia de cataratas o refractiva y toxicidad por farmacos.
- Queratoconjontivitis limbica superior
- Queratitis neurotrofica
- Oclusion prolongada por parches o asociada con blefarospasmo esencial

## DX

## SINTOMAS

Molestias y sensacion CE

HC

Blpharospasme

Photophobia

Epiphora

## SIGNOS

Hebras de celulas epiteliales degeneradas y moco unido a une extremo de la cornea que se mueven con el parpadeo. Se tiñen bien con el rosa bengala.

Puede existir un pequeño defecto epitelial en la base de un filamento.

## TTT

## GENERAL

Debe tratarse causa subyacente como el ojo seco.

Debe suspenderse todos los farmacos innecesarios.

Corticoides topicos a corto plazo

Tmb pueden utilizarse gotas de antiinflamatorios no esteroideos, como diclofenaco 0'1% y parecen tener un efecto anestesico.

## TTT ESPECIFICO
