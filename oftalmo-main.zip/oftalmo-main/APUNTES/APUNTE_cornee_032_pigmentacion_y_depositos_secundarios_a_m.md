---
categoria: apuntes
area: cornea
emoji: 👁️
seccion: Cornée
orden_seccion: 4
orden: 32
fuente: OneNote del Dr. Castilla Martí
---
# Pigmentación y depósitos secundarios a medicamentos - Fabry

## 🧠4.4. Pigmentación y depósitos secundarios a medicamentos

## 🩸Localización de depósitos según capa corneal

## 📍A. A NIVEL EPITELIAL

Fármacos que pueden pigmentarse o depositarse:

- **Aminoquinolonas**
- **Amiodarona**
- **Clofacimina**
- **Clorpromacina**
- **Indometacina**
- **Naproxeno**
- **Perhexilina**
- **Suramina**
- **Tamoxifeno**
- **Tioxantinas**
- **Tilorona**
