---
categoria: apuntes
area: oculoplastica
emoji: 🫥
seccion: Oculo-Plastie
orden_seccion: 3
orden: 31
fuente: OneNote del Dr. Castilla Martí
---
# Hertel

Grande myope

Equivalence 3D::::1mm

Psuedoexophtalmie

Diference entre myope forte entre 2 yeux

Examen voies lacrymals

JAMAIS rincer une petite enfant ( risque laryngoespasme)

Expliquer patiente que on va faire,

Expliquer que c’est ne pas une aiguille

Seringue de 3-5cm

Toujours verifie que seringue et matériel fonctionne

Importante: tenir la paupieres avec petite doigt de main contralaterale. Comme ca paupiere bouge pas.
