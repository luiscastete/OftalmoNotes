---
categoria: apuntes
area: cornea
emoji: 👁️
seccion: Cornée
orden_seccion: 4
orden: 35
fuente: OneNote del Dr. Castilla Martí
---
# Dystrophies 2.0

Epithelial and Subepithelial Dystrophies

- Epithelial Basement Membrane Dystrophy (EBMD) - Cogan microcystic epithelial dystrophy - map-dot-fingerprint dystrophy.
  - Most common anterior corneal dystrophy
  - F: irregular often loose epithelium with caract appearance (map, dot and fingerprint)
  - Pathology: poor epithelial adhesion to BM.
