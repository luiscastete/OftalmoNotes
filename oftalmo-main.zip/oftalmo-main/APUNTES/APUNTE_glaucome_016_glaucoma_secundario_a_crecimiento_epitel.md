---
categoria: apuntes
area: glaucoma
emoji: 🟢
seccion: Glaucome
orden_seccion: 5
orden: 16
fuente: OneNote del Dr. Castilla Martí
---
# 🧫 Glaucoma secundario a crecimiento epitelial (Epithelial Ingrowth)

## ✅Definición

• **Complicación rara pero grave** de cirugía del segmento anterior o trauma.

• Consiste en la **migración de células epiteliales conjuntivales o corneales** hacia el segmento anterior, a través de una herida quirúrgica o traumática.

• Estas células **proliferan** y pueden formar una **membrana epitelial** invasiva.

## 🔬Mecanismos de ↑PIO

| **Mecanismo** | **Detalle** |
|---|---|
| Obstrucción trabecular directa | Por membranas epiteliales |
| Cierre angular sinequial | Formación de sinequias por la membrana |
| Células desescamadas + inflamación | Obstrucción adicional del ángulo |

💣 Glaucoma **difícil de tratar** y con **mal pronóstico visual** si no se erradica completamente el epitelio.

## 🔎Diagnóstico

| **Hallazgo clínico** | **Descripción** |
|---|---|
| ❗ Uveítis anterior persistente | Postoperatoria, de difícil resolución |
| 👁️ Membrana grisácea y traslúcida | Sobre la cara posterior de la córnea, bordes festoneados |
| 🌀 Distorsión pupilar | Por tracción o invasión |
| 🧬 Padrón proliferativo quístico o fibroso | Mejor pronóstico en comparación con difuso |

## 💊Tratamiento

🎯 **Objetivo**: eliminar completamente el epitelio invasivo para evitar recurrencia.

| **Tratamiento** | **Detalles** |
|---|---|
| 🔪 **Exéresis en bloque** | Resección simultánea de córnea, esclera, iris y cuerpo ciliar comprometidos. Cubrir con injerto tectónico. |
| 🔥 **Crioterapia** | Devitalizar epitelio residual (en córnea, ángulo, cuerpo ciliar). Se protege tejido sano con aire intraocular. |
| 💉 **5-Fluorouracilo intracameral** | Resultados variables. |
| 💉 **Metotrexato intravítreo** | 400 mcg/0,1 ml c/2 semanas × 6 ciclos → casos exitosos reportados. |
| 📦 **Dispositivos de drenaje** | Útiles en glaucoma no controlado médicamente y sin posibilidad de exéresis quirúrgica. |
