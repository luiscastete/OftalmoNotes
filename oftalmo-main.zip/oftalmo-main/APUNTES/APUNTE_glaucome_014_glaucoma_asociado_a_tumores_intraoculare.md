---
categoria: apuntes
area: glaucoma
emoji: 🟢
seccion: Glaucome
orden_seccion: 5
orden: 14
fuente: OneNote del Dr. Castilla Martí
---
# 🧬 Glaucoma asociado a tumores intraoculares

## 🧬Glaucoma asociado a tumores intraoculares

## ✅Generalidades

• Afecta aproximadamente al **5% de los ojos con tumores intraoculares**.

• Se trata de un **glaucoma secundario** debido a mecanismos variados, que pueden coexistir y no siempre son distinguibles clínicamente.

## 🔍Mecanismos fisiopatológicos

## 1. Bloqueo trabecular directo

| **Mecanismo** | **Descripción** | **Comentarios** |
|---|---|---|
| 🔸 **Invasión del ángulo** | Por tumor sólido, ej. **melanoma de iris** | Masa tumoral obstruye físicamente el drenaje |
| 🔸 **Infiltración trabecular** | Por células tumorales (melanoma de iris, retinoblastoma) | Más raro, pero puede provocar aumento de PIO |
| 🔸 **Glaucoma melanomalítico** | Macrófagos cargados de **pigmento y células tumorales** obstruyen el trabéculo | Similar al glaucoma facolítico, suele ocurrir con melanomas |
|  |  |  |

## 2. Cierre angular secundario

| **Mecanismo** | **Ejemplos** | **Comentarios** |
|---|---|---|
| 🔹 **Glaucoma neovascular** | Asociado a **melanoma coroideo** o **retinoblastoma** | Es el mecanismo **más frecuente** en estos casos |
| 🔹 **Desplazamiento anterior del diafragma iris-lente** | Por **melanoma de cuerpo ciliar** o tumor posterior grande | Empuja estructuras anteriores → cierre angular |
|  |  |  |

## 🧠Flashcards rápidas
