---
categoria: apuntes
area: glaucoma
emoji: 🟢
seccion: Glaucome
orden_seccion: 5
orden: 12
fuente: OneNote del Dr. Castilla Martí
---
# Mutaciones genéticas

## 🧬

## Genética y Glaucoma / Disgenesias del Segmento Anterior

| **Gen** | **Patología asociada** | **Herencia** | **Comentario clave** |
|---|---|---|---|
| **CYP1B1** | Glaucoma congénito primario | Autosómica recesiva | Gen más frecuente en PCG; afecta desarrollo trabecular |
| **MYOC** | Glaucoma primario de ángulo abierto (POAG) familiar | Autosómica dominante | Inicio precoz; miocilina se acumula en TM |
| **PITX2** | Síndrome de Axenfeld–Rieger | Autosómica dominante | Anomalías oculares + dentales + umbilicales |
| **FOXC1** | Síndrome de Axenfeld–Rieger | Autosómica dominante | Similar a PITX2; más glaucomatoso |
| **PAX6** | Aniridia congénita | Autosómica dominante | Defecto en desarrollo del iris y fovea; riesgo de glaucoma |
| **OPTN** | Glaucoma primario de ángulo abierto de evolución lenta | Autosómica dominante | Asociado a algunos casos no familiares |

## 🧠

## Tips para memorizar
