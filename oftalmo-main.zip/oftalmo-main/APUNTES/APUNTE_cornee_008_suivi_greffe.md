---
categoria: apuntes
area: cornea
emoji: 👁️
seccion: Cornée
orden_seccion: 4
orden: 8
fuente: OneNote del Dr. Castilla Martí
fecha: 2024-01-12
---
# Suivi greffe

Suivi pots greffe

Suivre:

Axis

Pachy

Contage endothelial
