---
categoria: apuntes
area: retina-medica
emoji: 🩸
seccion: Ret Med y coroides
orden_seccion: 19
orden: 36
fuente: OneNote del Dr. Castilla Martí
---
# Retinosis pigmentaria RP

## 3. RETINOSIS PIGMENTARIA (RP)

## 3.1. EPIDEMIOLOGÍA

- **Prevalencia**: 1/3.000 a 1/5.000 personas (distrofia hereditaria más frecuente).
- Mayor incidencia en primeras 4 décadas. Rara vez causa ceguera total.
- 25% de los pacientes quedan legalmente coegos de AO aunque raramente pierden vision total.
- En fases tardías, el 50% mantiene AV ≥ 6/12 en al menos un ojo.

## 3.2. CLÍNICA Y DIAGNÓSTICO

**Por consenso, el diagnóstico se establece cuando están presentes los siguientes hallazgos:**

## 1) compromiso bilateral.

## 2) pérdida de visión periférica.

**3) disfunción de bastones evidenciada por el umbral final de bastones aumentado en la adaptación a la oscuridad y respuestas de bastones en ERG reducidas en amplitud y prolongadas en tiempo implícito o no detectables.**

## 4) pérdida progresiva en la función de todos los fotorreceptores.

**Síntomas clave**:

- Ceguera nocturna + pérdida progresiva del campo periférico → visión tubular.
- Afectación central en fases avanzadas.

- Las anomalías de la función visual incluyen cambios en el campo visual, agudeza visual, visión de colores y adaptación a la oscuridad. Las anomalías funcionales aparecen de forma temprana incluso antes de los cambios oftalmoscópicos y empeoran progresivamente. La constricción del campo visual es gradual y mayor en condiciones mesópicas o escotópicas y evoluciona a la visión tubular a medida que la enfermedad progresa. Debido a la afectación tardía del área macular, la AV se conserva hasta etapas tardías de la enfermedad, que en el caso de la RP autosómica dominante, es buena incluso después de los 50 o 60 años. El defecto de color típico es la tendencia a la tritanopia, aunque el primer signo detectable de RP es la sensibilidad a la luz reducida en áreas retinianas localizadas13. Con el progreso de la enfermedad, el umbral escotópico también se hace gradualmente más alto.
