---
categoria: apuntes
area: catarata
emoji: 🔍
seccion: Cristallin - Lens
orden_seccion: 21
orden: 3
fuente: OneNote del Dr. Castilla Martí
---
# PCR - Posterior Capsular Rupture

Risk factor for PCR during cataract surgery include:

- Surgeon inexperience
- Smaller pupil size
- Presence of pseudoexfoliation
- Denser cataracte
- History of previous inrtavitreal injections
- Posterior polar cataract
- History of ocular trauma

Intraoperative signs of PCR include:

- Sudden deeping of the ant chamber

- Momentary pupillary expansio

- Lens nucleus does. Not rotate well

- Lens nucleus does not come to the phako tip like did before

- Lens tilt or drops…upsi

- Occlusion of phako tip without any fragments at tip

Very first thing to to if PCR:

- Take a deep breath and be calm!! Is not the end of the world for thid eye and good results can still occur if thwe surgeon manages the PCR well.

  - PRIMARY GOALS AREA:
    - Remove as much as lens material as you can safely can
    - Prevent vitroeous prolapse or removal all vitreous thath is anterior to the lens capsule
    - Insert an inraocular lens in a safe and stable location
