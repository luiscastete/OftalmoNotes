---
categoria: apuntes
area: cornea
emoji: 👁️
seccion: Cornée
orden_seccion: 4
orden: 28
fuente: OneNote del Dr. Castilla Martí
---
# Queratitis fungicas

## 3.2. Queratitis fúngicas

## 🪠3.2.1. Patogenia

- Poco frecuente en climas templados. 1-7% de las queratitis infecciosas.
- Alta prevalencia en regiones tropicales y en países en desarrollo.

## 🦠Tipos de hongos

- **Levaduras**: *Candida spp.* → infecciones en climas templados.
- **Hongos filamentosos**: *Fusarium*, *Aspergillus* → frecuentes en climas tropicales.

## ⚠️Factores predisponentes

- Enfermedad crónica de la superficie ocular.
- Corticoides tópicos prolongados.
- Uso de lentes de contacto.
- Inmunosupresión sistémica, diabetes.
- Traumatismos con material vegetal o herramientas.

## 🔍3.2.2. Cuadro clínico

## 😷Síntomas

- Comienzo gradual: dolor, arenilla, fotofobia, visión borrosa, secreción mucopurulenta.

## 🔎Signos

- **Cándida**: infiltrado blanco-amarillento supurativo.
- **Filamentosos**: infiltrado estromal gris/amarillo con bordes desflecados.
- Lesiones satélite, necrosis, adelgazamiento corneal.
- Puede haber: hipopión, placa endotelial, aumento PIO, escleritis, endoftalmitis.

## 🔌Diagnóstico diferencial

- Queratitis bacteriana, herpética, amebiana.

## 🔢3.2.3. Evaluación de laboratorio

- Tinción con **hidroxido potásico (KOH)** → visualización de hifas.
- **Cultivo en agar sangre**, Sabouraud o infusión cerebro-corazón.
