---
categoria: apuntes
area: cornea
emoji: 👁️
seccion: Cornée
orden_seccion: 4
orden: 41
fuente: OneNote del Dr. Castilla Martí
---
# Meeting 25

Forte valeur pédagogique pour le patient le meibograohie

Tjrs donné anti-inflammatoire

Privilegie hidrocortisone

Ciclosporine - aussi comment

Serum autologue et PRP - chaque fois plus utilisé
