---
categoria: apuntes
area: glaucoma
emoji: 🟢
seccion: Glaucome
orden_seccion: 5
orden: 36
fuente: OneNote del Dr. Castilla Martí
---
# Glaucoma congénito Embryotoxon

**Embryotoxon** es un hallazgo **ocular congénito** que se refiere a una **línea blanca o anillo** visible en la periferia de la **córnea**, justo delante del **limbo esclerocorneal**, como resultado de una **anomalía en la membrana de Descemet**.

## ✅Resumen rápido para el EBO

- 🔍 **Definición**: Línea opaca blanquecina o grisácea que representa un **engrosamiento anterior de la membrana de Descemet**, visible en la lámpara de hendidura como una línea blanca cerca del limbo.
- 📍 **Localización**: Periferia corneal (más evidente en el sector nasal).
- 😶 **Asintomático**: No afecta la visión por sí solo.
- 🧬 **Puede ser**:
  - **Aislado** (variante normal, hasta en 15% de la población sana).
  - **Asociado a síndromes** → importante como signo clínico.

## 🔎

## Síndromes asociados (EBO KEY)

| **Síndrome** | **Asociaciones** |
|---|---|
| **Síndrome de Axenfeld-Rieger** | Embryotoxon anterior + sinequias iridocorneales + anomalías del ángulo y pupila + riesgo de glaucoma |
| **Síndrome de Alagille** | Embryotoxon + colestasis + facies característica + cardiopatía congénita + anomalías vertebrales |
