---
categoria: apuntes
area: catarata
emoji: 🔍
seccion: Cristallin - Lens
orden_seccion: 21
orden: 1
fuente: OneNote del Dr. Castilla Martí
fecha: 2022-08-30
---
# CATARACTE

Perte de la transparence du cristallin.

## Épidemiologie

Prevalence variable ( 71% si >85% ans) 1er cause de cécite reversible mondiale, 40% des cas de cécite dans le monde.

## SYMPTOMES

BAV de loin et de près

- Rapidement pour les cat. Sous-capsulaires post.
- lente pour les cat. Corticales et nucleaires

Diplopie monoculaire (par definition refractive)

+/- MYOPISATION d'indice, surtout dans les cataractes nucleaires: possible phenomen de second sight ou les patients n'ont plus besoin de leur lunettes de lecture pour voir de près.

Eblouissement

Halos autour des lumieres ( surtout decrit le soir avec phares lors de la conduite).

Baisse de la sensibilite aux contrastes.

Alteration de la vision des couleurs.- absortion des couleurs des courtes longeurs d'ondes-perte couleurs froids-bleus

Possible cecite si pas ttt.

## SIGNES

## AV basse qui s'àméliore au trou stenopeique

Sclerose nucleaire, cataracte corticale, voile sous-capsulaire posterieur ( bien visible à la retro-ilumination du cristallin en mydriase)

Attention si hypermetropie + cataracte: risque glaucome àngle fermé +/- glaucome aigu par fermeture de l'angle.

## ETIOLOGIE

Age

Trauma

Medicaments: corticoesteroides, antipsychotiques.
