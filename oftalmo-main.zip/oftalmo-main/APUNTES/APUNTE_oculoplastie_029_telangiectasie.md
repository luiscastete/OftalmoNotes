---
categoria: apuntes
area: oculoplastica
emoji: 🫥
seccion: Oculo-Plastie
orden_seccion: 3
orden: 29
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-03-31
---
# Télangiectasie

La télangiectasie correspond à une lésion cutanée due à la dilatation permanente de petits vaisseaux sanguins, en forme d’étoile pour les angiomes stellaires ou suivant un trajet vasculaire linéaire sur la

peau.

Les télangiectasies sont le plus souvent bénignes, mais peuvent être le symptôme d'une maladie sous-jacente.

Les télangiectasies (Telangiectasias ou angioectasias pour les anglophones) désignent différentes formes de dilatation de petits vaisseaux sanguins situés près de la surface de la peau, des muqueuses ou du blanc de l'œil, quand cette « dilatation vasculaire » est anormale par sa taille (0,5 à 1 millimètre de diamètre1) et sa permanence.Elles peuvent être composées d'agrégats anormaux d'artérioles, capillaires ou veinules. Leur couleur varie de rouge à violet. Elles sont rares chez les enfants.

C'est un symptôme possible de :

la rosacée (qu'il est possible de réduire par le biais de la vitropression) ;
