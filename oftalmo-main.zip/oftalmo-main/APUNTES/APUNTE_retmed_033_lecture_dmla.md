---
categoria: apuntes
area: retina-medica
emoji: 🩸
seccion: Ret Med y coroides
orden_seccion: 19
orden: 33
fuente: OneNote del Dr. Castilla Martí
---
# Lecture Dmla

C’est pire sous traite! Pas assez et donner plus va jamais faire mal.

Référence avec Av en lettres ETDRS et CV.

Faire schemas regles/ structures donne mieux résultats.

6.6 injections par ans de moyen.

Seulement il y a un 10% de patients souffre de sur traitement!

Donc plus de risque en perdre a cause de la progression de la maladie que pour donner trop des injections.

En general patients son sous traite! Et après c’est trop tard.

FARICIMAB-
