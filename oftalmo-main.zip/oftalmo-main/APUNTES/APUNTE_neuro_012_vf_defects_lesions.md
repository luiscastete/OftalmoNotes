---
categoria: apuntes
area: neuro
emoji: 🧠
seccion: Neuro-Ophta
orden_seccion: 8
orden: 12
fuente: OneNote del Dr. Castilla Martí
---
# Vf defects lesions

https://app.pulsenotes.com/specialities/ophthalmology/notes/visual-field-defects

Junctional scotoma

El escotoma de la union se produce a nivel de la union del nervio optico con el quiasma, afectando a la rpodilla de Von Willebrand. Esto produce un escotoma central ipsilateral y un escotoma temporal superior contralateral. Estos escotomas son debidos a que la decusaciion en el quiasma tiene como pecularidad que las fibras provenientes del cuadrante nasal inferior se decusan en la porcion anterior del quiasma formando la lammada rodilla de Von willebrand en el nervio optico contralateral.
