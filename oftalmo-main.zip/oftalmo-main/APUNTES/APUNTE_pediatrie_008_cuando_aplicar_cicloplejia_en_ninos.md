---
categoria: apuntes
area: pediatria
emoji: 🧸
seccion: Pediatrie
orden_seccion: 9
orden: 8
fuente: OneNote del Dr. Castilla Martí
---
# ¿Cuándo aplicar cicloplejía en niños?

🔹 **¿Cuándo aplicar cicloplejía en niños?**

Debes hacer refracción cicloplejica en:

🔹 **¿Hasta qué edad es útil la cicloplejía?**

💊 **Elección de cicloplejico por edad:**
