---
categoria: apuntes
area: retina-medica
emoji: 🩸
seccion: Ret Med y coroides
orden_seccion: 19
orden: 2
fuente: OneNote del Dr. Castilla Martí
---
# Síndrome de Tracción Vítreomacular (VMT)

Síndrome de Tracción Vítreomacular (VMT)

Definición

Tracción ejercida por un **desprendimiento vítreo posterior (DVP) incompleto**, con persistencia de adherencia vitreofoveal que produce deformación anatómica de la mácula y alteración visual. (EyeWiki)

Fisiopatología

Factores de riesgo
