---
categoria: apuntes
area: pediatria
emoji: 👀
seccion: Strabo-logie
orden_seccion: 22
orden: 3
fuente: OneNote del Dr. Castilla Martí
---
# Endotropias

## 🔍¿“Endotropía” es siempre patológica?

**✅Sí: el términoendotropía se refiere a unadesviación patológica del ojo hacia adentro (aduccióninvoluntaria oanómala).**

- Es un tipo de **estrabismo manifiesto**, no un movimiento normal del ojo.
- El ojo está **permanentemente o intermitentemente desviado** hacia la nariz, incluso cuando el paciente intenta mirar al frente (posición primaria).
- Puede ser **intermitente, constante, acomodativa, no acomodativa**, etc.

## ⚠️No confundir con

| **Término** | **Qué es** |
|---|---|
| **Aducción** | Movimiento normal del ojo hacia la nariz (voluntario) |
| **Endotropía** | Estrabismo convergente patológico (desviación hacia adentro) |
| **Endoforia** | Tendencia latente a la desviación hacia adentro (solo aparece al romper la fusión) |

## 🧠Resumen clínico
