---
categoria: apuntes
area: cornea
emoji: 👁️
seccion: Cornée
orden_seccion: 4
orden: 39
fuente: OneNote del Dr. Castilla Martí
---
# CCR

Tt post-op:

Nevanac

Dexafree

Vigamox

LDC pansement

Petites detailles:

Pour le TransPRK ( ablation epith et stroma )

Anesthésie avec oxy

Pas tetra car trop toxique et parfois abime le epith.

Pour PRK ( nous ablationons le épithélium avant avec 20% OH)

Anesthésie avec tetra

Indications post-op

Douleurs et larmoiments normale pdt 2 sem

Eviter toute type d’eau

Venir avants si visulisation de point blanche

Vision va fluctuer pdt 2 sem

Pas conduire pdt 2 sem

AT 5j

Normale si vous avez de constipation provoque pour le co dafalgan

PRK:

Avantage

techniquement c’est simple

Cornée tpute la vie est plus solide

Désavantage

Douleurs premiers 3-7j

Récupération plus lente et AV amélioration lente mais progressive

LASIK

Avantage

AV bien depuis l’opération et moins douleurs

Désavantage

Risque déplacement voilé pdt toute la vie

Les deux technique

Sécheresse possible dans le deux

Photophobie possible les deux

Halos et éblouissement les soirs

DLK
