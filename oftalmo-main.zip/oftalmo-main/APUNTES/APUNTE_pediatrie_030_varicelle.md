---
categoria: apuntes
area: pediatria
emoji: 🧸
seccion: Pediatrie
orden_seccion: 9
orden: 30
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-07-08
---
# Varicelle

Vesicules en borde palpebrale ?

Ttt comme Herpes:

Pommade acyclovir 5xj pdt 7j

Add tobrex gtt 4xj pdt 7j

Optava au beson

PC dans 5j
