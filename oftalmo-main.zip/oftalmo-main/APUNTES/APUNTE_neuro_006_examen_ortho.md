---
categoria: apuntes
area: neuro
emoji: 🧠
seccion: Neuro-Ophta
orden_seccion: 8
orden: 6
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-10-24
---
# Examen ORTHO

## Examen Orthoptique

## Déviations 

Peut-on avoir une tropie et une phorie ? - Expliquant.com

Phorie :

Exophorie (X de près X’) (pas de mouvement de prise de fixation, mouvement de restitution de l’extérieur vers l’intérieur)

Esophorie (E de près E’) (pas de mouvement de prise de fixation, mouvement de restitution de l’intérieur vers l’extérieur)

Hyperphorie (si œil gauche en hyperphorie G/D) (pas de mouvement de prise de fixation, mouvement de restitution de haut en bas)

Hypophorie (si œil gauche plus bas que l’œil droit D/G) (pas de mouvement de prise de fixation, mouvement de restitution de bas en haut)

Tropie :

Exotropie (XT de près X’T)   (mouvement de prise de fixation, de l’extérieur vers l’intérieur)

Esotropie (ET de près E’T) (mouvement de prise de fixation, de l’intérieur vers l’extérieur)

Hypertropie (si œil gauche en hyperphorie G/DT)  (mouvement de prise de fixation, de haut en bas)

Hypotropie (si œil gauche plus bas que l’œil droit D/GT)  (mouvement de prise de fixation, de bas en haut)
