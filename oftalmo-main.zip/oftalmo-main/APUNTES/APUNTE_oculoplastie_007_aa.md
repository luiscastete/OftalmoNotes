---
categoria: apuntes
area: oculoplastica
emoji: 🫥
seccion: Oculo-Plastie
orden_seccion: 3
orden: 7
fuente: OneNote del Dr. Castilla Martí
fecha: 2024-08-06
---
# AA

COMMENT DECRIRE UN MASSE PALPEBRALE

-masse souple-mou/indure

-indolore/douleuresuse a la palpation

-pas / signes inflammatoires

-depuis quand?

-mobile?

-masse homogene? Heterogene?

-associe lesion cutanées ou conjonctivales?

-
