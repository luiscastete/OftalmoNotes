---
categoria: apuntes
area: retina-medica
emoji: 🩸
seccion: Ret Med y coroides
orden_seccion: 19
orden: 4
fuente: OneNote del Dr. Castilla Martí
---
# Vortex vein Varix

Vortex Vein Varix - EyeWiki
