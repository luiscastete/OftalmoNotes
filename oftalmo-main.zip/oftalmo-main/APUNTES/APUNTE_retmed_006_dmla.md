---
categoria: apuntes
area: retina-medica
emoji: 🩸
seccion: Ret Med y coroides
orden_seccion: 19
orden: 6
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-03-14
---
# DMLA

Maladie degenerative de la macula. Presentation clinique variable selon phenotype et stade.

Majoritariament bilaterale asymetrique

Formes: atrophique vs exsusative.

## SYMP

Asymptomatiques

BAV progressive ( surtout de près)

Métamorphopsies

Scotome central

Difficulte au changement d'éclairage.

## SIGNES

Forme precoce:

- Drusen, remainiments de épithelium pigmentaire ( REP)

Formes tardives:

- Atrophique (perte tissue fonctionnel): plage atrophique maculaire +/- étendue.
- Exsudative ( prèsence de neovaisseux sous retiniens): hémorragie sous/intra/préretinnienne, exsudation, cicatrice fibrogliale ( stade avance).

## ETIOLOGIE/EPIDEMIOLOGIE

Prevalence augmente avec l'age: 10% chez >65 ans et 30% chez >85ans.

Facteurs de risque: age: majoritairement, alimenttaion pauvre en antioxydants: lutein, tabac, femme, iris clair, population caucasien.

Pathologenese: 70% genetique, 30% enviromentale-stress oxydatif.

Maladie de l'épithelium pigmentaire maculaire qui n'arrive plus é elimier les toxines de la macula.

## STATUS

AV-TIO

Grille d'Amsler

FO dilate

## BILAN
