---
categoria: apuntes
area: uveitis
emoji: 🔥
seccion: Immuno-infectio
orden_seccion: 7
orden: 23
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-03-14
---
# Traitement PREDNISONE

Contacter MT pour savoir si contraindications

Prendrre le matin t^t car sinon problemes pour dormir

Schèma degressif si 1mg/kg/j schèma degressif en 10 en 10 par semaine

Si prends 40mg pdt 3 j tu peut arreter du coup mais si prends pendat de semaines tu ne peut pas arreter du coup important arreter doucement.

Patient n'a pas MT. 1er rdv en mai 2023.

Plan:

PC sem prochaine pour pister labo. si pas contraindications au labo ni comorbilites ( DM? ulcères gastriques? maladies auto-immune?)

add labo: VS et TBC ( pas possible surajouter bilan ant)

Prévenir patient: si infection consulter urgence, se protéger du soleil, prendre prednisone le matin pour éviter troubles du sommeil, risque de DM, risque de ulcère gastrique, risque de troubles psychiatriques et dépression.

Avis garde médecin interne CHUV:  Prednisone70mg x jour pdt 2sem puis 60mgxj pdt 1sem, puis 50mgxj pdt 1 sem, puis 30mgxj 1sem, puis 20mgxj 1sem, 10mgxj 1sem, 5mgxj 1sem et stop ( total 8sem).

add Pantoprazol 20mg 1xj pdt 8 sem, Calcimagon-D3 forte 1cpr le matin pdt 8 sem et profilaxis avec Bactrim forte 1cpr pdt 6 sem.
