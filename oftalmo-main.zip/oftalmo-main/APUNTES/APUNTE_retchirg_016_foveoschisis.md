---
categoria: apuntes
area: retina-quirurgica
emoji: 🪡
seccion: Ret Chirg
orden_seccion: 6
orden: 16
fuente: OneNote del Dr. Castilla Martí
---
# Foveoschisis

Avec l’âge tu vas change de vouloir pas opérer que operer.

Pas c’est cassé la tête.

The best surgeon is not the best who operates. The best surgeon is the one thats knows not what to operate.

Dont do unecessary things!

Meilleur operation l’opération avec le minimum de gest possibles.
