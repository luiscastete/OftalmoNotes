---
categoria: apuntes
area: retina-medica
emoji: 🩸
seccion: Ret Med y coroides
orden_seccion: 19
orden: 28
fuente: OneNote del Dr. Castilla Martí
---
# Distrofias hereditarias a ordenar con el resto

## 10. DISTROFIA EN PATRÓN

- **Definición**: Grupo heterogéneo de distrofias maculares hereditarias que afectan al EPR, con acumulación de **lipofuscina**.
- **Gen afectado**: Mutaciones en el gen **RDS / periferina**.
- **Patrón clínico**: Depósitos bilaterales amarillo-anaranjados a nivel de EPR.
- **Clasificación**:
  - Distrofia viteliforme del adulto
  - Distrofia en alas de mariposa
  - Distrofia reticular
  - Distrofia en patrón multifocal (puede simular Stargardt)
  - Fundus pulverulentus
- **Síntomas**: Asintomáticos o leve ↓ AV / metamorfopsias.
- **Edad**: 40–60 años.
- **Exploración**: AFG útil según patrón; EOG levemente reducido.
- **EBO Key**: Diagnóstico clínico por **patrón macular**, pensar en **RDS**, pueden simular Stargardt pero sin atrofia macular severa.

## 11. COROIDEREMIA

- **Definición**: Distrofia coriorretiniana **ligada al X**, con degeneración progresiva de coroides, EPR y fotorreceptores.
- **Gen afectado**: **CHM** (proteína REP1).
- **Epidemiología**: Varones jóvenes con **nictalopía precoz** y pérdida periférica progresiva. AV conservada hasta 5ª-6ª década.
- **Fondo de ojo**:
  - Atrofia coriorretiniana bilateral simétrica
  - Exposición escleral + vasos coroidales visibles
  - Comienzo ecuatorial → patrón centrípeto

- **Hallazgos adicionales**: Cataratas subcapsulares, edema macular, NVC.
- **Pruebas**:
  - OCT: aumento asintomático de espesor macular inicial → ↓ desde 4ª década.
  - ERG: ↓ escotópico precoz → ↓ fotópico tardío
  - AF: útil para seguimiento
- **Tratamiento**:
  - Terapia génica / células madre
  - Luteína ± Vitamina A (en estudio)
- **EBO Key**: Ligado a X + **patrón atrófico en “islas” con esclera visible** + **nictalopía en la infancia**.
