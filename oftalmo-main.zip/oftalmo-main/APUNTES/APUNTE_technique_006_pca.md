---
categoria: apuntes
area: general
emoji: 🛠️
seccion: Technique-Procedures
orden_seccion: 13
orden: 6
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-11-22
---
# PCA

PCA + mise en place LDC

+ examen 1h après PCA: sup temp normalement.

Add Floxal gtt 4xj pdt 2 + scopolamine 3xj ( diminution douleurs) + floxal pommade + pansement occlussif ce jour + scopolamine ce jour.

Add bilan:

- Cytomégalovirus PCR°
- Herpes simplex type 1 PCR°
- Herpes simplex type 2 PCR°
- Varicelle-Zoster PCR°
