---
categoria: apuntes
area: catarata
emoji: 🔍
seccion: Cristallin - Lens
orden_seccion: 21
orden: 11
fuente: OneNote del Dr. Castilla Martí
---
# Anatomia

## 📑Anatomía y fisiología celular del cristalino – Notas EBO

## 🔬1. Anatomía básica del cristalino

- **Cápsula**:
  - Membrana basal más gruesa del cuerpo humano.
  - Rodea completamente al cristalino.
  - Producida por células epiteliales del cristalino.
- **Epitelio subcapsular anterior**:
  - Monocapa de células cúbicas bajo la cápsula anterior.
  - Zona **germinativa en el ecuador** → células madre que originan fibras nuevas.
- **Fibras del cristalino**:
  - Células alargadas, sin núcleo ni organelos, llenas de proteínas cristalinas.
  - Forman la masa transparente del cristalino.

## 🔬2. Ciclo vital de las células del cristalino

- **Zona germinativa (ecuador)**
  - Las células epiteliales se dividen activamente.
  - Es el único lugar donde se producen nuevas células.
- **Diferenciación**
  - Estas células migran hacia la parte posterior y anterior del ecuador.
  - Se alargan → pierden núcleo y organelos → se convierten en **fibras del cristalino**.
- **Acumulación de capas**
  - Con el tiempo, las nuevas fibras se depositan en la periferia.
  - Las fibras más antiguas quedan comprimidas en el centro → forman el **núcleo del cristalino**.
  - Las más recientes forman la **corteza**.
