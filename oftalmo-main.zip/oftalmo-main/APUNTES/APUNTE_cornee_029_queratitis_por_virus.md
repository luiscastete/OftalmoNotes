---
categoria: apuntes
area: cornea
emoji: 👁️
seccion: Cornée
orden_seccion: 4
orden: 29
fuente: OneNote del Dr. Castilla Martí
---
# Queratitis por virus

## 🧬Queratitis vírica: Herpes simple y zóster

## 1. Virus del Herpes Simple (VHS)

## 🦠Generalidades

- VHS-1: infección más frecuente en cara, labios y ojos.
- VHS-2: herpes genital, pero también puede afectar al ojo.
- Causa más común de ceguera infecciosa en países desarrollados.
- 1/3 de la población sufre infecciones recurrentes.

## 🔄Tipos de infección

- **Primoinfección**: suele ser subclínica. Afecta a piel y mucosas inervadas por el trigémino.
- **Recurrente**: el virus queda latente en el ganglio trigémino. Reactivación por fiebre, estrés, trauma, luz UV...

## 👁️Formas clínicas oculares

## 1. Queratitis epitelial

- Asociada a replicación activa.
- **Síntomas**: malestar, fotofobia, lagrimeo, visión borrosa.
- **Signos**:
  - Queratitis epitelial puntiforme → dendrítica (ramificada con bulbos) → geográfica (si corticoides).
  - Tinción con fluoresceína (lecho) y rosa de Bengala (bordes).
  - Hipoestesia corneal.
- ❌ Corticoides contraindicados.
- ✅ Tratamiento: aciclovir 3% pomada o ganciclovir 0,15% gel 5x/día.

## 2. Queratitis estromal

- **Disciforme (no necrotizante)**:
  - Edema estromal central, precipitados retroqueráticos.
  - Reacción inmune vs antígenos virales.
- **Necrotizante**:
  - Replicación viral activa + respuesta inmune.
  - Opacificación, necrosis, vascularización, cicatrización.
- ✅ Tratamiento: corticoides tópicos + antivírico.

## 3. Endotelitis

- Inflamación endotelial.
- Edema estromal y epitelial + precipitados queráticos + iritis.
- Tipos: disciforme (más frecuente), lineal, difusa.
