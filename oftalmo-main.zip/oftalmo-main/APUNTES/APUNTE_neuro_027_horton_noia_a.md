---
categoria: apuntes
area: neuro
emoji: 🧠
seccion: Neuro-Ophta
orden_seccion: 8
orden: 27
fuente: OneNote del Dr. Castilla Martí
fecha: 2022-09-02
---
# HORTON / NOIA-A.

Infarctus de la tête du NO sur troubles circulatoires du réseau artériel ciliare posterieur avec perte de fonction visuelle , du à **une artérite gigantocellulliare(maladie de Horton )**

## Facteur disposantes

- >50a
- Polymialgie rheumathique
- Tabac
- BMI bas
- Femme 4:1 homme

## SYMPTOMES

- BAV souvent monoculaire. Profonde, brutale\*\*\*
- Deficit CV ipsilateral
- Anomalie vision des couleurs
- Antecedents:
  - amaurosis fugace
  - ou diplopie transitoire

## AA HORTON

Claudication de la mâchoire, céphales, douleur du scalp, scupalgies, perte de poids, sudations nocturnes, fatigue inhabituelle.

## SIGNES

Patients with NAION will typically have some or all of the signs of an optic neuropathy including decreased visual acuity, dyschromatopsia, an RAPD, a swollen optic nerve with splinter hemorrhages and a visual field defect. ( BASIC NOIA SIGNES, YOU PUT A NAME, THEN THE SURNAME)

## Ophtalmiques

- RAPD  (si atteinte asymetrique)
- BAV (on s'enfiche si ça touche le NO)
- Dyschromatopsie (altération vision des couleurs),
- attente du CV
- Contraste diminué
- Oedeme papillaire +++ EN AIGUIE
- papile pâle ++ uni ou Bilaterale ANCIENNE
- Diplopie
- Ischemie rétinienne concominante:
  - cotton wool spots,
  - OACR,
  - Oclussion artere cilio-retinien.
