---
categoria: apuntes
area: cornea
emoji: 👁️
seccion: Cornée
orden_seccion: 4
orden: 25
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-01-30
---
# Sécheresse oculaire

Insufissance lubrification de surface oculaire

## SYMPTOMES

Souvent bilat et chronique. Possible unilat aigue.

Brûlure ocualire qui péjore pdt la journée

Douleur, sensation CE, fatigue visuelle, prurit.

Photophobie

Larmoiment

Blépharosphasme

Baisse d'acuite visuelle, souvent intermitent.

Symptomes souvent disproportionnées avec les signes cliniques

Varient bcp d'une persone a une autre et sont influences par le type de personalite.

## FR

Age, status hormanal: grossese, ménopause, climatisation, chauffage, ventilation, climat aride ou venteux, fumée, poussiere, utilisation prolonge des yeux avec clignement inssufisant: utilisation écran, s/p operation cataracte, refractive.

## SIGNES

BUT< 10 sec

Menisque lacymal <0,5mm et irregulier – marginal tear meniscus (crude measure of the vol of aqueous in tear film) normal is 0.2-0.4mm - in dry eye is <0.25mm.

HC

KPS-kératite ponctiforme superficielle

KPS Confluants fluo + ---signes secheresse de longue terme

Filaments attaches à la surface cornéen

Blépharite ant ou post, conjoctivochalasis...

## ETIOLOGIES

## SJOGREN SYNDROME (SS)😉

- Autoimmune disorder charact by lymphocytic imnflammation and destruction of lacrimal and salivary glands and other exocrine organs.
- Classical clinical triad: 1- dry eye 2-dry mouth 3-parotid gland enlargement.
- \_\_\_
