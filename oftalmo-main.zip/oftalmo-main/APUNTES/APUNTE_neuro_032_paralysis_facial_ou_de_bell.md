---
categoria: apuntes
area: neuro
emoji: 🧠
seccion: Neuro-Ophta
orden_seccion: 8
orden: 32
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-03-09
---
# Paralysis Facial ou de Bell?!

Classification

| ***Grade*** | ***Description*** |
|---|---|
| **1** | Pas de parésie .Fonction motrice normale.Au repos, pas de déformation.Mouvements actifs normaux. |
| **2** | Parésie légère.Fonction motrice : faiblesse / syncinésie uniquement à l'examen attentif.Au repos, pas de déformation.Mouvements actifs : frontaux diminués, fermeture des paupières presque normale, de la bouche très diminués. |
| **3** | Parésie modérée.Fonction motrice : différence manifeste par rapport à l'autre coté, syncinésie, contracture.Au repos, pas de déformation.Mouvements actifs : frontaux encore présents, fermeture des paupières totale à l'effort maximum, de la bouche diminués. |
| **4** | Parésie moyenne.Fonction motrice : asymétrie défigurante.Au repos, pas de déformation.Mouvements actifs : frontaux absents, fermeture des paupières incomplète, de la bouche asymétriques. |
| **5** | Parésie marquée.Fonction motrice : quelques mouvements résiduels visibles.Au repos : asymétrie (ptose de la commissure labiale, pli nasolabial effacé).Mouvements actifs : frontaux absents, fermeture des paupières incomplète, de la bouche asymétriques. |
| **6** | Paralysie complète.Fonction motrice : aucun mouvement.Au repos : atonieMouvements actifs : aucun |
