---
categoria: apuntes
area: retina-medica
emoji: 🩸
seccion: Ret Med y coroides
orden_seccion: 19
orden: 29
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-08-10
---
# CHRPE

**Congenital hypertrophy of the retinal pigment epithelium (CHRPE)** is a typically benign, asymptomatic, pigmented fundus lesion. It is a congenital hamartoma of the retinal pigment epithelium (RPE) and occurs in three variant forms:

- solitary (unifocal),
- grouped (multifocal) and
- atypical.

Atypical CHRPE is associated with familial adenomatous polyposis (FAP), an autosomal dominant cancer syndrome, characterized by numerous adenomatous polyps of the colon and rectum. Left untreated, virtually all FAP patients develop colorectal carcinoma/s by middle age. FAP sub-types, including Gardner syndrome (FAP plus skeletal hamartomas and various soft tissue tumors) and Turcot syndrome (FAP plus various brain tumors) are also associated with atypical CHRPE.

## Epidemiology

The prevalence of CHRPE in the general optometric population has been estimated to be 1.2%.

## Risk Factors

Atypical CHRPE is the earliest and most common extra-colonic manifestation of FAP, present in up to 90% of patients.
