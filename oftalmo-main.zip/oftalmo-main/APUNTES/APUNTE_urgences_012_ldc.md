---
categoria: apuntes
area: urgencias
emoji: 🚑
seccion: URGENCES---TRAUMATOLOGIE
orden_seccion: 2
orden: 12
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-01-28
---
# LDC

COMPLICATION LDC

## CLARE syndrome: Contact lens-induced acute red eye

Bringing Clarity to CLARE (reviewofcontactlenses.com)

**Signs and Symptoms**CLARE is typically characterized by sudden onset of unilateral eye pain, photophobia, epiphora and ocular irritation. Accompanying slit lamp signs include diffuse conjunctival and limbal hyperemia, as well as the presence of multiple corneal epithelial and subepithelial infiltrates. The infiltrative reaction is generally located in the corneal periphery and mid-periphery; when sodium fluorescein stain is instilled in the eye, the infiltrative areas do not typically exhibit overlying punctate staining, indicating minimal epithelial involvement.3,4 In more severe cases of CLARE, corneal edema or anterior uveitis may also be present, although these signs are not common.1,2 Visual acuity is usually unaffected.

## TTT

## Simple

STOP LDC

Add Optava 3-5xj + Viscotears le soir 1xj

## Si peu claire si CLARE vs Kératitis

Add floxal gtt 3xj 5j + ttt simple

PC dans 5-7j et add FML ou DX schema degressif

## Autre option est

Add FML-Neo direct
