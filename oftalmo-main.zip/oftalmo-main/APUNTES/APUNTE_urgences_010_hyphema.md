---
categoria: apuntes
area: urgencias
emoji: 🚑
seccion: URGENCES---TRAUMATOLOGIE
orden_seccion: 2
orden: 10
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-08-12
---
# Hyphema

Hyphema: présence de cellules sanguines sédimentées dans la CA- visble à l'oeil un.

Microhyphéma: présence d'érythrocytes en suspension dans la CA, uniquementvisible à la LAF.

## SYMPTOMES

BAV

Douleurs

Rougeur oculaire

Photophobie

## SIGNES

Cellules sanguines sédimentes formant un niveau visible vs cellules sanguines en suspension ( peuvent sédimnter et former un niveau par la suite)

+/- Caillot sanguin

Autres signes en fonction de l'étiologie

## ETIOLOGIES

- Traumatisme ( chercher si cataracte traumatique, iridodialise...)
- Chirurgie intra-oculaire
- Traitements antiagregants ou anticoagulants
- Troubles de la crase
- Rubéosis
- Tumeurs ( mélanome, rétinoblastome...)
- Xanthogranulome juvénile
- Vascular Tufts congénital irien.

## STATUS

Exclure une perforation oculaire\*\*

AV-TIO

Éversion des paupieres

LAF: mesure verticale de l'hyphema, caillot de sang?

Hertel

oculomotricite

FO dilate ( si possible)

\*\*Faire tjrs Gonio pour chercher si sang en angle- pour faire attention si risk HTIO dans les prochaines jours\*\*

## STADE

- Stade 0: Mycrohyphéma
- Stade 1: <1/3 CA
- Stade 2: 1/3 à ½ CA
- Stade 3: >½ CA
- Stade 4: toute la CA

## BILAN

- USB: si FO non visualisable
- UBM: évaluation les estructures de l'angle.
- CT-Scan orbitaire et cérébral: si trauma avec perte de connaisance ou suspicion fracture orbitaire.
- Bilan laboratoire selon clinique: frottis sanguin et électrophoreses des proteines pour exclure la drepanocytose.

## TTT

1.Repos pdt 1-2 sem ( pas activite physique, pas porte de charges lourdes, avec tête suréleve 30° +/- coque protectrice. Reprise de activite normal après resoluction totale hyphema.

2.Si possible, interrompe la prise d'antiagregants et antocoagulants à discuter avec MT.

3.Cycloplegie:

- Scopolamine 0.25% 3xj jusqua résolution

4.Corticoides topiques: évidence non prouvée

- Predforte/Dexafree 4xj à 1x/h initialment, puis schéma dégressif en fonction de l'améliortaion des signes cliniques ( en prencipe, à garder tant que persistancede cellules saguines en CA)

5.si HTIO: Traité > 30mmHg:

- Cosopt 2xj ( bbloq/IAC )
- Si insuffisant, ajout: Iopidine 3xj (alpha agoniste)
- Si inssufisant ajout Diamox 500mg 2xj ( IAC systemique)
- Si inssufisant ajout: Mannitol.

- A éviter:
  - 1.Myotiques, protanglandines: possible péjoration d'inflammation.
  - 2.Alph-agoniste chez enfants <2ans

- **REMARQUE:**
- HTIO secondaire à l'obstruction de trabeculum par les cellules sanguines.
- Si drépanocytose: Traite HTIO > 24mmHg: éviter les IAC et diuretiques ( risque de déclencher une crise falciforme)

## INDICATION CHIRURGICALE

## Lavage de CA si

Hématocornée

Hyphema >50% aprés 1 sem ( but: prevenir la formation de synechies anterieurs)

HTIO non controlé

Enfant à risque d'amblyopie

NB: Environ 5% des patients avec hyphéma traumatique nécessitnmet une prise en charge chirurgicale.

## SUIVI

Hospitalisation si nécessaire

Suivi initial:

Hyphema: journalier pdt les 5 premiers jours (risque e recurrence surtout dans les 5-10 j)

Microhyphema: j3-5

Instruction aux patient: consulter en urgence en cas de nouvelle BAV ou péjoration des douleurs

Suivi 1xj/semaine jusquau résolution

Si post-trauma: suivi 4 sem pour Gonio + FO dilaté

\*\*\*Selon Sara: rdv à 24h pour suivi PIO vite fait si même 1+ cellules.\*\*\*
