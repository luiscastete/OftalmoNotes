---
categoria: apuntes
area: pediatria
emoji: 🧸
seccion: Pediatrie
orden_seccion: 9
orden: 7
fuente: OneNote del Dr. Castilla Martí
---
# Controle de base Enfante

En un niño que acude a consulta de rutina por control oftalmológico, los **exámenes básicos esenciales** incluyen:

🔍 **1. Agudeza visual monocular (lejos y cerca):**

👀 **2. Motilidad ocular extrínseca:**

👁️‍🗨️ **3. Cover test (cerca y lejos):**

🧠 **4. Estereopsis:**

🔦 **5. Reflexión corneal (Hirschberg y Krimsky si es necesario):**

📸 **6. Reflexión roja y prueba de Brückner:**

🕶️ **7. Refracción objetiva:**
