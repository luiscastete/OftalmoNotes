---
categoria: apuntes
area: glaucoma
emoji: 🟢
seccion: Glaucome
orden_seccion: 5
orden: 19
fuente: OneNote del Dr. Castilla Martí
---
# Glaucoma maligno (aqueous misdirection)

## 🔬Glaucoma maligno (aqueous misdirection)

- Es una complicación rara, generalmente **post-quirúrgica** (ej. trabeculectomía, cirugía de catarata, vitrectomía).
- Mecanismo:
  - El **humor acuoso es desviado hacia el vítreo**, en lugar de fluir hacia cámara anterior.
  - Esto hace que el vítreo anterior se hidrate → aumenta volumen → empuja todo el diafragma irido-cristalino hacia adelante.
  - Resultado: **cámara anterior muy estrecha/colapsada** + **PIO elevada**, a pesar de un ángulo abierto previamente.

## 📊Rol de los procesos ciliares

- Se cree que los **procesos ciliares rotan hacia adelante contra el cristalino o cápsula anterior**.
- Este contacto forma una especie de “sello” que **desvía el humor acuoso hacia el vítreo** en lugar de hacia la pupila.
- Es un mecanismo **sin pupillary block**, distinto al iris bombé.
