---
categoria: apuntes
area: glaucoma
emoji: 🟢
seccion: Glaucome
orden_seccion: 5
orden: 7
fuente: OneNote del Dr. Castilla Martí
fecha: 2024-06-06
---
# Examen BARN et ISNT

BANR en el contexto de la exploración clínica del nervio óptico (NO) mediante lámpara de hendidura se refiere a "Border, Area, Notching, Rim". Este es un enfoque sistemático para evaluar el disco óptico y la proporción copa/disco (cup-to-disc ratio, C/D ratio) cuando se sospecha de patologías como el glaucoma o neuropatías ópticas.

- **B (Border) – Borde:**

Se evalúa la nitidez del borde del nervio óptico. En condiciones normales, los márgenes del disco óptico son nítidos y bien delimitados.

Borde difuso o borroso puede indicar edema de papila o procesos inflamatorios como neuritis óptica.

- **A (Area) – Área:**

Se refiere a la proporción entre la copa y el disco (C/D ratio). Una C/D ratio normal suele estar alrededor de 0.3 a 0.4.

Una C/D ratio aumentada (por ejemplo, > 0.6) puede sugerir glaucoma u otros procesos que causan pérdida de fibras nerviosas.

- **N (Notching) – Escotadura:**

Se refiere a la presencia de una escotadura focal en el anillo neurorretiniano, generalmente asociada con la pérdida de fibras nerviosas glaucomatosa.

La escotadura puede afectar el borde inferior o superior, común en el glaucoma primario de ángulo abierto.

- **R (Rim) – Anillo neurorretiniano:**

Se evalúa el espesor del anillo neurorretiniano, que debería seguir la regla ISNT (el grosor del anillo debe ser mayor en el inferior, seguido del superior, luego nasal, y finalmente temporal).

Un adelgazamiento del anillo neurorretiniano, especialmente en las porciones inferior o superior, puede ser un signo temprano de glaucoma.

Proporción C/D en la práctica clínica:

Normal: Una relación copa/disco menor de 0.4 generalmente se considera dentro de los límites normales, con márgenes del disco bien definidos.

Anormal: Una C/D ratio mayor de 0.6, asimetría entre los ojos (> 0.2 de diferencia), o la presencia de notching son signos preocupantes que podrían sugerir glaucoma o pérdida de fibras del nervio óptico.
