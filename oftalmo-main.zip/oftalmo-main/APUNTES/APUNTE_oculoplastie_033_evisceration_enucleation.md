---
categoria: apuntes
area: oculoplastica
emoji: 🫥
seccion: Oculo-Plastie
orden_seccion: 3
orden: 33
fuente: OneNote del Dr. Castilla Martí
fecha: 2024-08-09
---
# Evisceration/Enucleation

Eviscération / énucléation - institut ophtalmologique Sourdille Atlantique (sourdille-atlantique.fr)
