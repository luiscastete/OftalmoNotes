---
categoria: apuntes
area: uveitis
emoji: 🔥
seccion: Immuno-infectio
orden_seccion: 7
orden: 30
fuente: OneNote del Dr. Castilla Martí
---
# lecture Lunch immuno

Imprimer les articles.

Mini review. Vaut la peine.

SIDA

- Chiffre Cd4?
- Ttt?
- Etat immunology
- Attention pick de citokines sndr inflamm.
- Attention sindrome re immuno.

- Attention immunodeprime:
- Curiosite
- Si drogue veneuse: chercher mycose en oeil.
- Si sex moins risk.

- Attention ZONA monstruo se poser la question si HIV +.

- Quand tu donnes un bol de surdomedrol. Tu enleves tout inmmunite pendant 3j.
- Aatention pas doner bolus en cas pas claire. Attention virus + bolus : Necrose rétinienne aigue.

- 3 maladies infect que tu peux perdre la vision en 24-48h :
- Behcet
- Necrose retinite aigue
- Endophtalmie

Vitre en enfants très fortement fixe. Attention VPP  car provoques des dechirures par tout! Attention enfants et jeunes avec vitré.

Plus la immunodepressiô est forte. Plus de choses bizarres qui arrive.

Nécrose rétinienne aiguë:
