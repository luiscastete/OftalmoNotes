---
categoria: apuntes
area: oculoplastica
emoji: 🫥
seccion: Oculo-Plastie
orden_seccion: 3
orden: 28
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-01-13
---
# Eczéma palpebrale

eczéma palpébrale bilatérale d'origine indéterminé

att:

-Dans les 2 yeux

Zaditen gtt 2xj

Optava au besoin

Ultracortenol pommade 3xj 1 sem puis 2xj 1 sem puis qxj 1 sem et stop

Viscotears gel le soir 3 mois

-PC dans 1 mois

-recommandation consulter dermatologue
