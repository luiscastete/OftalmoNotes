---
categoria: apuntes
area: oculoplastica
emoji: 🫥
seccion: Oculo-Plastie
orden_seccion: 3
orden: 6
fuente: OneNote del Dr. Castilla Martí
---
# Blépharospasme / fasciculations palpebrales idiopatiques

Blépharospasme essentiel beginge - benign essential blepharospasm (BEB)

Blepharospasm (Eyelid Twitching): Causes, Symptoms, and Treatment (patient.info)

Blépharospasme

Secondaire? A des troubles de surface?

Mioquimie palpebrale

Att:

Diminution consomation caffeine

Amélioration qualite du sommeil

Controle de estrés

Add complement alimentaire magnesium 250-400mg par jour + VITAMIN b12
