---
categoria: apuntes
area: retina-quirurgica
emoji: 🪡
seccion: Ret Chirg
orden_seccion: 6
orden: 15
fuente: OneNote del Dr. Castilla Martí
---
# Melanoma

Tt de base: Proton thérapie. Irradiation localise très precise.

Bon résultat mais bcp des complications.

L’objectif du chirurgien est éviter les complications plus graves.

Ischemie+ Inflammation : toxic tumeur syndrome.
