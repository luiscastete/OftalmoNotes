---
categoria: apuntes
area: cornea
emoji: 👁️
seccion: Cornée
orden_seccion: 4
orden: 9
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-10-11
---
# K. Amibienne Acanthamoeba

## CL wearer (70% times) + EXTREM PAIN

## EARLY STAGES

## Punctate keratopathy with limbitis

**Epithelial + subepithelial infiltrates + perineural infiltrates\*\*\*\*-PATHOGNOMIQUE NEARLY!**

## LATTER STAGES

## Anular infiltrates

## Ulceration

## Ant uveitis

## Hypopion

## Dx

## Confoscan microscopy

**Frottis + examen direct avec tincions + cultures classique complet. + PCR + antibiogram/antifungique.**

## AMBULATOIRE

-DEBRIDEMENT OF EPITHELIUM

## -PHMB 0'2% UDS

1xh pdt 7j puis

1xh2h pdt 7j puis

4xj pdt 2-4 mois

## -Désomedine 0,1% UD

1xh pdt 48h

4xj pdt 2-4 mois
