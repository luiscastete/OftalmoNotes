---
categoria: apuntes
area: general
emoji: 💊
seccion: Pharmacologie Farma
orden_seccion: 23
orden: 2
fuente: OneNote del Dr. Castilla Martí
---
# Tetraciclines - doxiciclina

| **Mecanismo** | **Descripción** | **Aplicaciones oftalmológicas** |
|---|---|---|
| Inhibición de metaloproteinasas de matriz (MMPs) | Inhibe MMP-2 y MMP-9 → preserva matriz extracelular y tejido corneal | Úlceras corneales, queratitis periférica estéril |
| Disminución de citocinas inflamatorias | Reduce la liberación de IL-1, IL-6, TNF-α → menos inflamación | Rosácea ocular, conjuntivitis crónica |
| Reducción de la quimiotaxis de neutrófilos | Disminuye la migración de neutrófilos → menos daño tisular | Blefaritis, queratitis marginal |
| Estabilización del meibum (glándulas de Meibomio) | Mejora la calidad del lípido secretado → reduce obstrucción e inflamación | Disfunción de glándulas de Meibomio |
| Inhibición de fosfolipasa A2 e iNOS | Disminuye producción de prostaglandinas y óxido nítrico → menor respuesta inflamatoria | Rosácea ocular, úlceras inflamatorias crónicas |

Las **tetraciclinas** son un grupo de **antibióticos de amplio espectro** que se utilizan para tratar una variedad de infecciones bacterianas. Aquí te explico su funcionamiento, clasificación y usos:

## 🧬¿Qué son las tetraciclinas?

Las tetraciclinas son antibióticos **bacteriostáticos**, lo que significa que **inhiben el crecimiento** de las bacterias pero no las matan directamente. Se obtuvieron originalmente de *Streptomyces spp.* aunque ahora suelen ser sintéticas o semisintéticas.
