---
categoria: apuntes
area: cornea
emoji: 💧
seccion: Conj + Episclere + Sclere
orden_seccion: 25
orden: 9
fuente: OneNote del Dr. Castilla Martí
---
# Acné rosácea /  Dermatitis atópica

## 3.5. Otros síndromes mucocutáneos

## 3.5.1. Acné rosácea

## Definición

Dermatosis idiopática crónica que afecta piel facial (zonas expuestas al sol) y, en un 50%, los ojos.

## Patogenia

- Desconocida, pero se relaciona con:
  - Sobreexpresión de **catelicidinas**, que inducen inflamación.
  - Presencia de **Demodex folliculorum**, ácaro que puede actuar como desencadenante inflamatorio.

## Epidemiología

- Edad media: 30-60 años.
- Ligera predominancia femenina.
- Factores desencadenantes: alcohol, comidas picantes, estrés, alteraciones hormonales, exposición solar.

## Manifestaciones clínicas

- **Cutáneas**:
  - Eritema facial (frente, nariz, mejillas, mentón), pápulas, pústulas, telangiectasias.
  - No hay comedones (diferencia con acné vulgar).
  - **Rinofima** en varones (hipertrofia glándulas sebáceas).
- **Oftalmológicas** (50%):
  - **Párpados**: blefaritis crónica, disfunción de glándulas de Meibomio, telangiectasias en el borde palpebral, chalazión de repetición.
  - **Conjuntiva**: hiperemia interpalpebral, conjuntivitis crónica/cicatricial.
  - **Córnea**:
    - Queratitis punteada superficial.
    - Infiltrados marginales estériles.
    - Ulceración, adelgazamiento, pannus inferior, neovascularización.
    - **Queratitis pseudodendrítica**, incluso bilateral (DD con VHS).
  - **Otros**: epiescleritis, iridociclitis.
