---
categoria: apuntes
area: neuro
emoji: 🧠
seccion: Neuro-Ophta
orden_seccion: 8
orden: 10
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-08-12
---
# Anisocorie

L'anisocorie se définit par une différence de taille entre les deux pupilles. Une des deux pupilles est atteinte, elle est soit en mydriase, soit en myosis.

Les causes conduisant à ce trouble sont diverses, allant de l'anisocorie physiologique bénigne jusqu'à des troubles neurologiques graves. Sa présence nécessite donc un avis médical systématique.

Le chanteur anglais David Bowie était atteint de ce trouble

## MECANISMES

- Ophtalmologique
- Physiologique essentielle
- Neurologique
- pharmacologique

## STATUS

- Mesure du diametre pupillaire en condition scotopique (sans lumiere) et photopique (lumiere)
- Mesure fentes palpebrale avec metre ( difference jusqua 1mm >1mm )
- Examen fentes palpebrales et oculomotilité
- Examen LAF
- Test pharmacologique si besoin

- **Anisocorie plus marqué en photophique (lumière)**
- **La grande pupille se contacte moins bien**

- **Traumatisme du sphinter irien.**
- Lesion visible à LAF: déchirures, synechies, atrophie, transilumination.

- **Atteinte parasympatique:**

- **2.1-Pupille tonique d'Adie**
  - Parésie sectorielle irienne <8 sem:
    - Light-near dissociation ( reinnervation aberrante).
    - Myosis avec pilocarpine 0.125% ( hypersensibilité de dénervation)

- **2.2.Parésie du NC III**
  - Ptosis palpébral
  - Troubles oculomoteurs
  - Mauvauis réflexe accomodatif.
  - Myosis avec pilocarpine 2%
  - Chronique: myosis avec pilocarpine 0.125% ( hypersensibilité de dénervation)

- **Mydriase pharmacologique**
- Aucune réaction pupillaire: Lumière, accommodation, pilocarpine 2%.

  - **Anisocorie plus marqué en scotopique ( lumière de nuit)**
  - **La grande pupille se contacte moins bien**

- 1.Synechies irido-cristallienes
- Examen LAF

- **SYNDROME DE CLAUDE BERNAND HORNER**

- Associe au myosis:
- Ptosis palpebral >1-2mm
- Ptosis palpebrale inf inverse 1mm
- Anhydrose.
  - Test cocaine 10% positif ( augmentation anisocorie) \* test à la cocaine: utilisable à tout age des la naissance.

  - Test apraclonidine (iopidine) positif ( diminution ou inversion anisocorie et/ou ptosis) \*\* test à l'apraclonidine: contre-indique aux enfants < 2ans car risque de dépression respiratoire.

  - 2.1.Central/pré-ganglionnaire
  - Anhydrose +/- couvrant l'hémiface

  - 2.2.Post-ganglionnaire
  - Anhydrose +/- sus-sourciellière

- **Myosis pharmacologique**
- Myosis serré

- **Anisocorie physiologique**
- Absence de retard de dilatation de la petite pupille.
- Tests pharmacologique nég.
