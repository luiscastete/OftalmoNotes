---
categoria: apuntes
area: oculoplastica
emoji: 🫥
seccion: Oculo-Plastie
orden_seccion: 3
orden: 22
fuente: OneNote del Dr. Castilla Martí
---
# ANATOMÍA

## 🧠ANATOMÍA FUNCIONAL DEL PÁRPADO

## (Con nombres claros, funciones, inervación y correlación clínica)

## 🧩FUNCIONES PRINCIPALES DEL PÁRPADO

- Protección de la superficie ocular
- Distribución y estabilización de la película lagrimal
- Expresión facial
- Drenaje lagrimal
- Cierre reflejo frente a estímulos

## 🔷1. COMPONENTES MUSCULARES DEL PÁRPADO

## 🔸Músculo orbicular del ojo

- **Ubicación**: Subcutáneo, rodea el ojo en forma de anillo.
- **Inervación**: Nervio **facial (VII par)**
- **Funciones**:
  - Cierre palpebral:
    - **Porción palpebral** → parpadeo suave
    - **Porción orbitaria** → cierre forzado
    - **Porción lacrimal (de Horner)** → bombeo del sistema lagrimal
- **Patología**:
  - Parálisis del VII → lagoftalmos, epífora, queratitis por exposición

## 🔸Músculo elevador del párpado superior

- **Ubicación**: Se origina en el techo orbitario y se inserta en el tarso superior por su aponeurosis.
- **Inervación**: Nervio **oculomotor (III par)**
- **Función**: **Elevar activamente el párpado superior (~10-12 mm)**
- **Patología**:
  - Parálisis del III → **ptosis completa**, ojo en infraducción/abducción

## 🔸Músculo tarsal superior (de Müller)

- **Ubicación**: Músculo **liso**, nace en el elevador y se inserta en el borde superior del tarso
- **Inervación**: **Simpática**
- **Función**: Aporta **tono basal adicional** (~2 mm de elevación)
- **Patología**:
  - Lesión simpática (síndrome de Horner) → **ptosis leve**

**Nota**: Su equivalente en el párpado inferior (músculo tarsal inferior) también mantiene el tono, pero tiene menos relevancia clínica.

## 🧱2. ESTRUCTURAS DE SOPORTE PALPEBRAL

## 🔹Tarso palpebral = “el esqueleto del párpado”

- **Ubicación**: Parte posterior del párpado, entre el músculo orbicular (adelante) y la conjuntiva (atrás).
- **Función**:
  - Da **forma, rigidez y soporte** al párpado.
  - Punto de anclaje para:
    - **Aponeurosis del elevador**
    - **Músculo de Müller**
  - Contiene las **glándulas de Meibomio** (secreción lipídica lagrimal)
- **Importancia quirúrgica**:
  - Se usa como punto de fijación en cirugía de ptosis o tarsorrafias
  - Su integridad es clave en reconstrucciones palpebrales

## 🔹Tabique orbitario (también llamadosepto orbitario)

- **Ubicación**: Membrana fibrosa que va desde el **reborde orbitario** hasta:
  - El **tarso inferior**, en el párpado inferior
  - La **aponeurosis del elevador**, en el párpado superior
- **Función**:
  - Actúa como **barrera anatómica** entre el contenido orbitario y el párpado
  - **Contiene la grasa preaponeurótica**
- **Clínica**:
  - Si se debilita con la edad → herniación de grasa (bolsas)
  - Punto clave en **blefaroplastia** (se atraviesa para manipular grasa)
  - Límite anatómico entre **celulitis preseptal vs. orbitaria**

## 🔩3. LIGAMENTOS PALPEBRALES: CANTAL MEDIAL Y LATERAL

## 🔸Ligamento cantal medial

- **Ubicación**: Desde los extremos mediales de los tarsos al **hueso maxilar (reborde medial de la órbita)**
- **División**:
  - Porción **anterior**: se inserta en la cresta lagrimal anterior
  - Porción **posterior**: se inserta en la cresta lagrimal posterior
- **Función**:
  - Mantiene el **anclaje medial del párpado**
  - Rodea la **saco lagrimal**, esencial para la bomba lagrimal
- **Importancia clínica**:
  - Lesionado en trauma → telecanto, epífora
  - Es reposicionado en cirugías reconstructivas y de ectropión/entropión

## 🔸Ligamento cantal lateral

- **Ubicación**: Desde la unión de los tarsos al **reborde orbitario lateral** (fosa lagrimal lateral)
- **Función**:
  - Mantiene la **posición horizontal del párpado**
  - Define la **tensión y ángulo del canto lateral**
- **Importancia quirúrgica**:
  - Se manipula en **canthoplastias** o **canthopexias**
  - Clave en el tratamiento de **retracción palpebral**, **ectropión** y **síndrome de malposición palpebral postquirúrgico**

## 🔄INTEGRACIÓN FUNCIONAL

| **Estructura** | **Inervación** | **Función** | **Clínica si se altera** |
|---|---|---|---|
| Orbicular | Facial (VII) | Cierre palpebral | Lagoftalmos, exposición |
| Elevador | Oculomotor (III) | Apertura activa | Ptosis completa |
| Müller | Simpático | Tono basal palpebral | Ptosis leve (Horner) |
| Tarso | – | Soporte estructural | Entropión, ectropión |
| Tabique orbitario | – | Barrera y contención | Bolsas, celulitis orbitarias |
| Lig. cantal medial | – | Estabilidad medial, drenaje lagrimal | Telecanto, epífora |
| Lig. cantal lateral | – | Estabilidad lateral | Malposición palpebral |

## 🧪CLAVES CLÍNICAS Y QUIRÚRGICAS

- La **ptosis** puede ser:
  - **Neurogénica (III par o simpático)**
  - **Miogénica (miopatías, miastenia)**
  - **Aponeurótica (edad, desinserción del elevador)**
  - **Mecánica (masas, edema)**
- En blefaroplastia, la preservación del **tabique orbitario** y del **ligamento cantal lateral** es fundamental para evitar malposición postoperatoria.
- En trauma facial, la **avulsión del ligamento cantal medial** es una causa frecuente de **telecanto traumático**, que requiere reconstrucción anatómica precisa.
