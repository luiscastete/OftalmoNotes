---
categoria: apuntes
area: uveitis
emoji: 🔥
seccion: Immuno-infectio
orden_seccion: 7
orden: 11
fuente: OneNote del Dr. Castilla Martí
---
# HLA

El **HLA (Human Leukocyte Antigen)** es un complejo de genes que codifica las proteínas del **Complejo Mayor de Histocompatibilidad (MHC)** en humanos. Estas proteínas están en la superficie de la mayoría de las células y cumplen una función clave en la **presentación de antígenos al sistema inmunológico**, particularmente a los linfocitos T.

## ¿Por qué es importante en uveítis?

- **Predisposición genética**: Ciertos alelos del HLA están fuertemente asociados con enfermedades autoinmunes o autoinflamatorias que cursan con uveítis. Por ejemplo:
  - **HLA-B27**: asociado a uveítis anterior aguda recurrente, y enfermedades como espondilitis anquilosante, artritis reactiva, etc.
  - **HLA-A29**: relacionado casi exclusivamente con **coriorretinopatía de tipo birdshot**.
  - **HLA-B51**: fuertemente asociado con **enfermedad de Behçet**, que incluye uveítis panuveítica y vasculitis retiniana.
  - **HLA-DR15 (DR2)**: relacionado con **neuromielitis óptica y esclerosis múltiple** que pueden incluir neuritis óptica y uveítis intermediaria.
- **Mecanismo inmunológico**: Los alelos del HLA influyen en cómo se presentan los antígenos endógenos o exógenos al sistema inmunológico. Algunas variantes presentan epítopos propios de manera aberrante o ineficaz, lo que contribuye a la autoinmunidad o a respuestas inflamatorias descontroladas.

## ¿Por qué hay tantos subtipos relacionados con enfermedades?

- El sistema HLA es **altamente polimórfico**: existen cientos de variantes para cada gen (por ejemplo, más de 1000 alelos de HLA-B).
- Esta diversidad tiene un valor evolutivo porque permite una mayor capacidad para reconocer distintos patógenos, pero también implica que ciertos alelos predisponen a **respuestas inmunes anómalas** frente a autoantígenos o antígenos ambientales.
- Las **asociaciones HLA-enfermedad** son el resultado de coevolución entre el sistema inmune humano y el entorno microbiano, además de factores epigenéticos.
