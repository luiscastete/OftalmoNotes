---
categoria: apuntes
area: glaucoma
emoji: 🟢
seccion: Glaucome
orden_seccion: 5
orden: 4
fuente: OneNote del Dr. Castilla Martí
---
# HTIO (>21mmHg) Ocular Hypertension

3 criteres pour decider si traiter HTIO sans glaucome ( NO et CV dans la norme)

-Age

-Pachy

-HTIO ( dépend si c’est 21 que 35)

+\\- Ant Fam glaucome

Suivre guide européen de glaucome

En internet grattos

Savoir que le dégât de RFNL on le voit à 4-6 mois dans les examens

\_\_\_\_\_\_\_\_

HTO – hypertension oculaire

Caract:

- PIO >21mmHg sans tt
- CV normale
- Papille et RFNL normale
- Gonioscopie: angle ouverte - exclure fermeture intermitente angle
- Aucune signe autre maladie oculaire ou steroides
- FR: aucune

RISK calculator

Risk Calculator | Ocular Hypertension Treatment Study (OHTS) | Washington University in St. Louis (wustl.edu)

TT:

Recomande si FR élevée de conversion à glaucome.

En generale proposer tt si vingtaine années avec PIO élevées meme sans FR.

Principes et choix tt seront semblables du GPAO.D'abord tt medicale ou trabeculoplastie au laser.

Suivi intervales 6 à 12 mois initialment si stable prolonger.
