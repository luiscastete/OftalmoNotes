---
categoria: apuntes
area: oculoplastica
emoji: 🫥
seccion: Oculo-Plastie
orden_seccion: 3
orden: 15
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-04-15
---
# DACRYOCYSTITE (sac lacrymal)

## DEFINITION

Inflamm du sac lacrymal, plus fréquement d'origine infectieuse bacterienne, résultatnt d'une obstruction du canal lacrymo-nasal (CLN) et de l'ostium interne du canalicule commun. Peut etre aiguie ou chronique.

## SYMP

Douleurs en dessous du ligament canthal médial ( LCM)

Larmoiment

## SIGNES

Tumefcation inflammatoire sous le LCM

Epiphora

Reflux au niveau des méats lacrymaux à la pression de la tumefaction

Fistule spontanée du sac lacrymal à la peau (rare)

## ETIOLOGIES

## Bactérienne

- **NOUVEAU-NE:** (en association avec obstruction congénitale du canal nasolacrymal): S.pneumoniae, Staph. Aureus, Hinfluenzae, S agalactiae.
- **ENFANTS/ADULTES:** Staph. Épidermidis, staph. Aureus.
- **ADULTES:** staph aureus, staph. Pneumoniae and pseudomonas aeruginosa.

## Inflammatoire

- inflammation ethmoidale, inflammations chroniques.
- Traumatique, post-chirugie orbitaire, post chirg ORL.
- Obstruction CLN par un kyste, tumeur du sac lacrymal, dacryolithes, infections répétées..

## STATUS

Status ophta: AV-TIO-LAF-FO

Status orbitopalpébral: Examen cutanée, Hertel, oculomotilité

## BILAN ET TT

## JAMAIS IRRIGATION DES VOIES LACRYMALES EN AIGU!!

Alteration état général?

Sévérelemt polymorbide?

Cellulite orbitaire?

Si OUI:----Hospitalisation

Si Non:--Ambulatoire

## HOSPITALISATION

Add CT Orbitaire

Prévelement bacteriologiques si secretios

Add tobradex collyre 1gtt 4xj

Add Antibiotherapie i.v.:

Adultes fiche cellulite orbitaire—Amox-clav 2.2g 3xj

Enfants amox clav 150mg/kg/j en 3xj ( dose maximal unitaire de 2g amox)

## Suivi 48h

Si évolution favorable: relais antibiotherapie à per os 10 j en total +  DCR à distance.

Si péjoration:

- Si collection: drainage chirurgicale
- Si pas collection: DCR aigue.

## AMBULATOIRE

Add tobradex gtt 1gtt 4xj pdt 7j

Antibiotherapie per os:

- **ADULTES:** amox –clav 875/125mg 2xj pdt 7-10J. Alternative si allergie: Bactrim forte 1x/12h ou clndamycine 600mg/8h.
- **ENFANTS:** Amox-clav, 80-90mg/kg/j, en 2 doses/j, pdt 7-10j ( dose maximal de 875mg d'amox par prise, ce qui correspode à la dose adult)

## Suivi 48h

Si péjoration----- add CT scanner orbite avec coups fines + cerebrale + add avis si drainage vs HOSPITALISATION

Si évolution favorable: continuer antibiotherapie per os 10j au total.

+/- DCR à distance
