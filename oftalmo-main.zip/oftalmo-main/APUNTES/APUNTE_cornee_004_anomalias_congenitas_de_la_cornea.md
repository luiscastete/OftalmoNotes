---
categoria: apuntes
area: cornea
emoji: 👁️
seccion: Cornée
orden_seccion: 4
orden: 4
fuente: OneNote del Dr. Castilla Martí
---
# Anomalías congénitas de la cornea

ANOMALIAS DE LA ESTRUCTURA O TRANSPARENCIA CORNEAL

Embriotoxon posterior

Esta afección implica la presencia de un anillo de Schwalbe (unión de la malla trabecular con la terminación de la membrana de Descemet) engrosado y con desplazamiento central y anterior, de forma que es visible en la exploración externa. Se hereda de forma dominante. El ojo, por lo demás, es normal.

El **embriotoxon posterior** es un hallazgo clínico caracterizado por una línea blanca o grisácea prominente en la periferia de la córnea, justo anterior a la inserción del endotelio y membrana de Descemet. Es visible durante una exploración con lámpara de hendidura y representa una **anomalía del desarrollo en la migración de las células de la cresta neural**.

## ¿Por qué es importante?

Aunque puede ser un hallazgo aislado y benigno en individuos sanos (hasta en un 15% de la población general), su presencia puede ser significativa por las siguientes razones:

1. **Asociación con síndromes sistémicos u oculares**:

• **Síndrome de Axenfeld-Rieger**: el embriotoxon posterior es una de sus características clave, acompañado de adherencias iridocorneales, hipoplasia del iris, y riesgo elevado de glaucoma.

• **Anomalía de Alagille**: trastorno hepático y multiorgánico asociado con embriotoxon posterior en más del 90% de los casos.

2. **Evaluación del ángulo iridocorneal**: Puede dificultar o indicar anomalías en el desarrollo del ángulo, lo cual es crucial en la evaluación de **glaucomas congénitos o del desarrollo**.
