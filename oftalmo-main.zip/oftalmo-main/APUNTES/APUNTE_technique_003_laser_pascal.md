---
categoria: apuntes
area: general
emoji: 🛠️
seccion: Technique-Procedures
orden_seccion: 13
orden: 3
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-03-10
---
# Laser PASCAL

Indications:

Photocoagulaton rétinniene déchirure rétinnien

Photocoag pan rétinnienne (PRP): si ischemie rétinniene étendue, néovascularisation rétinniene ou irienne, glaucome néovasculaire (RDP, OACR, OVCR, OBVR, syndrome ischemie ocualire)

Infos à doner au patient:

Complication de la PRP: érosions cornéens, décollement sereux rétinienn ou choroidienn, Oedeme maculaire cystoide, Hémorragie vitéenne.

Effects secondaire de l PRP: rétrécissement du CV, héméralopie et ébloiussement, BAV.

Complications du barrage laser d'une déchirure: érosions cornéenes, décollements de rétine ( delai cicatrisation des impacts du laser).

ATERIAL PREPARATION:

Dilatation pupillaire: Tropi + phénylephrine

Anesthesie local: oxybuprocaine

Gel: viscotears

| VERRE DE CONTACT | Coeficient de magnification du spot | Réglage taille du spot | Tailes réelles des impacts ret |
|---|---|---|---|
| V3m | X1.08 | 500 um | 500 um |
| Super squad 160<br>Retina 180 | X 2.0 | 250 um | 500 um |

## BARRAGE LASER DECHIRURE RET

Barrage circulaire 360° au tour déchirure

3 courons d'impacts contigus

Si trop péripherique: faire barrage en omega vers l'Ora serrata

## PRP

Commencer toujours en inf – car si saign – VH reste en inf et provoque pas BAV. ( recommendation ROBIN) si tu vas faire un 360°
