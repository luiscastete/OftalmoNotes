---
categoria: apuntes
area: neuro
emoji: 🧠
seccion: Neuro-Ophta
orden_seccion: 8
orden: 12
fuente: OneNote del Dr. Castilla Martí
---
# VF Defects Lesions

https://app.pulsenotes.com/specialities/ophthalmology/notes/Visual-Field-Defects

Junctional Scotoma

The union scotoma occurs at the level of the junction of the optic nerve with the chiasm, affecting the rpodilla of von Willebrand. This produces an ipsilateral central scotoma and a contralateral superior temporal scotoma. These scotomas are due to the decussation in the chiasm that the fibers coming from the lower nasal quadrant are decussated in the anterior portion of the chiasm, forming the lick von Willebrand's knee on the optic nerve. contralateral.
