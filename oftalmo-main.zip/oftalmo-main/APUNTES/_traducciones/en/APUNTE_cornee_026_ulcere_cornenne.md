---
categoria: apuntes
area: cornea
emoji: 👁️
seccion: Cornée
orden_seccion: 4
orden: 26
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-01-30
---
# horn ulcer

Epithelial erosion with corneal stroma involvement: It can be infected or sterile.

Symptoms

Signs

Aetiology

Examination

Treatment

Follow-up
