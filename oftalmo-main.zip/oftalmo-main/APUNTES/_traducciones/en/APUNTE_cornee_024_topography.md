---
categoria: apuntes
area: cornea
emoji: 👁️
seccion: Cornée
orden_seccion: 4
orden: 24
fuente: OneNote del Dr. Castilla Martí
fecha: 2024-02-07
---
# topography

Why use the mole?

- Determine the regularity and symmetry of the cornea to:
- DX OF CORNEAL PATHOLOGY
- Assess optical quality of the cornea

- Know your power to:
- Plan Indole or Refractive Target Surgery

with what?

MAPAS TOPGRAFICOS:

To determine the regularity and symmetry:

- 1.Curvature Maps (Placido Discs)
- 2.Lift Maps (Other Technologies Surface Analysis)

To know the corneal power:

- 3. Refractive maps – corneal power.

## 🔬

## Key Differences: Topography vs. Corneal tomography

| Feature | Corneal topography | Corneal tomography |
|---|---|---|
| What does it measure? | Corneal anterior surface curvature (relief, power) | Three-dimensional map of the thickness, anterior and posterior curvature of the cornea |
| used technology | Projection of Rings of Placido (Placido Disc) | ScheImpFlug scan, OCT or low coherence laser |
| evaluated areas | only anterior surface | Anterior surface + back + corneal thickness |
| generated maps | Axial power, tangential, previous elevation | Anterior/rear elevation, pachimetry, three-dimensional curvature maps |
| equipment examples | Keratograph, TMS, Medmont | pentacam, galilei, sirius, orbscan, casia (oct) |
| useful for | Astigmatism detection, initial keratoconus | Complete evaluation for keratoconus, ectasias, surgical planning |
| limitations | No posterior ectasia or peripheral tuning | more sensitive to early and pathological changes |
