---
categoria: apuntes
area: uveitis
emoji: 🔥
seccion: Immuno-infectio
orden_seccion: 7
orden: 24
fuente: OneNote del Dr. Castilla Martí
fecha: 2024-06-10
---
# Anamnese by systems

Here is a typical order used in many medical practices:

## general

- Fatigue
- Unintentional weight loss
- Fever, chills
- Night sweat

## Skin

- skin rashes
- Itching (itching)
- sores or ulcers
- Changes in moles

## head and neck

- headache
- Dizziness
- Neck Pain
- mass or swelling

## peepers

- vision disorders
- eye pain
- redness of the eyes
- secretions

## Ears, nose, throat (ent)

- tinnitus
- hearing loss
- Rhinorrhea (nasal discharge)
- Throat pain

## breathing apparatus

- Cough
- Dyspnea (respiratory difficulties)
- sputum (sputum)
- chest pain
