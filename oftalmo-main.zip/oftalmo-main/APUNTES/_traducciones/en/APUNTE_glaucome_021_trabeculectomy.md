---
categoria: apuntes
area: glaucoma
emoji: 🟢
seccion: Glaucome
orden_seccion: 5
orden: 21
fuente: OneNote del Dr. Castilla Martí
---
# trabeculectomy

## 📑Trabeculectomy – EBO notes

## 🔬 Definition

- Glaucoma surgery that consists of creating a fistula between the anterior chamber and the subconjunctival space to allow the exit of aqueous humor.
- Forms a filtration bleb (subconjunctival ampoule).
- Objective: To reduce IOP to prevent glaucomatous progression.

## 📊 Basic technique

- Conjunctival incision (Fornix or Limbus-based).
- Partial scleral flap (rectangular/triangular).
- Exeresis of a block of tissue at the angle (trabeculectomy “-ectomy” = resection).
- peripheral iridectomy.
- Partial closure of the scleral flap → Controlled exit from aqueous humor.
- conjunctival closure.

💊 Antimetabolites (MMC, 5-FU) are usually used to reduce healing.

## 👁️ Indications

- Open or closed angle glaucoma when medical treatment/laser insufficient.
- refractory secondary glaucomas (eg pseudo-exfoliative, pigmentary, inflammatory).
