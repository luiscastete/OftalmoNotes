---
categoria: apuntes
area: neuro
emoji: 🧠
seccion: Neuro-Ophta
orden_seccion: 8
orden: 5
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-09-05
---
# Examination

## Related System: Function

AV

Ishihara

Student: ISO-ISO, RAPD?

Amsler grid

CV by confrontation + interpretation exams

## Efferent system: Structure

FO: NO

OCT

## Efferent system: Engine

Fixation: stable or unstable

Tyroles: Fast-Precise vs Slow-Imprecise

Chase: Lise vs No Lise

Vestibulo-occular reflex:

Convergence

ANICARY
