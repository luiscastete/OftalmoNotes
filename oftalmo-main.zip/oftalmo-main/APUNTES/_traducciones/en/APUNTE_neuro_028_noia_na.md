---
categoria: apuntes
area: neuro
emoji: 🧠
seccion: Neuro-Ophta
orden_seccion: 8
orden: 28
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-02-10
---
# NOIA-NA

Neuropathie optique ischemique anterieur- Non arteritique

Infarctus de la tete de NO sur trouble circulatoire de reseau arteriel ciliare posterieur court resultant en perte fonction, d'origine non inflammatoire.

## FR predisposants

-Disk at risk:

- C/D <0.1, drusen papillaires, hypoplasie

-FR cardiovasculaire:

- HTA, Hypercholesterolemie, obésité, tabagisme, DM, SAOS.

## Symptoms

BAV monoculaire d'apparition brutale, pouvant se péjorer sur qqs semaines

Déficit de CV ipsilateral

- Souvents altitudinal inf
- Nearly 25% of patients will have central scotomas but the majority of patients will have an altitudinal field loss, inferior being most common[62].

No pain, no transitory diplopia

## Anamneses de maladie Horton: nég TOUJOURS FAIRE!!

## Signs

Présents:

- RAPD
- Dyschromatopsia and CV involvement
- Oedeme papillaire unilat +/- sectoriel------------------------------------------------------------------------
- Flammer peripapillary bleeding
- Disk at risk dans oeil contralat. C/D: 0 or 0.1

Absents

- Other neurological signs: Oculomotricity disorders, nerve damage V, VII, VIII.
- Rétinite, uveite, vasculite

- Si présents---changer DD!
