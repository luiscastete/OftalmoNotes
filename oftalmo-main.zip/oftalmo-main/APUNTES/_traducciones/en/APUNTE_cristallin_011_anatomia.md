---
categoria: apuntes
area: catarata
emoji: 🔍
seccion: Cristallin - Lens
orden_seccion: 21
orden: 11
fuente: OneNote del Dr. Castilla Martí
---
# Anatomy

## 📑 Cellular Anatomy and Physiology - EBO Notes

## 🔬1. Basic anatomy of the lens

- Capsule:
  - thickest basement membrane of the human body.
  - completely surrounds the lens.
  - produced by epithelial cells of the lens.
- Anterior subcapsular epithelium:
  - Cubic cell monolayer under the anterior capsule.
  - Germinative zone in Ecuador → Stem cells that originate new fibers.
- Crystalline fibers:
  - Elongated cells, without nucleus or organelles, filled with crystalline proteins.
  - They form the transparent mass of the lens.

## 🔬2. Life cycle of lens cells

- Germinative Zone (Ecuador)
  - Epithelial cells actively divide.
  - It is the only place where new cells are produced.
- Differentiation
  - These cells migrate to the posterior and anterior part of the equator.
  - They elongate → lose core and organelles → become lens fibers.
- layer accumulation
  - Over time, the new fibers are deposited in the periphery.
  - The oldest fibers are compressed in the center → form the nucleus of the lens.
  - The most recent form the cortex.
