---
categoria: apuntes
area: catarata
emoji: 🔍
seccion: Cristallin - Lens
orden_seccion: 21
orden: 15
fuente: OneNote del Dr. Castilla Martí
---
# Viscoelastic's

1️⃣What are viscoelastics? o OVD's - Opthalmic ViscoSurgical Devices

Substances used in intraocular surgery (mainly cataract and anterior segment) for:

- keep space
- Protect the corneal endothelium
- Facilitate surgical maneuvers

👉 They are mainly derived from hyaluronic acid or cellulose (HPMC).

## 2️⃣Fundamental Classification (Ebo Key)

## 🔹A. viscoelasticscohesive

## Alta viscosidad – alto peso molecular – made from hyaluronic acid

They tend to clump more – high surface tension- easily removed from eye – higher in molecular weight – if left in the eye pressure much more than dispersive agents bcs of their higher molecular weight and trab meshwork clogging ability.
