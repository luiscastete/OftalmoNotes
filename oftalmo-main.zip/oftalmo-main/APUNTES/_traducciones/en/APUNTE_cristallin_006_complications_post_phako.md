---
categoria: apuntes
area: catarata
emoji: 🔍
seccion: Cristallin - Lens
orden_seccion: 21
orden: 6
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-12-28
---
# Post-Phako complications

## Acute and subacute endophthalmitis

## ENDOPHTALMIE CHRONIQUE

## Posterior capsular opacification

## Anterior capsule contraction syndrome

## Focused on implants

## Retinal detachment

## Cystoid macular edema or Irvine Gass syndrome

EN: Capsular rupture with glass outlet, glass imprisonment at the incision, AC implant, DM, uveitis.

Average start time 6 to 10 weeks after surgery sometimes longer.

TT:

1st intention:

Cortis eye drops: DX or PF 3-4XJ?

Diamox ½ Cpr 3xj + supplementary potassium.

Alternative:

Ains Ketorolac 0.5% - Acular 3xJ

2nd intention:

Inravital injection of cortis or subconjunctival injection cortis, anti-VEGF, vitrectomy of 'Pars flat.

## corneal edema
