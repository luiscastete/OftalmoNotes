---
categoria: apuntes
area: uveitis
emoji: 🔥
seccion: Immuno-infectio
orden_seccion: 7
orden: 30
fuente: OneNote del Dr. Castilla Martí
---
# Immune lunch reading

Print the items.

mini review. worth it

SIDA

- CD4 number?
- Ttt?
- Immunology state
- Selection of care of cytokines SNDR inflamm.
- Attention Re Immuno Syndrome.

- Immunosuppressed care:
- curiosity
- If it is venous drug: look for mycosis in the eye.
- If the sex less risk.

- Attention monster zone will have the question if HIV +.

- when you give him a bowl of an overdomedrol. Eliminate all immunity for 3 days.
- Attention not donor bolus in unclear case. Attention Virus + Bolus: Acute retinal necrosis.

- 3 infected diseases that you can lose vision in 24-48 hours:
- Behcet
- Acute retinitis necrosis
- Endophthalmitis

Children's window very strongly fixed. Attention VPP because it causes tears everywhere! Attention children and young people with Vitré.

The stronger the immunosuppression. More weird things happen.

Acute retinal necrosis:
