---
categoria: apuntes
area: cornea
emoji: 👁️
seccion: Cornée
orden_seccion: 4
orden: 4
fuente: OneNote del Dr. Castilla Martí
---
# Congenital anomalies of the cornea

Corneal Structure or Transparency Anomalies

posterior embryotoxon

This condition involves the presence of a schwalbe ring (joining of the trabecular mesh with the termination of the Descemet membrane) thickened and with anterior and central displacement, so that it is visible on the external examination. It is inherited dominantly. The eye, otherwise, is normal.

Posterior embryotoxon is a clinical finding characterized by a prominent white or gray line on the periphery of the cornea, just anterior to the insertion of the Descemet endothelium and membrane. It is visible during a slit lamp scan and represents a developmental anomaly in neural crest cell migration.

## Why is it important?

Although it may be an isolated and benign finding in healthy individuals (up to 15% of the general population), its presence may be significant for the following reasons:

1. Association with systemic or ocular syndromes:

• Axenfeld-Rieger syndrome: Posterior embryotoxon is one of its key characteristics, accompanied by iridocorneal adhesions, hypoplasia of the iris, and high risk of glaucoma.

• Alagille anomaly: hepatic and multi-organic disorder associated with posterior embryotoxon in more than 90% of cases.

2. Evaluation of the iridocorneal angle: It can make it difficult or indicate abnormalities in the development of the angle, which is crucial in the evaluation of congenital or developmental glaucomas.
