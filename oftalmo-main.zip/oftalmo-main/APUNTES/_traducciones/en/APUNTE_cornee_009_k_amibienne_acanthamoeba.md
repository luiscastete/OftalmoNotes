---
categoria: apuntes
area: cornea
emoji: 👁️
seccion: Cornée
orden_seccion: 4
orden: 9
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-10-11
---
# K. Amebian Acanthamoeba

## CL carrier (70% times) + extreme pain

## EARLY STAGES

## Punctate keratopathy with limbitis

Epithelial infiltrates + subepithelials + perineural-pathognometic infiltrates almost!

## LATTER STAGES

## Annular infiltrates

## ulceration

## Ant uveitis

## hypopion

## Dx

## Confoscan microscopy

Smear + direct examination with tinnius + complete classical cultures. + PCR + Antibiogram/Anti-fungals.

## AMBULATOIRE

-DEBRIDEMENT OF EPITHELIUM

## -PHMB 0.2% pcs

1xh for 7 days then

1xH2H for 7 days then

4xj for 2-4 months

## -DESOMEDINE 0.1% UD

1xh for 48h

4xj for 2-4 months
