---
categoria: apuntes
area: glaucoma
emoji: 🟢
seccion: Glaucome
orden_seccion: 5
orden: 34
fuente: OneNote del Dr. Castilla Martí
---
# TT Guide 3.0

## 🧭 Quick Clinical Guide: Topical Glaucoma Treatment (EGS 2022)

## 🔶 Step 1: Initial Evaluation

• 📌 Confirmed glaucoma diagnosis

• 🎯 Estimate target PIO according to:

- glaucomatous damage
- Risk factors (age, systemic BP, corneal thickness, family history)
- life expectancy

• ⚖️ Decide between starting topical treatment or considering SLT as the first option if there is a risk of low adherence or patient preference

## 🔶 Step 2: Start Monotherapy

- ✅ 1st Line – Prostaglandins Analogs (PGAS)- Prost
- Examples: Latanoprost, Travoprost, Bimatoprost, Tafluprost
- IOP reduction: 25–35%
- Standard dose: 1 time a day (at night)
- ✔️ Advantages: High efficiency, good safety profile, good adhesion
- ❌ Contraindications: uveitis, macular edema, ocular herpes
- ⚠️ Adverse effects: hyperemia conj, hyperpigmentation iris, hypertrichosis- growth eyelash growth, periocular fat atrophy
- Skin hyperpigmentation. Chronic pericoular erythema, occasional headache.

- 📋 Key questions:
- Do you have a history of uveitis or macular edema?
- Are you comfortable with aesthetic changes?

## 🔶 Step 3: Response to Monotherapy

❌ If the target IOP is not reached but there is good tolerance → Add different class drug or fixed combination
