---
categoria: apuntes
area: neuro
emoji: 🧠
seccion: Neuro-Ophta
orden_seccion: 8
orden: 27
fuente: OneNote del Dr. Castilla Martí
fecha: 2022-09-02
---
# Horton / Noia-A.

No head infarction on circulatory disorders of the posterior ciliary artery network with loss of visual function, due to gigantocelluliare arteritis (Horton's disease)

## Get rid of the postman

- >50a
- rhotomic polymiagia
- Tobacco
- low BMI
- Woman 4:1 man

## Symptoms

- often monocular bav. Deep, brutal*
- ipsilateral CV deficit
- Color vision anomaly
- PRINCIPLE:
  - fleeting amarosis
  - or transitory diplopia

## AA HORTON

Jaw claudication, headaches, scalp pain, Scalgia, weight loss, night sweats, unusual fatigue.

## Signs

Patients with NAION will typically have some or all of the signs of an optic neuropathy including decreased visual acuity, dyschromatopsia, an RAPD, a swollen optic nerve with splinter hemorrhages and a visual field defect. ( BASIC NOIA SIGNES, YOU PUT A NAME, THEN THE SURNAME)

## ophthalmic

- RAPD (if asymmetric deterioration)
- bav (we stick if it hits the no)
- Dyschromatopsia (alteration of color vision),
- CV waiting
- decreased contrast
- Papillary edema +++ in needle
- Pale Pale ++ Unique or Bilateral Old
- Diplopia
- Concomitant retinal ischemia:
  - cotton spots,
  - OACR,
  - occlusion of the cilium-retinal artery.
