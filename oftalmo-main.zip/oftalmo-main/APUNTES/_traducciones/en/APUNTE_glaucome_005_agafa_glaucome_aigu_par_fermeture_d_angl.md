---
categoria: apuntes
area: glaucoma
emoji: 🟢
seccion: Glaucome
orden_seccion: 5
orden: 5
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-02-05
---
# AGAFA - Acute Glaucoma by Corner Closure

Fermeture aigue angle irido-cornéen

## Symptoms

eye redness

aches and pains

BAV

## Signs

BAV variable

TIO Haute >40mmHg

HC +/- cercle perikératique

Oedeme cornéen épithélial

CA étroite +/- Tyndall

Pupille en semi-mydriase arreflexique

Glauckomflecken ( Glaukomflecken are small anterior subcapsular opacities secondary to lens epithelial necrosis resulting from acute angle closure glaucoma. These photographs from two different patients show central glaukomflecken and iris atrophy secondary to prior episodes of acute angle closure glaucoma.)

## Aetiology

## Primaire

Bloc pupillaire

Iris plateau

## Secondaire

Bloc pupillaire: Cristallin ( cataracte post-trauma, laxite zonulaire..), séclusion pupillaire, synechies posterieurs, vitré, silicone, implant phaque, implant en CA..

CNG, ice syndrome, inflammatory membranes, PAS,

malignant glaucoma, ocular tumerus, silicone or gas, uveal effusion,

Medicamenteuse: Topiramate, sulfonamides...
