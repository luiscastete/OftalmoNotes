---
categoria: apuntes
area: oculoplastica
emoji: 🫥
seccion: Oculo-Plastie
orden_seccion: 3
orden: 1
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-03-28
---
# When to refer oculoplasty

## Polyclinic follow-up

- blepharitis
- Chalazion

## Oculoplasty reference without emergency

- New case review or second ophthalmologist
- foreign patient
- Orbital pathologies
- Eyelid tumors
- Indication Palpebral surgery: ptosis, dermatochalasis, ectropion, entropion...
- patient request

## Oculoplasty reference with emergency

- Inflammatory exophthalmos
- exophthalmos and child
- Orbital cellulitis
- Preseptal cellulitis
- Lacrimal tract wounds

## PARTICULAR CASE

- Fracture of the orbital frame ---Imagier chuv effect with maxillofacial management surgery.
