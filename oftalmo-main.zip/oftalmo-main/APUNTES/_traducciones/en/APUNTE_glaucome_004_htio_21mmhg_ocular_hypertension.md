---
categoria: apuntes
area: glaucoma
emoji: 🟢
seccion: Glaucome
orden_seccion: 5
orden: 4
fuente: OneNote del Dr. Castilla Martí
---
# HTIO (>21 mmHg) Ocular hypertension

3 Criteria to decide whether to treat HTIO without glaucoma (NO and CV in the standard)

-Age

-Pache

-htio (depends if it is 21 than 35)

+\- Ant glaucoma

Follow the European Glaucoma Guide

In the scratches of the internet

Know that RFNL damage is seen at 4-6 months on exams

\_\_\_\_\_\_\_\_

Hto - Eye Hypertension

CHARACTER:

- PIO > 21 mmHg without TT
- normal CV
- Normal and RFNL papilla
- Gonioscopy: open angle - excludes the intermittent closing angle
- There are no signs of other eye or steroid diseases
- EN: None

Risk calculator

Risk Calculator | Ocular Hypertension Treatment Study (OHTS) | Washington University in St. Louis (wustl.edu)

TT:

Recommend if in high glaucoma conversion.

In general offer TT if twenty years with high pio even without fr.

Principles and Choice TT will be similar to GPAO.First TT Medical or Trabeculoplasty Laser.

6 to 12-month interval tracking initially if stable is extended.
