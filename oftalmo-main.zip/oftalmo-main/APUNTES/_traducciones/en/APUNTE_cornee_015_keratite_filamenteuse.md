---
categoria: apuntes
area: cornea
emoji: 👁️
seccion: Cornée
orden_seccion: 4
orden: 15
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-07-22
---
# Kératite filamenteUse

It is a habitual pathology that can cause significant discomfort. It is assumed that a loose area of epithelium acts as a focus for the deposit of mucus and cell debris. Causes include:

- The dry eye due to deficiency aquoasa is the most frequent.
- Corneal epithelium instability (recurrent erosion syndrome, corneal graft, cataract surgery or refractive toxicity and drug toxicity.
- Upper limbic keratoconjontivitis
- Neurotrophic keratitis
- Prolonged occlusion due to patches or associated with essential blepharospasm

## DX

## SINTOMAS

discomfort and sensation

HC

Blpharospasme

Photophobia

Epiphora

## SIGNOS

Strands of degenerate epithelial cells and mucus attached to an end of the cornea that move with blinking. They stain well with pink flare.

There may be a small epithelial defect at the base of a filament.

## Treatment

## GENERAL

Underlying cause should be treated like dry eye.

All unnecessary drugs must be suspended.

Short-term topical corticosteroids

TMB non-steroidal anti-inflammatory droplets, such as 0.1% diclofenac, may be used and appear to have an anesthetic effect.

## TTT ESPECIFICO
