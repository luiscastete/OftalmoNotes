---
categoria: apuntes
area: uveitis
emoji: 🔥
seccion: Immuno-infectio
orden_seccion: 7
orden: 11
fuente: OneNote del Dr. Castilla Martí
---
# HLA

HLA (Human Leukocyte Antigen) is a gene complex that encodes the proteins of the major histocompatibility complex (MHC) in humans. These proteins are on the surface of most cells and play a key role in the presentation of antigens to the immune system, particularly T lymphocytes.

## Why is it important in uveitis?

- Genetic predisposition: Certain HLA alleles are strongly associated with autoimmune or autoinflammatory diseases that have uveitis. For example:
  - HLA-B27: Associated with recurrent acute anterior uveitis, and diseases such as ankylosing spondylitis, reactive arthritis, etc.
  - HLA-A29: Related almost exclusively to birdshot chorioretinopathy.
  - HLA-B51: Strongly associated with Behçet disease, which includes panuveitis uveitis and retinal vasculitis.
  - HLA-DR15 (DR2): related to optic neuromyelitis and multiple sclerosis that may include optic neuritis and intermediate uveitis.
- Immune mechanism: HLA alleles influence how endogenous or exogenous antigens are presented to the immune system. Some variants present their own epitopes in an aberrant or ineffective way, which contributes to autoimmunity or uncontrolled inflammatory responses.

## Why are there so many disease-related subtypes?

- The HLA system is highly polymorphic: there are hundreds of variants for each gene (for example, more than 1000 HLA-B alleles).
- This diversity has an evolutionary value because it allows a greater capacity to recognize different pathogens, but it also implies that certain alleles predispose to anomalous immune responses to autoantigens or environmental antigens.
- HLA-disease associations are the result of coevolution between the human immune system and the microbial environment, as well as epigenetic factors.
