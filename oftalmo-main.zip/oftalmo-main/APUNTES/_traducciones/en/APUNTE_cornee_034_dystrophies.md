---
categoria: apuntes
area: cornea
emoji: 👁️
seccion: Cornée
orden_seccion: 4
orden: 34
fuente: OneNote del Dr. Castilla Martí
---
# Dystrophies

1 - ✓ Epithelial and subepithelial dystrophies:

- ■ Epithelial basement membrane dystrophies (EBMD). on map-point-fingerprint or microcystic dystrophy of Cogan.
- ■ Dystrophy with recurrent epithelial erosion (ERED).
- ■ Mucinous subepithelial corneal dystrophy (SMCD).
- ■ Meesmann Corneal Dystrophy (MECD).
- ■ Lisch's epithelial corneal dystrophy (LECD).
- ■ Gelatinous corneal dystrophy in drops (GDLD).

2 - ✓ Bowman Cloak Dystrophies:

- ■ Corneal dystrophy of Reis–Bücklers (RBCD).
- ■ Thiel–Behnke corneal dystrophy (TBCD).

3 - ✓ Stromal dystrophies:

- ■ TGFBI corneal dystrophies:

- Corneal Lattice Dystrophy:

  - ♦ Lattice corneal dystrophy, TGFBI type (LCD):
    - Lattice classical corneal dystrophy (LCD1) variants
  - ♦ Gelsolin type corneal dystrophy (LCD2).

- granular corneal dystrophy.
  - ♦ Granular corneal dystrophy, type 1 (classic) (GCD1).
  - ♦ Granular corneal dystrophy, type 2 (granular-lattice (GCD2) (havellino).

- ■ Macular corneal dystrophy (MCD).
- ■ Schnyder corneal dystrophy (SCD).
- ■ Congenital stromal corneal dystrophy (CSCD).
- ■ Motated corneal dystrophy (FCD).
- ■ Amorphous posterior corneal dystrophy (PACD).
- ■ Central cloudy corneal dystrophy by François (CCDF).

- ■ Pre Descemet corneal dystrophy (PDCD).

4 - ✓ Descemet membrane dystrophies and endothelium:

- ■ Fuchs endothelial corneal dystrophy (FECD).
- ■ Posterior polymorphic corneal dystrophy (PPCD).
- ■ Hereditary congenital endothelial corneal dystrophy 1 (CHED1).
- ■ Hereditary congenital endothelial corneal dystrophy 2 (CHED2).
- ■ X-linked endothelial corneal dystrophy (XECD).

## 👁️ Corneal Dystrophies – Epithelial Subtypes

## ✅ GENERAL DEFINITION

• Group of bilateral, progressive and primary disorders of the cornea.

• They affect a specific layer (epithelium, bowman, stroma, descemet or endothelium).

• Many are of genetic origin (autosomal dominant or recessive).

• Associated with corneal opacity, discomfort or visual loss (depending on the type).

📌 General rule: They affect a single layer, they are slowly progressive and bilateral.

## 🧬Classification according to the affected layer

| affected layer | Main examples |
|---|---|
| Epithelium | Cogan Dystrophy, Meesmann |
| Bowman's membrane | Reis–Bücklers, Thiel–Behnke |
| stroma | Granular, lattice, macular |
| Descemet membrane / endothelium | Fuchs, ched |
|  |  |

## 🔬 Epithelial Dystrophies

- 🌐1. Cogan (Epithelial Basement Membrane) Dystrophy -Map-Dot-Fingerprint Dystrophy

  - 📌 Key features
  - Also known as Map-dot-Fingerprint Dystrophy.
  - In most cases it is sporadic, although there are ad familial forms.
  - Clinically, it can simulate traumatic corneal erosions.

  - 🔬Histology
  - Basement membrane thickening.
  - Fibrillar deposit between epithelium and Bowman membrane.
  - Deficit of basal hemidesmosomes.

  - 👁️ Clinic
  - Start in the 2nd decade.
  - ~10% develop recurrent corneal erosions in the 3rd decade.
  - Many cases are asymptomatic.

  - 🔎Signs
  - Backlight display or scleral scatter.
  - Variable injuries:
    - 🟣 Microcysts and epithelial points.
    - 🗺️ Subepitelial maps with diffuse halo.
    - 🌀 Fingerprint spiral lines.
    - 🍇 Sub-pithelial “frosted glass” pattern.

  - 💊 Treatment
  - As for recurrent corneal erosions: lubrication, topical antibiotics, therapeutic contact lenses in persistent cases.

- 🔬2. Meesmann Epithelial Dystrophy

  - 📌 Key features
  - Rare and non-progressive disease of epithelial metabolism.
  - Mutations in corneal epithelial keratin genes.
  - Autosomal dominant transmission (AD).

  - 🔬Histology
  - Thickening of the epithelial basement membrane.
  - Intraepithelial cysts.

  - 👁️ Clinic
  - Most are asymptomatic.
  - In some cases: mild blurred vision, occasional erosions.

  - 🔎Signs
  - Multiple intraepithelial microcysts:
    - central distribution, do not reach limbo.
    - Cornea slightly thin, reduced sensitivity.

  - 💊 Treatment
  - Just lubrication. It does not usually require additional treatment.

## 🧿 Corneal Dystrophies – Bowman Layer / Previous Stromal

## ✅Generalities

• They are dystrophies that affect Bowman's membrane and the most anterior area of the corneal stroma.

• They are inherited in an autosomal dominant way (AD).

• Both are associated with recurrent corneal erosions in childhood.

• Caused by mutations in the TGFB1 gene (they share pathways with some stromals such as granular).

- 🧬 Fast comparison

| Feature | Reis–Bücklers | Thiel–Behnke |
|---|---|---|
| another name | CBD1 (Corneal Basement Dystrophy Type 1) | CBD2 (Type 2) / Honeycomb Dystrophy |
| associated gene | TGFB1 | TGFB1 + other not defined |
| Gravity | more severe | lighter |
| Histology | Replacing Bowman for Fibrous Tissue | Curly fibers in Bowman (EM) |
| Clinic | Severe erosions from childhood | milder erosions |
| opacities | gray, geographical, dense, reticular | subepithelial, in honeycomb ring |
| Distribution | Central, dense | central, more diffuse |
| corneal sensation | REDUCED | Variable |
| Treatment | Lubrication, excimer in severe cases | often not necessary |

- 🔍 Individual details

  - 1. Reis–Bücklers Corneal Dystrophy

    - Anterior variant of the type 3 granular.
    - Also known as CBD1-(Corneal Basement Dystrophy Type 1).
    - 👨‍👩‍👧‍👦 AD, Gen TGFB1.
    - 🔬 Histology: Bowman's disappearance → Replacement by connective tissue bands.

    - 👁️ Clinic
    - Severe corneal erosions from childhood.
    - Progressive decrease in vision over the years.

    - 🔎Signs
    - Gray subepithelial opacities, geographical, dense in the center.
    - They evolve to a reticulated pattern with age.
    - decreased corneal sensitivity.

    - 💊 Treatment
    - similar to the management of corneal erosions.
    - Keratectomy with excimer useful in severe symptomatic cases.

  - 2. Thiel–Behnke Corneal Dystrophy

    - Also called “Honeycomb Dystrophy”.
    - Also AD, TGFB1 gene + other.
    - 🔬 Histology: Spiral fibers or “curly fibers” in Bowman (visible in EM).

    - 👁️ Clinic
    - Erosions during childhood, but less serious than in Reis–Bücklers.

    - 🔎Signs
    - Less defined opacities, in the network of honeycomb-type rings.
    - It mainly involves the central cornea.

    - 💊 Treatment
    - Not always necessary.

## 🌫️ Corneal Stromal Dystrophies ( 7!! )

## ✅Generalities

• Mainly affect corneal stroma, can spread to other layers.

• Most are autosomal dominant inheritance (AD), except for the macular, which is autosomal recessive (AR).

• Common: TGFB1 mutated (same as in dystrophies of membr.Bowman?) in granular, lattice and avellino.

• They usually present from childhood or adolescence with:

- progressive opacities.
- visual decrease.
- sometimes recurrent corneal erosions.

## 🧬 Clinical comparison by subtype

| Type / Name | Gen | Deposit | Key Clinic | Treatment |
|---|---|---|---|---|
| Lattice Type 1 or Classic (TGFB1) | TGFB1 | ✴️ Amyloid | Erosions in childhood, central filiform opacity | Keratoplasty (penetrating or dalking) |
| Lattice type 2 or gelsolin (LCD2) | GSN | ✴️ Amyloid | Mild eye + systemic neuropathy | uncommon; progressive system |
| Type 1 granular or breadcrumbs | TGFB1 | 🧊 Hyaline | Deposits in “breadcrumbs”, rare erosions | keratoplasty; Superficial recurrence |
| Type 2 granular (star hazel) | TGFB1 | 🧊Hyaline + ✴️ Amyloid | stellar/annular; No refractive surgery | Avoid refractive surgery |
| macular | CHST6 | 🔷 GAGs | ar; diffuse opacities, from childhood | keratoplasty; frequent recurrence |
| Schnyder or Lipidica | UBIAD1 | 🧬 Lipids | Central Haze, Corneal Arc, 50% Crystals | Excimer or transplant if it affects vision |
| François Cloudy Dystrophy or Cloud | not clear | — | asymptomatic, similar to degeneration | Does not require treatment |

## 🔬 Details by subtype

Lattice : which has a network appearance or grid (hence the term “lattice” in English, which means “framed” or “grid”) appearance of fine branched lines.

## 👁️ How does it manifest?

• Fine white-gray lines in the central part of the corneal stroma

• Branched or crisscross arrangement (such as a mesh or net)

## 1. Lattice Dystrophy (TGFB1) or Type 1

- AD, TGFB1 gene.
- Amyloid deposits (congo red + green birefringence).
- Erosions from the 1st decade, blurred vision later.
- Central Refractile Filaments → Pattern in “Lattice” (does not affect limbo).
- frequent keratoplasty; can recur.

## 2. Lattice Gelsoline / Meretoja (LCD2) or Type 2

- AD, GSN*.
- Systemic: Cranial/peripheral neuropathy, rigid face, autonomic alteration.- Type II is associated with systemic amyloidosis
- Mild opacity, lines from periphery → center.
- rare erosions. Keratoplasty rarely necessary.

- 3. Type 1 granular (classic)
- AD, TGFB1 gene.
- Hyaline deposits (Red Masson Trichrome).
- Well-defined opacities: sugar / breadcrumbs aspect.
- central beginning, it expands over time.
- Progressively affected vision → Keratoplasty 5th decade.

## 4. Type 2 granular (havellino)

- AD, TGFB1 gene.
- Mix of hyaline and amyloid.
- Superficial opacities → stellars / annulars + deep linear opacities.
- ⚠️ Contraindicated Refractive Surgery: Accelerate progression.
- Generally does not require treatment.

## 5. Macular dystrophy

- AR, Gen CHST6.
- Gag deposits - Glycosaminoglycanos (Alcian Blue + Colloidal Iron).
- From childhood: poorly defined opacities → the entire cornea, to limbo.
- associated with early thinning and late edema.
- Very recurrent after keratoplasty.

## 6. Schnyder Dystrophy

- AD, gen ubiad1.
- lipid deposits (phospholipids and cholesterol).
- Central Haze, crystalline (only 50%).
- Corneal arc → advance towards the center.
- sometimes associated with systemic dyslipidemia.
- Treatment with excimer or transplant if there is visual impairment.

## 7. François Central Cloudy Dystrophy or Cloud

- Suspected as degeneration, not true dystrophy.
- Posterior polygonal opacities, without symptoms.
- Does not require treatment.

## 🧿Descemet Membrane and Endothelial Corneal Dystrophies ( 3 )

## ✅Generalities

• Group of dystrophies that affect the Descemet endothelium and/or membrane.

• Alter the function of the endothelium pump → Progressive corneal edema.

• They can be congenital or acquired, and many are hereditary (AD or AR).

• Some may be associated with glaucoma, abnormal iris or deafness.

## 🔬 Main subtypes

## 1. Fuchs Endothelial Corneal Dystrophy (FECD)

| Feature | Details |
|---|---|
| 🧬 Genetics | sporadic majority; AD cases by TCF4 (adults) or COL8A2 (early form) |
| 👩‍🦰 Epidemiology | Más frecuente en mujeres; aparece en edad media o avanzada. |
| 👁️ Clinic | morning blurred vision due to edema; Pain if there are bullas |
| 🔬 Histological signs | Endothelial guttata (excrescences), stromal edema and progressive epithelial, “beaten metal” |
| 📈 Complications | mild glaucoma ↑ risk; Bullous Keratopathy in advanced stadiums |
| 💊 Treatment | Hypertonic saline, keratoplasty (DSAEK/DMEK/PK), Rho-kinase (experimental) |
|  |  |

## ⚠️ Waterfall + Fuchs

→ Caution: Surgery can worsen edema. If CCT > 630–640μm, consider triple procedure.

## 2. Polymorphous corneal dystrophy (PPCD)

| Feature | Details |
|---|---|
| 🧬 Genetics | AD PPCD1: VSX1/PPCD2: COL8A2/PPCD3: ZEB1 |
| 👁️ Clinic | usually asymptomatic |
| 🔬 Signs | Endothelial lesions in the vesicular, linear or diffuse pattern |
| 🤝 Associations | Glaucoma, anomalous iris, Alport syndrome |
| 💊 Treatment | It is not usually necessary |
|  |  |

## 3. Congenital Hereditary Endothelial Dystrophy (CHED)

| subtype | CHED1 | CHED2 |
|---|---|---|
| Heritage | AD (locus on chromosome 20) | AR (SLC4A11) |
| Appearance | 1st year of life | from birth |
| Symptoms | Tearing, photophobia | No frequent eye symptoms |
| signs | Diffuse corneal opacity | Same, but more severe |
| ASOC. | Same entity as PPCD? | May be associated with deafness (Harboyan) |
| nystagmus | Weird | Common |
| Treatment | Lamelar or PK | Lamelar or PK |
|  |  |  |

## Descemet membrane and endothelial Dystrophies

Fuchs Endothelial Corneal Dystrophy

📘 1. Introduction

– Definition: Fuchs endothelial dystrophy is a progressive bilateral corneal disease characterized by accelerated loss of endothelial cells and corneal edema.

– Importance: The main cause of endothelial keratoplasty in older adults.

– Who is affected: Predominantly in women, with a habitual onset in middle or advanced age.

– Typical patient: Woman >50 years with progressive blurred vision, variable family history.

🧬 2. Etiology

– Genetics: Most cases are sporadic. There are autosomal dominant forms (Mutation in Col8A2 in early-onset variants; TCF4 in typical forms).

– Multifactorial: genetic influences and age.

– Iatrogenic: ocular surgery (eg phacoemulsification) can precipitate endothelial decompensation.

👁 3. Symptoms

– Typical symptoms:

• Morning vision that improves during the day (fluctuating corneal edema).

• Progressive visual decrease.

• Eye discomfort in advanced stages (eg pain from broken bullae).

– ⚠️ Alarm: Acute eye pain due to rupture of bulla; very low vision.

🔎 4. Signs

– Physical examination:

• Corneal guttata: Descemet membrane excrescences.

• Peripheral endothelial radial lines.

• Specular reflex: irregular mosaic → appearance of “bound metal”.

• Central stromal edema → progressive opacity.

• Epithelial edema with microcysts and bullas (bulous keratopathy).

• Chronic cases: subepithelial scars, peripheral neovascularization.

– ⚠️ Alarm: Signs of advanced endothelial decompensation or severe bullas pain.

🔬 5. Diagnosis

– Necessary tests:

• Biomicroscopy with slit lamp.

• Central pachymetry (>630–640 μm suggests high postoperative risk).

• Specular microscopy (loss of cells and guttata).

• Oct previous if available.

– Differential diagnosis:

• Congenital endothelial dystrophies (CHED).

• Pseudophakic bullous keratopathy.

• Corneal edema due to ocular hypertension or surgery.

– ⚠️ Red Flags Diagnostics:

• Cornea edematous in a patient with recent phaco.

• CCT >640 μm pre-surgical.

• Extensive guttata and advanced cell loss.

💊 6. TREATMENT

– First line (conservative):

• Sodium chloride 5% in drops or ointment.

• Decrease in IOP.

• Corneal drying (eg low power hair dryer).

– Alternatives / Palliative:

• Therapeutic contact lenses.

• Cycloplegia, topical antibiotics, lubricants.

• Anterior stromal puncture (for bullas).

– Surgery:

• DSAEK / DMEK (endothelial keratoplasties): high success rate.

• Penetrating keratoplasty in advanced cases.

• Surgeries in eyes without visual potential: conjunctival flaps, amniotic membrane.

• Innovative: topical inhibitors of rho-kinase after endothelial cryotherapy.

– ⚠️ Precautions:

• Cataract surgery can worsen endothelial function.

• Use techniques with minimal ultrasonic energy (torsional > longitudinal).

• Consider triple surgery (FacoE+lio+DSAEK/DMEK) in cases with edema.

• Pakimetry <630 μm → Less risk of post-phacus edema.

📅 6.1 Tracking

– Controls: according to clinical progression and established treatment (monthly to semi-annual).

– Evolution: slow but progressive; Good surgical response if treated in time.

🧭 7. Protocols / Algorithms

– Clinical suspicion + Biomicroscopy → Confirm with pachymetry and specular microscopy.

– Yes Compensated cornea → Conservative treatment + follow-up.

– If decompensated cornea → Assess keratoplasty (DMEK/DSAEK).

– Prior to Faco: Measure pachymetry and assess risk → Consider triple surgery if >630 μm.

📝 8. Personal Notes / Clinical Tips

– If morning blurred vision improves during the day, think of corneal edema by Fuchs.

– Always ask for preoperative pachymetry in patients >60 years before phaco. I also count endothelial cells right? If we have the machine, more info, better for us and the patient, right?

– Do not underestimate isolated guttata in asymptomatic eyes: they can evolve.

💎 9. Key points of the disease

💎 Progressive morning blurred vision in older adults.

💎 Corneal Guttata + Central Pakimetry >630 μm are diagnostic keys.

💎 DMEK is the treatment of choice in decompensated cornea with good visual prognosis.

🔗 10. Complementary resources

– Clinical images: guttata, stromal edema, bullous keratopathy.

– AAO Fundamentals & Kanski – Chapters of endothelial dystrophies.

– UptoDate review on current management and therapeutic novelties (Rho-kinasa).

🧠 11. Flashcards / EBO-type questions

– ❓ What is the typical initial finding in Fuchs? → Guttata in Descemet membrane.

– ❓ Which parameter predicts the greatest risk of post-phaco edema? → Central pachymetry >640 μm.

– ❓ What is the most effective surgical treatment? → DMEK.

– ❓ Why is this disease important? → It is the most common endothelial dystrophy and one of the main indications of keratoplasty.

– ❓ What should you never forget when you see it? → Always evaluate pachymetry before intraocular surgery.

✴️ 12. Final Key Message

– Fuchs is a progressive endothelial dystrophy that causes corneal edema and visual loss; Requires early diagnosis, pachymetric follow-up and timely surgical management with DMEK to preserve vision.

## 👶🏻 Ched – Congenital hereditary endothelial dystrophy

📘 1. Introduction

– Definition: Rare congenital disease characterized by diffuse or focal thickening of the Descemet membrane and endothelial degeneration.

– Importance: important cause of corneal opacity from childhood.

– Who is affected: Newborns or young children, depending on the type.

– Typical patient: Infant with opaque corneas at birth (CHED2) or with progressive opacity in childhood (CHED1).

🧬 2. Etiology

– Genetics:

• Ched1: autosomal dominant, locus on chromosome 20; Possible overlap with posterior polymorphous corneal dystrophy (PPCD).

• CHED2: autosomal recessive, mutation in SLC4A11; more frequent and severe.

– Associations: CHED2 can be associated with late-onset sensorineural deafness (Harboyan syndrome).

👁 3. Symptoms

– Ched1: photophobia, tearing, progressive opacity.

– CHED2: Generally asymptomatic at the beginning, but with opacity present from birth.

– ⚠️ Alarm: Nystagmus (most common in ched2), indicates visual deprivation.

🔎 4. Signs

– CHED2:

• Diffuse corneal opacity and thickening from birth.

• Frequent nystagmus.

• Discrepancy between corneal appearance and visual acuity (may be better than expected).

– CHED1:

• Opacity appears during the first or second year of life.

• It does not usually present nystagmus.

– ⚠️ Alarm: Neonatal bilateral dense opacity → suspect ched2.

🔬 5. Diagnosis

– Necessary tests:

• Neonatal/children's ophthalmological evaluation.

• Pakimetry, OCT previous if possible.

• Genetics: Study of SLC4A11 (CHED2).

– Differential diagnosis:

• Endothelial dystrophies (CHED vs. PPCD).

• Congenital corneal edema No dystrophies (congenital glaucoma, childbirth trauma, intrauterine infection).

– ⚠️ Red Flags Diagnostics:

• Bilateral corneal opacity from birth.

• Family history compatible with autosomal pattern.

💊 6. TREATMENT

– Surgical:

• Lamellar or penetrating keratoplasty according to the degree of involvement.

• In severe cases or with nystagmus → early intervention to avoid amblyopia.

– ⚠️ Precautions:

• Multidisciplinary management if there is suspicion of Harboyan syndrome (auditory evaluation).

• Evaluate and treat amblyopia postoperatively.

📅 6.1 Tracking

– Controls: frequent in childhood to assess visual development and post-surgical evolution.

– Evolution: Without surgery, the opacity is usually stable or progressive. With transplantation, good visual prognosis if intervened in time.

🧭 7. Protocols / Algorithms

– Neonatal bilateral corneal opacity → Assess thickness, intraocular pressure, family history → rule out ChED2.

– Genetic confirmation and visual monitoring → Keratoplasty according to severity.

📝 8. Personal Notes / Clinical Tips

– In bilateral neonatal corneal opacity without ocular hypertension, always consider ched2.

– Ched1 can be confused with other dystrophies → Family history is key.

– Nystagmus in Ched2 suggests visual deprivation → Requires urgent intervention.

💎 9. Key points of the disease

💎 Ched2 is more frequent, serious and neonatal onset.

💎 Ched1 has dominant inheritance and can be confused with PPPCD.

💎 Early Keratoplasty improves the visual forecast and reduces amblyopia.

🔗 10. Complementary resources

– Clinical images: neonatal corneal opacity, post-transplant evolution.

– References: Kanski, AAO, OMIM revision of the SLC4A11 gene.

– CHED and deafness association (Harboyan syndrome): Clinical genetic resources.

🧠 11. Flashcards / EBO-type questions

– ❓ What type of chedd appears at birth? → Ched2 (AR).

– ❓ What is the gene associated with CHED2? → SLC4A11.

– ❓ What neurological complication can be associated with CHED2? → Sensorineural deafness (Harboyan syndrome).

– ❓ Why is it important to diagnose early CHED? → To avoid severe amblyopia.

– ❓ What finding CHED1 differentiates from ched2? → Nystagmus (present in CHED2).

✴️ 12. Final Key Message

– Ched should be suspected in the bilateral congenital corneal opacity; Early diagnosis and adequate surgical treatment are essential to preserve vision in child development.

## 🧠Flashcards EBO – Corneal Epithelial Dystrophies

1. What is the most common epithelial dystrophy in adults?

→ Cogan (Epithelial Basement Membrane) Dystrophy.

2. What microscopic finding is typical in Cogan dystrophy?

→ Thickening of the basement membrane + subepithelial fibrillar deposit.

3. What pattern of injuries is associated with Cogan dystrophy?

→ map-dot-fingerprint: maps, microcysts, spiral lines.

4. What epithelial dystrophy is congenital and non-progressive?

→ Meesmann Epithelial Dystrophy.

5. What clinical finding differentiates Meesmann from Cogan?

→ Uniform epithelial microcysts that do not reach limbo.

## 🧠 Flashcards Ebo – Bowman Layer Dystrophies

1. What is the most severe dystrophy between Reis–Bücklers and Thiel–Behnke?

→ Reis–Bücklers.

2. What pattern of opacity is typical in Thiel–Behnke dystrophy?

→ Honeycomb (honeycomb).

3. What gene is mutated in both dystrophies?

→ TGFB1.

4. What histological finding is observed in Reis–Bücklers?

→ Replacement of Bowman with fibrous connective tissue.

5. What is the useful surgical treatment in Reis–Bücklers Severo?

→ Keratectomy with laser excimer.

6. How do both dystrophies differ histologically?

→ Reis–Bücklers: Collagen bands / Thiel–Behnke: Curly fibers in EM.

## 🧠 Flashcards Ebo – Endothelial Dystrophies

1. What gene is associated with the most common form of Fuchs in adults?

→ TCF4.

2. What histological finding defines Fuchs dystrophy?

→ Guttata: Descemet membrane excrescences.

3. What is the critical range of central corneal thickness predicting post-surgery edema in Fuchs?

→ > 630–640 µm.

4. What type of transplant is currently preferred in Fuchs?

→ DMEK or DSAEK (lamellars).

5. What is the most severe form of congenital endothelial dystrophy?

→ Ched2 (AR, SLC4A11).

6. What findings are seen in PPCD?

→ vesicular or band lesions in the endothelium; asymptomatic.

7. What complications can the advanced Fuchs have?

→ Epithelial bullae, pain, subepithelial healing, peripheral neovascularization.

8. What mutation is associated with the early form of Fuchs and PPPCD2?

→ COL8A2.

## 🧠 Flashcards Ebo – Stromal Dystrophies

1. What is the only recessive inheritance stromal corneal dystrophy?

→ Macular (CHST6 gene).

2. What type of deposit is found in type 1 granular dystrophy?

→ Hyaline.

3. What pattern is typical in avellino dystrophy?

→ Stellar or annular lesions + deep linear opacities.

4. What stain is characteristic to confirm amyloid in lattice-type dystrophies?

→ Congo RED + green birefringence with polarized filter.

5. What stromal dystrophy is associated with systemic peripheral neuropathy?

→ Lattice Gelsoline type (Meretoja / LCD2).

6. What clinical characteristic contraindicates refractive surgery in type 2 granular?

→ Risk of acceleration of dystrophy after corneal trauma.

7. What dystrophy looks like breadcrumbs and requires keratoplasty in the 5th decade?

→ Type 1 granular.

8. What dystrophy has lipid deposits and can be associated with systemic dyslipidemia?

→ Schnyder.

## Fuchs dystrophy: distrophieendothelial-descemetique

Sporadic or autosomal dominant

Getting Started Overall >40 Years by: Halos, Glare with Intermittent BaV with Predominance in the Morning for Corneal Edeme Awake*

## STADE

- 1- Cornea guttata
- Descemet-looking membranes of whipped silver and pigmented deposits.

- 2-Oede Me Cornéen +/- Oedeme Microkystique

- 3-Fobose sous-épithéliale

## Dystrophie Posterieure Polymorphe

Autosom Dom. with previous presentation in life

vesicles, gray lignes, endothélial anomalies parfois géographiques.

Very slow symptom Progressive with log-time AV preserved

Localized thickening of the Descemet membrane with multilayer pseudoepithelial multilayer endothelium.

DD diagnosis: ICE snydome or iridocorneo-endothelial syndrome due to excessive proliferation of the endothelium at the expense of the posterior face of a cornea from the iridocorneal angle and the iris

## Dystrophie Endothelial Congenital Hereditaire – Ched

Périnatal débt

Absence of focal or diffuse corneal endothelium due to endothelial desquamation

Pseudoglaucomatous symptoms with bilateral corneal corneal edmematous opacifications

DX DD Congenital Glaucome.

TT:

Solution Hyperosmolars: ODM5

Endothelial graft: DSAEK or DMEK

Greffe Transfixiantes

| 📊 Table 1 – Full summary of all corneal dystrophies (by layers) |  |  |  |  |  |  |  |
|---|---|---|---|---|---|---|---|
| Layer | Name | Heritage | Gen | Deposit / Injury | Clinic | Key signs | Treatment |
| Epithelium | fuck | Sporadic / AD | - | MB thickening, lines | slight erosions | Map, footprint, points | Lubrication |
| Epithelium | Meesmann | AD | epithelial keratin | Intraepithelial cysts | asymptomatic | Cysts without reaching limbo | Does not require |
| Bowman | Reis–Bücklers | AD | TGFB1 | MEMBER. Bowman replaced by fibrous tissue | severe erosions | geographical opacities | excimer |
| Bowman | Thiel–Behnke | AD | TGFB1 | Curly fibers in Bowman Membrane Honeycomb | slight erosions | central honeycomb | Does not require |
| stroma | Lattice (TGFB1) | AD | TGFB1 | Amyloid | early erosions | Refractile lines | Keratoplasty |
| stroma | Lattice (Gelsoline) | AD | GSN | Amyloid | Mild + neuropathy | lines from the periphery | Conservative |
| stroma | Type 1 granular | AD | TGFB1 | Hyaline | Glare, progressive | dots like breadcrumbs | PK |
| stroma | Hazel | AD | TGFB1 | hyaline + amyloid | It worsens post-surgery | Stellar + linear injuries | Avoid refractive surgery |
| stroma | macular | AR | CHST6 | GAGs | from childhood | diffuse to limbo | PK |
| stroma | Schnyder | AD | UBIAD1 | lipids | dyslipidemia | Central Haze + Arc | pk or excimer |
| stroma | François Cloudy | possible ad | - | - | asymptomatic | polygonal opacities | Does not require |
| endothelium | Fuchs | Sporadic / AD | TCF4 / COL8A2 | Guttata | Morning Blurred Vision | Beaten metal, bullas | DMEK/DSAEK |
| endothelium | PPCD | AD | VSX1 / ZEB1 | vesicular injuries | asymptomatic | vesicles / bands | Does not require |
| endothelium | CHED2 | AR | SLC4A11 | Descemet thickening | nystagmus, deafness | Neonatal opacity | PK |

| 📌 Table 2 – The Essentials to Differentiate (Key Concepts) |  |  |  |  |  |
|---|---|---|---|---|---|
| Name | Gen | Layer | key pattern | Distinctive Clinic | Treatment |
| fuck | - | Epithelium | Map-Fingerprint | erosions without trauma | Lubrication |
| Meesmann | epithelial keratin | Epithelium | cysts | asymptomatic | None |
| Reis–Bücklers | TGFB1 | Bowman | Geographic | severe erosions | excimer |
| Thiel–Behnke | TGFB1 | Bowman | Honeycomb | Mild | Nothing |
| Lattice (TGFB1) | TGFB1 | stroma | Filaments | early erosions | pk / dalk |
| Lattice (Gelsoline) | GSN | stroma | Peripheral | Systemic neuropathy | Conservative |
| Type 1 granular | TGFB1 | stroma | Bread crumbs | well delimited | PK |
| Hazel | TGFB1 | stroma | stellar + linear | Post-surgery worsens | Avoid refractive surgery |
| macular | CHST6 | stroma | Diffuse | Childhood, AR | PK |
| Schnyder | UBIAD1 | stroma | Haze + Arc | dyslipidemia | pk / excimer |
| Fuchs | TCF4 | endothelium | Guttata | Blurred morning vision | DMEK/DSAEK |
| PPCD | VSX1 | endothelium | vesicles | asymptomatic | Does not require |
| CHED2 | SLC4A11 | endothelium | Neonatal opacity | Deafness + nystagmus | PK |

| 🧠 Table 3 – Minimum to memorize |  |  |  |
|---|---|---|---|
| Dystrophy | Layer | Keyword | What distinguishes it |
| fuck | Epithelium | Map-Fingerprint | erosions without trauma |
| Meesmann | Epithelium | cysts | Childhood, no symptoms |
| Reis–Bücklers | Bowman | Geographic | severe erosions |
| Thiel–Behnke | Bowman | Honeycomb | Mild |
| lattice tgfb1 | stroma | Filaments | early erosions |
| Hazel | stroma | stellar + linear | Contraindicated excimer |
| macular | stroma | diffuse to limbo | ar, childhood |
| Granular 1 | stroma | Bread crumbs | well delimited |
| Schnyder | stroma | lipids + arc | dyslipidemia |
| Fuchs | endothelium | Guttata | Morning blur |
| PPCD | endothelium | vesicles | asymptomatic |
| CHED2 | endothelium | Neonatal opacity | Deafness, nystagmus |
