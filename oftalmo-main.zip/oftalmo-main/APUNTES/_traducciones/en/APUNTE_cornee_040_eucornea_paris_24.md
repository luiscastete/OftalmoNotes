---
categoria: apuntes
area: cornea
emoji: 👁️
seccion: Cornée
orden_seccion: 4
orden: 40
fuente: OneNote del Dr. Castilla Martí
---
# Eucornea Paris 24

Infectious keratitis

Smear

ATB + valaciclovir

Cortis after min 48h with good ant

Add amniotic membrane

Otherwise, insulin falls

Wait 2 months: add keratoplasty?
