---
categoria: apuntes
area: cornea
emoji: 👁️
seccion: Cornée
orden_seccion: 4
orden: 27
fuente: OneNote del Dr. Castilla Martí
---
# Q. Bacterial

- ✅ Summary structured for OneNote with the key concepts of bacterial keratitis.
- ✅ Comparative summary table of pathogens, risk factors, clinical signs and treatment.
- ✅ Ebo flashcards with real questions to review.

## 📘 Notes for OneNote – Bacterial Keratitis

## 🔬 3.1 Bacterial Keratitis

## 🧪 Pathogenesis

Conditions to produce infection: usually requires previous alteration of ocular defenses.

Exceptions (may go through healthy epithelium):

- Neisseria gonorrhoeae, N. meningitidis, C. diphtheriae, H. influenzae

Frequent pathogens:

| Bacterium | Type | Features |
|---|---|---|
| Pseudomonas aeruginosa | Gram-negative bacillus | Very aggressive, >60% LC keratitis |
| Staph. aureus | Gram-positive coconut | Well-defined white/yellow infiltrate |
| Streptococci | GRAMPOSITIVES | Aggressive, crystalline (α-hemolytic) infections |
