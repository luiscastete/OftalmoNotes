---
categoria: apuntes
area: neuro
emoji: 🧠
seccion: Neuro-Ophta
orden_seccion: 8
orden: 9
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-12-20
---
# I saw or abduct

ATTEINTE NUCLEAIRE

It does not lead to diplopia because there is an attack in both eyes with horizontal paralysis of the gaze: limitation of ipsiterral abduction and contralateral adduction.

ATTEINTE INFRANUCLEAIRE

kidnapping deficit with that deviation.

Diplopia more marked in distant vision than in close vision.

DD: myasthenia ocular, distiroidownnw orbitopathy, myositis, other orbital causes: tumor, hematoma, trauma...

Find localization signs: Cavernous sinus: If you attend the sympathetic chain of associates, vascular spouffle or orbit
