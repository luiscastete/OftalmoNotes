---
categoria: apuntes
area: neuro
emoji: 🧠
seccion: Neuro-Ophta
orden_seccion: 8
orden: 26
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-08-24
---
# optic neuritis

Inflammation of the optic nerve of idiopathic or demyelinating origin

Often associated with multiple sclerosis (EM)

Typical from 20 to 50 years

woman>man

## Symptoms

Subacute BAV evolving in a few hours/days

Orbital pain and/or oculomotilitis (90%)

phosphenes (30%)

## Signs

Retrobulbar optic neuritis: no visible improvement of the papilla (65%)

Typical optic neuritis: Papillitis (35%)

## Examination

AV: Variable-grade BAV

Color Test:

- Ishihara test
- Red Desaturation Test: Dyschromatopsia
- * Proof of contract in A.Kawasaki? Discussion with her, it really allows the no exam.

Pupil Test: Rapd of the affected eye

CV by confrontation, CV 30°: Variable deficit.

Oculomotricity: Pain

Dilated fo: normal / papillite

OCT: RFNL, RGCL – important for tracking*

## Balance Sheet (Additional)

Brain MRI and fine orbital cuts with injection of gadolinium and gadolinium and fat suppression.

delay < 1 week.

Yes Typical clinical presentation: No emergency for a MRI in the same way.

Evaluation of Neuro CHAV
