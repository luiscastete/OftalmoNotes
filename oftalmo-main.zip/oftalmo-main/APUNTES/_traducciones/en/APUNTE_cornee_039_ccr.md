---
categoria: apuntes
area: cornea
emoji: 👁️
seccion: Cornée
orden_seccion: 4
orden: 39
fuente: OneNote del Dr. Castilla Martí
---
# CCR

Postoperative TT:

Nevac

dexlibre

Vigax

dressing

Small details:

For TranspRK (epith and stroma ablation)

anesthesia with oxy

Do not tetra because it is too toxic and sometimes damages the epith.

For PRK (we talked to the front epithelium with 20% OH)

Anesthesia with tetra

Postoperative indications

Normal pain and tears for 2 weeks

Avoid any type of water

Forward if white dot display

Vision fluctuates for 2 weeks

Do not drive for 2 weeks

AT 5j

Normal if you have causes of constipation for Co Dafalgan

PRK:

Advantage

Technically it is simple

Tpute's horny life is stronger

Disadvantage

First pains 3-7 days

Slow recovery and slow improvement AV but progressive

LASIK

Advantage

a good one since the operation and less pain

Disadvantage

Movement veiled by risk for life

both techniques

possible drought in both

photophobia possible both

Halos and glare at night

DLK
