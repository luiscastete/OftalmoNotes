---
categoria: apuntes
area: cornea
emoji: 💧
seccion: Conj + Episclere + Sclere
orden_seccion: 25
orden: 12
fuente: OneNote del Dr. Castilla Martí
---
# Conjunctival tumors 1.Epithelial

## 🧠 Summary Notes: Conjunctival Tumors (Theme 5)

## 5.1. Epithelial tumors

## ✅ Benign epithelial tumors

| Injury | Main features | Treatment |
|---|---|---|
| Hereditary benign intraepithelial dyskeratosis | Autosomal dominant (cr. 4), limbo, gelatinous, without invasion or dysplasia. Also in pharynx and mouth. | extirpation (can relapse) |
| Pseudoepitheliomatous hyperplasia | Reactive hyperkeratotic nodule, without dysplasia or vessels | observation or excision |
| Conjunctival squamous papilloma | Sessile or pedunculated, HPV (6-11 most common), young people 20-40 years old. Inverted = Endophytic Growth | extirpation + cryotherapy. IFNA-2B, MMC or 5-FU possible |
| Actinic keratosis | Leukoplastic, slow, interpalpebral limbo. About Pinguecula or Pterygion | Excision (may progress to carcinoma) |
