---
categoria: apuntes
area: cornea
emoji: 💧
seccion: Conj + Episclere + Sclere
orden_seccion: 25
orden: 10
fuente: OneNote del Dr. Castilla Martí
---
# C. Scars

## 🧠3. Scar conjunctivitis

## 🔷3.1. Mucous membrane pemphigoid (PMM)

Definition: Chronic, autoimmune bullous disease, which mainly affects mucous membranes → Progressive fibrosis. It can be isolated ocular or multisystemic.

Epidemiology:

- Women > Men (2–3:1)
- Average age: 65 years
- 75% with oral involvement, only 15% cutaneous

PATHOGENESIS:

- Type II hypersensitivity
- Autoantibodies (IgG, IGA, C3) vs:
  - LAMINA 332
  - Integrins α4, α6
- Association with HLA-DR4
- Ocular pseudopenfigoid: similar clinical phenotype, associated with topical eye drops (Timolol, pilocarpine…) → non-progressive

Clinical Presentation:

- Insidious Home: Chronic Repetition Conjunctivitis
- Bilateral and progressive (asymmetric) signs:
  - Stage I: tarsal fibrosis, hyperemia, keratinization caruncle
  - Stage II: Fornix shortening
  - Stage III: Symbolic
  - Stage IV: Ankyloblepharon, keratinization of SO
- Complications:
  - Trichiasis, Entropion
  - Severe dry eye (by alteration of meibomy and lacrimal glands)
  - Ulcers, peripheral corneal vascularization
