---
categoria: apuntes
area: glaucoma
emoji: 🟢
seccion: Glaucome
orden_seccion: 5
orden: 37
fuente: OneNote del Dr. Castilla Martí
---
# Surgical TT

## 💉 Surgical treatments in the management of glaucoma

This document summarizes in clinical and practical format all the surgical techniques used for the treatment of glaucoma, with a question-response structure, and prioritizing the real utility in consultation.

---

❓ How are glaucoma surgeries classified?

Incisional surgeries are divided into two large groups:

🔷 A. Penetrating surgeries

- They completely cross the sclera and communicate the anterior chamber with the subconjunctival space.

- Examples: trabeculectomy, drainage implants (valves)

🟢 B. Non-penetrating surgeries

- They do not access the previous camera directly.

- Examples: Deep non-perforating sclerectomy (EPNP), viscocanalostomy

---

❓ What is trabeculectomy and how does it work?

🧬 Principle:

Create a fistula that allows the aqueous humor to leave the anterior chamber towards the subconjunctival space, where a filtering blister forms.

⚙️ Technique:

1. Conjunctival dissection and superficial scleral flap

2. Partial excision of the trabeculum

3. Peripheral iridectomy
