---
categoria: apuntes
area: uveitis
emoji: 🔥
seccion: Immuno-infectio
orden_seccion: 7
orden: 18
fuente: OneNote del Dr. Castilla Martí
fecha: 2024-05-13
---
# EALS disease

Entity apparently to idiopathic peripheral retinal vasculitis. It occurs in the form of OCCL followed by vasculitis. His physiology is unknown.

## Epidemic and Etio

Affected population before the age of 40

Slight predominance in maculine subjects

Bilat affection.

There is no clearly identified etiology even if Bacillus Koch is retrouve in patients in the endemic area.

## Signs

It can be discovered fortuitously

may be associated with a previous Tyndall, see Ehyalita

Occurrence of pre-Retinal neoVVSx on the border between perfused and non-perfused territories often in pre-equatorial retina. These neovvsx can sickle cell fan SSEA

Revetaion disease due to neovascular complications: Homovitrée, fibrovascular veiled retinal tractions

Extraocular signs of absence

## DX DD

Often attaches TBC without setting

Other occlusive vacularities whose cause is known: sickle cell disease, Susac syndrome, Behçet, sarcoidosis, toxo, connectivity.

## EX COMPLEMENTAIRES

FLUO ANGIO:

Perfusion and retinal dissemination of sudden stop of preretinal neovssx.

Sometimes macular ischemia with discrete enlargement of the ZAC that reduces the visual prognosis

Zac Oct: Allows macular detachment DX in case of doubt.

## TT

The argon laser of ischemic territories may be sufficient

Tt surgery is sometimes necessary in cases of vitreoretinal or hemoviterous tractions that limit laser production
