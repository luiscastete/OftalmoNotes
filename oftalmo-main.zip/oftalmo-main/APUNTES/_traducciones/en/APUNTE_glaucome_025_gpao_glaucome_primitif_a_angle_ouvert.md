---
categoria: apuntes
area: glaucoma
emoji: 🟢
seccion: Glaucome
orden_seccion: 5
orden: 25
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-07-24
---
# GPAO - Open Angle Primary Glaucoma

Chronic, progressive, potentially blinding and irreversible eye diseases that cause RNA loss and associated CV deficiencies. The angle appearance is normal and the FR ppal are the advanced and aged IOPs.

Aetiology

remains blurry.

Multiple F genetics and influences of comorbolities are likely to play a role. Deformation hypothesis The filmed blade caused by IOP levels that are not stolen for a given eye. Axonal Death Attack Cel No Ganglion + FRCV...

Any increase in IOP is caused by high flow resistance of HA in the trabeculum flow paths. A significant proportion develops a GPAO with PIO in the standard.

GPAO subdivided into glaucoma with high IOP and glaucoma with normal IOOP

It is premature that FRs other than IOP have a greater importance in GPN.

TT is the same.

FR GPAO:

- age
- High IOP
- black race
- Ant glaucoma
- Strong myopia
- Low diastolic resistance
- ECC thinner
- FRCV

## Juvenile Start Open Angle Glaucoma

Has been linked to mutations in trab meshwork - TIRG/MYOC

OPTN - optineurin mutations have been linked to normal tension glaucoma

CYP1B1 mutations have been linked to congenital glaucoma
