---
categoria: apuntes
area: glaucoma
emoji: 🟢
seccion: Glaucome
orden_seccion: 5
orden: 45
fuente: OneNote del Dr. Castilla Martí
fecha: 2024-06-12
---
# GSAO - Secondary open angle glaucoma

Secondary open angle forms a heterogeneous group of disease where high PAL is the glaucomatous optic neuropathy of Ppal f.

GSAO caused by eye disease

- Exfoliative or pseudoexfoliative glaucoma - Gpex
- Pigmentary Glaucoma - PG
- Lens-induced open angle glaucoma
- Glaucoma associated with intraocular hemorrhage
- Uveitic glaucoma
- neovascular glaucoma
- Glaucoma and intraocular tumors

Post-traumatic GSAO

Iatrogenic GSAO

- cortisonic glaucoma
- Glaucoma after eye and laser surgery
- Glaucoma after vitreoretinal surgery

GSAO and extraocular disease

- Glaucoma caused by high venous episcleral pressure
