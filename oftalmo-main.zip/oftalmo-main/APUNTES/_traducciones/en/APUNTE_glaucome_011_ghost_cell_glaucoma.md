---
categoria: apuntes
area: glaucoma
emoji: 🟢
seccion: Glaucome
orden_seccion: 5
orden: 11
fuente: OneNote del Dr. Castilla Martí
---
# 👻 Ghost Cell Glaucoma

## 👻Ghost Cell Glaucoma

## ✅ Definition

Secondary glaucoma due to trabecular obstruction caused by degenerate red blood cells (“Ghost cells”) after vitreous hemorrhage.

## 🔬 Pathogenesis

• ~2 weeks after vitreous hemorrhage:

• Hemoglobin leaves the erythrocytes → transform into ghost cells.

• These cells pass through a defect in the anterior face of the hyaloid and enter the anterior chamber.

• When they lose their flexibility → they get trapped in the trabecular mesh, obstructing the drainage of aqueous humor → ↑pio.

## 📌 Associated clinical situations

| Situation | Comment |
|---|---|
| Cataract surgery with previous vitreous hemorrhage | Ghost Cells migrate after surgery. |
| Aphakic or pseudophakic eye with HV | Ghost Cells can freely pass to the previous segment. |
| HV and Hyphaema complicated cataract surgery | Hyphaema disappears, but Ghost Cells persist. |
|  |  |

## 🔍 Clinical manifestations

• Cornea edematous by ↑pio.

• Anterior camera with Ghost Cells:

- Appearance: Reddish brown or khaki particles in aqueous humor.
- ⚠️ Do not confuse with leukocytes → Avoid incorrect treatment for uveitis.
