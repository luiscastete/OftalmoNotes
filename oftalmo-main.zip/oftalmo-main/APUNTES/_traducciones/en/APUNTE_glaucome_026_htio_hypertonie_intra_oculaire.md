---
categoria: apuntes
area: glaucoma
emoji: 🟢
seccion: Glaucome
orden_seccion: 5
orden: 26
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-07-24
---
# htio-hypertonie intra oculaire

Factors associated with increased IOP are those associated with increased episcleral venous pressure (crouching or supine position, holding breath, high central venous pressure, intubation, obstruction of orbital venous drainage, playing wind instrument, maneuvering Vasalva, dress neck or tie tight, excessive fluid intake), those that produce an increase in pressure in the eye (blepharospasm, cry), high body temperature, hormonal influence (hypothyroid, thyroid ophthalmopathy), drugs ( anticholinergics, corticosteroids, ketamine, LSD, topiramate, caffeine) and diseases such as uveitis or high blood pressure (the latter negligiblely).

pg 348 Kansky

## Eyepiece Hypertension (OHT)

IOP >21mmHg + Open Angle + Without Detectable Glaucomateuse Damage:

Aprox 1 of 10 will develop glaucome over 10 years period and m ayority wount develop glaucome in life time.

## RISK DEVELOPING GLAUCOMA ( consider this citeria )

- increases with older age
- Increses with higher hypertension (is not the same 21 than 28mmhg)
- Risk is greater in thin cornear <555um and lower in >588um.
- Cup/disc - the greater the ratio the greater the risk ( so more risk c/p 0.5 than 0.2)
- The Higher of PSD
- africans
- evils
- heart disease
- Diabetes
- Family History + Glaucoma
