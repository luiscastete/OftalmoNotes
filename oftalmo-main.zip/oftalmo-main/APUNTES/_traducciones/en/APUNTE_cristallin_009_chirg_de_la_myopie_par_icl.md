---
categoria: apuntes
area: catarata
emoji: 🔍
seccion: Cristallin - Lens
orden_seccion: 21
orden: 9
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-03-28
---
# chir Myopia by ICL

Implant myopia surgery is possible when strong myopia cannot benefit from Lasik with femtosecond laser.

## AVANTAGES

The advantages of implants are: precision, visual quality, reversibility (in case of fake implant), good tolerance.

## Why fake implants?

The question of phake implants should be done in case of:

Myopia greater than -10.

The cornea is too thin for a laser.

Corneal scar contraindicating any laser surgery.

Astigmatism too irregular for laser treatment.

## In what cases/eligibility

The implant is possible in non-laser operable cases: - Too high myopia not correctable by a femtosecond LASIK >10/12-corneal diopters is too thin to be excavated by the laser.

-The first is not to be eligible for a laser technique.

-Be at least 25 years old.

-The space between your cornea and your lens should be enough to let the implant pass.

-Your cornea should not show signs of premature aging of type Fuchs dystrophy.

-You must not have glaucoma or ocular hypertonia.

-Your expectations should be in line with the final and expected results.

-You must understand postoperative follow-up and agree to respect the treatments and controls planned.

INCONVENIENTS:

– This is a riskier operation than laser surgery, endocular. It requires regular control of the eye condition. In case of intolerance, the implant must be removed with return to the initial myopia.
