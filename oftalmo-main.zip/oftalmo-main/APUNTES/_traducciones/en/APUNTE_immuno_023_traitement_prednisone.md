---
categoria: apuntes
area: uveitis
emoji: 🔥
seccion: Immuno-infectio
orden_seccion: 7
orden: 23
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-03-14
---
# Prednisone treatment

Contact MT to find out if contraindications

Take the morning t^t because otherwise trouble sleeping

Degressive diagram if 1mg/kg/d Degressive scheme at 10 of 10 per week

If you take 40 mg PDT 3 J, you can stop suddenly, but if it is taken for weeks, you can't stop. important to stop suddenly.

The patient did not make the mountain. 1st appointment in May 2023.

Plan:

PC next SEM to the follow-up lab. YES NO Contraindications in the laboratory or comorabilities (DM? Gastric ulcers? Autoimmune diseases?)

Add Labo: VS and TBC (Ant balance cannot be added)

Prevent the patient: If the infection consults the emergency, protect yourself from the sun, take prednisone in the morning to avoid sleep disorders, risk of DM, risk of gastric ulcer, risk of psychiatric disorders and depression.

Internal opinion of the doctor chuv: prednisone70mg x day PDT 2sem then 60mgxj PDT 1sem, then 50mgxj PDT 1 sem, then 30mgxj 1sem, then 20mgxj 1 week, 10mgxj 1wk, 5mgxj 1wk and stop (total 8sem).

Add Pantoprazole 20mg 1xJ PDT 8 SEM, Calcimagagon-D3 Forte 1CPR in the morning PDT 8 SEM and Prophylaxis with Bactrim Forte 1CPR PDT 6 weeks.
