---
categoria: apuntes
area: glaucoma
emoji: 🟢
seccion: Glaucome
orden_seccion: 5
orden: 29
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-07-24
---
# Pigment dispersion syndrome and pigment glaucoma

It corresponds to a release of iris pigments by chronic rubbing of iris epith on the face of the ant. of the lens. It may be responsible for pigment glaucoma due to secondary accumulation of pigments in work. and outbreaks of ocular hypertonia.

## MECANISMES PHYSIOPATHOLOGIQUES

Reverse pupillary block of the first step: Presence of a concave iris with reversal of the pressure gradient between the part of the ant. and the part of the publication. of the iris.

2-Step Pigment Release in AC by chronic post-face friction. Iris against the ant face. of the lens and the zonula.

3-stage accumulation pigments in work. then secondary ocular hypertonia.

development of 4 steps. Secondary glaucoma

## Epidemiology and FR

Adult 20-40 years – myopia –3/-4.

Pigmentary glaucoma: male predominant 80% 30-50 years

## PARTICULARITES DIAGNOSTIQUES

Asymptomatic logtime time: Rare htio seizures with vision of transient disorder, halos, eye pain during physical exercise.

Clinical Examination:

- Peripheral transillumination
- Kruckengbers package: Vertical pack of pigments on the face post-corne + pigment deposits in the Zonule.
- Concave Iris
- Rare Tyndal pigment
- Gonium: Open angle Iridcorneal + abnormal pigmentation in grade 3-4 according to Scheie
- OCT SA or UBM: Concave iris rubbing observed during an examination.

## TT
