---
categoria: apuntes
area: cornea
emoji: 💧
seccion: Conj + Episclere + Sclere
orden_seccion: 25
orden: 20
fuente: OneNote del Dr. Castilla Martí
fecha: 2022-09-16
---
# Episcleritis

Inflammation of the episclere

Self-limited, recurrent, often bilateral attack.

More frequently in young adults F>H

rare in children.

2 types:

- simple
- and nodular, clinically differentiable.

## Aetiology

- idiopathic (mainly)
- Associated with eye damage: dry eye, blepharitis, ocular rosacea, atopy, LDC port.
- Associated with systemic deterioration (especially scleritis, rarely episcleritis): Inflammatory disease: conectivitis and vasculitis (10% of cases): rheumatoid arthritis, reactive arthritis (Reiter syndrome), Crhon, RCUH hemorrhagic rectolitis is a chronic inflammatory bowel disease (IBD), systemic lupus erit, SPA, Chrug-Strauss syndrome, granulomatosis with polyangiitis, Behçet...Gout, thyroid disease.
- Infections: Herpes zoster, TB, syphilis, borreliosis, toxoplasmosis...
- Rare: Malignant tumors: T-type leukemia, Hodking lymphoma.
- Mixed origin: Drugs: topiramate, pamidronate, bifopsonates...

## Symptoms

| Simple Episcleritis 75% | Nodular episcleritis 25% |
|---|---|
| -Start start <24h, then advance resolution to a few days.<br>Sectoral redness / (2/3 of cases) > Diffuse cases 1/3<br>Minor discomfort (even absent) in serious<br>sand feeling<br>Photophobie<br>Larmoiment | localized redness, more often it shows when you wake up<br>More insidious start (2-3 days), with progressive increase in redness and discomfort<br>impression of this<br>Photophobie<br>Larmoiment |
