---
categoria: apuntes
area: cornea
emoji: 👁️
seccion: Cornée
orden_seccion: 4
orden: 33
fuente: OneNote del Dr. Castilla Martí
---
# Complications Refractive Surgery Chirurgie Refractive

Contraindications refractive surgery:

- Patients with collagen vascular, auto-immune or immunodeficiency disease
- Women who are pregnant or nursing - including woman who actively trying to get pregnant
- Patients with abnormal topography
- Patients with unstable refraction. In general should be stable for at least 1 year.
- Medications: isotretinoin-accutane and amiodarone.

📍 Diffuse Lamellar Keratitis (DLK)

📍 Interface Fluid Syndrome (IFS)

AR facing the ebo:

## 🔶1.Diffuse Lamellar Keratitis (DLK)

## ✅¿Qué es?

A sterile (non-infectious) inflammatory reaction that appears in the interface space between the corneal flap and the underlying stroma after LASIK surgery.

## 🕒When does it appear?

usually between day 1 and 5 post-Lasik.

## 🧠 Why does it happen?

- Surgical trauma
- Toxin contamination, meibomy, powder, talc of gloves
- epithelial defects
- Surgery with excessive energy (femtosecond)

## 👁️

## Clinical signs

- Diffuse cell infiltrates on the interface
- May affect visual acuity if it progresses
- No flashy conjunctival hyperemia or pain

## 🎯Classification in degrees (1 to 4)

- Grade 1–2: Mild, central or peripheral
- Grade 3–4: Can compromise vision if not treated

## 💊 Treatment

- Intensive topical corticosteroids
- In advanced degrees: lift the flap and wash with BSS

## 🧠 Key to ebo

DLK = sterile inflammation, appears early, treated with corticosteroids.

## 🔷2.Interface Fluid Syndrome (IFS)

(Also called “Pressure-Induced Stromal Keratitis” – Pisk)

## ✅¿Qué es?

Fluid accumulation between the flap and the corneal stroma, caused by ocular hypertension — often induced by postoperative corticosteroids.

## 🕒When does it appear?

It can be days or weeks after surgery, even months or years if the patient returns to use steroids.

## 🧠 Why does it happen?

- Increased real IOP, which is not well detected with flattening tonometry (gives false low values by the flap)
- Result: Aqueous Humor Leakage to the Interface

## 👁️ Clinical signs

- AV decrease
- Appearance of fluid between flap and stroma (clear space in slit lamp)
- PIO Normal or slightly elevated measurement (but falsely low!)

## ❗Difficult diagnosis if not suspected

## 💊 Treatment

- Suspend corticosteroids
- Start treatment Aggressive hypotensive
- Monitor with corneal OCT and visual field

## 🧠 Key to ebo

IFS = fluid due to ocular hypertension, worsens with corticosteroids, falsely normal IOP, it is treated by lowering the IOP.

## 🔄 Quick Comparison Table

| Feature | DLK | IFS |
|---|---|---|
| Origin | Sterile inflammation | Ocular hypertension |
| Start | 1–5 days post-LASIK | days/weeks, even late |
| PIO | Normal | High (but falsely normal) |
| common cause | Surgery, toxic, epithelium | Postoperative corticosteroids |
| Clinic | Interface infiltrators | Fluid on interface |
| Treatment | Topical corticosteroids | Suspend corticosteroids, hypotensives |
| Forecast | good if early | good if it is detected in time |
