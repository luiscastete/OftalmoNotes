---
categoria: apuntes
area: neuro
emoji: 🧠
seccion: Neuro-Ophta
orden_seccion: 8
orden: 35
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-05-26
---
# Suivi Plaquenil/Hydroxychloroquine

## Definition

Macular Toxicity: dose-dependent and duration of TTT.

Possible presentation: Subclinical retinopathy or sytomatic maculopathy in the eye of a protrusion.

## Mechanism of Toxicity

The mechanism of hydroxychloroquine retinal toxicity has yet to be fully elucidated. Studies have shown that the drug affects the metabolism of retinal cells and also binds to melanin in the RPE, which could explain the persistent toxicity after discontinuation of the medication. However, these findings do not explain the clinical pigmentary changes causing a bull’s-eye maculopathy.

## Recomendation dosage

## Dose maximale recommande: <5mg/kg/j

A check at each control query.

Risque toxicite ret si dose <5mg/kg:

<1% après 5 ans

<2% après 10 ans

20% after 20 years of TT

## FR

Although it is not possible to predict which patients will develop retinal toxicity, high-risk characteristics include the following:

## daily dose >5mg/kg; Cumulative >1000g or

## Durée de tt >5 ans

## Rétinopathie préexistante

## Insuffisance rénale +/- hepatopathie ( car clearence by both routes)

## Age >60ans

## Concomitant treatment with tamoxifen (ca.sein).

## Symptoms

Asymtomatique

Paracentral scotoma

decrease in perception colors

## Signs

- Changes in macular or perimacular PRE
- Always bilateral! - If unilateral changes investigate other causes

- FAF: porthole maculopathy with perifaveolar disautofluorescence extended to the posterior pole (advanced stage).
- Macular OCT: Severe involvement of parafoveolar photoreceptors and migration of the pigmental epithelium.
- CV 10°: Annular scotomas, central savings. Reason 1st and dangerous!
- MF-ERG: decreased central amplitudes.

## RECOMMENDATIONS

## AAO 2016

- Basic exam in 1st year TT:
- AV+FO
- If pre-existing retinopathy is suspected:
- macular SD
- CV Octopus 10°-30° Yes Asian

- Annual evaluation after 5 years of TT:
- AV+FO+SD-OCT Macular
- macular faf
- CV Octopus 10°-30° Yes Asian

- Annual evaluation from the beginning if:
- Risk factors
- Dose >5.0 mg/kg/d

- If pathological examinations or doubt:
- Add MF-erg

## HOJG

- Basic exam, at the beginning of the TT
- av+fo+photo fo
- macular SD
- macular faf
- CV Octopus 10°-30° Yes Asian
- Mf-ERG

- Annual evaluation under TT
- av+fo+photo fo
- macular SD
- macular faf
- CV Octopus 10°-30° Yes Asian
- Mf-ERG

- MF-ERG to repeat:
- After 5 years of TT.
- If retinno toxicity is suspected (anomalies present in the other tests)*
- Asian patients: also examination of the peripheral retina, car pattern of toxic peripheral retinopathy.

## Tt

Without TT. It is irreversible and can progress even after stopping the platenil.

-DD of Bull's-Eye Maculopathy

- Age-related macular degeneration
- benign concentric annular dystrophy
- Central Areolar Choroidal Dystrophy
- Chloroquine/Hydroxychloroquine Retina Toxicity
- Chronic macular hole
- Cone and cone-rod dystrophies
- Stargardt's disease

Results analysis:

SD-OCT:

- Early: Localized retinal thinning in the perifaveolar or extramacular region, near the Asian arches.
- Possible, early: Focal interruption of the outer layer of photorecept.

FAF

- Early: EP hyperfluorescence in the perifaveolar/extramacular region. can precede Oct.
- Afternoon: hypofluorescence.

CV

- Most frequent initial attack: Inf-temporal retino----sup-deficiency nasal CV.

Results analysis:
