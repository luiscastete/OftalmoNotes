---
categoria: apuntes
area: cornea
emoji: 👁️
seccion: Cornée
orden_seccion: 4
orden: 38
fuente: OneNote del Dr. Castilla Martí
---
# Toxic keratitis

Chronic ulcer when duration > 3 weeks

Allergies to preservatives instead of active ingredients!

Ask the question if cobsomation of recreational drugs.
