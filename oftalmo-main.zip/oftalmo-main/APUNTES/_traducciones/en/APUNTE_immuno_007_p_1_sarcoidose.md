---
categoria: apuntes
area: uveitis
emoji: 🔥
seccion: Immuno-infectio
orden_seccion: 7
orden: 7
fuente: OneNote del Dr. Castilla Martí
fecha: 2024-05-15
---
# P.1- Sarcoidosis

Granulomatous systemic disease of unknown etiology.

Characterized by histological epitheloroid and gigantocellular granulomas without caseous necrosis.

All structures of the eyeball and orbital content can be affected.

The ophthalmological manifestations are polymorphic.

## Epidemiologies and Etiology

25-50% of patients with sarcoidosis have ophthalmic disease. And it can have that purely ocular sarcoidosis without systemic manifestations.

The disease occurs between the ages of 20 and 40 with a perimenopause peak.

There is no preponderance of the disease according to gender.

## SIGNES OCULAIRES

- apart from the uvee
- All ocular structures can be affected, with order of frequency outside the UVEE:
  - The cornea: dry keratitis, interstitial keratitis, keratopathy in bandages
  - The conjunctiva: conjunctival granulomas
  - Scleritis: Scleritis, Episcleritis
  - The orbit: lacrimal gland, muscle...
  - Optical pathways: papillary odema, granuloma, norb.

- SIGNES OPTHALMOLOGIQUES
  - Precipitates the cornea in the fat of the sheep and the granulomatous corneal precipitates and (or Iriene nodules from the pupillary edge - Koeppe or Stroma - Busacca
  - Trabecular nodules and/or synechiae in the store
  - Vitreous opacites: iceberg effect, pearl chain
  - Multifocal peripheral choroiditis: active lesions or scars
  - Segmental or nodular periflebitis (spots of candles) and/or nmacroaneurysms within an inflammatory eye
  - Papillary nodules/Granulomas and/or Choroidal solitary nodule
  - Bilaterality

- SIGNES PARACLINIQUES
  - Tuberculin anergy in patients previously vaccinated by BCG or who have before a test +
  - ACE Elevation – Angiotensin Converting Enzyme – Serum and/or Lisozyme Serum
  - Bilateral hilarious adenopathies in chest X-ray
  - Alteration of liver work - 2 Among the following tests: alkaline phosphatases, ASAT, ALAT, LDH or GGT.
  - TRORAC + computed tomography

- UVEITE SARCOIDOSIQUE

- It is the most common ophthalmologic manifestation

  - Anterior uveitis - 50-70% of cases
    - Chronic, granulomatous, uni- or bilateral.
    - Sheep fat precipitates
    - Iriene nodules - Koeppe
    - ca tyndall
    - iridistalinian post.
    - eye hypertonia. Search with gonium if secondary trabeculitis Presence of sarcoidosis granulomas then goniosinechia and evolution towards secondary glaucoma

  - Intermediate uveitis – 10 to 20% of cases – the initial seat of inflammation is the basis of the vitreous
    - Tyndall Vitrean
    - Finger OEFS/Snowballs – Ice Fleet
    - Segmental and oeripheral focal periflebitis
    - Complications: WTO, secondary cataract, peripheral occlusive vasculitis

  - Posterior uveitis: 10-30% of cases
    - Tyndall Vitrean Central
    - Retinal damage: perivenous candle spots, posterior pole segmental and focal periflebitis, arterial sheath, pseudo-tuoral form, venous branches occlusion, pre-papillary or pre-papillary neovascularization
    - Croidinal damage: croroidal granulomas in the absence of vitreous inflammation, pigmented scar in the form of multifocal choroiditis, neovascularization, cystoid macular edema, papillary hyperheemia, granuloma no.
