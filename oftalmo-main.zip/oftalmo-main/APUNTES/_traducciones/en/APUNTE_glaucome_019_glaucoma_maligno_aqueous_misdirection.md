---
categoria: apuntes
area: glaucoma
emoji: 🟢
seccion: Glaucome
orden_seccion: 5
orden: 19
fuente: OneNote del Dr. Castilla Martí
---
# Malignant glaucoma (Aqueous Misdirection)

## 🔬 Malignant glaucoma (Aqueous MiDirection)

- It is a rare complication, usually post-surgical (eg trabeculectomy, cataract surgery, vitrectomy).
- Mechanism:
  - The aqueous humor is diverted towards the vitreous, instead of flowing towards the anterior chamber.
  - This causes the previous vitreous to hydrate → increases volume → pushes the entire irid-crystalline diaphragm forward.
  - Result: Very narrow/collapsed anterior chamber + elevated IOP, despite a previously open angle.

## 📊 Role of ciliary processes

- The ciliary processes are thought to rotate forward against the anterior lens or capsule.
- This contact forms a kind of "seal" that diverts the aqueous humor towards the vitreous instead of the pupil.
- It is a mechanism without Pupillary Block, different from the bombé iris.
