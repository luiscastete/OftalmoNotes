---
categoria: apuntes
area: glaucoma
emoji: 🟢
seccion: Glaucome
orden_seccion: 5
orden: 41
fuente: OneNote del Dr. Castilla Martí
---
# Epithelial (EI) - Fibrous Ingrowth (fi) /Downgrowth

## 📑 Epithelial vs Fibrous Ingrowth – Ebo Summary

## 🔬 Definition

- Epithelial Ingrowth: Proliferation of epithelial cells within the anterior chamber through surgical/corneal wounds.
- Fibrous Ingrowth: Proliferation of fibrous tissue (fibroblasts and collagen) in surgical wounds or eye incisions.

## 👁️ Clinical findings

- Epithelial: flat, glossy, transparent foil; can invade angle → secondary glaucoma.
- fibrous: whitish, dense, scary mass; more localized and static.

## 🧪 Diagnostic differentiation

- Biomicroscopy:
  - Epithelial → Smooth, glassy appearance.
  - Fibrous → Opaque, elevated.
- OCT Previous segment / UBM: Delimits extension and density.
- Nd:YAG/Argon Laser Test:
  - Epithelial Ingrowth → Whitening (white bubble) by cell gas release.
  - Fibrous Ingrowth → Does not bleach, no visible change.
