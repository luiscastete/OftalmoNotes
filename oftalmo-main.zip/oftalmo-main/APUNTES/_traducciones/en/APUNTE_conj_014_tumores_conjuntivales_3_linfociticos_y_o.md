---
categoria: apuntes
area: cornea
emoji: 💧
seccion: Conj + Episclere + Sclere
orden_seccion: 25
orden: 14
fuente: OneNote del Dr. Castilla Martí
---
# Conjunctival tumors 3.Lymphocytic and others

## 🧠5.3. Conjunctival lymphoma

## 🔍 Generalities

- 3rd most common conjunctival malignant tumor, after melanoma.
- It represents 1.5% of conjunctival tumors and 8% of extranodal NHL.
- More common in middle-aged adults (~6th decade).
- It derives from the lymphoid tissue associated with conjunctiva.
- Usually non-Hodgkin's lymphoma (NHH) of B cells, mostly:
  - MALT (extranodal marginal zone) (~66%)
  - Follicular
  - Rare: mantle cells, diffuse large B cells (high grade)

## 🧬Risk factors

- chronic inflammatory stimulus.
- Immunodeficiency (HIV), autoimmunity.
- Infections: Chlamydia psittaci, H. pylori, HCV (not fully confirmed).

## 👁️ Clinic

- Salmon mass, mobile, subconjunctival, elevated, non-vascularized, insidious.
- It is usually in fornix or bulbar conjunctiva.
- Sometimes it presents as chronic follicular conjunctivitis.
- It can be bilateral (20%) and have systemic involvement (20-30%).

## 🧪 Diagnosis

- HR-OCT: Homogeneous subepithelial mass with normal epithelium.
- Essential biopsy (formol + fresh for IHQ, cytometry, genetics).
- Complete systemic study: PET, CT, bone marrow biopsy.

## 💊 Treatment

- External radiotherapy (20-30GY): Choice in localized lesions.
- Intralesional IFN or Rituximab: Good response.
- Oral doxycycline: Useful if there is Chlamydia psittaci (up to 60% remission).
- Systemic chemotherapy: in high degree or systemic involvement (rituximab + CHOP, VCP, etc.)

## 📈 Forecast

- Excellent, with survival >90%.
- Risk of late systemic involvement → semester follow-up 5 years, then annual.

## 🧠5.4. Other conjunctival tumors

## 🔹5.4.1. pyogenic granuloma and capillary hemangioma

- Pyogenic granuloma: reactive hemangioma after trauma or surgery. rapid growth. Treatment: Topical corticosteroids or removal.
- Capillary hemangioma: no previous trauma, no inflammation, appears in adults. simple exeresis or cryotherapy.

## 🔹5.4.2. Kaposi's sarcoma

- Malignant vascular neoplasia (associated with HHV-8), in the context of AIDS.
- Red, nodular, vascularized subconjunctival lesion, especially in lower fornix.
- TREATMENT:
  - Observation if immune control with HAART.
  - Surgery, cryotherapy, radiotherapy, vinblastine or IFN-α intralesional if progressive.

## 🔹5.4.3. Epibulbar choristomas

- Heterotopic congenital lesion: tissue in an abnormal location.
- Types:
  - Epibulbar dermoid: Solid whitish mass in inferotemporal limbo. May contain hair and glands.
  - Dermolipoma: Yellow mass (adipose tissue) in supertemporal quadrant.
- They can cause astigmatism, amblyopia. Surgical treatment if functional or cosmetic involvement.
- Associations: Colobomas, Goldenhar syndrome, Treacher-Collins, linear sebaceous nevi.

## 📊 Comparative table

| Tumor | Characteristic Clinic | Most frequent histological type | Diagnosis | main treatment | Forecast |
|---|---|---|---|---|---|
| Conjunctival lymphoma | Salmon, fornix or bulbar dough | MALT type LNH | Biopsy + HR-OCT + systemic study | External radiotherapy (20-30 Gy) |  |
| pyogenic granuloma | Post-trauma vascular lesion | Reactive hemangioma | Clinical / Biopsy Yes Doubt | Topical corticosteroid or surgery | Excellent |
| Kaposi's sarcoma | Vascular nodular reddish mass, AIDS | Vascular neoplasia (HHV-8) | Clinical, HIV + | Observation or radiotherapy / IFN | Variable (better with HAART) |
| Epibulbar choristoma | Solid congenital mass, inferotemporal limbo | Dermoid / Dermolipoma | Clinical | Surgery whether functional or aesthetic | Well, it doesn't malign |
