---
categoria: apuntes
area: neuro
emoji: 🧠
seccion: Neuro-Ophta
orden_seccion: 8
orden: 6
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-10-24
---
# Ortho exam

## Orthopedic exam

## damages 

Can we have a troop and a foria? - Explaining.com

foria:

Exophoria (x close x’) (no fixing grip movement, restitution movement from outside to inside)

Esophoria (E Close E') (no fixing grip movement, restitution movement from inside to outside)

Hyperforia (if the left eye in G/D hyperphoria) (no fixing grip movement, restitution movement from top to bottom)

Hypophoria (if the left eye is inferior to the right eye D/G) (no fixing grip movement, bottom-up restitution movement)

Troop:

Exotropy (XT Close X'T) (Fixing grip movement, from outside to inside)

Esotropy (and close up is) (Fixing grip movement, from inside out)

Hypertropy (if the left eye in g/dt hyperphoria) (fixing grip movement, from top to bottom)

Hypotropy (if the left eye is lower than the right eye D/GT) (fixation of the plug movement, from bottom to top)
