---
categoria: apuntes
area: neuro
emoji: 🧠
seccion: Neuro-Ophta
orden_seccion: 8
orden: 32
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-03-09
---
# Facial or bell paralysis?!

Classification

| Degree | Description |
|---|---|
| **1** | Without paresis. normal motor function. at rest, without deformation. normal active movements. |
| **2** | light paresis. Motor function: Weakness/sinkinesia only on careful examination. at rest, without deformation. Active movements: frontal closure, almost normal, eyelid closure, greatly diminished mouth. |
| **3** | moderate paressis. Motor function: manifest difference compared to the other side, synkinesia, contracture. at rest, without deformation. Active movements: frontal still present, closure of the total eyelids at maximum effort, of the decreased mouth. |
| **4** | paressis stockings. Motor function: disfiguring asymmetry. at rest, without deformation. Active movements: absent forehead, incomplete closure of the eyelid, asymmetrical mouth. |
| **5** | marked paresis. Motor Function: Some visible residual movements. At rest: asymmetry (ptosis of the commissure of the labial commissure, erasing the nasolabial fold). Active movements: absent fronts, incomplete closure of the asymmetrical eyelid. |
| **6** | complete paralysis. Motor Function: None Movement. At rest: Active atonial movements: None |
