---
categoria: apuntes
area: uveitis
emoji: 🔥
seccion: Immuno-infectio
orden_seccion: 7
orden: 21
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-07-24
---
# Up- posterior uveitis

## Definition

Eye inflammation that can be blinding and affecting one or more of the following structures: choroid, retina, vitreous, retinal VSSX.

## how to refer

Refer all up, before investigations, immediately in the immune unit.

## Symptoms

- OCULAIRES:
  - Redness
  - deep pain
  - Photophobie
  - blurred vision
  - No secretions
  - Myodesopsia

- Systemic:
  - +/- Cutaneous
  - +/- Respiratory
  - +/- Neurological
  - +/- digestive
  - -Always do AA by systems

## Signs

Vitrite (snowball you look especially depressed)

Scar / Focus of chorioretinitis (for example, toxoplasmosis)

Vasculitis (vascular sheath, caliber jump)

Periflebitis (venous vasculitis)

Perivascular bleeding

retina edema

Neuroretin: Bartonella in 30% of cases

daddy
