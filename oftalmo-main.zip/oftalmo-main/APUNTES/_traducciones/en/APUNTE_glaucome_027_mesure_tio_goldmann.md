---
categoria: apuntes
area: glaucoma
emoji: 🟢
seccion: Glaucome
orden_seccion: 5
orden: 27
fuente: OneNote del Dr. Castilla Martí
---
# Mesure Uncle Goldmann

## Factors that alter tonometry — Understanding why

## Reminder of the beginning

Tonometer measures the force needed to flatten the corneaIf something makes the cornea easier to flatten → Lee Falsely lowIf something makes the cornea more difficult to flatten → Lee Falsely Tall

The question you should always ask yourself is:

- Does this factor make the cornea easier or harder to flatten?

## 1. Corneal Thickness (CCT — Corneal Thickness Center)

## Thick Cornea → Falsely Tall PIO

Normal cornea = ~540 microns

thick cornea = ~620 microns

Imagine you have to flatten:

- A sheet of thin cardboard → Little resistance
- A double cardboard sheet → More resistance

Thick cornea ↓More material to compress/scroll ↓Need more force to flatten ↓Tonometer reads High force ↓Interpret PIO high ↓But the real IOP is normal
