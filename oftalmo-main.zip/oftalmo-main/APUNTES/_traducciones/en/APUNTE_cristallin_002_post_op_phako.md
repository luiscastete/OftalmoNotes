---
categoria: apuntes
area: catarata
emoji: 🔍
seccion: Cristallin - Lens
orden_seccion: 21
orden: 2
fuente: OneNote del Dr. Castilla Martí
---
# POST-OP PHAKO

phako dre.cayette

## Post Faco

TOBRADEX

1 drop 3 times a day for 1 month

NEVANAC

1 drop 3 times a day for 1 month

Wearing the helmet only at night for 7 days
