---
categoria: apuntes
area: cornea
emoji: 👁️
seccion: Cornée
orden_seccion: 4
orden: 3
fuente: OneNote del Dr. Castilla Martí
---
# anatomy

The anterior corneal surface has a dioptric power of 48D. The posterior corneal surface has a dioptric power of -5.8D. Therefore the average dioptric power is around 42 to 43D.

3 predominant glycosaminoglycans found in corneal stroma are:

Keratan Sulfate

Chondroitin Sulfate

Dermatan Surlfate

The lens is the most sensitive followed by the cornea - retina and optic nerve.

There is generally a period of 2-3 years before the cataract develops with radiation.

1.1. Anatomy and Physiology

The cornea is a transparent and avascular tissue, responsible for three-quarters of the optical power of the eye (43.25 D, being the total dioptric power of the normal human eye 58.6D).

for its nutrition, it depends on the diffusion of glyco-

sa from the aqueous humor and oxygen that spreads to

through the tear film. Along with this, the periphery

It receives oxygen from the limbo circulation.

The cornea is the body tissue with the highest density

nervous, so disorders such as abrasions

and bullous keratopathy are associated with intense pain,

photophobia and tearing; There are two nerve plexuses

one subepithelial and one deep stromal, innervated

both for the first division of the trigemino.

Measures 10-11 mm in vertical direction and 11-12 mm

in a horizontal direction. Its central thickness has a

average of 540 mm, being thicker towards the pe-

rifle.

1.1.1. composition of the cornea.
