---
categoria: apuntes
area: uveitis
emoji: 🔥
seccion: Immuno-infectio
orden_seccion: 7
orden: 12
fuente: OneNote del Dr. Castilla Martí
fecha: 2024-05-13
---
# p.4-Behcet

Behçet's disease is a recurrent disease of the chronic inflammatory system, of unknown etiology. It is characterized by intraocular inflammation + ulcerations of the oral and genital mucous membranes + skin lesions.

## Epidemiology

MB touches more patients of frequency throughout the Mediterranean and Japan: the ancient Silk Road.

Ocular involvement occurs in approximately 70% of patients with MB. It is bilateral in more than 70% of cases. Posterior involvement/panuveitis is the most common form of uveitis in their patients.

Phthalmological involvement may be the inaugural sign of MB in 10-35% of cases due to recurrent inflamm inflamm, interspersed with acute inflammatory outbreaks.

Classically it affected the young adult from 25 to 35 years old, but it can occur in children. male preponderance.

multifactorial disease. Known for having a genetic predisposition, it is associated with HLA-B51.

## SIGNES OCULAIRES

The patient may have BAV bodies, red eyes, floating unibilaterally.

The ophthalmic diseases of ppal are:

- Anterior uveitis with hypopion
- Retinal necrosis
- retinal vasculias
- Retinal bleeding and edema
- Hyalitis, intravitrenne hemorrhage, capillary ocl suion and retinno neovascularization.

Rare ocular manifestations include: conjunctival PHTE, episcleritis, filamentous keratitis, conjunctivitis, and oculomotor paralysis secondary to neuro-MB.

## Among the inflammatory episodes, the OFTA exam may be normal.
