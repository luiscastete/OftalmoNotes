---
categoria: apuntes
area: cornea
emoji: 👁️
seccion: Cornée
orden_seccion: 4
orden: 25
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-01-30
---
# Dry eye

Inadequate lubrication of the ocular surface

## Symptoms

often bilatable and chronic. Possible acute unilat.

Eyeburn that pejores during the day

Pain, CE sensation, eyestrain, itching.

Photophobie

Larmoiment

Blepharoscophany

Less visual acuity, often intermittent.

Symptoms often disproportionate to clinical signs

Varian BCP from one person to another and are influenced by the type of personality.

## FR

Age, hormonal status: pregnancy, menopause, air conditioning, heating, ventilation, arid or windy climate, smoke, dust, prolonged eye.

## Signs

but < 10 sec

Menisque lacymal <0,5mm et irregulier – marginal tear meniscus (crude measure of the vol of aqueous in tear film) normal is 0.2-0.4mm - in dry eye is <0.25mm.

HC

KPS-Superior punctate keratitis

KPS Fluo Confluent + ---Long-term drought signs

Filaments attached to the corneal surface

Ant or post blepharitis, conjoctivolasis...

## Aetiology

## Sjogren Syndrome (SS)😉

- Autoimmune disorder charact by lymphocytic imnflammation and destruction of lacrimal and salivary glands and other exocrine organs.
- CLASSICAL CLINICAL TRIADA: 1- Dry eye 2-Dry mouth 3-parotid enlargement of the gland.
- \_\_\_
