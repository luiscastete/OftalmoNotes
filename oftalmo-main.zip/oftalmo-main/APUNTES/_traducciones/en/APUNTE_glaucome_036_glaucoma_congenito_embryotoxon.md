---
categoria: apuntes
area: glaucoma
emoji: 🟢
seccion: Glaucome
orden_seccion: 5
orden: 36
fuente: OneNote del Dr. Castilla Martí
---
# Congenital glaucoma Embryotoxon

Embryotoxon is a congenital ocular finding that refers to a visible white line or ring on the periphery of the cornea, just in front of the sclerocorneal limbus, as a result of an abnormality in the Descemet membrane.

## ✅ Quick summary for EBO

- 🔍 Definition: Whitish or grayish opaque line that represents an anterior thickening of the Descemet membrane, visible in the slit lamp as a white line near the limbo.
- 📍 Location: Corneal periphery (more evident in the nasal sector).
- 😶 Asymptomatic: Does not affect vision on its own.
- 🧬 It can be:
  - Isolated (normal variant, up to 15% of the healthy population).
  - associated with syndromes → important as a clinical sign.

## 🔎

## Associated syndromes (Ebo Key)

| Syndrome | Associations |
|---|---|
| Axenfeld-Rieger syndrome | Embryotoxon anterior + iridocorneal synechiae + angle and pupil anomalies + risk of glaucoma |
| Alagille syndrome | Embryotoxon + Cholestasis + Facies Characteristic + Congenital heart disease + Vertebral anomalies |
