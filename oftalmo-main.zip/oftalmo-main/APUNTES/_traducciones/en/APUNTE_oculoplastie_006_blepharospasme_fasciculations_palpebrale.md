---
categoria: apuntes
area: oculoplastica
emoji: 🫥
seccion: Oculo-Plastie
orden_seccion: 3
orden: 6
fuente: OneNote del Dr. Castilla Martí
---
# Blepharospasm / Idiopathic palpebral fasciculations

Blepharospasm Essential Begin - Benign Blepharospasm Essential Benign (BEB)

Blepharospasm (Eyelid Twitching): Causes, Symptoms, and Treatment (patient.info)

Blepharospasm

Secondary? Do you have surface disturbances?

palpebral myoquimie

Att:

Decreased caffeine intake

Improved sleep quality

stress control

Add food supplement Magnesium 250-400mg per day + Vitamin B12
