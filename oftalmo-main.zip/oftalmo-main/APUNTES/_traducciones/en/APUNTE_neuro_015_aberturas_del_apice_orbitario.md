---
categoria: apuntes
area: neuro
emoji: 🧠
seccion: Neuro-Ophta
orden_seccion: 8
orden: 15
fuente: OneNote del Dr. Castilla Martí
---
# Orbital apex openings

## Orbital apex openings

At the apex of the orbit there are three main openings:

1️⃣ Optic Channel

2 ️⃣ Superior Fissure Orbital (SOF)

3️⃣ Lower Fissure Orbital (IOF)

Each connects the orbit with different regions of the skull.

## 1️⃣Optic Channel

- Connect:

- Orbit ↔ middle cranial fossa

- It contains only two important structures:

  - optic nerve (II)
  - ophthalmic artery

- 💡 Very asked:
- The ophthalmic artery does not enter through the sof, it enters through the optic channel.

## 2️⃣Superior Orbital Fissure (SOF)

- Connect:

- Orbit ↔ Cavernous sinus / Middle cranial fossa

- Main structures:

- Inside the Zinn Ring

  - III
  - VI
  - nasociliary (v1)

- outside the ring

  - IV → Superior Oblique
  - Front (V1)
  - Tear (v1)

- Glasses

  - superior ophthalmic vein

- 💡 This explains the upper orbital fissure syndrome.

- Upper orbital fissure and Zinn ring (clinical vision for examination)

- The superior orbital fissure (SOF) communicates the orbit with the middle cranial fossa.
- It is clinically divided according to its relationship with the common tendon ring (Zinn ring), which is the origin of the extraocular rectus muscles.

- 1️⃣Structures above the Zinn ring (extraconals)

- They don't go through the ring.

- nerves:

  - lacrimal nerve (v1)
  - Frontal nerve (V1)
  - Trochlear nerve (IV) → innervates superior oblique muscle

- glasses:

  - Part of the superior ophthalmic vein

- 2️⃣Structures within the ring (intraconals)

- This group is very important for examination because it corresponds to the intraconal space.

- nerves:

  - Superior Division of III →
    - upper straight
    - eyelid elevator
  - Lower division of III →
    - medial rectum
    - lower straight
    - lower oblique
  - Nasociliary nerve (V1)
  - Nerve abducens (VI) → innervates the lateral rectus muscle

## 3️⃣Structures below the ring

- Upper or lower ophthalmic vein (variable)
- sympathetic fibers of the carotid plexus

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## Quick rule to remember

## outside the ring

- IV
- frontal
- Tear

## inside the ring

- III
- VI
- nasociliary

## important syndromes

## 1 ️⃣Upper orbital fissure syndrome

Affects:

- III
- IV
- VI
- V1

Clinic:

- Ophthalmoplegia
- ptosis
- mydriasis
- Hypoesthesia V1

Causes:

- trauma
- Tumors
- Sinus cavernous thrombosis
- Tolosa-Hunt

## 2️⃣orbital apex syndrome

It is like the previous one but with involvement of the optic nerve.

Affects:

- II
- III
- IV
- VI
- V1

Clinic:

- visual loss
- Ophthalmoplegia
- Anesthesia v1

Frequent causes:

- Mucormycosis
- Orbital tumors
- inflammation
- trauma

## 3️⃣Lower Orbital Fissure (IOF)

Connect:

## Orbit ↔ Pterigopalatine fossa + Infratemporal fossa

Structures:

- Infraorbital nerve (V2)
- Zygomatic nerve (V2)
- Infraorbital artery and vein
- inferior ophthalmic vein
- Pterygopalatine ganglion branches

## Is there a lower orbital fissure syndrome?

Yes, but it is much less classic and less asked.

## Lower orbital fissure

Structures:

- Infraorbital nerve (V2)
- Zygomatic nerve (V2)
- infraorbital vessels
- inferior ophthalmic vein

injury produces:

- Cheek hypoaesthesia
- Lower eyelid hypoaesthesia
- Upper lip hypoaesthesia

frequent in:

- Blow-out fractures

## Quick comparison (very useful for exam)

| Opening | structures |
|---|---|
| Optic channel | II + ophthalmic artery |
| SOF | III, IV, VI, V1 |
| IOF | V2 |
|  |  |

Many teachers sum it up like this:

## 2 – 3,4,5,6 – V2

## Ebo pearls that usually ask

## 1️⃣LR6 SO4 R3

- Side straight → VI
- Superior Oblique → IV
- Rest → III

## 2 ️⃣Most vulnerable nerve in cavernous

👉 VI

Because it is inside the breast, not on the wall.

## 3️⃣Blow-out Fracture

Affects:

- orbital soil
- Infraorbital NERVE (V2)

Clinic:

- Diplopia
- Cheek hypoaesthesia

## 4️⃣Retrobulbar lock

It takes place in the intraconal space.

Block:

- III
- VI
- Ciliary ganglion

May not block IV.

## 5️⃣orbital apex syndrome

Affects:

- II
- III
- IV
- VI
- **V1**

Key Difference with Sof Syndrome:

👉 There is visual loss.

\_\_\_-

## Typical ebo questions about this area

## 1️⃣Anthesia retrobulbar

The needle enters the intraconal space.

Block:

- III
- VI
- Ciliary ganglion

Doesn't always block:

- IV (because it is out of the ring)

That is why sometimes the movement of the superior oblique remains.

## 2 ️⃣Anthesia peribulbar

The needle is extraconal.

Ventajas:

- lower risk of:
  - Eye perforation
  - optic nerve injury

disadvantage:

- slower effect.

## 3️⃣Most vulnerable structure in cavernous

El VI.

because it is free inside the cavernous sinus, while III, IV and V1 go on the wall.

## 4️⃣Fracture blow-out

Affects:

- orbital soil
- Infraorbital nerve (V2)

Clinic:

- Cheek hypoaesthesia
- Diplopia due to entrapment of the lower rectum

## Rapid mnemonics of extraocular muscles (classic EBO)

## LR6 SO4 R3

- Side straight → VI
- Superior Oblique → IV
- Rest → III

Location of orbital lesions (intraconal vs extraconal vs apex)

In the clinical cases of EBO, many questions try to find where the lesion is in the orbit.

The orbit is divided into three key compartments:

1️⃣ Extraconal

2 intraconal

3️⃣ Orbital Apex

The anatomical reference is the muscular cone formed by the extraocular rectus (Zinn ring).

## 1️⃣Extraconal space

Location:

between:

- orbital bone
- Extraocular muscles

that is, outside the muscle cone.

## Typical injuries

- Dermoid Cyst
- Lacrimal Gland Tumors
- extraconal hemangioma
- Orbital abscess

## Typical Clinic

- Proptosis with globe displacement
- non-axial displacement

Example:

Lacrimal gland tumor →

## Inferodially displaced globe

💡 Ebo rule

## extraconal = non-axial proptosis

## 2️⃣Intraconal space

Location:

inside the muscle cone, around:

- optic nerve
- Ophthalmic vessels
- Ciliary ganglion

## Typical injuries

- Cavernous Hemangioma (more classic)
- Schwannoma
- optic nerve meningioma
- metastasis

## Typical Clinic

- axial proptosis
- Progressive visual loss
- late motility alteration

💡 Ebo rule

## Intraconal = axial proptosis

## 3️⃣orbital apex

Location:

back area where they converge:

- Optic channel
- superior fissure orbital

Structures:

- II
- III
- IV
- VI
- V1

## Orbital apex syndrome

Clinic:

- visual loss
- Ophthalmoplegia
- Anesthesia v1
- ptosis

Classic Causes:

- Mucormycosis
- Tumors
- inflammation
- trauma

## Case 1

Axial proptosis, progressive, without pain.

👉 Cavernous intraconal hemangioma

## Case 2

Proptosis with inferomedial displacement of the globe.

👉 Lacrimal gland tumor (extraconal)

## Case 3

Vision ↓ + Ophthalmoplegia.

👉 Apex Syndrome Orbital

## Quick table for exam

| compartment | Typical find |
|---|---|
| extraconal | Non-axial proptosis |
| intraconal | axial proptosis |
| orbital apex | Visual loss + ophthalmoplegia |

💡 Pearl very questioned

The most common benign orbital tumor in adults is:

👉 Cavernous Hemangioma

and is usually intraconal.

## axial proptosis

Axial proptosis means that the eyeball moves directly forward, without deviating up, down, medial, or lateral.

That is to say:

👉 The eye goes straight forward following the visual axis.

This typically occurs when the lesion is within the orbital muscle cone (intraconal space).

## Why does it happen?

The four rectus muscles form a muscle cone around the optic nerve.

If a mass appears inside that cone, push the balloon symmetrically forward.

That is why the displacement is straight (axial).

## Typical lesions that produce axial proptosis

The most classic:

- Orbital cavernous hemangioma (very typical exam)
- optic nerve tumors
- Intraconal schwannoma
- Intraconal metastases

## Difference with non-axial proptosis

## Non-axial proptosis (eccentric)

Here the eye does not come out straight, but moves in a specific direction.

This occurs when the injury is outside the muscle cone (extraconal).

Classic example:

## lacrimal gland tumor

- It is superolateral
- Push the eye inferodially

## Quick Rule of Examination (Fully Used in EBO)

| type of proptosis | probable location |
|---|---|
| Axial | intraconal |
| not axial | extraconal |

💡 Pearl very questioned

The most common benign orbital tumor in adults:

👉 Cavernous hemangioma

and typically produces slow and progressive axial proptosis.

\_\_\_\_

How to differentiate thyroid proptosis, tumor and vascular (key for clinical cases EBO)

In clinical cases of EBO, they often describe proptosis and you should deduce the cause according to clinical + evolution + accompanying signs.

The three most asked causes are:

- Thyroid (severe orbitopathy)
- tumor
- vascular

## 1️⃣Thyroid proptosis (thyroid orbitopathy)

Cause: Graves' disease.

Typical features:

- Bilateral (frequent)
- axial
- Slow evolution
- Palpebral retraction
- Lid Lag
- Motility limitation (mostly lower straight)
- Corneal exposure

In image:

- thickening of extraocular muscles
- respect for tendons

💡 Classic exam phrase:

## “muscle belly enlargement with tendon sparing”

## 2️⃣Tumoral proptosis

usually caused by orbital mass.

Features:

- unilateral
- progressive
- painless
- It can be axial or non-axial

Typical example of the EBO:

## cavernous hemangioma

Findings:

- adult
- Slow axial proptosis
- late visual loss

## 3️⃣Vascular proptosis

Here the key is that proptosis changes with blood flow.

## Carotid-cavernosa fistula

Features:

- Pulsatile proptosis
- KEMOSIS
- Conjunctival arterialization
- orbital murmur
- Increase intraocular pressure

Classic sign:

## “Red Eye + Pulsatile Proptosis”

## Orbital Varix

Features:

- intermittent proptosis
- It appears with Valsalva
- Increases by bowing your head

This happens because the orbital veins are filled.

## Comparative table (very useful for examination)

| Type | Features |
|---|---|
| thyroid | Bilateral, axial, thickened muscles |
| tumor | unilateral, progressive |
| Vascular | Pulsatile or intermittent |

## Clues that usually appear in ebo questions

## yes they say

## Bilateral proptosis + palpebral retraction

👉 Thyroid orbitopathy

## yes they say

## Pulsatile proptosis + chemosis

👉 Carotid-cavernous fistula

## yes they say

## proptosis that appears with Valsalva

👉 Orbital Variz

## yes they say

## Slow axial proptosis in adults

👉 Cavernous hemangioma

💡 Pearl very questioned

The most affected muscle in thyroid orbitopathy is:

👉 Lower straight

Classic order:

## I’M SLOW

- lower rectus
- medial rectus
- Superior Rectus
- Rectus side
- obliques (rare)

\_\_\_
