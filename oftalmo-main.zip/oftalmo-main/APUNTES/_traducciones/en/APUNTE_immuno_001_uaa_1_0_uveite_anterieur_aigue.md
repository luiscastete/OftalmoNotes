---
categoria: apuntes
area: uveitis
emoji: 🔥
seccion: Immuno-infectio
orden_seccion: 7
orden: 1
fuente: OneNote del Dr. Castilla Martí
fecha: 2022-09-08
---
# UAA 1.0 - Acute anterior uveitis

When referring to the immune unit:

-Severe uveitis:

- Ca 3+ or hypopion cells.
- not to see
- Hyalitis associates

-Av <0.8 (oct)-ref If OMC.

-HTIO >25mmHg.

- Recurring shapes.

-Systemic TTT: immunosuppressive or antiviral.

- Pejoration or no response to TTT for 48-92 hours

-Need to introduce systemic TTT or periocular inj.

- Unclear situation.

-HIV +.

-UAA of the child: UAA + white eye: think of idiopathic juvenile arthritis and care for the Raèpide need and specialize. TTT: PF 1% 3-6XJ Max + Scopo 0.25 Yes >6 years, Tropi 0.5% Yes >

TOUJOURS!

Exclude posterior attack: vitrito, chorioretinal focus, peripheral vasculitis, snowballs and flat pars snowbaking.

## state balance

- corrected av
- TIO
- CA CLASSIFICATION
- Vitré evaluation
- To dilate bilateral.--If you can't see, contact CDC.
- Oct pole

| TYPE UAA | -non-granulomatous,<br>and unilateral<br>and first episode<br>and simple clinic | -Granulomatous<br>and/or bilateral<br>and/or recurring<br>and/or severe clinic<br>(it is more corticosteroid) | - Herpetic granulomatous (HSV or VSV) |
|---|---|---|---|
| BILAN | HLA-B27<br>Bilateral OCT if AV<0.8<br>+/- Add immunological questionnaire | FSC, VS, CRP, CA2+ corrected, Lisozyme, ECA, IL-2R.<br>VDLR, TPHA.<br>TB-spot/ Quantiferon.<br>Bartonella (not refunded)<br>Borreliosis<br>+/- RX chest vs TC-Scan chest<br>+/- bilateral OCT if AV <0.8.<br>+/- -Add immunological questionnaire | It does not balance herpes because + in 99% of the population. : NB can be useful in the child.<br>Bilateral OCT if AV <0.8.<br>+/- -Add immunological questionnaire |
| Treatment | PF 1% in hours + Scopolamine GTT 0.25% 3xJ + Ultracortenol ointment 1xJ at night<br>*François: Do you prefer Tropi because it is Boca + and avoids wider synegias? )<br>Pred Forte GTT Opht<br>In hours for 2 days<br>8x/d for 5 days then<br>6x/d for 5 days then<br>4x/day for 5 days then<br>3x/day for 5 days then<br>2x/day for 5 days then<br>1x/day for 5 days.<br>Tropicamide<br>2x/day for 7 days<br>Ultracortenol POAM<br>1xD at night before sleeping for 7 days | PF 1% 3xJ + scopolamine 0,25% 3xJ | Valtrex Cpr for OS 500mg 3xj PDT The entire duration of the cortis.<br>If Htio >25mmHg: Add Cosopt 2xj +/- Iopidine 0.5% 3xj +/- Diamox per OS (250 vs 500mg depending on weight and kidney function) depending on the degree D Htio E ICS (sulphamide allergies, asthma, IR, Stevenson-Johnson syndrome... |
| Follow-up | In 48 hours (in uveitis consultations?) | In 24h or 48h | in 48 hours |
| Treatment | If the favorable evolution:<br>PF 1% in hours + scopolamine 3XJ + UCP at night | If the favorable evolution:<br>PF 1% 3XJ+ Escopolamine 3XJ | If the favorable evolution:<br>Valtrex Cpr for OS 500mg 3xj PDT The entire duration of the cortis. |
| Follow-up | cô in 96h-d4 | cô in 96h-d4 | cô in 96h-d4 |
| Treatment | If the favorable evolution:<br>PF 8XJ PDT 3-7J, 6XJ PDT 3-7J, 4XJ PDT 3-7J, 3XJ PDT 3-7J, 2XJ PDT 3-7J, 1XJ 3-7 days and then stop.<br>If you calm down:<br>STOP UCP<br>Stop scopolamine and add Tropi 0.5% 2x/night<br>Tropi around 6-9 p.m., inducing a shorter and less annoying mydriasis. Attention because the tropi does not induce a cyclopegia don does not eliminate the pain secondary to ciliary spasm. | If the favorable evolution:<br>PF 3xJ PDT 2-3 SEM, 2XJ PDT 2-3 SEM, 1XJ PDT 2-3 SEM and then stop.<br>If you calm down:<br>Stop scopolamine 0.25% and add Tropi 2xJ/Even | If the favorable evolution:<br>Valtrex 500mg ( 1g IF VZV ) 3xJ PDT Any duration Cortis + PF 3xJ PDT 2-3 weeks, mp 2xJ PDT 2-3 weeks, mp 1xj for 2-3 weeks and then stop.<br>If you calm down:<br>Stop Scopo and add Tropi 2xJ PDT at night |
| Follow-up | cô at 1-2 weeks. | cô at 1-2 weeks. | cô at 1-2 weeks.<br>The arrest of PF or TT antivirals deepen the risk of recurrence and the location of LEA injury in the case of a disciplinary case. A Valtrex TT can be kept for life. The use of Cortis requires the maintenance of a topical or systemic antiviral TT. |
