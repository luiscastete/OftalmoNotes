---
categoria: apuntes
area: uveitis
emoji: 🔥
seccion: Immuno-infectio
orden_seccion: 7
orden: 14
fuente: OneNote del Dr. Castilla Martí
fecha: 2024-05-13
---
# p.2 -Vogt-Koyanagi-Harada / VKH

It is an inflammatory uveo-meningitis of autoimmune (against tyrosine-related proteins).

Associate an attack:

- neurological
- Ophthalmic
- dermatological

## Etio and Epidemic

melanoderm patient

between 20-50 years

HLA-DR4, DRW53 and DQW7

## Symptoms

They depend on the phase of the disease:

- -Prodromal phase:
  - Meningeal syndrome - 80%
  - dysacusis
  - Dizziness

- -Acute uveitis phase:
  - Bilateral and fast VAT
  - serous detachment of the retina -DSR
  - hyalite
  - daddy
  - retinal vasculitis
  - UAA
  - detachment of the ciliary nuclei

- - Chronic phase - In absence TT:
  - Depigmentation fo: appearance at sunset
  - Rounded choroid spots
  - Pigment migrations
  - Subretinal fiberosis
  - Vitiligo Periligo- Sign of Sugiura
  - Extraophthalmological signs: alopecia, vitiligo, poliosis

- -Chronic recurring phase:
  - Anterior chronic synechial granulomatous uveitis

  - Rare posterior recurrence
