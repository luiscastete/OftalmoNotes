---
categoria: apuntes
area: glaucoma
emoji: 🟢
seccion: Glaucome
orden_seccion: 5
orden: 14
fuente: OneNote del Dr. Castilla Martí
---
# 🧬 Glaucoma associated with intraocular tumors

## 🧬 Glaucoma associated with intraocular tumors

## ✅Generalities

• It affects approximately 5% of the eyes with intraocular tumors.

• It is a secondary glaucoma due to varied mechanisms, which can coexist and are not always clinically distinguishable.

## 🔍 Pathophysiological mechanisms

## 1. Direct Trabecular Block

| Mechanism | Description | Comments |
|---|---|---|
| 🔸 Angle invasion | for solid tumor, eg. Iris melanoma | Tumor mass physically obstructs drainage |
| 🔸 Trabecular infiltration | by tumor cells (iris melanoma, retinoblastoma) | weirder, but can cause increased IOP |
| 🔸 Melanomalytic glaucoma | Pigment-laden macrophages and tumor cells clog the trabeculus | Similar to phacolytic glaucoma, it usually occurs with melanomas |
|  |  |  |

## 2. Secondary angular closure

| Mechanism | Examples | Comments |
|---|---|---|
| 🔹 Neovascular glaucoma | associated with choroidal melanoma or retinoblastoma | It is the most common mechanism in these cases. |
| 🔹 Previous displacement of the iris-lens diaphragm | by melanoma of the ciliary body or large posterior tumor | Pushes anterior structures → Angle closure |
|  |  |  |

## 🧠 Fast flashcards
