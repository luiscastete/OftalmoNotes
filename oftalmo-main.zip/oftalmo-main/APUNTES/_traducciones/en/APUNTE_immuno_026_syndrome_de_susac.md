---
categoria: apuntes
area: uveitis
emoji: 🔥
seccion: Immuno-infectio
orden_seccion: 7
orden: 26
fuente: OneNote del Dr. Castilla Martí
fecha: 2024-05-22
---
# Susac syndrome

Rare autoimmune disease affecting small blood vessels in the brain, retina and inner ear.

It is also known as retinococleocerebral angiopathy. This condition was first described by Dr. John Susac in 1979.

The main symptoms of Susac syndrome include:

- Encephalopathy: Patients may experience cognitive impairment, behavioral changes, headaches, walk disorders, and seizures.

- Arterial retinal occlusions: They can lead to loss of partial or total vision in one or both eyes.

- Hearing loss: Sensorineural hearing loss, often asymmetrically, and accompanied by dizziness or tinnitus may occur.

The diagnosis of SUSAC syndrome is based on a combination of clinical criteria, imaging (such as brain MRI), and complementary tests such as retinography and hearing tests. Magnetic resonance imaging can show specific lesions in the corpus callosum and arterial retinal occlusions may be observed during an ophthalmic examination.

Treatment of Susac syndrome usually involves immunosuppressants and corticosteroids to control inflammation and prevent recurrences. Multidisciplinary attention is often necessary, involving neurologists, ophthalmologists and otorhinolaryngologists.

## Rare disease depending on the teacher (3 cases in 20 years)

## The Japanese we saw is probably a BCP Plus Freq behçet
