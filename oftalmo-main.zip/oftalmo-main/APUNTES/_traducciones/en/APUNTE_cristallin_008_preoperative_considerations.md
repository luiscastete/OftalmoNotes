---
categoria: apuntes
area: catarata
emoji: 🔍
seccion: Cristallin - Lens
orden_seccion: 21
orden: 8
fuente: OneNote del Dr. Castilla Martí
---
# Preoperative considerations

## Indications for surgery

- visual improvement
- Medical indicaction

## Systemic preoperative assesment

- 1 - Current medicatio should be recorded

  - MEDICATION RELEVANT TO EYE SURGERY:

    - Systemique alfa-blockers ( TAMSULOSIN)
      - Are asssoc with intraoperative floppy iris syndrome (IFIS).

    - Anticoagulant theraphy or antiplatelet agent should follow local protocol. Most not stop stop for cataract surgery but yes in oculoplastic or glaucome surgery. - it scommon to check INR within the 24h prior surgery.

- 2 - Allergy (not intolerance)
  - Medication: sulfonamides and atb sommonly used following cat surgery.
  - Iodine or shellfish - the letter may indicate an iodine allergy. If allergy to iodine is present an alterantive is chlorhexidine.
  - Others: allergies to latex.

- OPTHALMIC PRE-OPERATIVE ASSESMENT

  - VISUAL ACUITY
  - COVER TEST - amblyopia?
  - PUPILLARY REPONSE
  - OCULAR ADNEXA - if any inflamation or tear film anormality may predispose to endophtalmitis - treat condition prior to intraocular surgery!-CORNEA - suspicion diminution of  endothelial cell counts? Add Specular microscopy and pachymetrie
  - ANT CHAMBER - Tamsulosin? Poor pupille dilatation? Planify surgery if suspected IFIS.
  - LENS - id back nuclear opacities extremelly dense and maybe prefered extracapsular extraction - PSEUDOEXFOLIATION syndrome may indicate weak zonules - phakodonesis - lens wobble - a fragile capsule and poor mydriasis
  - FUNDUS EXAMINATION- if nor possible make ultrasonography - i would do also OCT mac and NO.
  - SCLERA - if encircling band has been placed during prior retina detachment surgery or if the eye is paarticulary large and sclera thin(myopia forte) peri and retrobulbar local anesthesia should be avoided - go general anesthesia.
  - CURRENT REFRACTIVE STATUS- keratometry readings made during the Biometry should be noted -if toric implant may be placed.

  - Pg 316 - probabilities of complications - good data
