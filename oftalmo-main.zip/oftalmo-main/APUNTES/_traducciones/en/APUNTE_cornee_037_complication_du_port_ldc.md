---
categoria: apuntes
area: cornea
emoji: 👁️
seccion: Cornée
orden_seccion: 4
orden: 37
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-08-10
---
# Port Complication PMA

## COMPLICATION INFECTIEUSE

## FR

General: DM, corticosteroids, immunosuppressants

Local: blepharitis, dry eye, corneal hypoaesthesia.

Not respecting hygiene and e-retention instructions, not respecting the time of use.

## Aetiology

bacterial

Amoebia (pools, lake...)

Mushrooms (diabetes, alcoholism, immunosuppression...)

## TT

-------> Consult infectious keratitis.

## COMPLICATIONS ALLERGIQUES

- 1. Gigant-papillary conjunctivitis

- FR:
- early age
- very long use time.
- Lens covered with tanks, not very frequent renovation, large diameter.
- Insufficient cleaning system.

- Symptoms
- Often with soft LDC
- Progressive intolerance to the lens, forcing premature abstinence during the day.

- Signs
- (Eversion eyelids sup)
- Stage 1: Mild hyperemia
- Stage 2: Clearly visible papillae <0.5mm.
- Stage 3: 1 mm diameter papillae.

- TT:
- Anti-allergic drops Ex: Opatanol 2xJ PDT 10-15J.
- Lens type change, maintenance product change.

- 2. Allergies to cleaning products (conservatives, enzymes, antiseptics)

- TT:
- Promotes the daily port of PMA.

## COMPLICATION MECANIQUES

- 1. Syndrome 3 hours - 9 hours (specific for rigid lenses)

- ETIOLOGIES VARIABLES
- Relative eye dryness, defective flicker, poor lens geometry (too much support on the edge).

- Symptoms
- Stage 1: KPS at 3 and 9 no coalcensus injuries.
- Stage 2: KPS with coalescent but no deep layered fluorescent diffusion
- Stage 3: Dense localized KPS.
- Stage 4: Localized opacification or neovascularization.

- TT
- Changes in lens geometry, radius (in the flattening direction), diameter (larger or small)

- Consequences of a deterioration of the lens (tear/deposit).

- Signs
- Superficial corneal neovascularization.

- TT
- Use thinner daily LDC and higher DK/E ratio, or switch to rigid LDC port.

## COMPLICATIONS INFLAMMATOIRES

- Aetiology
- immune reaction
- related to the use of LDC or endotoxins of bacteria, or combination of the two.

- Signs
- Normally peripheral infiltrates often without epithelial deficiency

- TT
- At first: Topical antibiotics, lubricants
- In the tenth time: +/- Topical cortis.
