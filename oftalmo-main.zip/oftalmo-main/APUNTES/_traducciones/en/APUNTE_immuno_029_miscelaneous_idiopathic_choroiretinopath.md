---
categoria: apuntes
area: uveitis
emoji: 🔥
seccion: Immuno-infectio
orden_seccion: 7
orden: 29
fuente: OneNote del Dr. Castilla Martí
---
# Miscelaneous Idiopathic Choroiretinopathies

PIC - PUNCTATE INNER CHOROIDIOPATHY -pg 497 KANSKY

PIC affects young myopic women. Both eyes are involved in 80%-assymetrically. It is likely to be a form of IMC but involving the macula.

Symptoms

Blurring, scotoma, floaters and photopsia.

Ant uveitis and vitritis ABSENT.

FUNDUS: Several small yellow-white macular spots with fuzzy borders at the leel of the inner choroid and retina +/- serous sensory detachment --->sharpy demarcated atrophic scars with little pigmentation.

PROGNOSIS:

Central vision may be compromised by lesion at fovea or by MNV (40%). Visual acuity improves to 6/7.5 in 50%.

INVESTIGATIONS

VS: enlargment of blind spot + central or paracentral scotomas.

FAF : hypo and hyperautofluorescence spots

FA : MNV

OCT-A/OCT : MNV

ICG

TT:

No treatment advised unless there is evidence of MNV if in the macular region add anti-VGF.

Steroids and szstemic immunosupression can be helpful in the management of recurrent CMV.
