---
categoria: apuntes
area: oculoplastica
emoji: 🫥
seccion: Oculo-Plastie
orden_seccion: 3
orden: 3
fuente: OneNote del Dr. Castilla Martí
---
# Benign palpebral lesions

## 🟣2.18. melanocytic nevus

## Definition

- Third most frequent benign lesion in the periocular region (after papillomas and epidermal cysts).
- Origin: Grouping of neucos (undifferentiated melanocytes) in epidermis and dermis.

## 🔹 Types

## 📌 Congenital

- uncommon. Generally small, but they can be extensive.
- Uniform color. Histology similar to those acquired.
- Variant: Nevus in kiss → affects upper and lower eyelids; can contain hair.

## Management

- Asymptomatic: They do not require treatment.
- Resection indications: Growth, malignant transformation or aesthetic impact.
- Technique: Shaving or wedge excision.

## 📌 Acquired

Classified by histological location → represent evolutionary phases:

| Phase / Type | Description | typical age | malign potential |
|---|---|---|---|
| 🔸 JUNTURAL NEVUS | Flat macula, homogeneously pigmented. cells in dermoepidermal junction. | Young | Low-moderate |
| 🔸 Composite nevus | Elevated and pigmented lesion. cells at union + dermis. | Middle age | Low |
| 🔸 Intradermal nevus | Elevated lesion, sparsely pigmented (often amelanotic). only in dermis. | Old men | Null |

## 🟣2.22. Dermal melanocytosis (OTA nevus)

## Definition

- Congenital blue nevus.
- It affects the skin of the eyelid (blue-gray coloring), with possible extension to the frontal region.

## Etiopathogenesis

- Proliferation of dermal melanocytes in the territory of the 5th cranial nerve (1st and 2nd dermatome).

## Epidemiology

- Most common in women of African, Asian or Hispanic origin.

## Associated variant

- Oculodermal melanocytosis: affects skin + uvea + episclera.
- Risk of malignancy (melanoma): 1/400 cases.

## Treatment

- There is no curative treatment; Periodic follow-up is indicated for the risk of ocular malignancy.

## 🟣2.25. capillary hemangioma

## Definition

- Congenital benign vascular tumor, more common in the upper eyelid.
- It can extend to the orbit.

## Etiopathogenesis

- Unilateral proliferation of vessels in dermis and subcutaneous tissue.
- Bright red, it increases with tears and whitens with pressure (typical sign).

## CLINICAL COURSE

- It appears in the first months of life.
- rapid growth during the first year.
- progressive involution between the following 4 and 5 years.

## Complications

- can cause:
  - Mechanical ptosis
  - amblyopia due to deprivation
  - anisometerpy
  - Squint

## Treatment

- Indications: Risk of amblyopia or visual compromise.
- Choice of choice:→ Intralesional corticosteroid injections.

## 🟣2.26. Port wine stain

## Definition

- Congenital, unilateral subcutaneous cavernous hemangioma.
- Defined edge pink lesion → darkens over time (purple color).
- Does not bleach with pressure (different from capillary hemangioma).

## associated syndrome

- It can be part of Sturge-Weber syndrome→ encephalo-trigeminal angiomatosis (neurological + ocular involvement).

## Management

- Aesthetic: Laser.
- Neurological and ophthalmological: multidisciplinary follow-up.
