---
categoria: apuntes
area: neuro
emoji: 🧠
seccion: Neuro-Ophta
orden_seccion: 8
orden: 22
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-03-06
---
# Ophthalmic migraines

## Clinical presentation

## Visual auras

- Recurring episode, completely reversible.
- Gradual appearance >5min.
- Symptoms <1h, often 30 min.
- accompanied or followed within 60 minutes of a headache.
- Binocollar events.
- Visions of positive phenomen:
  - Scotoma scotoma (typical),
  - phosphenes,
  - bright lines.
  - Kaleidoscopic vision
- Negative visual phenomena:
  - blurred vision,
  - Mistym homonymous lateral hemianopsia.
- Visual hallucinations (children)
- persist with firm eyes.

## headache

- occur before, PDT or after (90% of cases) will have visual.
- Visual auras can be accompanied by:
  - Migraine headaches*
  - Non-migratory headaches
  - Absence headache.

## Migraine headaches (ICHD-3 criteria)

- Typically unilateral, but can be bilateral.
- often temporary seat.
- Pulsatile pain, of moderate intensity in severe, aggravated by physical activity, accompanied by nausea or vomiting, photophobia and phonophobia. It lasts 4-72 hours.
