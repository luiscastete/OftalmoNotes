---
categoria: apuntes
area: neuro
emoji: 🧠
seccion: Neuro-Ophta
orden_seccion: 8
orden: 18
fuente: OneNote del Dr. Castilla Martí
fecha: 2024-07-20
---
# Horner - Claude Bernard Horner Syndrome

### Pathophysiology of Horner's syndrome

Horner syndrome is the result of a disruption in the sympathetic pathway that innervates the eye and the periorbital region. The sympathetic ocular pathway is a route of three neurons, and interruption can occur at any of these levels, leading to the characteristic signs and symptoms of Horner's syndrome.

#### Anatomy of the sympathetic pathway

1. First neuron (central):

- It originates in the hypothalamus and descends through the brainstem to the level of C8-T2 in the spinal cord, known as the ciliospinal center of Budge.

2. Second neuron (pre-ganglionic):

- It leaves the spinal cord at the level of C8-T2 and travels through the paravertebral sympathetic chain to the superior cervical ganglion.

3. Third neuron (post-ganglionic):

- From the superior cervical ganglion, the post-ganglionic fibers follow the internal carotid artery, enter the skull and reach the eye. These fibers innervate the dilator muscle of the pupil, the Müller muscle (upper eyelid elevator) and the facial sweat glands.

#### Causes of Horner Syndrome

Depending on the level of the injury, the causes can vary considerably:

1. First neuron lesion:

- Stroke

- Tumors (e.g., gliomas)

- trauma

- multiple sclerosis
