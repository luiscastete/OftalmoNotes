---
categoria: apuntes
area: uveitis
emoji: 🔥
seccion: Immuno-infectio
orden_seccion: 7
orden: 22
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-02-15
---
# Ophthalmic Herpes (Herpes Zoster) / Keratitis in VZV

## ZONA OPHTALMIQUE

It corresponds to a recurrence of the VZV virus after a primary infection in childhood-Vacricellus.

After the prodrome headache phase, dysthesia, fever. Innervation of the frontal nerve, branch of the ophthalmic nerve V1- Branch of the trigeminal nerve v.

The shingles (herpes zoster) are found in an infection that appears when the latent varicella-zoster virus (VZV) is reactive in a ganglion of the posterior spinal root sensory nerve.

Ophthalmic herpes (herpes zoster) results from damage to the Gasser ganglion.

Chickenpox and tiles (Herpes zoster) are caused by the chickenpox virus-zoster (Human Herpes Virus 3)

Chickenpox is the primary acute phase of viral disease.

The zone (herpes zoster) is the reactivation of the virus of the latent phase.

Viral infection of the eye and its annexes that initially manifests itself by rash and pain that affect the dermatoma of the V1 nerve.

## When to refer to Immuno?

If ocular involvement, AUA, afferent defect, hyalitis, oculomotricity involvement, acute retinal necrosis.

## Symptoms

- Prodroms:
- (3-5D before eruption) Discomfort, febrile state, headache, pain +/- paresthesia throughout the dermatome V1, eye pain.

- Cutaneous: unilateral eruption in the path of the V1 nerve (lower palpebral border).

- Eyes: BAV, feeling of pressure, feeling of sand or CE, pain, tears, photophobia and redness of the eyes.
