---
categoria: apuntes
area: glaucoma
emoji: 🟢
seccion: Glaucome
orden_seccion: 5
orden: 33
fuente: OneNote del Dr. Castilla Martí
---
# Drugs 2.0

📘 Notes on Ophthalmology – Drugs to reduce IOP

All treatments seek to reduce intraocular pressure (PIO) through two main pathways:

- 1. Reducing the production of aqueous humor
- 2. Increasing your drainage

1️⃣ Drugs that decrease the production of aqueous humor

| Group | Examples | Mechanism |
|---|---|---|
| Beta blockers 🧊 | Timolol, betaxolol | They inhibit β2 receptors in ciliary processes |
| α2 agonists 🔺 | Brimonidine, apraclonidine | ↓ Production and ↑ Uveoscleral drainage |
| Carbonic anhydrase inhibitors 💧 | Dorzolamide, brinzolamide, acetazolamide | They inhibit aqueous humor formation |

2️⃣ Drugs that increase the drainage of aqueous humor

| Group | Examples | Mechanism |
|---|---|---|
| Prostaglandins 🌙 | Latanoprost, bimatoprost | ↑ Uveoscleral drainage (M.E. remodeling) |
| Colinergics (myotics) 🧠 | Pilocarpina | Contraction of the ciliary muscle → ↑ Trabecular drainage |
| Rock Inhibitors 🚧 | netarsudil | Relax Trabeculus → ↑ Trabecular Drainage |

3️⃣ Frequent combinations

They are used to improve adherence and enhance effects:

- Timolol + Dorzolamide
