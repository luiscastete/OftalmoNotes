---
categoria: apuntes
area: cornea
emoji: 💧
seccion: Conj + Episclere + Sclere
orden_seccion: 25
orden: 8
fuente: OneNote del Dr. Castilla Martí
---
# C. Autres others

## 2.4. Other conjunctivitis

## 2.4.1. Parinaud's oculoglandular syndrome

## Etiology

The most common cause is cat scratch disease, caused by Bartonella henselae. Other etiologies include Francisella tularensis, Sporothrix schenckii, mycobacteria and Chlamydia trachomatis (Serotypes L1-L3).

## Clinic

Unilateral granulomatous conjunctivitis with painful regional lymphadenopathy and mild systemic symptoms.

## Diagnosis

based on clinical history and serology. PCR can be useful in specific cases.

## Treatment

Systemic antibiotics such as doxycycline or azithromycin. In complicated cases, combinations with rifampin or trimethoprim-sulfamethoxazole can be considered.

## 2.4.2. Reiter syndrome (reactive arthritis)

## Etiology

It is a reactive spondyloarthropathy associated with genitourinary (for Chlamydia trachomatis) or gastrointestinal (Salmonella, Shigella, Yersinia, Campylobacter) infections.

## Clinic

Classic triad of conjunctivitis, urethritis and arthritis. Conjunctivitis is usually bilateral, with mucopurulent secretion, and can be associated with anterior uveitis.
