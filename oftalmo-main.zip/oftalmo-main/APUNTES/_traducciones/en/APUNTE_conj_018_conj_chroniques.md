---
categoria: apuntes
area: cornea
emoji: 💧
seccion: Conj + Episclere + Sclere
orden_seccion: 25
orden: 18
fuente: OneNote del Dr. Castilla Martí
---
# Conj Chroniques

Infectious agents that can cause chronic conjunctivitis (≥4 weeks duration) are less common than acute ones, but important due to their prolonged or recurrent evolution. Here are the main ones:

🔴 1. Chlamydia trachomatis

🟠 2. Neisseria Gonorrhoeae

🟡 3. Virus (less frequent in chronicity)

🟢 4. Mycobacterium tuberculosis
