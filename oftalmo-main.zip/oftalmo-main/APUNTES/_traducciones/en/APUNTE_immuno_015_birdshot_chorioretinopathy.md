---
categoria: apuntes
area: uveitis
emoji: 🔥
seccion: Immuno-infectio
orden_seccion: 7
orden: 15
fuente: OneNote del Dr. Castilla Martí
---
# Birdshot Chorioretinopathy

## 📌2.2.7. Chorioretinopathy in Perdigonada (Birdshot Chorioretinopathy)

## 🧠Etiology and general characteristics

- Type: Bilateral granulomatous multifocal choroiditis.
- Age group: middle-aged adults 40s.
- Genetic Association:
  - HLA-A29 positive in >90% of cases.
  - Increases risk x224 (present in ~7% general population).
- Not associated with systemic pathology.

## 👁️ Clinic

- Symptoms:
  - blurred vision
  - Myodespsies
  - Nyctalopia
  - Alteration in color vision

- Signs:
  - little or no inflammation in the anterior segment.
  - vitritis in variable degree.
  - Whitish choroidal lesions, creamy, irradiating from the optic nerve.
    - best visible in indirect ophthalmoscopy.
    - They are not pigmented over time.
  - In acute phase: non-occlusive retinal vasculitis, papillitis and cystic macular edema (EMQ).
