---
categoria: apuntes
area: cornea
emoji: 💧
seccion: Conj + Episclere + Sclere
orden_seccion: 25
orden: 21
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-10-04
---
# scleritis

inflammation of sclerosis

Uncommon pathology

f>h 40-60 years

>50% bilateral commitment

50% associated with systemic involvement:

- >50% of nodular scleritis
- 25% diffuse ant scleritis
- 70-95% necrotizing scleritis (PR+)
- 30% posterior scleritis

## CLASSIFICATION

- anterior scleritis:
  - non-necrotizing:
    - spread 50%
    - Nodular 25%
  - Necrosing:
    - with 10% inflammation
    - No inflammation 5%

- Posterior scleritis: 10%

Refer all scleritis before investigations immediately in a specialized unit!!!

## Symptoms

## Ant scleritis

- Non-necrotizing (diffuse and nodular) and necrotizing with inflammation.
- Acute or subacute appearance
- Pain >6/10, insomnia, with irradiation in the jaw, temples and scalp.
- touch-sensitive balloon
- Necrotizing without inflammation (scleromalacia perforating and non-inflammatory).
- Light irritation, painless, vision preserved.

## posterior scleritis

- Pain 6/10, pejoría to eye motility
- Photophobie
- Bav, Diplopia

## Signs

Ant scleritis:

## Non-necrotizing (diffuse and nodular)

- Sectoral or diffuse redness, with deep scleral dilation vssx.
- Isolated or multiple scleral nodule (nodular scleritis)
- Examine LAF: Non-mobilizable nodule with cotton swab (nodular scleritis), ant surface. of elevated sclera (unlike episcleritis)
- Chemiosis, edema with palpebral
- Others: HTIO, UAA, cataract, secondary corneal damage (puk, keratisclerosing), secondary astigmatism with scleral thinning.

## Necrotizing with and without inflammation (scleromalacia perforators)

- Progressive thinning of the sclera, with exposure of the underlying VU: bluish appearance of the sclera, better visible to natural light.
- Scleral necrotic plates near the limbo, which widen and become coalescing. Vascularization decreased or disappeared in the area of necrosis.
- Balloon drilling = rare but possible. EMERGENCY!!

## posterior scleritis

- Papillary oedma, choroidal folds, exudative DR, uveal effusion with choroidal detachment, macular edema, granulomas under retina +/- vitrito, retinal hemorrhages.
- Quick start hyperopia
- Myositis with ocular motility restrictions
- +/- associated with anterior scleritis.
- +/- htio, periorbital edema, exophthalmia, ptosis, chemiosis.

## Aetiology

- Associated with systemic diseases >50%

  - Inflammatory disease – in order of frequency:
  - Rheumatoid arthritis - PR
  - Systemic vasculitis:
    - Granulomatosis with polyangiitis - Wegener's disease, PAN, Takayasu, Horton, Behçet.
    - Systemic lupus erythematosus - LED
    - Atrophic polychondritis
  - Spondylartropatitis:
    - Ankylosing spondylitis, arthritis-reiter reaction syndrome, psoriatic arthritis.
    - Sarcoidosis, IgG4 syndrome...
  - Infections - 7% patients:
    - Herpes simplex, VZV, tuberculosis, syphilis, borreliosis, Bartonella, lepre...
  - Metabolic disorders: gout, pophyria.

  - Local causes:
  - Trauma, surgery-induced necrotizing scleritis-surgery
  - Local infection: Oseudomonas, Aspergillus, Fusarium, sporontricose, often scxlero-keratitis.

## Examination

av-tio-laf-fo dilated

## BILAN

DX CLINIQUE

Phenylephrine test 2.5%: Persistence of eye redness.

AUTRE BILAN:

- AA by systemic:

Here is a typical order used in many medical practices:

## general

- Fatigue
- Unintentional weight loss
- Fever, chills
- Night sweat

## Skin

- skin rashes
- Itching (itching)
- sores or ulcers
- Changes in moles

## head and neck

- headache
- Dizziness
- Neck Pain
- mass or swelling

## peepers

- vision disorders
- eye pain
- redness of the eyes
- secretions

## Ears, nose, throat (ent)

- tinnitus
- hearing loss
- Rhinorrhea (nasal discharge)
- Throat pain

## breathing apparatus

- Cough
- Dyspnea (respiratory difficulties)
- sputum (sputum)
- chest pain

## cardiovascular

- chest pain
- palpitations
- lower limb edema
- Syncope (fainting)

## digestive system

- Abdominal pain
- Nausea, vomiting
- Diarrhea, constipation
- Jaundice

## Urinary route

- Dysuria (pain with urination)
- Hematuria (blood in the urine)
- Pollakiuria (frequent need to urinate)
- urinary incontinence

## reproductive system

- Vaginal or penile discharge
- Pelvic pain
- Menstrual disorders
- sexual dysfunction

## Musculoskeletal system

- joint pain
- Muscle weakness
- joint swelling
- Rigidity

## neurological system

- seizures
- memory problems
- Paresthesias (numbing)
- shake

## psychiatric system

- mood disorders
- Anxiety
- Sleep disorders
- hallucinations

## endocrine system

Intolerance to heat or cold

Polyuria (excessive urination)

Polydipsia (excessive thirst)

sudden change in weight

- Following this order, you can ensure a complete and systematic assessment of the patient's health.

Search Sick Associate: Complete evaluation after discussion with the immune unit

2.Laboratory

FSC, VS, CRP, uric acid, Na, K, creatinine, urea, rheumatoid factor, anti-CCP antibodies, anti-fsofolian antibodies, P and C-ANCA, antigen HBV-PAN, ANA, Anti-DNA, Natives, HLA B27, HLA B51.

Ace, Lyzozyme, Corrected Ca2+, IL2-R dose- Sarcoidosis?

TPHA/VDRL-syphilis, TB point, borreliosis serology, Bartonela Henselae if post scleritis and neuroretin. - Non-refunded*

It often requires immunosuppression: predict HIV, HBV, HCV, ASAT, ALAT, urea, creatinine, FSC, VS, CRP.

- If you suspect posterior scleritis:
  - Panoramic photo
  - Oct, Oct – EDI
  - USA: T-sign search, thick scleral, dr, choroidal folds.
- +/MRI/CT Brain orbital sections:
  - Scleral thickening, exophthalmos.
- External ICG
  - Does it make it possible to differentiate scleritis from episcleritis by visualizing vascularization of sclera, determines the presence of necrosis and the signs of active inflammatory vascularitis?
- Biopsy
- They rarely contribute except in cases of infectiousness - attention because the risk of perforation increases if the inflammation.
- Image:
- chest rx-CT-sarcoidosis-TB?
- See the TM or rheumatologist for systemic evaluation.

TT

According to Severita and etiology

Pain: Excellent index of scleritis control

- TT principles for non-necrotizing ant scleritis:

- Local TT:
  - LA 4-6xj
  - Ains: Nevanac 0.1% 3xJ or topical steroids if light is formed – DF 4XJ.
  - CAUTION* Steroids to avoid if perforations and risk care occur if herpetic scleritis

- Systemic TT to discuss with the immune unit:
  - 1st intention NSA systemic- Ibuprofen 400-600mg 3xJ or indomethacin 75mg 2xj. + IPP Pantoprazole 20mg 1xj
- C-I: kidney failure, gastric ulcer, rude elceration...

  - 2nd prednisone intention 1mg/kg in the initial dose and then decrease the IV diagram in severe cases

  - 3rd intention
    - TT Steroid Savings: Systemic Immunosuppressants. +/- Biological TT.

- TT antimicrobials directed at infectious origin-TJR exclude before TT steroids.

- ATTENTION!
- There is no injection of parabulbar from steroids due to risk of perforation in cases of necrotizing scleritis.
