---
categoria: apuntes
area: uveitis
emoji: 🔥
seccion: Immuno-infectio
orden_seccion: 7
orden: 25
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-05-26
---
# Suivi Plaquenil/Hydroxychloroquine

## Definition

Macular Toxicity: dose-dependent and duration of TTT.

Possible presentation: Subclinical retinopathy or sytomatic maculopathy in the eye of a protrusion.

## Mechanism of Toxicity

The mechanism of hydroxychloroquine retinal toxicity has yet to be fully elucidated. Studies have shown that the drug affects the metabolism of retinal cells and also binds to melanin in the RPE, which could explain the persistent toxicity after discontinuation of the medication. However, these findings do not explain the clinical pigmentary changes causing a bull’s-eye maculopathy.

## Recomendation dosage

## Dose maximale recommande: <5mg/kg/j

A check at each control query.

Risque toxicite ret si dose <5mg/kg:

<1% après 5 ans

<2% après 10 ans

20% after 20 years of TT

## FR

Although it is not possible to predict which patients will develop retinal toxicity, high-risk characteristics include the following:

## daily dose >5mg/kg; Cumulative >1000g or

## Durée de tt >5 ans

## Rétinopathie préexistante

## Insuffisance rénale +/- hepatopathie ( car clearence by both routes)

## Age >60ans

## Concomitant treatment with tamoxifen (ca.sein).

## Symptoms

Asymtomatique
