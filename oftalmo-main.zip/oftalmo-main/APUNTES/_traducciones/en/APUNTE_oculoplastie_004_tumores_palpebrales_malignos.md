---
categoria: apuntes
area: oculoplastica
emoji: 🫥
seccion: Oculo-Plastie
orden_seccion: 3
orden: 4
fuente: OneNote del Dr. Castilla Martí
---
# Malignant palpebral tumors

## ⚠️ Common Risk Factors

- ☀️ Chronic sun exposure
- 🧬 Personal history of cutaneous carcinoma
- 🚬 Smoking
- 👩‍🦳 Low phototype
- 💉 Immunosuppression (HIV, immunosuppressive treatments)
- ☢️ Previous radiotherapy
- 👪 Genetic syndromes: Gorlin-Goltz, Xeroderma Pigmentosa, Muir-Tower, Bazex

## 🔬Clinical suspicion of malignancy

- Irregular pigmented lesion
- Slow and painless growth
- Ulcers, scabs, bleeding
- Fixing to deep planes
- eyelash loss

## 📘3.1 Basal cell carcinoma

- + Frequent (90%)
- Predominates on lower eyelid >Medial edge > Upper > External
- Slow growth, not metastasize
- It originates from epidermal basal cells

## subtypes

- Nodular: Pearl nodule with telangiectasias.
- Nodulum-ulcerative (ulcus rodens): central necrosis.
- Morpheic/Sclerosing: Indurated, aggressive plaque, imprecise margins, loss of eyelashes.
- Others: pigmented, multiple superficial, cystic.

✅ Treatment: Surgery with margins. The sclerosing form may require techniques like Mohs.

## 📘 3.2 Squamous cell carcinoma (spike cell)

- Less common than the cell, but much more aggressive
- Has capacity for lymphatic, hematic, or perineural metastases
- It originates from squamous cells of the epidermis

🧬 Risk factors:

- advanced age
- Sun exposure
- immunosuppression

🧪 It can arise on:

- Actinic keratosis
- Carcinoma in situ (Bowen's disease)

🔍 Clinic:

- Similar to base cell, but without telangiectasia
- crusted nodule, ulceration
- Can grow rapidly and ulcerate

✅ Treatment: Surgical resection with exhaustive histological control due to risk of metastases.

## 📘3.3 Bowen's disease

- Carcinoma epidermoide in situ
- Atypical cells in epidermis without invading dermis

🔍 Clinic:

- Erythematous plaque with desquamation
- eczema appearance that does not disappear

⚠️ Risk of progression to invasive epidermoid carcinoma (~5%)

✅ Treatment: Complete resection.

## 📘3.4 Keratoacanthoma

- fast-growing tumor, often in weeks
- More frequent on the lower eyelid
- can spontaneously revolt

🔍 Clinic:

- Pink nodule with central crater filled with keratin
- Can be confused with squamous carcinoma

🔬 Histology: central cavity with keratin, cell shoulder in the periphery

✅ Treatment: Incisional biopsy + complete resection.

## 📘3.5 Sebaceous Adenocarcinoma

- Very aggressive tumor, high mortality (5-10%)
- More common in older women
- It originates from meibomy, zeis or sebaceous glands of caruncula/skin

🔍 Clinic:

- Similar to Chalazion or Blepharitis, but:
  - yellowish coloration
  - eyelash loss
  - Recurrent injury
  - Absent glandular holes

🧪 Typical pagetoid growth (intraepidermal)

✅ Treatment: wide resection + histological control

## 📘 3.6 Malignant Lentigo (Hutchinson's Fresh)

- Melanoma in situ
- Radial proliferation of intraepidermal atypical melanocytes

🔍 Clinic:

- Pigmented spot with irregular edges on photoexposed skin (malara/lid)
- slow growth

✅ Treatment: Wide resection with margin control

## 📘3.7 Palpebral melanoma

- Very weird, but very aggressive and deadly
- It can appear de novo or on a nevus / lentigo

🔍 Clinic:

- Pigmented lesion (although it can be amelanotic)
- Ulcers, bleeding, growth

🔬 Histology: Proliferation of atypical melanocytes in dermis

## Clinical subtypes

- Malignant Lentigo Melanoma: on previous lentigo
- Extensive surface
- Nodular: Pigmented or amelanotic nodule

✅ Treatment: Wide resection with histological control

## 📘3.8 Merkel Cell Carcinoma

- Very rare but highly metastatic tumor
- Red nodule, well delimited, rapid growth

🔍 Clinic:

- Located on the upper eyelid
- visible telangiectasias

🔬 Origin: Dermal neuroendocrine cells

✅ Treatment: Surgery + Radiation / Chemotherapy

## 📘3.9 Kaposi Sarcoma

- Malignant vascular tumor associated with HIV/AIDS
- Subconjunctival or palpebral red lesion

✅ Treatment:

- Observation
- Surgical resection
- radiotherapy or cryotherapy if progressive

## 📘 3.10 General Treatment Palpebral Tumors

| Technique | Instruction | Key Notes |
|---|---|---|
| Biopsy | Diagnosis (incisional or resection) | Always mark zone |
| Surgery | Gold Standard: Resection with histological control | Margins: ≥2-4mm, more in aggressive tumors |
| Mohs | Recurrent or infiltrative tumors | Preserve healthy tissue |
| Cryotherapy | Alternative Yes Surgical Contraindication | Does not allow histological control |
| Radiotherapy | Radiosensitive tumors, Kaposi, or rejection surgery | Risk of stenosis, dry eye, scars |

## 🧾 Comparative table: Basal cell carcinoma vs. Epidermoid carcinoma

| Feature | Basal cell carcinoma (CBC) | Epidermoid carcinoma (CEC) |
|---|---|---|
| Frequency | ≈ 90% of palpebral malignant tumors | ≈ 5% of palpebral malignancies |
| age and phototype | Elders, phototypes I–II | Elderly, immunosuppressed, low phototypes |
| Typical location | Lower eyelid > Medial edge > Upper eyelid | Lower or upper eyelid |
| Increase | Slow, locally invasive, no metastases | Fast, aggressive, with metastatic potential |
| Typical Clinic | Pearl nodule with telangiectasis, can ulcer (ulcus rodens) | Crust nodule, ulceration, no telangiectasis |
| Histology | Basaloid cell nests with peripheral palisade, little pleomorphism | Atypical squamous cells with keratinization and intercellular bridges |
| clinical forms | nodular, ulcerative, morphiform (sclerosing), pigmented, superficial, cystic | In situ (Bowen's disease), invasive, keratoacanthoma |
| Treatment | Surgery with margins of 2–4 mm; Mohs in recurrent or morphiform cases | Surgery with broad margins; Rigorous histological control |
| Forecast |  | worst prognosis; Risk of metastasis and recurrence |

## 🧠 Anatomy and histology of the eyelid

The eyelid is a complex structure that protects the eyeball and participates in the distribution of the tear film. It is made up of several layers, from anterior to posterior:

- Skin: Slim and no significant subcutaneous tissue.
- Orbicularis Muscle: Responsible for palpebral closure.
- Orbital septum (Septo): Fibrous sheet separating the orbital contents of the eyelid.
- Tarsal sheet (tarsus): structure of dense connective tissue that gives shape and support to the eyelid.
- glands:
  - Meibomian glands: Modified sebaceous within the tarsus; Its obstruction can lead to chalazion.
  - Glands of Zeiss and Moll: associated with hair follicles; They can be the origin of styes.
- Palpebral conjunctiva: mucosa that covers the inner surface of the eyelid.

This anatomical arrangement explains the diversity of tumors that can originate on the eyelid, depending on the layer or structure affected.

## 📌 Palpebral tumors relevant to the EBO exam

In addition to basal cell and epidermoid carcinoma, it is important to pay attention to:

- Sebaceous adenocarcinoma: Aggressive tumor originating from the Meibomian glands; It can simulate a recurring chalazion.
- Melanoma: Although rare on the eyelids, it is highly aggressive and can derive from a malignant lentigo.
- Merkel cell carcinoma: Neuroendocrine tumor with rapid growth and high metastatic potential.
- Kaposi sarcoma: vascular tumor associated with immunosuppression, especially in patients with HIV.
