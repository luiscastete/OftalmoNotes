---
categoria: apuntes
area: cornea
emoji: 💧
seccion: Conj + Episclere + Sclere
orden_seccion: 25
orden: 11
fuente: OneNote del Dr. Castilla Martí
---
# Anatomy

## 👁️ Layers of the conjunctiva

The conjunctiva is a thin transparent mucous membrane that covers part of the eyeball and the inside of the eyelids. It is divided into:

- 🔹1. Conjunctival epithelium (more superficial)

  - Stratified (2 to 5 cell layers)
  - Contains:
    - Goblet cells → secrete mucin (part of the tear film)
    - Immune cells (lymphocytes, macrophages)

  - Varies in thickness and number of cells according to location

- 🔹2. Stroma (own sheet)

  - loose connective tissue
  - richly vascularized and with lymphatics
  - It is divided into:
    - Adenoid superficial layer → Contains lymphoid tissue (contributes to ocular immunity)
    - Fibrous Deep Layer → Connects to the Underlying Tissue (Tarsi or Sclera)

## 📍 Anatomical location of the conjunctiva
