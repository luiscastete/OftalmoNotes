---
categoria: apuntes
area: cornea
emoji: 👁️
seccion: Cornée
orden_seccion: 4
orden: 18
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-01-30
---
# Keratitis/Marginal Ulcer

Type III hypersensitivity reaction against staphylococcal exotoxin.

Complete deposits of AC-Ag in the peripheral cornea. With separation edges between cornàe and conj.

Corneal lesions - to cultivation but the FREC S.Aureiûs is isolated on the palpebral margin.

Symptom: redness, ce sensation, tear, photophobia, visual discomfort, bav, sometimes bilat.

## Signs

INFILTRATS CATARRHAUX

INFILTRAT CATARRAL

It infiltrates under Epith. Peripherals separated from the limbo by a healthy space (loc 1-2 mm of the limbo).

With epith of rupture (Fluo +) = marginal ulcer

No rupture epith (fluorescent -) = marginal keratitis

Defect Epith size <infiltrate size

sometimes infiltrated rounded coalescent.

Typical locomotive: 4-8h (Typical Inf ++) and 1'-2h. (Leye contact area)

HC Adjacent Zone Infiltrates

Chronic blepharitis associated with FREC

Precos demonstration: Inf. punctuated epitheliopathy.

No reaction ca

## Course

No TTT Spontaneous resolution 1-4 weeks.

geese. Leaves a superficial scar. Residue and a slight corneal aminisation in the infiltrate zone with light sometimes pannus.

neovasc iriens peuvents will develop if large leions persistent mais resolution Quand inflam disparate.

Recurrences are common.

## DX

Clinic: No assessment necessary.

## Treatment

OBJ: Reduce local inflammatory and reduce stimuli for future recurrences.
