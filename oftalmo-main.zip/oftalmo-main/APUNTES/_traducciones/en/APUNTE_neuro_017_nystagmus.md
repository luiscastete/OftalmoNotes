---
categoria: apuntes
area: neuro
emoji: 🧠
seccion: Neuro-Ophta
orden_seccion: 8
orden: 17
fuente: OneNote del Dr. Castilla Martí
---
# Nystagmus

## 1. Definition

- Nystagmus = Rhythmic, repetitive and involuntary ocular movement.
- It consists of two phases:
  - Slow Phase → The eye deviates (due to a vestibular imbalance or a follow-up movement).
  - Fast Phase → The eye corrects with a quick pull.
- It is named according to the direction of the rapid phase (eg “Nystagmus to the right”).

## 2. Main types

- a) According to physiology

  - Physiological:
    - Okn (optokinetic) → Looking at a moving landscape.
    - vestibular (VOR) → When you turn your head.

  - PATHOLOGICAL:
    - It appears in neurological, vestibular, ophthalmological diseases.

- b) according to the form

  - Pendular: There is no rapid phase, both movements are of equal speed → typical of congenital or sensory nystagmus.
  - Jerk (saccadic): with slow + fast phase → typical in vestibular or neurological acquired.

- c) According to the address

  - horizontal (most common).
  - vertical (eg upward nystagmus in cerebellar lesions).
  - torsional (rotary, eg trunk/cerebellum lesions).
  - mixed.
