---
categoria: apuntes
area: cornea
emoji: 👁️
seccion: Cornée
orden_seccion: 4
orden: 41
fuente: OneNote del Dr. Castilla Martí
---
# Meeting 25

Strong pedagogical value for the patient Meibograohie

Anti-inflammatory is always given

Hydrocortisone privilege

cyclosporine - also how

Autologous serum and PRP: increasingly used
