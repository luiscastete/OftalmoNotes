---
categoria: apuntes
area: neuro
emoji: 🧠
seccion: Neuro-Ophta
orden_seccion: 8
orden: 3
fuente: OneNote del Dr. Castilla Martí
---
# NF 1 neurofibromatous

Links:

cdo212_cv_p001_p003-v2:cdo (cahiers-ofthalmology.fr)

## Optha NF1 events

-plexiform neurofibroma of the eyelid

-Sphenoidal dysplasia --Responsible - Orbital dystopia +/- Exoptalmia

-The ectropion of the iris postcard

-Congenital or infantile glaucoma

-Buftalmia without glaucoma

-Vascular abnormalities of the retina

-Hyperreflective tasks in infrared shots --Yasunari's Tasks

-Visual pathway

- Intracranial hypertension

## SUIVI OPTHA

- av + uncle
- CV by confrontation if doubt kinetic
- students, rapd
- FO
- Oct Mac, RFNL, CL and infrared
- +/- Iris photo if possible
