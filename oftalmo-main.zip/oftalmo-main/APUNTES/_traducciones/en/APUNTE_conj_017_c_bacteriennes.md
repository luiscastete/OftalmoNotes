---
categoria: apuntes
area: cornea
emoji: 💧
seccion: Conj + Episclere + Sclere
orden_seccion: 25
orden: 17
fuente: OneNote del Dr. Castilla Martí
fecha: 2024-07-02
---
# C. BACTERIENNES

## 👁️‍🗨️2.2 Bacterial Conjunctivitis – General

## 🔬

## Pathophysiology

- Bacterial proliferation in the conjunctiva → Inflammation → Recruitment of neutrophils → Mucopurulent secretion.
- In chronic forms, such as S. aureus or Moraxella, they are associated with blepharitis and catarrhal infiltrates.

## 💧 Typical acute clinical form

## 📌 Clinical features

- Sudden onset, moderate mucopurulent secretion.
- tarsal papillae, without follicles.
- Unusual preauricular adenopathy except for severe or hyperacute forms.

## 🧫 Common Etiology and Prevalence

| Pathogen | Frequency / Clinical notes |
|---|---|
| S. aureus | adults. most frequent cause. Chronicle. associated with blepharitis. |
| H. influenzae (not typifiable) | small children. flictenulas. can produce systemic clinic. |
| S. pneumoniae | children. classic acute form. |
| Moraxella lacunata | children/adults. Angular blepharitis, tendency to chronification. |
| GN germs (E. coli, Pseudomonas, etc.) | Hospital cases, corneal exposure, immunosuppression. |
| Neisseria gonorrhoeae/meningitidis | Very serious (hyperacute). rare. STDs or autoinoculation. quick corneal perforation possible. |
