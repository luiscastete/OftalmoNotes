---
categoria: apuntes
area: cornea
emoji: 👁️
seccion: Cornée
orden_seccion: 4
orden: 7
fuente: OneNote del Dr. Castilla Martí
---
# 🏥 Eye Bank

## 🏥 Eye Bank – Structured Summary

## 🎯Objective

Ensure the availability of eye tissue with the highest quality and safety, respecting legal and ethical principles. In case of shortage, ensure equitable distribution.

## 🏛️ Legislation

• Based on the European Directive 2004/23.

• Transposed in Spain by RD 1301/2006 → replaced by RD-Law 9/2014.

• The authorization of the banks is transferred to the CCAA.

## 🌍 Key data

• Spain is a world leader in tissue donation and transplantation.

• The age of the donor is not absolute contraindication: the quality of the tissue is valued.

## 🧪 Fabric removal

• In appropriate facilities, but sterile operating room is not required.

• Types:

- full eyeball.
- Isolated corneoscleral cap.
- Maximum time after death: 6–12 h.

## 🔬Cornea evaluation

• Biomicroscopy with slit lamp.

• Endothelial specular microscopy: evaluates:

• Cell density ≥ 2000–2500 cells/mm².

• Low pleomorphism and polymegatism.

## Donor Mandatory Serologies

• HIV 1 and 2 (AC)

• Hepatitis C (AC)

• Hepatitis B (HBS AG and AC Core)
