---
categoria: apuntes
area: cornea
emoji: 👁️
seccion: Cornée
orden_seccion: 4
orden: 28
fuente: OneNote del Dr. Castilla Martí
---
# FUNGAL KERATITIS

## 3.2. fungal keratitis

## 🪠3.2.1. Pathogeny

- Uncommon in temperate climates. 1-7% of infectious keratitis.
- High prevalence in tropical regions and in developing countries.

## 🦠 Types of mushrooms

- Yeasts: Candida spp. → Infections in temperate climates.
- Filamentous fungi:Fusarium,Aspergillus→ Frequent in tropical climates.

## ⚠️ Predisposing factors

- Chronic disease of the ocular surface.
- Prolonged topical corticosteroids.
- Use of contact lenses.
- Systemic immunosuppression, diabetes.
- trauma with plant material or tools.

## 🔍3.2.2. clinical picture

## 😷 Symptoms

- Gradual onset: Pain, grit, photophobia, blurred vision, mucopurulent discharge.

## 🔎Signs

- Candida: Suppurative white-yellow infiltrate.
- Filamentosos: Gray/yellow stromal infiltrate with deflated edges.
- Satellite lesions, necrosis, corneal thinning.
- There may be: hypopion, endothelial plaque, augmentation PIO, scleritis, endophthalmitis.

## 🔌 Differential diagnosis

- Bacterial, herpetic, amoebic keratitis.

## 🔢3.2.3. Laboratory evaluation

- Staining with potassium hydroxide (KOH)→ Display of hyphae.
- Culture on blood agar, sabouraud or brain-heart infusion.
