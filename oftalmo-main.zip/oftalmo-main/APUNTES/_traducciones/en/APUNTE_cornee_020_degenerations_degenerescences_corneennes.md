---
categoria: apuntes
area: cornea
emoji: 👁️
seccion: Cornée
orden_seccion: 4
orden: 20
fuente: OneNote del Dr. Castilla Martí
fecha: 2024-02-14
---
# degenerations degéréscences cornéennes

## Corneal degenerations

Not hereditary, acquired and more frequent with age or due to environmental/inflammatory damage.

## 🔹1. Arcus Senilis (Gerontoxon/Arcus lipoids)

• Common in the elderly, bilateral, peripheral.

• Association with dyslipidemia if it occurs in young people (Arcus juvenis).

• Signs:

- Stromal lipid deposit in upper/lower pole → circumference (1mm width).
- Crisp peripheral edge separated from the limbo by light zone.
- Diffuse central border, vertical > horizontal pattern.

• Treatment: None.

## 🔹2. Vogt Limbal Girdle

- Very common (>60% >40 years), more in women.
- Growing whitish in limbo, 3 and 9 h, more nasal.
- Type I: Swiss cheese pattern with light zone (similar to Band Keratopathy).
- Type II: More common, no holes or clear area.
- Histology similar to Penguécula/Pterygion.
- Treatment: None.

## 🔹3. Cornea farinata

- Microscopic deposits in central deep stroma.
- Fluor-like, bilateral, does not affect vision.
- Treatment: None.

## 🔹4. Crocodile Shagreen

- Gray polygonal opacities separated by light stroma.
- Location: Anterior (most common) or later.
- Asymptomatic, simulates François' central dystrophy.
- Treatment: None.
