---
categoria: apuntes
area: cornea
emoji: 👁️
seccion: Cornée
orden_seccion: 4
orden: 23
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-01-30
---
# keratoconus

More frequent Conana dystrophy, affecting 1 in 2000.

The cornea becomes progressively thinner and more convex giving irregular astigmatism.

Diagnosis especially complicates in the initial forms and, in general, is raised during adolescence.

Slow and unpredictable evolution

## SYMTOMES

Progressive, bilateral, but asymmetrical AVB, which usually begins in adolescence.

If dropsy:

- sudden bav
- aches and pains
- eye redness
- Photophobie
- Larmoiment

## Signs

Slowly Progressive Irregular Astigmatism

Conical appearance of the cornea

Thinning of the cornea in the central or lower region

- +/- Feischer ring (iron tank at the base of the cone)
- +/- VOGT stripes (tension lines on the Descemet)
- +/- corneal scar
- +/- Signs from Munson (protrusion of the lower paupiee when looking down).
- +/- dropsy (corneal edema suddenly at the breakdown of the descemet, advanced form).

## Notes

Suspicion of Kc if:

- Autofefractometer: Cylinder >1.5D, Cylinder progress over time, Cylinder asymmetry, Keratometry >45D.
- Subjective refraction difficult to perform in a young patient.
- Frequent change of optical correction.
- Complaint of visual quality or decline of inexplicable vision.
