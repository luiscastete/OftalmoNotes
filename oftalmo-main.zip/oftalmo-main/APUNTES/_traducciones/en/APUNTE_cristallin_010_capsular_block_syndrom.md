---
categoria: apuntes
area: catarata
emoji: 🔍
seccion: Cristallin - Lens
orden_seccion: 21
orden: 10
fuente: OneNote del Dr. Castilla Martí
---
# 🟡 Capsular Block Syndrom

## 🟡 Capsular Block Syndrome (CBS)

## 🔹¿Qué es?

Complication in cataract surgery due to accumulation of fluid in the capsular sac, causing distension and sudden increase in pressure.

## 🔹

## Types

- Intraoperative (acute): during hydrodissection
- Postoperative (late): Fluid retained behind the IOL

## 🔹

## intraoperative signs

- Iris prolapse
- Narrow anterior chamber
- Very hard eye
- core not broken
- Posterior capsule rupture risk

## 🔹

## RISK FACTORS

- small capsulorrexis
- Hard core
- Hydrodissection without escape route
- Bulky zonular or crystalline tension
