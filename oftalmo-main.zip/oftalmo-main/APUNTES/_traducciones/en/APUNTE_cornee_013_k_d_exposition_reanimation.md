---
categoria: apuntes
area: cornea
emoji: 👁️
seccion: Cornée
orden_seccion: 4
orden: 13
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-10-30
---
# Exhibition K. - Resuscitation

Corneal damage from the dry eye in an incomplete or inadequate closure of the eyelid. The production of tears is normal.

## Symptoms

Dry eye symptoms +++

symptom. Exacerbated during exposure conditions: air conditioning, wind exposure, heating, activities that decrease freq-eye blinking on screen...

## Signs

Drought signals +++ that can lead to corneal ulceration and cause perforation.

## Aetiology

- Lagoptalmia palpebral: causes the drying of the original evaporative cornea.
- Multi-origin lagophthalmia:
  - Neurological: Facial paralysis NC VII—Palpebral paralysis +/- Reduced corneal sensitivity - NC V
  - Muscle: Parkinson's disease ++
  - Mechanics: Exothalmia – Tumor, parabulbar jet., post-trauma cicarice, or post-trauma blepharoplasty

## Examination

- AV-TIO
- Evlauer palpebral closure. If necessary, measure the degree of lagoptlamia.
- Test corneal sensitivity.
- LAF: With fluo, it excludes infection, thinning, ulceration or perforation.

## TT

- doctor:
- The eye dressing + PVA + nocturnal for lagophthalmia.

- Surgical
- Tartardon
- Amniotic membrane graft
- Orbital decompression for exoptlamia

## other measures

Stop all toxics for the cornea

Treat concomitant blepharitis

Therapeutic PPM

## Eye protection in resuscitation

Ensure eye protection of neuro-sedated patients in resuscitation stays.

Especially in prolonged ventral positions, which prohibits eye care.

Before returning to the ventral position, install in both eyes:

Add Floxal GTT 1xJ + Viscotears or Celluvisc or PVA

Closure of the eyelids by hypoallergenic plaster.

Care should be taken to avoid compression of the eyeball. Risk of acute ischemic optic neuropathy.
