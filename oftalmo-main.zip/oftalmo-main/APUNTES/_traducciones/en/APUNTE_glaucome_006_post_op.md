---
categoria: apuntes
area: glaucoma
emoji: 🟢
seccion: Glaucome
orden_seccion: 5
orden: 6
fuente: OneNote del Dr. Castilla Martí
---
# POST-OP

TRABECULOTOMIE

Normal bleeding for 7-10J.

If bav for blurred vision (hyphema) with tio eo and well is formed: the normal reassures the patient and continues tt idem

Avoid dilation to prevent iris imprisonment in trab: if necessary, USB for Exminr IF HV
