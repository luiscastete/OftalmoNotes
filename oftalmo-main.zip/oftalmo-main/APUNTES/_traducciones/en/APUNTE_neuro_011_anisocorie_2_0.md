---
categoria: apuntes
area: neuro
emoji: 🧠
seccion: Neuro-Ophta
orden_seccion: 8
orden: 11
fuente: OneNote del Dr. Castilla Martí
---
# Anisocorie 2.0

## 🔍

## Why do we suspect Adie's pupil in this case?

## ✅ Young woman, asymptomatic, 26 years old

- Adie's pupil is more common in young women.
- It is often discovered incidentally, with no relevant visual symptoms.

## ✅ Anisocoria that increases with intense light

- This suggests that the largest (mydriatic) pupil is the anomalous, since:
  - In light conditions, the normal pupil contracts.
  - The affected pupil does not respond well to light, therefore the anisocoria is accentuated.
- This largely rules out a Horner syndrome, which is accentuated in the dark (due to lack of dilation).
