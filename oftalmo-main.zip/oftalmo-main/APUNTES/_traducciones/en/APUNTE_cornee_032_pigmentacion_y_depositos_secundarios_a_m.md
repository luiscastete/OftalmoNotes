---
categoria: apuntes
area: cornea
emoji: 👁️
seccion: Cornée
orden_seccion: 4
orden: 32
fuente: OneNote del Dr. Castilla Martí
---
# Pigmentation and secondary drug deposits - Fabry

## 🧠4.4. Pigmentation and secondary drug deposits

## 🩸Localization of deposits according to corneal layer

## 📍 A. At the epithelial level

Drugs that can be pigmented or deposited:

- Aminoquinolones
- amiodarone
- Clophacimin
- Chlorpromazine
- indomethacin
- Naproxen
- perhexiline
- Suramina
- Tamoxifen
- Thioxanthines
- Tylorone
