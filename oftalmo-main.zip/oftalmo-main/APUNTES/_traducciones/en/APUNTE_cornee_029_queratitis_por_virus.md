---
categoria: apuntes
area: cornea
emoji: 👁️
seccion: Cornée
orden_seccion: 4
orden: 29
fuente: OneNote del Dr. Castilla Martí
---
# Virus keratitis

## Viral keratitis: Herpes simplex and zoster

## 1. Herpes simplex virus (HSV)

## 🦠Generalities

- HSV-1: Most common infection of the face, lips and eyes.
- HSV-2: Genital herpes, but can also affect the eye.
- Most common cause of infectious blindness in developed countries.
- 1/3 of the population suffers from recurrent infections.

## 🔄 Types of infection

- Primary infection: It is usually subclinical. It affects the skin and mucosa innervated by the trigeminal.
- Recurring: The virus remains latent in the trigeminal ganglion. Reactivation by fever, stress, trauma, UV light...

## 👁️ Eye Clinical Forms

## 1. Epithelial keratitis

- associated with active replication.
- Symptoms: malaise, photophobia, tearing, blurred vision.
- Signs:
  - Puntiform epithelial keratitis → dendritic (bulb branching) → geographic (if corticoids).
  - Fluorescein staining (bed) and Bengal rose (edges).
  - corneal hypoaesthesia.
- ❌ Contraindicated corticosteroids.
- ✅ Treatment: Acyclovir 3% ointment or ganciclovir 0.15% gel 5x/day.

## 2. Stromal keratitis

- Disciform (non-necrotizing):
  - Central stromal edema, retrokeratic precipitates.
  - Immune reaction vs viral antigens.
- necrotizing:
  - Active viral replication + immune response.
  - Opacification, necrosis, vascularization, healing.
- ✅ Treatment: Topical + antiviral corticosteroids.

## 3. Endothelitis

- endothelial inflammation.
- Stromal and epithelial edema + keratic precipitates + iritis.
- Types: Disciform (more frequent), linear, diffuse.
