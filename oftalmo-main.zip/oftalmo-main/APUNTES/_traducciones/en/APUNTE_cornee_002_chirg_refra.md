---
categoria: apuntes
area: cornea
emoji: 👁️
seccion: Cornée
orden_seccion: 4
orden: 2
fuente: OneNote del Dr. Castilla Martí
---
# Chirg saying

Discussion with Dr. Hardy

stable for 2 years?

>60 years – not possible

Prebyte young woman from 40 to 50 years old: not a good candidate

Make a mole if you want to have fun, don't load it, write down if not direct contraindications

cost

PKR- 2000 over all eyes

lasik 3000 over all eyes

good books

Sinjab Pentacam

Refractive Myopia Surgery - Volume 1 (refractive surgery) - Cati Albou Gaganem
