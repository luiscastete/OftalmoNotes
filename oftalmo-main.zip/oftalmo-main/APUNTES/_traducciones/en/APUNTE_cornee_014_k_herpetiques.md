---
categoria: apuntes
area: cornea
emoji: 👁️
seccion: Cornée
orden_seccion: 4
orden: 14
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-01-30
---
# K. herpetic

## KERATITE EPITHELIAL

## Signs

Dendritic lesions

Geographic ulcer Fluo + (severe + HC + + abscess)

decreased corneal sensitivity

## Treatment

- PHASE ACTIVE:

- Topic: Acyclovir 5xJ PDT 7J ointment then 3xJ PDT 7J (when clearly epithelial) +/-

- Per os: Valacyclovir (Valtrex) 500 / 1000mg 3XJ 7J (Quand il and A Uveite normally) PUIS 500mg 3xJ PDT 7J

- Tobrex or Floxal GTT 4-6XJ PDT 7J + Cyclopegia if pain

- Attention because Acivision is toxic to the cornea works well for 2 weeks and after being too toxic

- such a bad evolution
- Decline of Acivision Add Valtrex Therapeutic
- Appointment in 3 days

- Never cut in this phase

- SUIVI: 3-5j

- PHASE CICATRICIELLE

- If bav over the central opacity: dx 3xj with degressive diagram dx 3xj pdt 10j, dx 2xj pdt 10j, dx 1xj pdt 10j.
- Tio tracking in 10-15 days
- PC in 1-2 months

- Filipo likes to hold the Valtrex 500mg 3xj with the DX if it still infiltrates when it is fluorescent, to protect us if it is pushed back.

- TT PREVENTIF*

- Valaciclovir 500mg 2xJ or acyclovir 800mg 2xj in the following cases:
  - Epithelial keratitis after 3 recurrences per year
  - Deep keratitis after 2 recurrences per year
  - In case of eye surgery
