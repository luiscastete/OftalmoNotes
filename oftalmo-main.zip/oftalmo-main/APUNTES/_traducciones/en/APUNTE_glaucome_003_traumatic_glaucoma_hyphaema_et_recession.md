---
categoria: apuntes
area: glaucoma
emoji: 🟢
seccion: Glaucome
orden_seccion: 5
orden: 3
fuente: OneNote del Dr. Castilla Martí
---
# Traumatic glaucoma (hyfama and recession)

## 🩸Hyphaema

## ✅ Definition

Presence of blood in the anterior chamber, usually post-trauma.

## ⚠️ RISKS ASSOCIATED

• ↑ IOP due to trabecular obstruction with red blood cells, even in small hyphaema.

## 📊 Forecast according to size

| Hyphaema size | % Complications | Final AV > 6/18 |
|---|---|---|
| < 50% previous camera | 20% | 80% |
| > 50% previous camera | 80% | ~33% |

🧠 Key: The visual forecast depends mostly on initial retinal damage.

## 🚨 IMPORTANT COMPLICATIONS

## 🔴 Pio elevation

• IOP > 50 mmHg ➝ Risk of damage to the optic nerve.

• Maintained elevation ➝ Ocular structural damage.

## 🎯Corneal staining

• It occurs when the red blood cells penetrate the corneal stroma.

• It usually happens if the hyphaema is large and the IOP remains elevated more than 4-5 days.

• Consequence: Persistent reddish-brown coloration of the cornea, potentially irreversible.

## 💥 Secondary hemorrhage

• It appears between days 3–5 after the initial trauma.

• It is usually more severe than primary bleeding.

• Associated with worse visual prognosis.

## 🧬Special cases: sickle cell hemoglobinopathy

• Higher risk of ↑ PIO due to:

• Trabecular obstruction with deformed red blood cells.

• Vascular occlusion.

## 🧠 Fast flashcards

## Which IOP puts the optic nerve at risk?

→ more than 50 mmHg.

## When can secondary hemorrhage appear?

→ Between 3 and 5 days after the trauma.

## What does the size of the hyphaema indicate?

→ Visual prognosis and risk of complications.

## Which patients are at high risk of complications?

→ Patients with sickle-headed hemoglobinopathy.

## What is corneal staining and when does it appear?

→ Infiltration of red blood cells in the corneal stroma. Appears if there is ↑pick maintained > 4-5 days.

## Treatment

## 🧾 General

• ❗ Rule out coagulation disorders (eg hemoglobinopathies).

• 🔎 Suspend anticoagulants after evaluation by internal medicine.

• 🚫 Avoid NSAIDs as painkillers.

• 🩺 If there is hemoglobinopathy (eg sickle cell anemia): consult with hematology before using risky drugs.

• 🏥 Hospital admission if hyphaema is great.

• 🚷 Absolute unnecessary rest, but limit activity.

• 🛌 Keep sitting/semi incorporated position, even when sleeping.

• 🥽 Wear eye protection (patch or shield).

## 💊 Medical treatment

| drug or measure | Indication / Comment |
|---|---|
| Topical anti-glaucomatous | β-blockers, prostaglandins, ± CAI topical (according to PIO). |
| systemic CAI | ❌ Avoid them in sickle cell hemoglobinopathies. |
| myotics | ❌ Contraindicated: ↑ Pupillary block, ↑ Inflammation. |
| Systemic hyperosmotics | restricted use. Caution in falciformes. |
| Topical steroids | They reduce the risk of secondary bleeding and control inflammation. |
| Atropine | Maintains mydriasis in large hyphaema, ↓ risk of rebleed. |
| Systemic antifibrinolytics | Ex: tranexamic acid or ACA. Consider whether recurring bleeding. |

## 🔬 Procedures

• Photocoagulation with gonioscope: on angular bleeding points (differ 5–6 days).

• Paracentesis or surgical evacuation (5% cases):

• Indicated if:

• Total hyphaema.

• PIO > 50 mmHg for > 2 days.

• PIO > 35 mmHg for > 5 days.

• Objective: Avoid corneal staining, optical atrophy, peripheral anterior synechiae, chronic glaucoma.

💡 Special caution in:

• Sickle-Cell: Moderately high IOP → Severe damage.

• Previous glaucoma.

• Young children (risk of amblyopia).

⚠️ In severe cases, a filtering procedure may be necessary.

## 📤 High and tracking

• 🕶️ Avoid any risk of eye trauma for several weeks.

• ⚠️ Bleeding reappears ➝ Immediate review.

## 🧠 Fast flashcards

## What medications to avoid in patients with sickle-headed hemoglobinopathy?

→ Systemic, myotic, hyperosmotic cais (use with great caution).

## When is surgery indicated in Hyphaema?

→ Total Hyphaema, PIO > 50 mmHg x 2 days or > 35 mmHg x 5 days.

## What drug helps prevent secondary hemorrhage?

→ Topical steroids and atropine (in large hyphaema).

## What antifibrinolytics can be used?

→ Tranexamic acid or aminocaproic acid (in cases with high risk of rebleed).

## 🔍 Angle Recession (Angular Recession)

## ✅ Definition

Rupture of the face of the ciliary body (between root of the iris and scleral spur) secondary to blunt trauma.

## 📊 Epidemiology and risk

| Feature | Detail |
|---|---|
| Relationship with Hyphaema | Very common after traumatic hyphaema |
| Glaucoma risk | <10% at 10 years |
| ↑ pio mechanism | Trabecular damage (not by the recession itself) |
| Significant risk if ≥ 3 quadrants | Recession < 3 quadrants: rare to cause glaucoma |

## 🧪 Diagnosis

## 👁️ Clinical presentation

• Unilateral chronic glaucoma in the eye with a history of trauma.

## 🔬Slit lamp exam

• Signs of previous trauma: eg. Pupillary sphincter rupture.

## 🔎 Gonioscopy

• Initial phase: Irregular widening of the ciliary body band.

• Late cases: Recession can be hidden by fibrosis and/or hyperpigmentation.

## 🩺 Treatment

| Therapeutic option | Comment |
|---|---|
| Medical treatment | as in secondary open angle glaucoma. often limited. |
| Laser trabeculoplasty | ❌ Ineffective. |
| Trabeculectomy + Ant-metabolite | ✅ Main surgical treatment. |
| Shunt or cyclophotocoagulation | Consider if trabeculectomy fails. |

## 📅 Tracking

• Annual PIO review if > 2 quadrants are affected.

• Reinsurance the patient: Low risk of developing secondary glaucoma if limited recession.

## 🧠 Fast flashcards

## What structure is broken in the angular recession?

→ Face of the ciliary body (between root of the iris and scleral spur).

## What percentage does glaucoma develop after 10 years?

→ Less than 10%.

## What is the key finding in initial gonioscopy?

→ Irregular widening of the ciliary body band.

What is the surgical treatment of choice if medical management fails?

→ Trabeculectomy with an antimetabolite.
