---
categoria: apuntes
area: glaucoma
emoji: 🟢
seccion: Glaucome
orden_seccion: 5
orden: 10
fuente: OneNote del Dr. Castilla Martí
---
# Pigment Dispersion Syndrome (PDS) vs Pigmentary Glaucoma (PG)

## 🔬 Pathophysiology

- Pigment release
  - In eyes with posterior concave iris (young myopes, especially).
  - The friction between the posterior face of the iris and the zonular fibers produces detachment of pigment granules from the iridian pigmentary epithelium.
- Pigment dispersion
  - The pigment is deposited in:
    - Corneal endothelium (Krukenberg Spindle).
    - Trabeculum (obstruction).
    - Zonular, anterior lens capsule.
- Trabecular obstruction
  - Pigment phagocytosed by trabecular or accumulated cells directly reduces the leakage of aqueous humor.
  - Result → ↑ Intermittent or sustained PIO.
- Glaucoma
  - Chronic elevated IOP causes damage to the glaucomatous optic nerve.

## 👁️ Clinic
