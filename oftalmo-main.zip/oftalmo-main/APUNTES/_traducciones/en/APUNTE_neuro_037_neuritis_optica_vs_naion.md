---
categoria: apuntes
area: neuro
emoji: 🧠
seccion: Neuro-Ophta
orden_seccion: 8
orden: 37
fuente: OneNote del Dr. Castilla Martí
---
# Neuritis Optica vs Naion

Comparative table: Optic neuritis vs. Non-arteritic anterior ischemic optic neuropathy (NAION)

| Feature 🧐 | Optic neuritis (optic neuritis) | Non-arteric anterior ischemic optic neuropathy (NAION) |
|---|---|---|
| Typical age 🎂 | 20–45 years old | >50 years |
| Home 🚀 | Fast (hours to days) | Suddenly, often upon waking |
| Eye pain | present, especially with eye movement | absent or minimal |
| Visual loss 👁️‍🗨️ | progressive in a few days | Sudden and usually fixed |
| Appearance of the optic nerve | Normal or mild edema (or retrobulbar) | diffuse or sectorial papilla edema, then palinging |
| Campimetric defect 🎯 | central scotoma | Altitudinal scotoma (often lower) |
| Chromatic vision 🌈 | very upset | relatively preserved |
| Marcus Gunn's Pupil (rapd) 🔦 | Present | Present |
| Risk factors ⚠️ | Multiple sclerosis, viral infections | hypertension, DM, dyslipidemia, sleep apnea |
| Recovery 🛠️ | Spontaneous or accelerated with IV corticosteroids | partial; Poor visual recovery |
| Treatment 💉 | IV corticosteroids (in selected cases) | control of vascular factors; No curative therapy |
| Pathophysiology 🧠 | Inflammation and demyelination of the optic nerve | Ischemic infarction due to hypoperfusion of the posterior ciliary circulation |
