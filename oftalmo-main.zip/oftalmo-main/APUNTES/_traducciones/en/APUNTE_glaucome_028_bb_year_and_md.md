---
categoria: apuntes
area: glaucoma
emoji: 🟢
seccion: Glaucome
orden_seccion: 5
orden: 28
fuente: OneNote del Dr. Castilla Martí
---
# bB/year and MD

## Understanding -0.36 dB/year and MD in glaucoma

## Basics First

## What is db (decibels)?

- 📊 Unit of measurement of visual sensitivity in campimetry
- 📊 Measures the intensity of light that the patient can perceive
- 📊 High values = better sensitivity (see better)
- 📊 Low values = worse sensitivity (see worse)

## MD (Mean Deviation) - Average Deviation

## What is MD?

## MD = Average deviation (mean deviation)

It is a global index that measures:

- ✅ The average difference between the patient's sensitivity and the expected sensitivity for his age
- ✅ If the field of vision is worse than normal globally
- ✅ Total visual field damage degree

## How is MD interpreted?

MD Normal: 0 dB to -2 dB → Normal field of vision Mild: -2 to -6 dB → Mild minor defect Moderate: -6 to -12 dB → Moderate defect SevereMd: < -12 dB → Severd defect very Severe: < -20 dB → Advanced damage

## Example

- md = -5 dB → field of vision is 5 decibels darker than normal for your age
- MD = -15 dB → Field of view is 15 decibels darker (severe damage)
