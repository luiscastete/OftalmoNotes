---
categoria: apuntes
area: cornea
emoji: 💧
seccion: Conj + Episclere + Sclere
orden_seccion: 25
orden: 19
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-07-21
---
# Ptegion

Fibrovascular, benign neoformation, with centrifugal evolution towards the corneal apex.

Etymologically, this term comes from the Greek ptero, which means ala.

## Symptoms

It can be asymptomatic

Functional symptoms of superficial pathology: tear, feeling of this, discomfort and pruritus.

Aesthetic discomfort

+/- BAV: by direct invasion of the optical axis or by induced astigmatism.

## Signs

It is preferably located in the bulbar conj in the interpalpebral region.

In 90% of nasal cases, temporary drag.

often bilateral and asymmetric

+/- Local hyperemia: often with repetition

+/- possibedur dellen

+/- Shop line: Iron line at the end of Pterygion

## Aetiology

Solar exposure +/- ultraviolet

Chronic irritation

## Examination

AV-TIO

LAF, Fluo, size measurement of the limbo in the PEX

## BILAN

Photo: Evolution tracking.

Corneal topography:

- Measurement of induced astigmatism (usually irregular and in line with the ruler).
- Monitoring of the evolution and regression of post-chirg astigmatism.

## TT

## TT MEDICAL
