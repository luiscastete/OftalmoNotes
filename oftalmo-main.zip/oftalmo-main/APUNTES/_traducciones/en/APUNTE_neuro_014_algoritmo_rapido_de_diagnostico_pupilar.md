---
categoria: apuntes
area: neuro
emoji: 🧠
seccion: Neuro-Ophta
orden_seccion: 8
orden: 14
fuente: OneNote del Dr. Castilla Martí
---
# Fast Pupillary Diagnostic Algorithm

## Fast Pupillary Diagnostic Algorithm

## 1️⃣Large Pupil (Midriasis) → Problem for Sympathetic

First question:

## Does the pupil respond to light?

## ❌ Does not respond → Think about

## 1. Injury of the III pair

Findings:

- mydriasis
- marked ptosis
- eye on down and out
- Diplopia

Frequent causes:

- Posterior communicating artery aneurysm
- Tumor compression
- Uncal herniation
