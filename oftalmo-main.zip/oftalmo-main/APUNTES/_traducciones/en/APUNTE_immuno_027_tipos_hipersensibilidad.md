---
categoria: apuntes
area: uveitis
emoji: 🔥
seccion: Immuno-infectio
orden_seccion: 7
orden: 27
fuente: OneNote del Dr. Castilla Martí
---
# Types Hypersensitivity

## 🧪

## Type I – Immediate hypersensitivity (anaphylactic)

- Mechanism: mediated by IgE bound to mast cells and basophils → release of histamine and other mediators.
- Examples: anaphylaxis, allergic asthma, allergic conjunctivitis, urticaria.

## 🧬

## Type II – Cytotoxic hypersensitivity

- Mechanism: mediated by IgG or IgM directed against cell antigens → Complement activation or cytotoxicity.
- Examples: Autoimmune hemolytic anemia, Graves' disease, hyperacute transplant rejection.

## 🧫

## Type III – Immunocomplex hypersensitivity

- Mechanism: Formation of antigen-antibody complexes that are deposited in tissues → inflammation due to complement activation.
- Examples: Systemic lupus erythematosus, rheumatoid arthritis, vasculitis, serum reaction.
