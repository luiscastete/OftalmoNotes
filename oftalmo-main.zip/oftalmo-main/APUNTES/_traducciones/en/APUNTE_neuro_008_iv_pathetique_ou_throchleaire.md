---
categoria: apuntes
area: neuro
emoji: 🧠
seccion: Neuro-Ophta
orden_seccion: 8
orden: 8
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-09-26
---
# IV - Pathetic or Throclear

In isolated case, acquired---

In adults --- ischemic pal, traumatic causes

in children—congenital. It can be revealed later in life for decompensation and make believe in an acquired attack.

## Signs

Oblique, diplopia torsion, in the look down (when reading or descending the stairs)

Limiting downward oscmotricity and adduction

Exciclotorsion:

- Maddox subjective torque glass, damaged wall, synoptic and Kratz torch.
- Objective Torsion-Rltinophotographies

Hypertropy of the affected eye

Torticolis with tilted head and tilted chin Opposite side (compensatory position)

Bielschowsky test +: Increased hypertropy when the head tilts from the rib of paralysis.

Hess-Lancaster test

## Acquired congenital form distinction

Trochlear paralysis is often of congenital origin. Patients become symptomatic from the age of 40 to 50 because it decreases its vertical fusion filling and then causes diplopia.

## In favor of congenital origins

Old torticollis – pictures

Vertical melting amplitude greater than 4-6 d.

Quite vertical diplopia: SP patients have adapted to torsional disorder.

Inf oblique hyperaction. Apparent but limitation of the oblique sup. moderate.

Stereoscopic vision often good but ability to suppress.

Facial asymmetry, observing the interincisive line

Atrophy of sup oblique to mri-visible however also in acquired pathologies.

## In favor of bilateral participation
