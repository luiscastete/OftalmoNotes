---
categoria: apuntes
area: glaucoma
emoji: 🟢
seccion: Glaucome
orden_seccion: 5
orden: 12
fuente: OneNote del Dr. Castilla Martí
---
# Genetic mutations

## 🧬

## Genetics and Glaucoma / Dysgenesis of the anterior segment

| Gen | associated pathology | Heritage | Key Comment |
|---|---|---|---|
| CYP1B1 | Primary congenital glaucoma | autosomal recessive | most frequent gene in PCG; affects trabecular development |
| MYOC | Familial open angle primary glaucoma (POAG) | autosomal dominant | early start; Myocillin accumulates in Tm |
| PITX2 | Axenfeld–Rieger syndrome | autosomal dominant | Eye anomalies + dental + umbilical |
| FOXC1 | Axenfeld–Rieger syndrome | autosomal dominant | Similar to Pitx2; more glaucomatous |
| PAX6 | Congenital aniridia | autosomal dominant | defect in development of the iris and fovea; Glaucoma risk |
| OPTN | Slow evolution open angle primary glaucoma | autosomal dominant | associated with some non-family cases |

## 🧠

## Tips to memorize
