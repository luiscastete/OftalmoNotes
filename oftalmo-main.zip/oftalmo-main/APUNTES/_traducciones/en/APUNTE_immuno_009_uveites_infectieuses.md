---
categoria: apuntes
area: uveitis
emoji: 🔥
seccion: Immuno-infectio
orden_seccion: 7
orden: 9
fuente: OneNote del Dr. Castilla Martí
fecha: 2024-05-22
---
# Uvéites infectieuses

They should be searched in priority because they lose a specific TT. It is necessary to remove them before considering a TT for cortis.

## Interrogation is a key element for DX.

- CANDIDOSE
- Revenges TCD4+ independent of IV and Australian lymphocytes and Australian patients in intensive care.

- Aetiology
- L'atteinte ophtalmique se fait pour embole infectieux.

- Signs
- Uvéite antérieur variable
- Asscotia's chorioretinal approach from posterior white intravitreal abscesses, fluffy and white, on a snowball.

- TT
- Medico-chirurgicale:
- Generally antifungal TT: Amphotericin B, Fluconazole/Triflucan
- +/- Intravitreen: Interest of a glassy beep for biological DX

- CMV
- It is infection + freq and ppal cause of blindness in patients with HIV.
- Testifies CMV systemic infection.
- CMV retinitis occurs when CD4+ num LT is <50/mm3 and the viral load is high.

- Signs
- The classical look is a white, edematous, hemorrhagic, paravascular, centrifugal range, which produces a cockade image.
- The center of the lesion heals, the intermediate crown is edematous and the peripheral crown is made up of small satellite bulbs in a healthy retina that will converge to form the front of viral progression, which can be reached.

- Risque de DR!

- DX
- Certitute by puncture with Ca in search of the CMV genome by PCR.

- TT
- Generale +/- local.
- First a high dose attack phase until retinitis healing varies and a maintenance phase to avoid recurrences.
- Ganciclovir or Foscarnet via IV in TT attack by IV.

- The maintenance TT can be stopped when the rate of CD4+ lymphocytic is >100/mm3 and the viral load has been undetectable for 6 months.

- CMV retinitis

- Images:
- CMV Retinitis - EyeWiki (aao.org)

- Disease Entity
- Cytomegalovirus (CMV) Retinitis is an acquired immunodeficiency syndrome (AIDS)-related opportunistic infection that can lead to blindness. CMV retinitis occurred with higher frequency prior to the advent of antiretroviral therapy, but has since been decreasing in well-developed countries, although still remains a prevalent condition in developing countries. It is a viral retinitis that can also be seen in patients who are immunosuppressed for other reasons aside from AIDS.

- Disease
- Cytomegalovirus (CMV) retinitis is an important ocular AIDS associated illness. It is a full thickness retinal infection that can lead to necrosis and retinal breaks and detachments.

- Physical examination

- Physical exam shows yellow white retinal lesions that often start in the periphery and follow the vasculature centripetally. However, it can start in the posterior segment. The classic findings are retinal hemorrhages with a whitish, granular appearance to the retina. Each lesion has the most activity in the borders. Vitreous signs of inflammation may be minimal as most patients are severely immunosuppressed. Very early CMV may resemble cotton wool spots, but with lesions larger than 750 µm, CMV must be considered. Three typical patterns have been described: a granular pattern, a fulminant/hemorrhagic appearance, or "frosted branch" angiitis.

- Rhegmatogenous retinal detachment occurs in approximately one-third of patients when greater than 25% of the retina is involved. The presence of concurrent keratic precipitates in a stellate fashion can also suggest CMV uveitis.

- Signs
- CMV retinitis can present as:
- 1. Fulminant - hemorrhagic necrosis on white/yellow cloudy retinal lesions. They may be centered around vasculature.
- 2. Granular - Found more often in the retinal periphery with little to no necrosis and hemorrhage.
- 3. Perivascular - The classic "frosted branch" angiitis showing white lesions surrounding the retinal vessels.

- Symptoms
- Most patients are asymptomatic,
- but may have floaters, flashes (photopsias), blind spots (scotomata). Pain and photophobia are uncommon.

- Clinical diagnosis
- The clinical diagnosis is made on history and classic retinal findings.

- Differential diagnosis
- Early CMV can resemble cotton wool spots. It may be confused with HIV retinopathy, which is actually more common the CMV retinitis. HIV retinopathy occurs in 50-70% of patients and is characterized by intraretinal hemorrhages, cotton wool spots, and microaneurysms. For small lesions that are hard to differentiate from cotton wool spots, serial exams should be performed, which will show enlargement of the CMV lesions. Immunosuppression should be treated like a spectrum; some patients are more immunosuppressed than other individuals. For cases of minor immunosuppression, CMV retinitis may present as acute retinal necrosis (ARN) syndrome but follows a chronic course similar to CMV retinitis, which may cause misdiagnosis.[1][2]

- Syphilitic hemorrhagic necrotizing retinitis can mimick CMV retinitis; all patients should undergo treponemal testing.[3]

- Management
- Management is largely medically based with intravenous (IV), oral, and intravitreal anti-viral medications. Topical corticosteroids can be used to treat anterior chamber inflammation. Management also hinges on HAART in HIV positive patients.
- Patients should be started on high dose induction therapy, which is followed by continuous maintenance therapy until CD4 counts increase, HAART is therapeutic, and CMV retinitis shows no progression

- Medical follow up
- Depending on the medication used, complete blood counts, chemistries, and intraocular pressure checks will be needed. Dilated eye exams should be performed at least weekly initially, then 2 weeks after induction therapy, followed by monthly thereafter while the patient is on anti-CMV treatment. Fundus photographs can be helpful to detect early relapse.

- Patients should be followed in an appropriate HIV clinic with CD4 counts and viral load studies.

- Complications
- The most serious complication of therapy for CMV retinitis, besides those listed above due to medications is immune recovery uveitis (IRU). As the CD4 counts rise with HAART, it is presumed that reactions to CMV antigens cause anterior or intermediate uveitis. Cystoid macular edema and epiretinal membranes are also potential complications of IRU. Posterior capsular cataracts, proliferative vitreoretinopathy, and optic nerve neovascularization are possible complications as well. HAART therapy can also unmask CMV retinitis in a patient without prior CMV disease (unmasking CMV-immune recovery retinitis (IRR)) or can cause worsening of known CMV retinitis (paradoxical CMV-IRR).
- CMV retinitis that involves > 25% of the retina can lead to rhegmatogenous retinal detachments from breaks that occur near thin, necrotic retina. Peripheral anterior retinal lesions are associated with increased risk of retinal detachment, due to the anterior adherence of the vitreous base.

- Prognosis
- The prognosis was almost uniformly fatal prior to the advent of HAART. Now it carries a much better prognosis, but even with HAART and anti-CMV therapy, mortality is still increased after diagnosis of CMV retinitis.

- Prognosis for patients with or without HIV infection, corticosteroid immunosuppression, and other risk factors all have similar visual outcomes. The strongest factor associated with poorer visual outcomes for all patients is retinal detachment.

- HERPES – Atteintes antérieures

- __Cat disease - Bartonella henselae

- __MALADIE DE LYME – BORRELIOSE

- NECREOSE RETINNIENE AIGUE – ARN

- PNEUMOCYSTOSE

- Pregressive external retina necrosis - Porn or retinitis A VZV

- __SYPHILIS

- TOXOCAROSE

- TOXOPLASMOSE OCULAIRE
- VOIR NOTE SEPARE

- TUBERCULOSE

- VIH
