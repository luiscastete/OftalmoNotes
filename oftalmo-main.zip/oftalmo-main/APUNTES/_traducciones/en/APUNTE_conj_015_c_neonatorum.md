---
categoria: apuntes
area: cornea
emoji: 💧
seccion: Conj + Episclere + Sclere
orden_seccion: 25
orden: 15
fuente: OneNote del Dr. Castilla Martí
---
# C. neonatorum

## 👶🏻 Ophthalmia neonatorum – newborn conjunctivitis

## 📌 Definition

conjunctivitis that occurs during the first 28 days of life. It is one of the most common infections of the newborn. Its incidence varies according to the prevalence of STDs and perinatal care.

## 🧬 Pathophysiology

- The RN has an immature conjunctiva:
  - Absence of lymphoid tissue → No follicles up to 6–8 weeks.
  - Low tear production, less lysozyme activity and absence of secretory IgA.
- The conjunctival flora reflects the maternal vaginal flora, from which infection usually arises during childbirth.
- Routes of infection:
  - during vaginal delivery (the most common).
  - Intrauterine: In case of premature rupture of membranes.
  - Postnatal: by hands, staff, fomites.

## 🚨 Risk Factors
