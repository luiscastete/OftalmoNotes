---
categoria: apuntes
area: cornea
emoji: 👁️
seccion: Cornée
orden_seccion: 4
orden: 30
fuente: OneNote del Dr. Castilla Martí
---
# Non-infectious/inflammatory keratitis

## 🔥4. Non-infectious/inflammatory keratitis

## 🧱4.1. Structural and exogenous disorders

## 🧊4.1.1. Exposure keratopathy

💡 Incomplete closure of the eyelids (lagophthalmos) → corneal desiccation despite normal tears.

Etiology:

- Neuroparalysis: Facial paralysis, Parkinson's.
- Mechanical: Scars, Blepharoplasty.
- Dermatological: Stevens-Johnson, Xeroderma Pigmentoso.
- proptosis.

Clinic:

- 👁️ Dry eye, interpalpebral dotted erosions.
- Ulceration, stromal lysis, severe if severe.
- Chronic changes: Salzmann degeneration.

TREATMENT:

- Preservative-free artificial tears + night ointment.
- Therapeutic contact lenses.
- Tarsorrhaphy / Amniotic membrane grafts / Gold weight on eyelid.
