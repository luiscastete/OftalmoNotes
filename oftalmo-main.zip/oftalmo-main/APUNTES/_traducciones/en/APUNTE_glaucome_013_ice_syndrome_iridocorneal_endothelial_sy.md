---
categoria: apuntes
area: glaucoma
emoji: 🟢
seccion: Glaucome
orden_seccion: 5
orden: 13
fuente: OneNote del Dr. Castilla Martí
---
# ❄️ Ice Syndrome – Iridocorneal Endothelial Syndrome

## ❄️Ice Syndrome – Iridocorneal Endothelial Syndrome

## ✅What is Ice Syndrome?

Endothelial iridocorneal syndrome (ICE) is a rare, acquired, unilateral eye disorder that mainly affects middle-aged women. It is characterized by an abnormal proliferation of corneal endothelial cells, which adopt epithelial behavior: they proliferate, migrate and adhere to structures of the anterior segment, such as the iridocorneal angle and the surface of the iris.

Corneal endothelium that behaves like epithelial tissue

🔬 This anomalous growth produces:

• Secondary glaucoma (≈50%): due to trabecular obstruction and angular closure due to contraction.

• Corneal decompensation: due to endothelial dysfunction.

• Progressive changes in the iris and angle.

## 🧬Why is it called “Ice”?

ICE = Irido-corneal endothelial syndrome

It is called that because it mainly involves three structures:

• Irido- → Changes in the iris.

• Corneal → involvement of the corneal endothelium.

• Endothelial → The primary alteration is in the corneal endothelium, which proliferates abnormally.

This "epithelialized" endothelium can migrate over the angle and the iris, causing synechiae, pupillary distortion and corneal opacity.

## 📋 Clinical presentations (3 subtypes)
