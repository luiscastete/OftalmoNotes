---
categoria: apuntes
area: neuro
emoji: 🧠
seccion: Neuro-Ophta
orden_seccion: 8
orden: 19
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-04-15
---
# Acute binocular diplopia

Sudden appearance of double vision with both eyes open. Simple vision with a single opening.

## AA

Pain

Impairment of visual function?

other neurological disorders?

## Examination

oculomotility

Eyelids (Ptosis or eyelid retraction)

Hertel's exophthalmetry.

Students (Anisocoria)

FO (Palea or papillary edema)

## Differential diagnosis

- Myopathy: Myositis, Basedow disease (Baledow or Graves-Basedow disease is autoimmune hyperthyroidism (thyroid disease) The affected person produces abnormal antibodies (stimulating the TSH receptor) directed Against the follicular cells of the thyroid instead of destroying these cells, as would any normal antibody, these antibodies reproduce the effects of TSH and continuously stimulate the release of thyroid hormones, causing hyperthyroidism accompanied by specific clinical signs)
- Neuromuscular: Myasthenia gravis
- Orbitopathy: Orbital cellulitis, fracture, tumor, hematoma, carotid carotid fistula.
- Peripheral Nueorpathy: Paresia of II, IV, VI.
- Central scope: III, IV,VI, OIN, biased deviation.
- decompensation of a pre-existing foria.

## BILAN COMPLEMENTAIRE

Depending on the suspicion of DX and after the clinical examination:

- Orbital and cerebral MR
- Blood test
- ice cubes test (myasthenia)
- Tensilon test (myasthenia)
- Temporal artery biopsy (Horton's disease)
