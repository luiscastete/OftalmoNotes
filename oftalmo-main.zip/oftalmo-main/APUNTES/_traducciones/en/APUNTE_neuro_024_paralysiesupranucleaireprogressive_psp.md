---
categoria: apuntes
area: neuro
emoji: 🧠
seccion: Neuro-Ophta
orden_seccion: 8
orden: 24
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-09-28
---
# Progressive supranuclear paralysis-PSP

Progressive supranuclear paralysis is a rare degenerative central nervous system that gradually alters the voluntary movements of the eyes, causing:

- bradykinesia,

-Muscle stiffness with progressive axial dystonia, pseudobulbar paralysis and dementia. The diagnosis is clinical. The treatment is symptomatic.
