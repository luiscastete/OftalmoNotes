---
categoria: apuntes
area: neuro
emoji: 🧠
seccion: Neuro-Ophta
orden_seccion: 8
orden: 30
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-08-24
---
# Unilateral papillary edema

AA-BILAN

## AA

pain?

Impairment of visual function? After when?

other neurological disorders? After when?

Does it accompany headaches? boy?

fever?

taking antibiotics?

other systemic diseases?

## Examination

AV

Neuro-Ophta: CV by confrontation, Ishihara, red desaturation test

Students: RAPD search

Hertel's exophthalmometry

LAF: UAA sign? vitrito?

Dilated fo: search for retinal lesions, vasculitis.

## Differential diagnosis

Papillary pseudoedema (drushe, hypoplasia)

Inflammatory (SEP,NMO, MOG, optic perinevity, post-vaccination)

Ischemic (Noia)

Infiltrative (sarcoidosis, leeuemia, metastasis)

Compressive (orbital lesion)

Infectious (Lyme, TB, syphilis, Bartonella, HIV)

Hereditary (Leber optic neuropathy)

Papillary edema stasis: Very rarely unilateral.

Traumatic: Exceptional

## With symptom of visual loss

- AVEC DOULEURS:
- Inflammatory (sarcoidosis)
- Infectious

- SANS DOULEURS
- ischemic
- infiltrator
- compressor
- Leber optic neuropathy

## No visual loss symptoms

pseudoedema

Papillary edema stasis

Compression: Rarely

## DRAPEAUX ROUGES

- Age > 60 years: --Horton! Exclude the disease from our beloved Hortonen emergency with AA and VS, CRP, thrombocytes (see chapter Noia-A).

- exophthalmos:
- infiltrating-compressive process.
- If Pain: Excludes inflammatory syndrome and orbital infectious infiltration (sinusitis) in Rugnce (evocative AA)
- Yes No Pain: Oncology AA and evaluation with cerebral and orbital magnetic resonance imaging (delays of a few days)

- Blindness (AV < mm):
- Noia (age>60 years + FRCV + painless)
- Leber optic neuropathy: young + painless
- NMO: Young woman + pain

## Examination

AV

Neuro-Ophta: CV by confrontation, Ishihara, red desaturation test

Students: RAPD search

Hertel's exophthalmometry

LAF: UAA sign? vitrito?

Dilated fo: search for retinal lesions, vasculitis.

## BILAN COMPLEMENTAIRE

Depending on the suspicion of DX and after the clinical examination:

Orbital and cerebral delay 8 Delays depending on the emergency)

Laboratory exam: (Emergence for suspicion of Horton disease): Infectious evaluation, autoimmune evaluation, anti-NMO antibodies, genetic testing in a specialized unit).

## When to refer to the neuro-oftha unit

If the presence of red flags: Discuss/present the patient in the unit.

Once the initial care is taken, the patient is followed in the unit.

Any patient went from the outside for the second opinion on unilateral papillary turgidity and examined directly at the unit.

## Notes

RAPD-free optic neuropathy: Only possible with Leber's optic neuropathy*

Severe sensitive cortic pain: suggestive of optic perinevirvicity or sarcoidosis.

An optical perineveity is not associated with MS.
