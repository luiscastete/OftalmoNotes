---
categoria: apuntes
area: cornea
emoji: 👁️
seccion: Cornée
orden_seccion: 4
orden: 36
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-01-30
---
# excess syndrome

AA LDC:

LDC type?

How much PMA?

bedroom with LDC?

PMA port in the shower/heat baths/pool/sauna last time? Bathing in the LEC this last time?

Similar episode in the past?

Last door of the LDCs?

To change the LDC box When?

Treatment

Add Floxal GTT 4-8XJ 48H

Add Optava 4-8xj

PC in 48h if it is fluorescent: add DF 3xj derelation diagram.

Att:

FLOXAL GTT 4XJ

FML 4xj

Choose as needed

PVA at night

2 Control

yes it's fine

stop f

fml 3xj pt 4j then 2xj pdt 4j then 1xj pdt 4j

Continue Optava and PVA

PC in 3-4 sem because FML BCP and it works fine.

If 2FML, you can decrease 1xJ PFT 5D and not control, but
