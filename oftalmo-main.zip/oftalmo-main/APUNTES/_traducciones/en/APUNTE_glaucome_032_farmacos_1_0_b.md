---
categoria: apuntes
area: glaucoma
emoji: 🟢
seccion: Glaucome
orden_seccion: 5
orden: 32
fuente: OneNote del Dr. Castilla Martí
---
# Drugs 1.0 B

Following order nemotectic rule of "Beatriz Chef of the Alfa prepares half pink hyperpicking lamb"

## 🧠 Mnemonic phrase

“Beatriz, the alpha chef, prepared lamb with a half-pink hyper-pop.”

## 📋 Summary table

| Keyword | Pharmacological group | representative drugs | main mechanism |
|---|---|---|---|
| Beatrice | Beta blockers | Timolol, betaxolol | ↓ Production of aqueous humor |
| Chef | INH. Carbonic anhydrase | Dorzolamide, acetazolamide | ↓ Production of aqueous humor |
| Alpha | alpha-agonists | Brimonidine, apraclonidine | ↓ Production + ↑ Uveoscleral drainage |
| prepared | prostaglandins | Latanoprost, travoprost | ↑ Uveoscleral drainage |
| Lamb | cholinergics | Pilocarpine, carbachol | ↑ Trabecular drainage |
| Middle | myotics |  |  |
| Pink | Rock Inhibitors | Netarsudil, ripasudil | ↑ Trabecular drainage + ↓ Mild production |
| Hyperpitch | hyperosmotics | Mannitol, glycerol | ↓ Vitreous volume (osmotic, acute) |

## 🔄 Phonetic Trick (ordered by phrase)

| Keyword | Pharmacological group | Termination or key root | phonetic trick |
|---|---|---|---|
| Beatrice | Beta blockers | “-lol” | if it contains”-lol”→ beta-blocker |
| Chef | INH. Carbonic anhydrase | “-zolamide” | If it ends in “-zolamide”→ inh. anhydrase |
| Alpha | alpha-agonists | “-Onidin” | If it ends in”-Onidine”→ alpha-agonist✅ |
| prepared | prostaglandins | “-prost” | If it ends in”-prost”→ prostaglandin |
| Lamb | cholinergics | – | They do not have a fixed phonetic pattern (memorized direct: pilocarpine, carbacol) |
| Pink | Rock Inhibitors | “-SUDIL” | if it contains”-sudil”→ rock inhibitor |
| Hyperpitch | hyperosmotics | – | If it sounds weird and it's urgent → Hyperosmotic 😅 |
