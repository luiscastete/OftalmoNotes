---
categoria: apuntes
area: uveitis
emoji: 🔥
seccion: Immuno-infectio
orden_seccion: 7
orden: 8
fuente: OneNote del Dr. Castilla Martí
fecha: 2024-05-22
---
# white spots on fo

## chorioretinopathy

Bird firing chorioretinitis is a bilateral posterior uveitis that affects 1% of patients with uveitis and 7% of patients with posterior uveitis.

It reaches Caucasian subjects between 15 and 79 years old.

Symptoms: Visual blur, myodesopsia, nyctalopia, photopsies, CV restriction, as well as abnormalities in color vision.

Typically, pellet lesions are observed that heal like hunting lead traces, the origin of the name of this pathology, "pigeon shooting" xD.

They are bilateral, oblong or round croidian shapes, or irregular or linear shapes, hypopigmented at the posterior pole and at the retroequatorial periphery. Lesions measure ¼ to ½ papillary diameter. They are found around the optic nerve and at the level of the vascular arches; They are more numerous in the nasal retina.

The SA is the seat of moderate infamation, the posterior synechiae and the retrocorneal precipitates are absent.

A moderate hyalitis - absent lesion from the ice pack or ant OEFS - was presnet with papilla edema and vasculitis - periflebitis at the post-pole

OCT in OCT is present in 30-35% of patients. This is the most common cause of VAD.

## Fluorescein and Indocyanine Green Angiography

AF usually shows hypofluorescent lesions in the initial phase. In later times, lseions often become hyperfluorescent. AF is useful for showing parietal leaks of retinnial VSSX and papillary hyperfluorescence which is almost present TJSR. It also shows a WTO and you can find a choroidal neovvs.

Indocyanine green langio (ICG) is more useful than AF to locate schoolgirl lesion that seems more numerous than in the FO or AF exam. These oval hypocyscent lesions are especially visible during the intermediate phase of the ICG.

## Diagnosis

DX first clinically and due to the presence of HLA-A29 human leukocyte antigen.
