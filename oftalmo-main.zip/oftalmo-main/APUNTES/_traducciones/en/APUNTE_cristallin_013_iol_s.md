---
categoria: apuntes
area: catarata
emoji: 🔍
seccion: Cristallin - Lens
orden_seccion: 21
orden: 13
fuente: OneNote del Dr. Castilla Martí
---
# IOL's

| IOL type | Correction | DISTANCES | Ideal patient | visual effects | Corregible astigmatism | commercial examples | contraindications | name explanation |
|---|---|---|---|---|---|---|---|---|
| monofocal | Myopia/hypermetropia | 1 distance | majority of patients; No high expectations | high visual quality; No halos | No | Acrysof IQ, Tecnis 1 | Does not correct astigmatism | Not applicable |
| monofocal-toric | myopia/hyper. + Astigmatism | 1 distance | Regular astigmatics ≥1 D | high visual quality; No halos | up to 4–6 d corneal | Acrysof Toric, Tecnis Toric | Do not use in irregular astigmatism | toric curvature (2 spokes); Correct astigmatism |
| Trifocal | Myopia/hypermetropia | Far + Intermediate + Close | High visual demand without eye pathology | Halos, Glare, ↓ Contrast | No | PanOptix, AT LISA tri | Do not use in DMAE, glaucoma, severe dry eye, irregular astigmatism | Divide light into 3 spotlights (diffractive) |
| Trifocal-toric | Idem + astigmatism | Far + Intermediate + Close | High visual demand + regular astigmatism | Halos, glare | up to 4–6 d corneal | PanOptix Toric, AT LISA tri Toric | Do not use on irregular corneas or pathologies | Toric + Trifocal Diffractive |
| EDOF | Myopia/hypermetropia | Far + intermediate (little close) | Good visual quality and night driving | Mild halos (less than trifocal) | No | Symfony, Vivity | Not ideal if you need a lot of reading without glasses | Extend the focus without dividing the light |
| edof-toric | Idem + astigmatism | far + intermediate | active with regular astigmatism | mild halos | up to ~4 d | Symfony Toric, Vivity Toric | Do not use in irregular astigmatism | EDOF + O-ring curvature |
| accommodative | Myopia/hypermetropia | Variable (limited) | selected cases; low actual efficiency | Little real independence | No | Crystalens, Trulign | current disuse | Axial mobility simulating focus |
| Aspherical (design) | Spherical aberration | Contrast improves | Demanding patients, drivers, night vision | Improved low light vision | No | Tecnis ZCB00, Acrysof IQ Aspheric | useful in all cases | Not perfectly spherical → Enhances peripheral focus |
| Blue filter | Macular Protection | Neutral optically | Risk of AMD, retinopathy, sun exposure | retina protection | No | Natural Acrysof | Controversial in visual artists | Built-in blue-violet light filter |
