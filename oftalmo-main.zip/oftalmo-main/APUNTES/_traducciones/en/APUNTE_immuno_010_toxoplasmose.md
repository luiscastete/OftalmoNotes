---
categoria: apuntes
area: uveitis
emoji: 🔥
seccion: Immuno-infectio
orden_seccion: 7
orden: 10
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-08-18
---
# Toxoplasmosis

## Definition

Causes more frequency of inflammation in the posterior segment of infectious origin

Parasitic infection caused by compulsory intracellular protozar, Toxoplasma gondi.

congenital or acquired origin.

The support mainly depends on the location of the focus.

__EPIDEMIOLOGIE

## Toxoplasma gondi, exists in 3 evolutionary forms

- Tachyzoites or free shapes

-Bradizoites contained in cysts

-Ocysts

## COMMENT REFEERER?

## DX

## Typical shapes

## Symptoms

Mostly asymptomatic (immunocompetent subjects) but serious risk if women who are pregnant, HIV-positive or weakened from the immune system.

## OCULAIRES

- Redness
- deep pain
- Photophobie
- BAV
- CV amputation
- Absence of secretions
- Myodesopsia

## SYSTEMIQUES
