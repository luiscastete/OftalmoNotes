---
categoria: apuntes
area: uveitis
emoji: 🔥
seccion: Immuno-infectio
orden_seccion: 7
orden: 5
fuente: OneNote del Dr. Castilla Martí
fecha: 2024-03-20
---
# Conjunctivitis at inclusion - Chlamydia

infection of the conj tarsal and bulbar of bacterial origin: Chlamydia trachomatis.

## Symptoms

## OCULAIRE

- Please often: Chronic conj >4 sem.
- Mucupurulent secretions
- Marked conjunctival hyperemia

## GENEREAUX

Man: Urethritis +/- Symptomatic

Woman: cystitis, vaginitis (flows) +/- pelvic inflammatory disease, that is, adnexitis, risk of infertility and Fitz-Hugh-Curtis syndrome.

## Signs

- Large follicles – lower tarsus +/- upper
- Usually unilateral signs.
- Yes Chronic: Papillae
- Sticky muques and secretions
- Palpable Petragian adenopathy
- Gray-white peripheral subepithelial infiltrates
- early Pannus associates.
- Superficial punctiform keratitis – KPS
- In the long run:
- conjunctival scars
- corneal pannus

## Aetiology

Chlamydia: Mandatory intracellular bacteria: the smear should bleed

Chlamydia:

- C.pneumoniae
- C.tracomatis
- C.Psitacci
