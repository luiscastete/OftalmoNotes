---
categoria: apuntes
area: cornea
emoji: 👁️
seccion: Cornée
orden_seccion: 4
orden: 42
fuente: OneNote del Dr. Castilla Martí
---
# Thea dry eye masterclass

Clinical cases

Leasing cause of evaporarive dry eye mgd

IPL - you can use it more freq if needed-

You can décide the freq on the go - selon réponse patient

Prof Benitez del Castillo

590 filtre and a vascular filter works better

He is using also cold compresses

Hot compresses if for masssages and taking out the sécrétions buut forbinflamatiom cold conpresses work well

Protocole recommands;

Hot compresses - strong blinking and massages - and then cold compresses*

Lípiflow? What is it?

Ménopause - systémique disease - if dry eye is the unique symptom no consultation but if other symptoms- add consultation for hormonal remplacements

Prof grupcheva

The 6 questions k Kipling

En ojo seco

Añadir

Shirmer and But and Meibomogtsohy if it doesn't get better.

Montarse esquema protocolo claro.

She opted for scleral lenses

Not good results bcs management complicated

Recommends cyclosporine and omega 3

Ciclosporine is an Immunomodulator ( not inmunosupresor ) and there is no need of stoping it - and is very safe and has no systemic effects

Minimum periods of 12 months

They don’t stop it - has a great antiinflamatoriy effect

Cases dry eye and sarcoidosis

Conj inflammation is difficult to see if you don’t put rose bengals or very lisamin * mucho mejor

CHRONIC GVHD - graft versus host disease

In patients treated by leukemia - dry eye is freq ++ gland lacrymal is afected.

Attention of cancer care and ocular effects - a lot of adverse effects in new therapies

New therapies

Anti cancer immunotherapy

Will unlock t cells - that will kill cancer but….also will get up immunodisease and dry eye!!!

PED -Kymionis

In Spain de use alot insulin drops

In other country a not, why? What effect they have

Formations

Dr Alvarez Castillo

Recommend Plugs a Silicone up and down to redeem Inflammation - because more tear helps to make less inflammation - don't go step by step you see with everything at first - especially when you have ded flares

Ikervis is safe - has some patients using it for 30 years bcs dry eye is a chronic condition

Main concept:

- We treat patients…not signs!

So mail y we make more attention to symptômes rather than signs.

YOU DONT NEED TO STOP  CYCLOSPROINE PRÉ AND POST SURGERY

( bcs is not a immunodepresant is an immunomodulator)

Insulin drops has same indications  serum autologueis

Mainly as a épithélial growth factor

Works in épithélial defectos

But is much less expensive

And has no systémique altérations

And diabétiques can take it

Posologie?

look for studies of Benítez of this man

Dosage:  1unidad internacion

You can use it with Cyclosporine

He gives insulin before autologeus sérum - prefers allogeneurs ( bcs the patient has plegy of inflammatoire factors in his blood ) so prefers others blood less inflammatoiry

In Spain has Also immuno safe -

Read about dysbiosis - Altered microbiota -

MEET THE EXPERT

Prod Akpek

Clinical evaluations:

1-Corneal staining

2-BUT

3-And conjuntiva staining with lisin green - attention is for conj and takes more minutes

Posologíe start with 2xj -

Next consultation at 6weeks

Continue reste of drops over the counter

With cortisone drops

8xj per 2 sem (HIOP comes in 3rd week)  puis 6xj pdnt 2 sem puis 4 pdt 2 sem puis 2xj pdt 2 sem

And some times 1xj per day

Not forget that you have to continue other tt…drops, creams, massages, plugs…

And don’t stop! The tt explain the patient that is going to stay

It is safe for children*

Explain that is much safer and better for the eye than cortisone long tt - for long pathology- what alternative you have? Be carefool cortisone with High IOP and cataracts!!! In lotemax

Microbiome in eyelid yes but not clear if there is is cornea - normally no -

Most important factor it tears is mucin layers

Not all tears are the same
