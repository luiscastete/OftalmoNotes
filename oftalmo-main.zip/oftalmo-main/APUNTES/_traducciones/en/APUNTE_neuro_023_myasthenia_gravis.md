---
categoria: apuntes
area: neuro
emoji: 🧠
seccion: Neuro-Ophta
orden_seccion: 8
orden: 23
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-08-24
---
# Myasthenia Gravis

Rare autoimmune disease (15/million incident), characterized by weakness and muscle fatigue due to a neuromotor plaque abnormality with a postsynaptic acetylcholine receptor dye.

## Symptoms

## OCULAIRES

Variable Diplopia

Variable ptosis

Multiple oculomother disorders No evocative pattern

## SYSTEMIQUES

Muscle weakness

Injury in case of bulbar signs: vital risks with change of voice, false paths, breathing difficulties.

## Signs

Oculomotor disorders not corresponding to classical damage to a type III, IV, VI paresis.

Significant variability of measurements and fatigue

Variable diplopia and ptosis with impaired fatigue, physical effort, heat.

No pupillary participation

## Aetiology

Autoimmune disease of unknown etiology

Different shapes, great heterogeneity of clinical presnetatations

Ocular signs as an initial presentation In 70% of cases, it is generalized in 80% of cases in 2 years.

Classically bimodal distribution: peaks around 20 years (f>h) and 60 years (h>f), more risk of progression to a serious and generalized form in late forms.

Frequent associated thymic anomaly (mainly hyperplasia, thymoma in 15% of cases) and other autoimmune diseases (4-10% of Graves' disease).

## Examination
