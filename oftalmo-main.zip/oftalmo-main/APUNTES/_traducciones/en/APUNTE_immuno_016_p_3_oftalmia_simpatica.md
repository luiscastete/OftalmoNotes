---
categoria: apuntes
area: uveitis
emoji: 🔥
seccion: Immuno-infectio
orden_seccion: 7
orden: 16
fuente: OneNote del Dr. Castilla Martí
---
# p.3 -Ophthalmia sympathetic

5.3. sympathetic ophthalmia (or rather empathic right? so much that she gets sick too)

## Definition

Bilateral granulomatous uveitis secondary to perforating trauma or intraocular surgery on one eye (excitizing eye), which subsequently affects the other healthy eye (sympathizer eye).

## Epidemiology and causes

- Incidence: ~1/1000 after penetrating ocular trauma.
- Currently, the most common cause is vitreous-retinal surgery.
- It affects both sexes equally. lower incidence in children.
- 1/3 occurs in the first 3 months, <50% during the first year after the event.

## Clinic

- Bilateral granulomatous panuveitis, initially more severe in the excitatory eye.
- Typical signs:
  - Keratic precipitates in ram fat.
  - Iridian thickening with later synechiae.
  - Dalen-Fuchs nodules: white-yellow, equatorial.
  - Serous retinal detachment (exudative DR).
  - Cataracts, EMQ, peripapillary/macular NVC, optical atrophy.
