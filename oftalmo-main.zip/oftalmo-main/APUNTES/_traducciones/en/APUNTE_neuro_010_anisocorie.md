---
categoria: apuntes
area: neuro
emoji: 🧠
seccion: Neuro-Ophta
orden_seccion: 8
orden: 10
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-08-12
---
# ANICARY

Anisocoria is defined by a difference in size between the two students. One of the two students is affected, is in mydriasis or in miosis.

The causes that lead to this disorder are diverse, ranging from benign physiological anisocoria to severe neurological disorders. Therefore, its presence requires systematic medical advice.

English singer David Bowie had this disorder

## MECANISMES

- Ophthalmic
- essential physiological
- neurological
- pharmacological

## Examination

- Measurement of pupillary diameter in scotopic (without light) and photopic (light)
- Measuring slots with meter (difference up to 1 mm > 1 mm)
- Examination of the palpebral clefts and oculomotility
- LAF exam
- Pharmacological test if necessary

- Most marked anisocoria in photography (light)
- La Grande Pupille Contact Moins Well

- Irien Sphinner trauma.
- Visible lesion in LAF: tears, synequies, atrophy, transillumination.

- Parasympathetic deterioration:

- 2.1-Adi Tonic Student
  - Sectoral paressis of Iria <8 sem:
    - Light-near dissociation (aberrant re-innervation).
    - Pilocarpine miosis 0.125% (hypersensitivity to denervation)

- 2.2.Nc III Paresis
  - lipstick ptosis
  - Oculomotor disorders
  - Bad accommodative reflection.
  - Pilocarpine miosis 2%
  - Chronic: Pilocarpine miosis 0.125% (hypersensitivity to denervation)

- Pharmacological mydriasis
- No pupillary reaction: light, accommodation, 2% pilocarpine.

  - Most marked anisocoria in Scotopic (Nightlight)
  - La Grande Pupille Contact Moins Well

- 1. Irido-crystalia synthesis
- LAF exam

- Claude Bernand Horner Syndrome

- Associated with miosis:
- Palpebral potosis >1-2mm
- Reverse Palpebrale Ptosis Reverse 1mm
- anhydrosis.
  - Cocaine test 10% positive (increased anisocoria) * Cocaine test: Usable at any age of birth.

  - Apraclonidine (iopidine) Positive test (decrease or inversion anisocoria and/or ptosis) Apraclonidine test: Contraindicates children < 2 years due to risk of respiratory depression.

  - 2.1.Central/pre-ganglionic
  - Anhidrosis +/- covering the hemiface

  - 2.2. post-ganglionic
  - anhidrosis +/-

- Pharmacological miosis
- Tight miosis

- Physiological anisocoria
- Absence of delay in dilation of the small pupil.
- pharmacological tests neg.
