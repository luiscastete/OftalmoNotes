---
categoria: apuntes
area: neuro
emoji: 🧠
seccion: Neuro-Ophta
orden_seccion: 8
orden: 29
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-08-24
---
# Bilateral papillary edema

## Symptoms

Asymtomatique

SYTOMATIC:

- Transient opacification episodes of Visiol transient amaurosis? tvs?
- Horizontal diplopia
- Nausea and/or vomiting
- headache
- Pulsatile tinnitus

## Signs

Bilateral papillary turgescence

+/- No bleeding

+/-Druses of no

+/-Retinal lesions

## Differential diagnosis

- Papillary pseudoedema
- Papillary edema stasis
- Malignant hypertension
- Toxic (Amiodarone)
- Druze of no

## BILAN

- CV computers*:
  - Normal or abnormal (particularly enlargement of the blind spot, nasal passage)* In an emergency, this only here we have had such a lost vision!!

  - Autofluorescein of the optic nerve (drushes)
  - OCT: RFNL, RGCL, EDI lines in no
  - +/- Ultrasound B scan
  - Control your
  - +/-Retinal angiography
