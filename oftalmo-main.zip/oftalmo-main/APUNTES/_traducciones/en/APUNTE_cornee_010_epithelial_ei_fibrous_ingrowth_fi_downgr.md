---
categoria: apuntes
area: cornea
emoji: 👁️
seccion: Cornée
orden_seccion: 4
orden: 10
fuente: OneNote del Dr. Castilla Martí
---
# Epithelial (EI) - Fibrous Ingrowth (fi) /Downgrowth

Epithelial (EI) - Fibrous Ingrowth (fi) /Downgrowth

Sunday, September 14, 2025

18:44

## 📑 Epithelial vs Fibrous Ingrowth – Ebo Summary

## 🔬 Definition

- Epithelial Ingrowth: Proliferation of epithelial cells within the anterior chamber through surgical/corneal wounds.
- Fibrous Ingrowth: Proliferation of fibrous tissue (fibroblasts and collagen) in surgical wounds or eye incisions.
