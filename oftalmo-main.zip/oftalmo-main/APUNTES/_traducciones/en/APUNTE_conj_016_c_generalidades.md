---
categoria: apuntes
area: cornea
emoji: 💧
seccion: Conj + Episclere + Sclere
orden_seccion: 25
orden: 16
fuente: OneNote del Dr. Castilla Martí
---
# C. GENERALITIES

## 👁️‍🗨️Conjunctivitis – General

Conjunctivitis is an inflammation of the conjunctiva, characterized by:

- Conjunctival hyperemia (vascular dilation)
- cell infiltrate
- Exudation

The clinical classification is based on:

- evolution time:
  - Acute: < 3 weeks
  - Chronic: ≥ 3 weeks
- type of secretion
- Conjunctival response morphology
- most affected area

## 💧 Types of secretion

| type of secretion | indicative of: |
|---|---|
| Serous | Acute viral or allergic conjunctivitis |
| Mucoid | Chronic allergy, dry eye |
| Mucopurulent (catarrhal) | Bacterial, chlamydia |
| purulent | Hyperacute conjunctivitis (e.g., Neisseria) |
