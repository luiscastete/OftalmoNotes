---
categoria: apuntes
area: cornea
emoji: 👁️
seccion: Cornée
orden_seccion: 4
orden: 21
fuente: OneNote del Dr. Castilla Martí
---
# Corneal ectasias- Keratoconus

## Keratoconus (QC)

Bilateral, asymmetric and progressive corneal ectasia characterized by corneal thinning, apical protrusion and irregular astigmatism.

## 🧬Etiopathogenesis and general characteristics

• Progressive degeneration of corneal stroma with central/paracentral thinning.

• Apical protrusion, irregular astigmatism and progressive myopization (clear plus curve + more power).

• Unilateral initial involvement, then bilateral (topographic).

• Typical onset age: 10–30 years.

• Associated factors:

-Systemic: Down syndrome, Marfan, Ehlers-Danlos, Osteogenesis imperfecta.

-Eye: Chronic eye rubbing, aniridia, blue sclerotics, Vernal QC, Leber congenital amaurosis.

• Autosomal dominant inheritance with incomplete penetrance (6–8% family cases).

## 🔍 Clinic

## Symptoms

• Progressive visual decrease due to irregular astigmatism.

• Halos, glare, blurred vision.

• Can debut with acute corneal hydrops.

## signs according to stage

| Stadium | Key signs |
|---|---|
| Early | Oil drop reflection (ophthalmoscopy),<br>Scissor reflex in retinoscopy - rizzutti sign |
| Intermediate | Vogt grooves are vertical (disappear with pressure),<br>Fleischer ring (Fleischer-Fe++ iron tanks),<br>Visible corneal nerves - corneal nerves become more prominent, |
| Advanced | Munson's sign (V deformation of the eyelid-consists of lower eyelid distortion when the patient with advanced keratoconus looks down),).<br>Acute corneal hydrops (Descemet break) |
|  |  |
