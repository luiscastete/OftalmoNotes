---
categoria: apuntes
area: uveitis
emoji: 🔥
seccion: Immuno-infectio
orden_seccion: 7
orden: 6
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-09-23
---
# AJI - Juvenile Idiopathic Arthritis (JIA)

Uveitis is one of the most common extra-articular manifestations of juvenile idiopathic arthritis (JIA). The classical clinical picture is that of a non-granulomatous chronic uveitis, which generally remains asymptomatic until the appearance of complications that can trigger the visual prognosis of these children.

The purpose of our work is to evaluate the correlation between the appearance of eye damage and the clinical course of JIA.

## Discussion

Idiopathic juvenile arthritis is the main etiology of uveitis in children. The attack is bilateral in ¾ of cases.

The risk factors for uveitis in children with JIA are: female sex, age < 6 years, oligo-articular form, antinuclear antibodies positivity, and negativity of the rheumatoid factor.

The main complications are: cataract, synechia, secondary glaucoma, keratopathy in strips.

## Conclusion

Ocular involvement associated with juvenile idiopathic arthritis is more asymptomatic, but it is likely to lead to dramatic complications, hence the interest in systematic detection and rapid and adapted management (reumerology that decides but usually 3-6-12 months)

## The purpose discards asymptomatic UA NG.

## uveitis of the child and chili

Uveitis in children accounts for about 10% of all intraocular inflammatory drugs.

Pediatric uveitis is mainly bilateral and non-infectious.

It is important to define whether uveitis is isolated or associated with AJI, sarcoidosis or behçet.

Very complicated patients to manage, very emotional component on the part of the parents*
