---
categoria: apuntes
area: uveitis
emoji: 🔥
seccion: Immuno-infectio
orden_seccion: 7
orden: 28
fuente: OneNote del Dr. Castilla Martí
---
# Eye knows

U HLA B27+

In case of recurrence < 3 months.

Add 1GTT Cortis XJ

Consider crotis peros if you cut pensande >2GTT cortis per day
