---
categoria: apuntes
area: catarata
emoji: 🔍
seccion: Cristallin - Lens
orden_seccion: 21
orden: 1
fuente: OneNote del Dr. Castilla Martí
fecha: 2022-08-30
---
# CATARACTE

Loss of lens transparency.

## Epidemiology

Variable prevalence (71% YES > 85% years) 1st cause of reversible blindness worldwide, 40% of cases of blindness worldwide.

## Symptoms

Bav from far and near

- quickly for cats. Publish subcapsular.
- slow for cats. cortical and nuclear

Monocular diplopia (by refractive definition)

+/- Index myopization, especially in nuclear cataracts: Possible second sight phenomenon or patients no longer need their reading glasses to see closely.

glare

Halos around the lights (especially described at night with headlights when driving).

decreased sensitivity to contrasts.

Alteration of color vision.- Color absorption of short wavelengths - Cold blue colors

this is possible if not ttt.

## Signs

## bass av that improves in the pinhole trou

Nuclear sclerosis, cortical cataract, posterior subcapsular veil (clearly visible to the backlight of the lens in mydriasis)

Attention if farsightedness + cataract: risk of closed glaucoma +/- acute glaucoma when closing the angle.

## Aetiology

Age

trauma

Drugs: corticosteroids, antipsychotics.
