---
categoria: apuntes
area: glaucoma
emoji: 🟢
seccion: Glaucome
orden_seccion: 5
orden: 30
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-03-13
---
# When to refer to Unite

HTIO

Stable treatment (no signs of glaucoma-oct, normal CV)

Untreated, low risk (Ti<25 mmHg, normal pachymetry, negative AF).

Suspicious glaucoma (papilla, cv)

Pseudo-exfoliative syndrome (PEX) or pigment scatter syndrome (PRS) without signs of glaucoma (normally uncle, healthy papilla, OCT + normal CV)

GPAO: Stable (patient taking a combined GTT or GTT: Xalacom, Duotrav, Ganfort) with stable OCT exams.

NOTE:

All patients who are treated and stable should be reviewed 2 times.

Patients who are suspected or have low-risk treatment should be seen every 9-12 m.
