---
categoria: apuntes
area: cornea
emoji: 💧
seccion: Conj + Episclere + Sclere
orden_seccion: 25
orden: 13
fuente: OneNote del Dr. Castilla Martí
---
# Conjunctival tumors 2.Melanocytic

- Quick ranking at startup
- Histopathological details of melanoma
- Final comparison table for easy review

## 🧠

## 5.2. Conjunctival melanocytic tumors – Key Summary

## 📊

## Quick classification

| Type | Elevation | Pigmentation | risk of malignancy |
|---|---|---|---|
| nevus | Sí | Variable | low (1%) |
| Acquired primary melanosis (PAM) | No | Sí | Variable (0–90%) |
| Secondary acquired melanosis | No | Sí | Null |
| conjunctival melanoma | Sí | Variable | High (15–30% metastases) |

## 🟤

## 5.2.1. conjunctival nevus

- Most common benign melanocytic tumor.
- Histological types: Junctional, compound, subepithelial (depends on age).
- Appearance: Childhood or adolescence.
- Location: Bulbar, limbo, plica, caruncle.
- Variable pigmentation (30% amelanotic).
- Intralesional cysts in 50% (typical data).
- Suspicious factors: growth in adults, unusual location, prominent vessels, without cysts.

- Malignancy risk: low (1%).
- 🩺 Management: Observation if there are no signs of suspicion.

## ⚫

## 5.2.2. Conjunctival melanosis

## ➤

## congenital

- Epithelial (efelids): Pigment increase, without proliferation. Stable, no malignancy.
- Subepithelial (melanosis oculi): affects episclera/sclera. Associated with OTA nevus (± meningeal, uveal, orbital involvement). Low risk of malignancy (1/400).

## ➤

## acquired

📍 PAM (primary acquired melanosis)

- Intraepithelial proliferation of melanocytes. analogous to the malignant lentigo.
- Clinic: Flat, unilateral pigmented patch in middle-aged/advanced Caucasians.
- ⚠️ You can progress to melanoma by 13–46% if there is atypia.

🔬 Histopathology:

- PAM without atypia: no risk of malignancy.
- PAM with atypia:
  - Basal atypia → 20% progression.
  - Epithelioid cells → 75%.
  - PageToide extension → 90%.

🩺 Management:

- <2 h of the clock → Tracking.
- Biopsy + cryotherapy if warning signs or extension.

📍 Secondary Acquired Melanosis

- Melanin increase without melanocytic proliferation.
- It has no malignant potential. Typical in dark, bilateral, perilimbic breeds.

## ⚠️

## 5.2.3. conjunctival melanoma

## 🔬

## histopathology

- Invasion of stroma by atypical melanocytes.
- Cell types:
  - small polyhedral.
  - fusiforms.
  - epithelioid (worst prognosis).
  - baloon.
- Immunohistochemical staining: S100, HMB-45, Melan-A.

## 📋

## Clinic

- Pigmented elevated mass (or amelelanotic), with nourishing vessels.
- 74% arise from PAM, 7% from nevus, 19% from de novo (more aggressive).
- Most frequent location: Bulbar interpalpebral.

## ⚠️

## Poor prognostic factors

- De novo, non-bulbar, thickness >2 mm, ulceration, recurrence, BRAF+.

## 📉

## Forecast

- Metastases: 15% (5 years), 25% (10 years).
- Mortality: 30% at 10 years.
- Metastatic sites: lung, liver, brain.

## 🩺

## Treatment

- No-touch surgery + margin cryotherapy.
- Adjuvant radiotherapy: strontium, ruthenium or iodine.
- MMC: adjuvant or in extensive PAM.
- Immunotherapy: BRAF/MEK inhibitors, anti-PD-1 (nivolumab, pembrolizumab).

## 📑 Comparative table summary

| Feature | nevus | PAM | Secondary melanosis | conjunctival melanoma |
|---|---|---|---|---|
| Origin | melanocytes | Intraepithelial melanocytes | Pigmented epithelium | Malignant melanocytic cells |
| Elevation | Sí | No | No | Sí |
| Pigmentation | Variable | Sí | Sí | Variable (up to 20% amelanotic) |
| Frequency | HIGH | Average | High in pigmented breeds | Low |
| malignant risk | low (1%) | Variable (13–90%) | Null | High (30% mortality at 10 years) |
| Typical location | bulb/limbar | Bulbar ± multifocal | bilateral perilimbic | Interpalpebral bulb |
| Typical Findings | Cysts, mobile | Flat pigmented plate | Stable pigmentation | High mass, nourishing vessels |
| Treatment | Observation ± Surgery | Follow-up ± Surgery | None | Surgery + Cryotherapy + Radiotherapy |
