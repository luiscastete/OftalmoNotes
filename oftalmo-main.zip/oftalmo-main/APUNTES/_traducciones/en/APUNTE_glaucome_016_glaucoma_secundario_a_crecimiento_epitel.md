---
categoria: apuntes
area: glaucoma
emoji: 🟢
seccion: Glaucome
orden_seccion: 5
orden: 16
fuente: OneNote del Dr. Castilla Martí
---
# 🧫 Glaucoma secondary to epithelial growth (Epithelial Ingrowth)

## ✅ Definition

• Rare but severe complication of anterior segment surgery or trauma.

• It consists of the migration of conjunctival or corneal epithelial cells to the anterior segment, through a surgical or traumatic wound.

• These cells proliferate and can form an invasive epithelial membrane.

## 🔬 ↑pio mechanisms

| Mechanism | Detail |
|---|---|
| Direct trabecular obstruction | by epithelial membranes |
| Sinequial angular closure | Formation of synechiae by the membrane |
| desquamated cells + inflammation | Additional angle obstruction |

💣 Glaucoma difficult to treat and with poor visual prognosis if the epithelium is not completely eradicated.

## 🔎 Diagnosis

| Clinical finding | Description |
|---|---|
| ❗ Persistent anterior uveitis | postoperative, difficult to solve |
| 👁️ Gray and translucent membrane | On the back of the cornea, scalloped edges |
| 🌀 Pupillary distortion | by traction or invasion |
| 🧬 Cystic or fibrous proliferative register | best prognosis compared to diffuse |

## 💊 Treatment

🎯 Objective: Completely eliminate the invasive epithelium to avoid recurrence.

| Treatment | Details |
|---|---|
| 🔪 Block exeresis | Simultaneous resection of the compromised cornea, sclera, iris and ciliary body. Cover with tectonic graft. |
| 🔥 Cryotherapy | Devitalize residual epithelium (in cornea, angle, ciliary body). Healthy tissue is protected with intraocular air. |
| 💉 5-Intracameral Fluorouracil | variable results. |
| 💉 Intravitreal methotrexate | 400mcg/0.1ml c/2 weeks × 6 cycles → reported successful cases. |
| 📦 Drainage devices | Useful in uncontrolled glaucoma and without the possibility of surgical exeresis. |
