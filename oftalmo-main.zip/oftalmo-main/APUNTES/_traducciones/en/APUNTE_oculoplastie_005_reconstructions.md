---
categoria: apuntes
area: oculoplastica
emoji: 🫥
seccion: Oculo-Plastie
orden_seccion: 3
orden: 5
fuente: OneNote del Dr. Castilla Martí
---
# reconstructions

## Expected answer

Candidates must know how to describe at least one eyelid reconstruction technique:

a. For lower eyelid defects affecting less than 50% of the total eyelid: direct defect closure or direct closure in association with canthotomy / cantholysis to achieve eyelid advancement and a tension-free closure.

b. The following can be performed for defects of more than 50%: semicircular Tenzel flap, Hughes tarsoconjunctival flap to reconstruct the posterior lamella with a free skin graft in the anterior lamella; free tarsal graft plus myocutaneous flap for anterior lamellar reconstruction, etc. It is important that candidates recognise that one should never attach two grafts, as one of the two lamellae must always provide vascularisation.

## 🧵 What is a flap?

A flap is a piece of living tissue that moves from one healthy part to another that has lost tissue. Stay connected to its base (like a hinge), so it keeps your blood supply and heals well.

## 🛠️ Most used flap types (explained easy)

## 🔹 Tripier flap

- It is taken from the upper eyelid and rotates towards the lower one.
- Contains skin + orbicular muscle.
- Useful for rebuilding the front part of the lower eyelid.
- Imagine cutting a curtain on top and sewing it down.

## 🔹 Tenzel (semi-circular) flap

- A semicircular cut is made on the skin near the eye (temporary zone).
- It rotates and stretches that piece to cover the defect.
- Ideal when the hole is moderate.
- like turning a piece of side cloth into the hole.

## 🔹 Tarso-conjunctival flap

- A part of the tarsus and the conjunctiva of the upper eyelid or the other eye are taken.
- It is used to rebuild the inner part of the eyelid (back plate).
- Sometimes it is covered with skin or a skin graft.

## 🧩 For large defects (>50%)

## 🔹Cuttler-Beard

- To reconstruct the upper eyelid using a full-thickness bottom flap.
- The fabric is “provided” from the bottom up, leaving the eyes closed temporarily (like a patch that is then cut!).

## 🔹 Hughes

- Upside down: the inner part of the upper eyelid is used to repair the lower one.
- The inside part is first reconstructed (tarsus and conjunctiva), then it is covered with skin.
- It also temporarily closes and opens after ~1 month.

## 🔹 Mustard

- Cheek skin is used, turning it towards the lower eyelid.
- It's like rotating skin from the face to cover the eyelid.
- Something extra (graft) is needed to rebuild the inside (back plate).

## 🧠 Trick to understand it

- 🧩 Think of the eyelid as a two-layer sandwich:
  - Previous sheet: Skin + Muscle
  - Backsheet: Tarsus + conjunctiva
- 🔧 If a layer is missing, we rebuild it with similar fabric.
- 💉 If there is a long way to go, sometimes we close the eye for a few weeks and then we reopen.

The key is the percentage of affected eyelid and whether it is upper or lower eyelid.

## 1. GENERAL PRINCIPLE

- The objective is to resect the lesion with safe oncological margins and then rebuild respecting the function (eye protection, mobile eyelid, aesthetic).
- The reconstruction strategy depends on:
  - Defect size (% of eyelid length).
  - Affected layer (lamela anterior, posterior, or both).
  - upper vs lower eyelid.

## 2. Small defects (≤ 25–30% palpebral length)

- They can be closed directly with the edges → Primary Closure.
- Technique: “Pentagonal Excision” (resection in wedge) and direct closure.

## 3. Moderate defects (≈ 30–50%)

- Direct closure with side cantolysis (release side edge to gain length).
- If not enough, local flaps are used:
  - Semi-circle feed flap (Tenzel Flap) → Very classic for lower eyelid up to 50–60%.
  - Local rotation or feed flaps according to location.

## 4. Large defects (>50–60%)

- Require major reconstructive techniques:
  - Lower eyelid: transposition flaps (Mustardé Rotation Flap, nasolabial flap).
  - Upper eyelid: Hughes flap (Tarso-Conjunctival Advancement Flap, in 2 stroke).
  - Upper eyelid Reconstruction: Cutler-Beard flap (lamela transposition from the lower eyelid to the upper eyelid, in 2 strokes).

## 5. Lamellar defects

- If a single lamella is missing (previous = skin/muscle or posterior = tarsus/conjunctiva) → can be directly grafted:
  - Anterior lamella → Cutaneous graft (retroauricular, supraclavicular).
  - Posterior lamella → Oral or palatal mucosa graft.
- If both lamellae are missing → one must come from a vascularized flap and the other can be grafted.

## 6. EBO PEARLS

- Default ≤ 30% → Direct closure.
- 30–50% → Direct closure with cantolysis or semicircular flap (Tenzel).
- > 50% → More complex flaps (Hughes, Cutler-Beard, Mustardé).
- Always: When rebuilding, a lamella must have its own vascularization.

👉 Mnemonic:

## “30–50–70 rule”

- < 30% → Direct closure.
- 30–50% → Local flaps (Tenzel).
- 50% → Complex Reconstruction (Hughes/Cutler-Beard).
