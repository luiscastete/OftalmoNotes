---
categoria: apuntes
area: uveitis
emoji: 🔥
seccion: Immuno-infectio
orden_seccion: 7
orden: 13
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-07-24
---
# Intermediate uveitis

## Definition

Intermediate uveitis: Uveitis whose site of main inflammation is vitreous or peripheral retina (Sol). It may or may not be associated with an infectious cause or systemic inflammatory pathology.

- Pars Planite (synonymous of intermediate idiopathic uveitis of the young subject): specific ui entity.
- Defined by the association of: Snowballs + snowbanking and absence of etiology.
- 15% of adult uveitis and 20% of uveitis of the child.

The user interface must be referred to the immunological unit to decide the investigations and TTT. If we refer to the CDC on guard, who will contact the Immuno team.

## Symptoms

Myodesopsia ++

Progressive (rarely brutal) visual blur

AV decreases if OMC.

## Signs

often bilateral but asymmetrical

## Inflam cells in glass (especially base inf).

Haze Vitrean (high concentration of plasma proteins, hemato-retinne barrier rupture).

Snowballs- Nodules of inflammatory cell ants

Snowbanks-bank next to the Pars Plana sangria of the flat pas

Peripheral peripheralbitis (not large trunks)

- Complications
  - Macular edema
  - Papillary edema
  - Subcapsular cataract
  - Tear detachment/retina
  - Intravitreal bleeding
  - Prepapillary or pre-retinal neovascularization
