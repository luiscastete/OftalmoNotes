---
categoria: apuntes
area: cornea
emoji: 👁️
seccion: Cornée
orden_seccion: 4
orden: 12
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-01-30
---
# Ultraviolet keratitis (photo keratitis + snow ophthalmia)

Caused by eye exposure to ultraviolet (UV) rays without protective glasses.

The cornea transmits a spectrum of 400 nm-700 nm but absorbs a length in a UV spectrum of 10 nm-400 nm. This absorption will create corneal damage. The pain comes from the exposure of the subepithelial nerve plexus.

Symptom: Bilat and peyoration at 6-12h after exposure. Severe pain, CE sensation, blepharosfasm, photophobia, tears, bav.

Signs

Moderate eyelid edema. HC, KPS, little or no corneal edema, +/- reac ca.

Aetiology

Mountain activity + in the snow

Welding (Arc Shot is used when UV comes from the electric arc of a welding station)

Solarium

Treatment

Floxal or Tobrex 4xD 5-7J

LA: Optava or Celluvisc 5-8XJ PDT 2 SEM

+/- Cyclopejie Hamartropin before departure

+/- NaCl 0.9% + cold and wet pads on the eyes

+/- Light insulation or sunglasses

+/- Dafalgan 1g 3xj 1 week

Follow-up

It is not followed from the beginning, but it is so serious in 3-4 days.
