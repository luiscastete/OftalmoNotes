---
categoria: apuntes
area: cornea
emoji: 👁️
seccion: Cornée
orden_seccion: 4
orden: 22
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-08-04
---
# Puk - Kératite Ulcerante Périphérique (puk)

Peripheral ulcerative keratitis complicating rheumatoid arthritis | SFO-Online - French Society of Ophthalmology

Peripheral Ulcerative Keratitis - StatPearls - NCBI Bookshelf (NIH.gov)

https://www.ncbi.nlm.nih.gov/books/nbk574556/

Arthur's line

Limbar conjunctiva recession in the context of peripheral ulcerative keratitis (PUK) is an important clinical finding that indicates a chronic and autoimmune inflammatory process, with risk of corneal perforation and damage. permanent eyepiece. Below, I explain the table and the therapeutic possibilities.
