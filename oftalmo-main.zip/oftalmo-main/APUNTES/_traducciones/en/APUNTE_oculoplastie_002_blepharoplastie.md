---
categoria: apuntes
area: oculoplastica
emoji: 🫥
seccion: Oculo-Plastie
orden_seccion: 3
orden: 2
fuente: OneNote del Dr. Castilla Martí
---
# Blepharoplasty

Post - Blepharoplasty op

DRE.CAYETTE

## Postoperative prescription -LeyBoards 

BLEPHACLEAN

Clean the scars in the morning and at night for 15 days

FLOXAL POMMADE

1 application on morning and evening scars for 15 days

Postoperative recommendations for the eyelids:

-The day of the operation do not touch the dressing will be withdrawn the day after the intervention

-There may be slight bleeding under the dressing the day of the procedure

-The dressing will withdraw the day after the intervention

-To clean the eyelids with the wipes, do not rub any scab, just put them on and then apply the antibiotic ointment (a hazelnut) using a cotton swab on the scars

-In case of pain you can take 1g of paracetamol (Dafalgan type)

- Swelling and bruising of the eyelids are very common after the operation, which resolves within a few weeks.

-The threads will be removed by Dr. Cayette between 5 and 10 days after the intervention.

-Sport is not recommended for 1 month after intervention

-Do not put water on the scars for 1 month after the procedure

-For hair washing: at the hairdresser or on the head backwards

-For face washing: wipes or wipes

-Scars should not be exposed to the sun for 1 year after the procedure, you should wear sunglasses and hat in case of sun exposure.

-In case of urgent problem you can contact Dr. Cayette at 079.137.50.46

Do not use this number for an appointment or question at the Secretariat.
