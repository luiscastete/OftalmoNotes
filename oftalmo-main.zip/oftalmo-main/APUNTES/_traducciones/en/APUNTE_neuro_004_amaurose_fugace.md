---
categoria: apuntes
area: neuro
emoji: 🧠
seccion: Neuro-Ophta
orden_seccion: 8
orden: 4
fuente: OneNote del Dr. Castilla Martí
fecha: 2024-08-07
---
# AMAUROSE FUGACE

at:

Add protocol chalazion

PC in 2 days with 30° CV, yes - Add inquiry on your MT for FRCV + eco-Doppller Carotid, SI + brain MRI and emergency neck.

Explanation Alarm Signs
