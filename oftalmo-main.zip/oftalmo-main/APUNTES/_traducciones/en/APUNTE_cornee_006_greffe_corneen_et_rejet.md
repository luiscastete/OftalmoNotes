---
categoria: apuntes
area: cornea
emoji: 👁️
seccion: Cornée
orden_seccion: 4
orden: 6
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-05-26
---
# Corneal transplant and rejection

Type IV immunological reaction of host cells against donor cells

Appears between 2 weeks to several years (>30 years) after keratoplasty

Highest Risk Period: During the first 18 months after transplantation.

## RAPPEL

## Types of corneal graft

- TRANSFIXIANTE
  - Penetrating keratoplasty PK

- Anterior lamellar grafts
  - Keratoplasty Therapeutic Laminar Anterior Altk-Surface
  - Dalk- Keratoplasty Anterior Deep Anterior - Deep

- Posterior/endothelial laminar
  - DMEK-Descemet membrane endothelial keratoplasty – as endotote decemetic layers
  - DSAEK- Descemet Pickling Keratoplasty Automated Endothelial - Decemetic Layers of Endotote + Posterior Stroma

  - Information from Kate:
  - DSAEK more easy surgery. So comorbilities. DSAEK
  - DMEK more complicated surgey and more complicated to have Donors, only accepted <50 years.

  - Simple Fuchs DMEK. DMEK for patients with good visual potential. Because less mist.
  - Existe aussi UT-DSAEK <100 ,Avantages of <100. Surgery is more easy and sticks better, has less haze post-op, has the advantages of the 2.

## Facterus rejection predictions
