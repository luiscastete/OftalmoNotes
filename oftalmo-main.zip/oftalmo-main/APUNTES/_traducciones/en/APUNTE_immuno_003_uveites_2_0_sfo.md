---
categoria: apuntes
area: uveitis
emoji: 🔥
seccion: Immuno-infectio
orden_seccion: 7
orden: 3
fuente: OneNote del Dr. Castilla Martí
fecha: 2024-04-05
---
# Uveites 2.0 - SFO?

Uveitis resembles the intraocular inflammations of the uvee: iris, ciliary body and choroid. They can be isolated at the ophthalmic level or associated with systemic damage. They can be: anterior, intermediate, posterior or reach the 3 parts: panuveitis.

## Examination

## aa ++ important

- ancestors
- allergies
- ethnic group
- Age
- Travel through the tropical country? When?
- Lifestyle and workplace
- history of symptoms
- Possible systemic signs: gastric, urological, neurological, rheumatological, dermatological, ENT, pneumological
- current TT

## Signs

- Oiel network a type of periconic circle
- sad
- BAV
- Tearing, photophobia, blepharospasm
- Tyndall or protein outbreak in ca- sometimes hypopion
- Retro decemetic or retrocornous precipitates granulomatous or not
- iridoctal sinequies-sic

## Ophthalmic exam

- AV

- TIO
- Uveitis hypertones: Herpes, VZV, Fuchs heterochromia, sarcoidosis, TB, Posner-Schlossman syndrome > 40 mmHg, Toxoplasmosis, Spondyloarthropathies and juveniles Idiopathic arthritis-aji, Behcet, syphilis.

- if secondary htio has topical cortis? corticoesponge?

- SA:
  - CA:
  - Tyndal Cell 1-4 Cross and Protein Flare 1-4 Cross
  - Retrodescemetic precipitates – Fig 55:
    - Non-graulomatous appearance, non-granulomatous uveitis
    - In sheep granulomatous fat = sarcoidosis, TB, VKH, syphilis...
    - HYPOPION SEARCH:
      - Unilateral: HLA B27, endophthalmitis, lymphoma
      - Bilateral: Behcet, sarcoidosis

      - Etiology Uveitis with hypopion: Spondyloarthropathies, AJI, Behcet, Leptospirosis, Herpes, Hemopathies, Enfoftalmia.

  - IRIS:
  - Search:
    - Iridocrsalinian-sic synechiae
    - Irian atrophy (transilable, sectoral iris, evocative herpes diffuse)
    - Iriene nodules (Koeppe and Busacca)
    - Fuchs Irian heterochromia

    - Non-synchronous uveitis etiology: pellet chorioretinopathy, Fuchs Irian heterochromia, Posner Schlossman, intermediary uveitis.
