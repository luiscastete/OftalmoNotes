---
categoria: apuntes
area: cornea
emoji: 💧
seccion: Conj + Episclere + Sclere
orden_seccion: 25
orden: 4
fuente: OneNote del Dr. Castilla Martí
---
# C. Allergic 2.0

## 🟣4. Allergy and eye surface

## 4.1. Seasonal allergic conjunctivitis (CAE) and perennial (CAP)

## Pathogeny

- IgE-mediated type I hypersensitivity.
- Early phase (20-30 min): Degranulation of mast cells MCTC → release of histamine, leukotrienes, prostaglandins → vasodilation and edema.
- Late phase (6h): Inflammatory infiltrate (eosinophils, neutrophils, lymphocytes, macrophages).

## Clinical presentation

- Falls: Sprouts in spring-summer. Bilateral ocular itching, hyperemia, tearing, sneezing, and rhinorrhea.
- CAP: milder and more perennial symptoms, with exacerbations.

## signs

- Conjunctival hyperemia, chemosis, palpebral edema, mild papillary reaction.

## Diagnosis

- Clinical + atopic history.
- prick-test useful.
- Conjunctival cytology: eosinophils ↑.
