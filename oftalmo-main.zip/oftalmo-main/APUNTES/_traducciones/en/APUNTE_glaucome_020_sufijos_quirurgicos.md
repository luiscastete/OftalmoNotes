---
categoria: apuntes
area: glaucoma
emoji: 🟢
seccion: Glaucome
orden_seccion: 5
orden: 20
fuente: OneNote del Dr. Castilla Martí
---
# Surgical suffixes

## 📑 Surgical suffixes – key vocabulary (EBO style)

| Suffix | Meaning | Example in Ophthalmology | What does it imply? |
|---|---|---|---|
| -Plasty | Repair/remodeling of an organ or tissue | Trabeculoplasty (ALT, SLT) | is not removed, but modified to improve function |
| -Tomia | Incision/cut in a tissue or organ | Iridotomy (laser iris incision) | opening a hole, no tissue is removed |
| -Ectomy | Total or partial excision | Trabeculectomy, iridectomy | Tissue is removed (eg iris flap or trabecular) |
| -Ostomy | Create an opening / permanent communication | Iridostomy (creation of a hole in iris), goniostomy | Generates an artificial step for fluids |
| -Desis | fixation / union | tarsodesis | one fabric is fixed to another |
| -Scopy | Display / Scan | Ophthalmoscopy, endoscopy | Use an optical instrument to observe |
| -Lysis | Release / Destruction of adhesions | Synechiolysis | Synechiae or membranes are broken |
| -Pexia | Surgical fixation | retinopexy, iridopexy | A structure is fixed in place |
| -Tripsia | Fragmentation by pressure or energy | Facotrypsy (old cataract technique) | A tissue breaks (today replaced by phacoemulsification) |
