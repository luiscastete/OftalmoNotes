---
categoria: apuntes
area: cornea
emoji: 👁️
seccion: Cornée
orden_seccion: 4
orden: 31
fuente: OneNote del Dr. Castilla Martí
---
# DELLEN

The sign of Dellen is a localized thinning of the non-inflammatory peripheral corneal stroma, which typically presents adjacent to an elevated lesion or alteration of the ocular relief (such as a pinguecula, pterygium, graft, or conjunctival edema).

## 🔬

## Pathophysiology

- It is produced by local desiccation of the corneal surface, secondary to interference with the normal flow of the tear film.
- The depressed area does not capture fluorescein (unlike an ulcer), but may seem eroded.
- Epithelization is preserved or slightly altered, without infiltrate, without neovascularization.

## 👁️

## Clinical characteristics

- Paracentral or peripheral corneal thinning.
- It appears as a clear, dry depression, adjacent to an elevation (pinguecula, scleral graft, suture, etc.).
- asymptomatic or with a mild foreign body sensation.
- reversible if the mechanical cause or exposure is treated.
