---
categoria: apuntes
area: uveitis
emoji: 🔥
seccion: Immuno-infectio
orden_seccion: 7
orden: 17
fuente: OneNote del Dr. Castilla Martí
---
# PANUVEÍTIS

| Entity | type of uveitis | specific findings | Diagnosis Image | Systemic Association | Treatment |
|---|---|---|---|---|---|
| Vogt-Koyanagi-Harada (VKH) | Bilateral granulomatous panuveitis | Serosos, Dalen-Fuchs nodules, Sunset Glow, Vitiligo, Tinnitus | AFG Starry Sky, AVI Hypocyanescence, Oct Dr Serous | Auditory, cutaneous (vitiligo, poliosis), neurological | Systemic corticosteroids + immunosuppressants |
| sympathetic ophthalmia | Bilateral granulomatous panuveitis | DR serosos, nodules of Dalen-Fuchs, previous traumatic history | Same as VKH, but with a traumatic background | None specific (except trauma) | Systemic corticosteroids + immunosuppressants |
| ocular sarcoidosis | Anterior/posterior uveitis/granulomatous panuveitis | Nodules in iris (from Busacca), perivascular granulomas, pulmonary sarcoids | Choroidal granulomas in OCT/AFG, chest findings | Pulmonary, cutaneous, ganglion | Corticosteroids + immunosuppressants (methotrexate) |
| ocular syphilis | Anterior/posterior variable uveitis | Retinal infiltrates, vasculitis, discoid lesions, VDRL+/FTA-ABS+ | Serologies, retinal lesions, aqueous humor PCR | Secondary/tertiary syphilis, neurosyphilis | Antibiotics (Penicillin G), corticosteroids if necessary |
| ocular tuberculosis | Granulomatous panuveitis | Choroidal tubercles, vasculitis, systemic lung involvement | AFG, aqueous humor PCR, lung imaging | Pulmonary or latent active TB | Antituberculosis + corticosteroids |

5. PANUVEÍTIS

Panuveitis involves the simultaneous inflammation of all the anatomical compartments of the eye (anterior segment, vitreous, retina or choroid) without predominance of any of them as an original inflammatory focus. It is common for structural complications. The pictures are generally bilateral, although the degree of involvement and the presentation time can be asymmetric. Panuveitis of immune cause will be treated below.

There are 4 major diseases:

1-Sarcoidosis

2-Vogt-Koyanagi-Harda Syndrome - VKH

3-Ophthalmia sympathetic

4-Behçet's disease
