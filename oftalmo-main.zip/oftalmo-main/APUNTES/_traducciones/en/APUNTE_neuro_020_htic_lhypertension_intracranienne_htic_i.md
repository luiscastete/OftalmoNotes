---
categoria: apuntes
area: neuro
emoji: 🧠
seccion: Neuro-Ophta
orden_seccion: 8
orden: 20
fuente: OneNote del Dr. Castilla Martí
---
# Idiopathic-intracranial hypertension HTIC (HTIC)

Summary

https://doi.org/10.1016/J.Praneu.2013.12.007

Idiopathic intracranial hypertension develops in the particular field of young overweight patients and manifests as headaches and papillary edema. The causes are multiple and their mechanisms remain unknown. They lead to a disruption of the balance between intracranial pressure, compression of the intracranial venous sinuses, and reabsorption of the cerebrospinal fluid, in a vicious circle that can interrupt the derivation or stent of a lateral sinus of LCS. In most cases, medical treatment and weight reduction manage to control the changes that remain benign.

The term idiopathic replaced Benin's today due to the existence in some cases of serious visual problems. In recent years, attention has been called on two points:

Fragment section
