---
categoria: apuntes
area: catarata
emoji: 🔍
seccion: Cristallin - Lens
orden_seccion: 21
orden: 7
fuente: OneNote del Dr. Castilla Martí
---
# FORMULAS

## 🧠Historical evolution of IOL (IOL) calculation formulas

## ⚙️1. First generation–70–80s

- Formulas: SRK (Sanders-Retzlaff-Kraff), Binkhorst I and II
- Features:
  - very basic.
  - They are based only on keratometry (K) and axial length (Al). No estimation of the depth of the previous camera - if nop that a constant value is used.
  - They do not fit well in extreme eyes (very long or very short).
  - Linear equation to predict the effective position of the lens (ELP).

## ⚙️2. second generation

- Formula: SRK II
- Features:
  - Introduce empirical corrections according to the axial length (Al). New: An estimate of the previous chamber is made.
  - It improves the performance against the original SRK, but it is still limited in extremes.
