---
categoria: apuntes
area: glaucoma
emoji: 🟢
seccion: Glaucome
orden_seccion: 5
orden: 40
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-03-11
---
# gonioscope

Ecxamen de l'angle-irido-cornéen

Lower starting angle: usually more open angle

## INDICATIONS

## MATERIEL

## PROCEDURE

## 👁️1. What structures do we see in gonioscopy and in what order?

From anterior to posterior, at a completely open angle, the structures of the iridocorneal angle are observed in this order:

| Order | Structure | Description |
|---|---|---|
| 1️⃣ | Schwalbe line | Bright reflection or white line → Represents the termination of the Descemet membrane |
| 2️⃣ | Trabecular mesh | Gray/brown area → Aqueous humor drainage (pigmented area = more posterior = functional) |
| 3️⃣ | scleral spur | Thick white line → Marks the insertion of the longitudinal muscle of the ciliary body |
| 4️⃣ | Ciliary Band | Dark, deeper area → Root of the ciliary body (not always visible) |
|  |  |  |
