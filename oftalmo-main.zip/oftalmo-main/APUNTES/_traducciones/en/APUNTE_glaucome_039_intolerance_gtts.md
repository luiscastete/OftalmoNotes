---
categoria: apuntes
area: glaucoma
emoji: 🟢
seccion: Glaucome
orden_seccion: 5
orden: 39
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-11-10
---
# Intolerance to GTT

Add wash:

Add 3xJ + Optava GTT 8xJ + FML GTT 2xJ PDT 5-7J

PC Add another Antui-HTA:

Switch to No Conservative or Type.
