---
categoria: apuntes
area: neuro
emoji: 🧠
seccion: Neuro-Ophta
orden_seccion: 8
orden: 7
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-12-20
---
# III or oculomotor

Isolated unilateral unilateral paralysis of PC III is often associated: microvascular pathology, especially if FRCV

TJ suspect:

- Horton's disease if you are > 50 years old
- Underlying compressive underlying especially aneurysm that can put the patient's prognosis into play. *Neuroradiological evaluation in an emergency is imperative. Especially if: <50 years of partial paralysis of extrinsec + pupillary involvement-midriasis of low reflection in light. Association to severe headache with FRCV.

## Signs

Complete ptosis: which can eliminate diplopia

Eye affected by eye deviation: exotropia, hypotropia or hypertropia

- Oculomotor deficit that affects: adduction, elevation, decrease.

Midriasis dimension reached with a reduced response to light and convergence

important to examine:

- Abduction preserves VI?
- IV Ciclotorsion preserved by the oblique integrality sup.

DD III extrinsque atteinet (Pupillary function preservation): Myasthenia, internuclear ophthalmoplegia, biased deviation.

- III Infranuclear Participation

  - A paralysis of III with pupillary involvement is a priori an aneurysm at the junction of the posterior carotid artery.

  - Ischemic involvement can cause pupillary involvement in 20%.

  - Balance sheet:
  - Add Angio – TDM or MRI Angio

- Isolated extrinsic paralysis + normal size and operating pupil

  - Complete extrinsic paralysis (complete ptosis + elevation of absence movement +
  - lowering + adduction) + No damage Pupiliare: It is benign.

  - Aetiology
  - Link to microvascular pathology-FRCV

  - Spontaneously back in a few months.
  - The affected absence of pupiliare is reassuring only in this case.

  - Add neuroradiological evaluation in case: Absence FRCV, <50 years, severe cephaleas association.

  - Isolated intrinsic paralysis

  - Strictly isolated pupillary involvement, without ptosis without associated oculomotor paralysis, is not due to aneurysm compression and is not III paralysis.
