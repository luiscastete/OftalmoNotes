---
categoria: apuntes
area: neuro
emoji: 🧠
seccion: Neuro-Ophta
orden_seccion: 8
orden: 13
fuente: OneNote del Dr. Castilla Martí
---
# OND - Optique Nerve Drusen

Fundus image of optic disc drusen with "lumpy-bumpy" appearance

## 🧠 Optic Nerve Druze – Diagnostic Summary

## Disease Entity

## History

Patients are usually asymptomatic.  Rarely, they can have transient visual obscurations (approximately 9% of patients)[6].  Visual field loss may also be seen gradually, and it has been estimated that a quarter of patient of patients with optic disc drusen have a visual field defect other than an enlarged blind spot[7]

## Physical Examination

If the optic disc drusen are superficial, this can aid in diagnosis during the dilated fundus exam.  The optic nerve usually has a "lumpy-bumpy" appearance.

## Signs
