---
categoria: apuntes
area: neuro
emoji: 🧠
seccion: Neuro-Ophta
orden_seccion: 8
orden: 33
fuente: OneNote del Dr. Castilla Martí
fecha: 2022-09-17
---
# functional problem

neuro-ophthalmologist:

-Pas RAPD

-No ALT or pain in eye mobilization

-Ishihara 0/13

-CV by confrontation 4/4

Test Mojon + 6/8.
