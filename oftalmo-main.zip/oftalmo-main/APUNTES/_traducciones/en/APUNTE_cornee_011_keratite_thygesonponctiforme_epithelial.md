---
categoria: apuntes
area: cornea
emoji: 👁️
seccion: Cornée
orden_seccion: 4
orden: 11
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-10-02
---
# Thygeson's Epithélial Kératite Thygeson

Thygeson's superficial keratitis is an idiopathic, non-bilateral, bilateral disorder characterized by exacerbations and remissions. It usually affects young adults more often, even if it occurs at any age, and recurrences can occur during decades. Although there are reports of virus isolation, they have not been confirmed.

## DX

Symptoms are recurrent irritation, photophobia, and tearing.

## SIGNOS

Elevated, irregular, obvious, granular and grayish epithelial lesions.

There may be a slight subepithelial turbidity, especially if topical antivirals have been used.

The conjunctiva is not affected and the vascularization is not characteristic. The most common DD is staphylococcal hypersensitivity, punctiform epitheliopathy, or adenovirus keratitis.

## Treatment

## TOPICO

In mild cases, it may be enough

CORTIS COMME DX 2XJ PDT 2 SEM PUIS 1XJ PDT 2 SEM. In some cases, TT may be necessary in low doses of long-term 1x sem.

They can be considered LDC in case of contraindication cortis.

Keratectomy provides short-term relief but there is likely to be recurrence.
