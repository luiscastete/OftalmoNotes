---
categoria: apuntes
area: glaucoma
emoji: 🟢
seccion: Glaucome
orden_seccion: 5
orden: 7
fuente: OneNote del Dr. Castilla Martí
fecha: 2024-06-06
---
# barn and not exam

BANR in the context of the clinical examination of the optic nerve (NO) by slit lamp refers to "border, area, notching, RIM". This is a systematic approach to assessing the optical disc and the cup/disk ratio (cup-to-disc ratio, c/d ratio) when pathologies such as glaucoma or optic neuropathies are suspected.

- B (Border) – Edge:

The sharpness of the edge of the optic nerve is evaluated. Under normal conditions, the margins of the optical disc are sharp and well delimited.

Diffuse or blurred edge can indicate papilla edema or inflammatory processes such as optic neuritis.

- A (area) – Area:

It refers to the ratio between the cup and the disc (c/d ratio). A normal C/D ratio is usually around 0.3 to 0.4.

An increased C/D ratio (for example, > 0.6) may suggest glaucoma or other processes that cause nerve fiber loss.

- N (notching) – notch:

It refers to the presence of a focal notch in the neuroretinal ring, usually associated with the loss of glaucomatous nerve fibers.

The notch can affect the lower or upper edge, common in the primary open angle glaucoma.

- R (RIM) – Neuroretinal ring:

The thickness of the neuroretinal ring, which should follow the ISNT rule, is evaluated (the thickness of the ring should be greater in the lower one, followed by the upper one, then nasal, and finally temporary).

A thinning of the neuroretinal ring, especially in the lower or upper portions, can be an early sign of glaucoma.

C/D ratio in clinical practice:

Normal: A cup/disk ratio less than 0.4 is generally considered within normal limits, with well-defined disc margins.

Abnormal: A c/d ratio greater than 0.6, asymmetry between the eyes (> 0.2 difference), or the presence of notching are worrying signs that could suggest glaucoma or loss of fibers from the optic nerve.
