---
categoria: apuntes
area: cornea
emoji: 👁️
seccion: Cornée
orden_seccion: 4
orden: 1
fuente: OneNote del Dr. Castilla Martí
fecha: 2022-09-18
---
# K. Infectious/bacterial

Stromal infiltration with opposite epithelial defies (ulcer).

## Symptoms

Redness, tear, photophobia, pain (so disproportionate... think of amoebas).

## Signs

Corneal infiltrate with Fluo +.

Others: if the satellite lesion (fungi thought),

Ca cells, hypopion.

Pernervous or Disciform radial infiltrates (think amoebas or herpes),

Detroscemetic precipitates (PRD)

## Risk factors

LDC - Gram + and Gram - ( Psuedomonas)

Long-lasting soft LDC + poor hygiene + tap water + LDC trauma with water Expo--- Acanthamoeba

Superficial pathology—Cocci Gram +, Champi.

TRAUMA--

BILAN:

## -When LDC--- It always stains! Bao Recommendation.

- Corneal spots!!!! (If severity criteria, in LDC carriers, if LDC and pseudodendrites: exclude amebian): Direct examination, culture: BAC + fungi, PCR: Acanthamoeba, Herpes, Candida.

- Severity criteria:

- Oversized infiltration > 2 mm
- infiltrated into the optical axis.
- Infiltration stromale profonde or deep stroma  >50%
- AC reaction > 1 cell, hypopion.
- Abscess after a trauma with plants/ground contamination
- Bad evolution under ATB establishes
- Signs and abnormal appearance/atypical champis? Acanthamoeba?
- General: child, immunosuppression, cognitive disorders, non-self-government to install GTT.
