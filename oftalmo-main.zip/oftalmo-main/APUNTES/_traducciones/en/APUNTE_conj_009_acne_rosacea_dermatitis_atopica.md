---
categoria: apuntes
area: cornea
emoji: 💧
seccion: Conj + Episclere + Sclere
orden_seccion: 25
orden: 9
fuente: OneNote del Dr. Castilla Martí
---
# Acne rosacea / atopic dermatitis

## 3.5. Other mucocutaneous syndromes

## 3.5.1. Acne rosacea

## Definition

Chronic idiopathic dermatosis that affects facial skin (areas exposed to the sun) and, in 50%, the eyes.

## Pathogeny

- unknown, but is related to:
  - Overexpression of catelicidins, which induce inflammation.
  - Presence of Demodex Folliculorum, mite that can act as an inflammatory trigger.

## Epidemiology

- Average age: 30-60 years.
- slight feminine predominance.
- Triggering factors: alcohol, spicy foods, stress, hormonal alterations, sun exposure.

## clinical manifestations

- Cutaneous:
  - Facial erythema (front, nose, cheeks, chin), papules, pustules, telangiectasias.
  - There are no comedones (difference with acne vulgaris).
  - Rhinophyma in males (hypertrophy sebaceous glands).
- Ophthalmological (50%):
  - Eyelids: Chronic blepharitis, meibomian gland dysfunction, telangiectasias on the palpebral edge, repetition chalazion.
  - Conjunctiva: Interpalpebral hyperemia, chronic/scar conjunctivitis.
  - Cornea:
    - Superficial dotted keratitis.
    - Sterile marginal infiltrates.
    - Ulceration, thinning, lower pannus, neovascularization.
    - Pseudodendritic keratitis, even bilateral (DD with HSV).
  - Others: Episcleritis, Iridocyclitis.
