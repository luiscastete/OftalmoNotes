---
categoria: apuntes
area: cornea
emoji: 💧
seccion: Conj + Episclere + Sclere
orden_seccion: 25
orden: 1
fuente: OneNote del Dr. Castilla Martí
fecha: 2022-08-31
---
# C. Allergique 1.0

Seasonal allergic conjunctivitis (CAS) and perennials (CAP) are the most common forms.

## Pathophysiology

ATOPIC KERATOCONJONCTIVITIS -AKC - affects both sup and inf conjonctiva with papilae scarring.

## Afffects more males

Akc OCCURS YEAR-ROUND INDIVIDUALS SUSCEPTIBLE TO ATOPY - ASTHME, ECZEMA, ATOPIC dermatitis…

## AKC - always active vs VKC - variable during the year

## Symptoms

Rougeur, démangeaison, secretions claires, bilat, terrain atopique, rhinite associe freq.

## Signs

Oedeme palpebrale, HC, PAPILLES conj, Chemosis, secretions claires, muqueses, absence d'adenopathie pre-auriculaire.

## Aetiology

Perannuelle: poils animaux, acariens: bon pronostic

Saisonniere: pollen, graminées: bon pronostic, recrudescences saissonnieres.

Giganto-papillary: Former Intol in the Prod LDC interview: Good prognosis.

## Examination

AV-TIO-LAF

## BILAN

Aucun

Whether it is severe or chronic: contact with allergolque
