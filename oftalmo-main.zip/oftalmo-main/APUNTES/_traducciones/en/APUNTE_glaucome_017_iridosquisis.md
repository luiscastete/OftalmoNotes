---
categoria: apuntes
area: glaucoma
emoji: 🟢
seccion: Glaucome
orden_seccion: 5
orden: 17
fuente: OneNote del Dr. Castilla Martí
---
# 🌿 Iridoschisis

## 🌿IridoChisms – full details

## ✅What exactly is it?

Iridochisis literally means “division of the iris” (from the Greek iris + schisis = “separation”).

• It is a segmental degeneration of the anterior stroma of the iris.

• The previous layer breaks into fibrils that float in the previous chamber.

• The posterior layer (closer to the pigmented epithelium) remains intact and attached to the sphincter.

## 🔍 Expanded clinical features

| Feature | Description |
|---|---|
| 📍 Location | More marked on the lower iris (by gravity + possible aqueous circulation) |
| 🔘 Pupil | usually normal, although in advanced cases there may be corectopia |
| 👁️ Previous camera | Shallow, predisposes to angular closure |
| 🧪 Gonioscopy | Narrow/occluded angle, not frequent |
| 🧬 Bilaterality | common, but can be asymmetric |
| 📈 Associated glaucoma | Up to 90% have PACG (Primary Angle-Closeur Glaucoma) |
|  |  |

## ❗ Differential diagnosis – what can it be confused with?

| Entity | Key differences |
|---|---|
| Iridian atrophy | Slim iris, but no floating fibrils |
| Iridodonesis | Trembling iris (floppy) due to absence of zonular support → no fibrillar separation |
| Flacid Iris (IFIS) | Intraoperative relaxation → No free fibrils, occurs in surgery |
| Chronic uveitis | There may be atrophy, synechiae, but no floating fibrils |
| Iridodialysis | Iris base rupture, typically post-trauma |
| Sector trauma | It may look like if there is laceration of the iris, but it is usually one-sided and with a clear history of trauma |
| Pseudo-exfoliation (PEX) | It can produce iridian degeneration, but accompanied by typical fibrillar white material in the zonula and pupil |
