---
categoria: apuntes
area: neuro
emoji: 🧠
seccion: Neuro-Ophta
orden_seccion: 8
orden: 1
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-08-24
---
# When to refer to the neuro-oftha unit

Emergency management of neuro-ofta problems:

- Any neuro-ofta problem that occurs in the Polyclinic Emergency Service is investigated by the MA/CDC of the Polyclinic.
  - Loss of vision, diplopi, oscillopsy...
- Any neuro-ofta problem in a hospitalized patient with chuv is examined by MA of CHUV.
- Any patient approach problem can be discussed in the neuro-ofta unit

Monitoring of patients examined in emergencies (HOJG-CHUV)

- Non-pharmacological treatment of neuro-ofta problems
- Any patient referred by an OFTA installed for a second opinion (NO URNet exam) should be examined directly on the Neuro-Ophta unit:
  - Optic neuropathy
  - Diplopia
  - Nystagmus
  - arriving at the CV
  - Unexplained loss of vision
- Patients examined at the Chuv Ophtha consultation requiring neuro-ophtha follow-up should be referred directly to the neuro-oftha unit.
