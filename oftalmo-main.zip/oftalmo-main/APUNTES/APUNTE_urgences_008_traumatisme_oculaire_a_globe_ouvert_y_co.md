---
categoria: apuntes
area: urgencias
emoji: 🚑
seccion: URGENCES---TRAUMATOLOGIE
orden_seccion: 2
orden: 8
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-08-12
---
# Traumatisme oculaire à globe ouvert  ( y compris CEIO)

Plaie de pleine épaisseur de la paroi oculaire

Classification de Birmingham eye trauma terminology – BETT:

Rupture vs Laceration ( pénétrante/perforante/CEIO)

## SYMPTOMES

- BAV variable
- Douleur variable
- Larmoiment variable
- +/-Photophobie

## SIGNES

- Hypotonie
- Oedeme ou hématome palpebral +/- plaie palpebrale +/- plaie voies lacrymales
- Hémorragies sous-conjonctivale, chémosis +/- plaie conjontivale
- Plaie cornéenne ou sclérale +/- seidel +/- hernie du contenu intra-oculaire
- Aym,etrie profondeur CA +/- athalamie +/- hyphéma
- +/- déformation pupillaire, corectopie, iriododialyse, aniridie, iridodonésis.
- +/- cataracte traumatique, sub-luxation, aphakie
- +/- hématovitrée, déchirure ou décollement de rétine, hémorragie pré/intra/sous-rétinniene
- +/- CEIO visible

## ETIOLOGIES

- Jeunes adultes sex maculin plus freq. 2 pics de freq 20-24 ans et 50-60 ans.
- Cause: projectils, objects pontus, contondants
- Contexte: accidents domestiques ou lisirs, accidents du travail, agressions, accients voies publiques, sport...

## AA-STATUS

- AA: heure de survenu, mécanismes du traumatisme (risque de CEIO et type?), heure du dernier repas solide/liquide, intoxication ( alcool, drogues), status vaccinal tétanique.
- Recherche de troubles neurologiques
- Examen bilteral **(doux)**: AV, Pupilles, TIO- LAF –FO dilaté- motilité oculaire

## BILAN

- Sans retarde la prise en charge chiurgicale urgente:
- CT cérébral et orbitaire coupes fines: si moindre doute sur CEIO, examen neurologique anormal, polytrauma, suspicion fracture: NB IRM contrindique si suspicion CEIO métallique.

## TT EN URGENCE

Laisser le patient à jeun, hospit en urgence

Compresses stérile sur globe oculaire-sans pression et coque

+/- Rappel tétanos

Antibiothérapie empirique: Avalox IV 400mg en dose unique (prévention endophtalmie)

Prise en charge chirurgicale prompte sous AG: exploration +/- ablation CEIO, sutures des plaies.

## SUIVI

Journalier en hospis: AV-TIO-LAF FO-ECHO B

Tt local: tobradex cll ou pommade 6-8xj

Mydriatique: scopo 3xj

+/- hypotonisant

Tt systemique: realis per os empirique: avalox peros 400mg pdt 7j

Avis retroret: CEIO, HV, DR..

Pronostic: Réservé.

## COMPLICATIONS

## Hémorragie intra-vitrenne

## Décollement rétine

## CEIO

- Freq: 16-30% des cas ou multiples.
- Type: Magnetique ( fer, nickel), non magnetique( vegetelae, cuivre, alominium, mercure, zinc), inerte ( carbone, verre, plastique, porcelaine, charbon, plomb).
- Attitude: avis ret chirg-extraction?
  - Conservatrice si CEIO inertes, enciens encapsules et bien toleres, surveillance CEIO métalliques.
  - Extractionn rapide si: endophtalmie, CEIO très souille, DR.
  - Complication de CEIO: DR
  - **Métalloses:**

## Endophtalmie

## Ophtalmie sympathique

- Freq 0.3-2% des cas.
- Uveite granulomateuse bilatérale rare: survenante >2 sem. Après un trauma ou chirg oculaire, majoritairement dans 1er année (90%).
- Signes: Panuvéeite bilaterale, uveite ant granulomateuse, PRD en graisse de mouton, synechies irido-cristaliniennes, vitrite  +/- oedeme papillaire/maculaire +/- DSR nodules de dalen-Fuchs.
- Att: avis immuno:

## Cataracte post-traumatique

## Glaucome
