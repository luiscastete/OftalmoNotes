---
categoria: apuntes
area: oculoplastica
emoji: 🫥
seccion: Oculo-Plastie
orden_seccion: 3
orden: 24
fuente: OneNote del Dr. Castilla Martí
---
# Anomalías anatómicas palpebro-orbitarias

Vamos a repasarlas y a organizarlas claramente:

## 📚PATOLOGÍAS AFINES AL TELECANTO

## (Anomalías anatómicas palpebro-orbitarias)

## 1.🔵

## Telecanto

- **Definición**: Aumento de la distancia **intercantomedial** (entre cantos mediales), con **distancia interpupilar normal**.
- **Etiología**: Congénito (síndromes craneofaciales, BPES) o traumático (fracturas nasoetmoidales).
- **Estructura afectada**: **Ligamento cantal medial**
- **Tratamiento**: **Canthopexia/canthoplastia medial** quirúrgica

## 2.🟣

## Hipertelorismo

- **Definición**: Aumento de la distancia **entre las órbitas óseas** → aumento real de la **distancia interpupilar**.
- **Causa**: Malformaciones craneofaciales (síndrome de Apert, Crouzon, etc.).
- **No afecta los ligamentos cantales**, sino la base ósea orbitonasal.
- **Tratamiento**: Cirugía craneofacial compleja (osteotomías frontoorbitarias)

🔁 **Diferencia clave con telecanto**: En el telecanto el ojo está en su lugar, pero el canto medial está desplazado. En el hipertelorismo, **todo el globo ocular está más lateralizado**.

## 3.🟡

## Blefarofimosis

- **Definición**: Disminución horizontal de la hendidura palpebral (párpados más cortos de lo normal)
- Se asocia con:
  - **Telecanto**
  - **Ptosis bilateral severa**
  - **Epicanto inverso** (pliegue cutáneo que cubre el canto medial)
- Se ve típicamente en el **Síndrome de Blefarofimosis-Ptosis-Epicanto Inverso (BPES)**
- **Tratamiento**: Cirugía secuencial:
  - Canthoplastia medial + resección de epicanto
  - Corrección de ptosis con suspensión frontal

## 4.🟠

## Epicanto

- **Definición**: Pliegue cutáneo vertical que cubre parcialmente el canto medial.
- Puede dar **falsa impresión de telecanto** en niños → “pseudo-telecanto”
- Tipos:
  - **Epicanto tarsal**: más común, cubre el canto desde el párpado superior
  - **Epicanto inverso**: pliegue desde el párpado inferior hacia arriba (típico de BPES)
- **Tratamiento**: Z-plastias, resección en cirugía estética o funcional

## 5.🟥

## Entropión y Ectropión congénitos

- **Entropión congénito**: inversión del borde palpebral, a veces asociado a exceso de piel (epiblefaron)
- **Ectropión congénito**: eversión del párpado, puede asociarse a displasia de colágeno (como en el síndrome de Ehlers-Danlos)

## 6.⚪

## Síndrome de coloboma palpebral

- Falta de desarrollo de un segmento palpebral (usualmente tercio medio del párpado superior).
- Puede asociarse a **telecanto, blefarofimosis y epicanto** en síndromes como **Treacher-Collins**.

## 🧠¿Cómo evaluarlos clínicamente?

Cuando veas una anomalía palpebral congénita o traumática, pensá en:

| **Alteración** | **Distancia interpupilar** | **Ligamento medial** | **Base ósea** |
|---|---|---|---|
| Telecanto | Normal | Afectado | Normal |
| Hipertelorismo | Aumentada | Normal | Aumentada |
| BPES | Normal o aumentada | Afectado | Normal |
| Epicanto | Normal | No desplazado | Normal |
