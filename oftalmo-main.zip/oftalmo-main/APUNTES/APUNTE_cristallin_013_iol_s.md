---
categoria: apuntes
area: catarata
emoji: 🔍
seccion: Cristallin - Lens
orden_seccion: 21
orden: 13
fuente: OneNote del Dr. Castilla Martí
---
# IOL's

| **Tipo de IOL** | **Corrección** | **Distancias** | **Paciente ideal** | **Efectos visuales** | **Astigmatismo corregible** | **Ejemplos comerciales** | **Contraindicaciones** | **Explicación del nombre** |
|---|---|---|---|---|---|---|---|---|
| **Monofocal** | Miopía/hipermetropía | 1 distancia | Mayoría de pacientes; sin altas expectativas | Alta calidad visual; sin halos | No | AcrySof IQ, Tecnis 1 | No corrige astigmatismo | No aplicable |
| **Monofocal-tórica** | Miopía/hiper. + astigmatismo | 1 distancia | Astigmáticos regulares ≥1 D | Alta calidad visual; sin halos | Hasta 4–6 D corneal | AcrySof Toric, Tecnis Toric | No usar en astigmatismo irregular | Curvatura tórica (2 radios); corrige astigmatismo |
| **Trifocal** | Miopía/hipermetropía | Lejos + intermedio + cerca | Alta demanda visual sin patología ocular | Halos, glare, ↓ contraste | No | PanOptix, AT LISA tri | No usar en DMAE, glaucoma, ojo seco severo, astigmatismo irregular | Divide luz en 3 focos (difractiva) |
| **Trifocal-tórica** | Idem + astigmatismo | Lejos + intermedio + cerca | Alta demanda visual + astigmatismo regular | Halos, glare | Hasta 4–6 D corneal | PanOptix Toric, AT LISA tri Toric | No usar en córneas irregulares o patologías | Tórica + difractiva trifocal |
| **EDOF** | Miopía/hipermetropía | Lejos + intermedio (poca cerca) | Buena calidad visual y conducción nocturna | Halos leves (menos que trifocal) | No | Symfony, Vivity | No ideal si se necesita mucha lectura sin gafas | Extiende el foco sin dividir la luz |
| **EDOF-tórica** | Idem + astigmatismo | Lejos + intermedio | Activos con astigmatismo regular | Halos leves | Hasta ~4 D | Symfony Toric, Vivity Toric | No usar en astigmatismo irregular | EDOF + curvatura tórica |
| **Acomodativa** | Miopía/hipermetropía | Variable (limitado) | Casos seleccionados; baja eficacia real | Poca independencia real | No | Crystalens, Trulign | Desuso actual | Movilidad axial simulando enfoque |
| **Asférica (diseño)** | Aberración esférica | Mejora contraste | Pacientes exigentes, conductores, visión nocturna | Mejora visión en baja luz | No | Tecnis ZCB00, AcrySof IQ Aspheric | Útil en todos los casos | No es perfectamente esférica → mejora enfoque periférico |
| **Filtro azul** | Protección macular | Neutro ópticamente | Riesgo de DMAE, retinopatía, exposición solar | Protección de retina | No | AcrySof Natural | Controversial en artistas visuales | Filtro de luz azul-violeta incorporado |
