---
categoria: apuntes
area: cornea
emoji: 👁️
seccion: Cornée
orden_seccion: 4
orden: 27
fuente: OneNote del Dr. Castilla Martí
---
# Q. bacteriana

- ✅ **Resumen estructurado para OneNote** con los conceptos clave de la *queratitis bacteriana*.
- ✅ **Tabla resumen comparativa** de patógenos, factores de riesgo, signos clínicos y tratamiento.
- ✅ **Flashcards tipo EBO** con preguntas reales para repasar.

## 📘Apuntes para OneNote – Queratitis bacteriana

## 🔬3.1 Queratitis bacteriana

## 🧪Patogenia

**Condiciones para producir infección**: suele requerir alteración previa de defensas oculares.

**Excepciones (pueden atravesar epitelio sano)**:

- *Neisseria gonorrhoeae*, *N. meningitidis*, *C. diphtheriae*, *H. influenzae*

**Patógenos frecuentes**:

| **Bacteria** | **Tipo** | **Características** |
|---|---|---|
| *Pseudomonas aeruginosa* | Bacilo gramnegativo | Muy agresiva, >60% de queratitis por LC |
| *Staph. aureus* | Coco grampositivo | Infiltrado blanco/amarillento bien definido |
| *Estreptococos* | Grampositivos | Infecciones agresivas, cristalinas (*α-hemolíticos*) |
