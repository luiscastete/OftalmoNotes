---
categoria: apuntes
area: pediatria
emoji: 🧸
seccion: Pediatrie
orden_seccion: 9
orden: 12
fuente: OneNote del Dr. Castilla Martí
fecha: 2024-03-04
---
# 🍼ROP - Rétinopathie du prématuré. Retinopatia del prematuro

## 🍼RETINOPATÍA DEL PREMATURO (ROP)

## 🧬FISIOPATOLOGÍA EN DOS FASES

- **Fase 1: Supresión del crecimiento vascular**
  - El bebé prematuro sale de un entorno intrauterino **hipóxico** a un entorno **hiperóxico**.
  - Esto **reduce la producción de VEGF e IGF-1**, deteniendo la vasculogénesis y angiogénesis normales.
  - Además, cesa el aporte de factores tróficos maternos como **hormona de crecimiento, Omega 3 e IGF-1**.
- **Fase 2: Vasoproliferación anómala**
  - La retina crece, pero al estar avascular se produce **hipoxia**, lo que **estimula en exceso VEGF**.
  - Esto origina **neovascularización inmadura**, que puede crecer hacia el vítreo y causar **tracción y desprendimiento de retina**.

## ⚠️FACTORES DE RIESGO

- Edad gestacional < 30-32 semanas, peso al nacer ≤ 1500 g.
- Oxigenoterapia prolongada (>72h).
- Baja ganancia ponderal <1.5kg (indica niveles bajos de IGF-1).
- Complicated hospital course
- Raza: Asiática > Blanca > Negra.
- Otros: Apgar bajo, ductus persistente, sepsis, enterocolitis necrosante, hemorragia IV, leucomalacia periventricular.
