---
categoria: apuntes
area: catarata
emoji: 🔍
seccion: Cristallin - Lens
orden_seccion: 21
orden: 15
fuente: OneNote del Dr. Castilla Martí
---
# Viscoelastic's

**1️⃣¿Qué son los viscoelásticos? O OVD's - Opthalmic viscosurgical devices**

Sustancias usadas en cirugía intraocular (principalmente catarata y segmento anterior) para:

- Mantener espacio
- Proteger el endotelio corneal
- Facilitar maniobras quirúrgicas

👉 Derivan sobre todo de **ácido hialurónico** o **celulosa (HPMC)**.

## 2️⃣Clasificación fundamental (CLAVE EBO)

## 🔹A. Viscoelásticoscohesivos

## Alta viscosidad – alto peso molecular – made from hyaluronic acid

**They tend to clump more – high surface tension- easily removed from eye – higher in molecular weight – if left in the eye pressure much more than dispersive agents bcs of their higher molecular weight and trab meshwork clogging ability.**
