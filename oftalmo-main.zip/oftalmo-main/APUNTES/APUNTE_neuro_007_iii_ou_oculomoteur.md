---
categoria: apuntes
area: neuro
emoji: 🧠
seccion: Neuro-Ophta
orden_seccion: 8
orden: 7
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-12-20
---
# III ou oculomoteur

Paralysie isolée, unilaterale de III PC est + souvent associe: pathologie microvasculaire surtout si FRCV

Suspecter tjs:

- Maladie Horton si age > 50 ans
- Atteint sous-jacente compressive nottament anévrisme\*\*qui peut metrreen jeu le pronostic du patient. **\*\*\*Bilan neuro-radiologique en URGENCE est impératif.** Surtout si: <50 ans paralyse extrinsec partielle + atteinte pupillaire-mydriase peu réflexique à la lumiere.  assoc à cephalées sévères avec FRCV.

## SIGNES

Ptosis complet- pouvant suprimer la diplopie

Deviation oculaire oeil atteinte: **exotropie,** hypotropie **ou** hypertropie

- Deficit oculomoteur affectant: adduction, élevation, abaissement.

Mydriase de cote atteinte avec une reponse reduite à la lumiere et à la convergence

Importante examiner:

- VI-abduction conserve?
- IV cyclotorsion conservée par integralite oblique sup.

DD III atteinet extrinseque ( conservation fonction pupillaire): myasthenie, ophtalmoplegie internucleaire, skew déviation.

- **ATTEINTE INFRANUCLEAIRE DU III**

  - Un paralysie du III avec atteinte pupillaire est a priori un ANEVRISME-**en jonction artere comunicante posterieur-carotide interne.**

  - Un atteinte ischémique peut provoquer une atteinte pupillaire dans 20%.

  - Bilan:
  - add angio –TDM ou angio IRM

- **PARALYSIE EXTRINSèQUE ISOLéE + PUPILLE DE TAILLE ET FONCTIONNEMENT NORMAUX**

  - Paralysie extrinsèque complète ( ptosis complet + absence mouv élévation +
  - Abaissement + adduction ) + sans atteinte pupilliare: est benigne.

  - **Etiologie**
  - Lie a pathologie microvasculaire-FRCV

  - Regresse spontanement en qqs mois.
  - Absence atteinte pupilliare est rassurante uniquemnt dans cette cas.

  - Add Bilan neuroradiologique en cas:  absence FRCV, <50 ans, associacio cephalées severes.

  - **Paralysie intrinsique isolée\*\***

  - Une atteinte pupillaire strictement isolée, sans ptosis sans paraliysie oculomotrice associe, n'est pas due à compression anevrismale et n'est pas paralysie du III.
