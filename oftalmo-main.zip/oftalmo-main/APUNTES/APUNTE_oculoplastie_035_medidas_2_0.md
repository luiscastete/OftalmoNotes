---
categoria: apuntes
area: oculoplastica
emoji: 🫥
seccion: Oculo-Plastie
orden_seccion: 3
orden: 35
fuente: OneNote del Dr. Castilla Martí
---
# Medidas 2.0

Aquí van las medidas más importantes, con sus valores normales y su utilidad diagnóstica 👇

**📏MEDIDAS PALPEBRALES CLAVES EN LA EVALUACIÓN DE PTOSIS Y OTRAS ALTERACIONES**

## 🔸1.

## MRD1 – Marginal Reflex Distance 1

- **Qué mide**: Distancia desde el **reflejo corneal (luz del oftalmoscopio)** hasta el **borde del párpado superior**.
- **Normal**: **+4 a +5 mm**
- **Importancia**:
  - Es la medida **más objetiva para cuantificar ptosis**
  - En **ptosis severa** puede ser **0 o negativa** (el párpado cubre la pupila)

## 🔸2.

## MRD2 – Marginal Reflex Distance 2

- **Qué mide**: Distancia desde el reflejo corneal hasta el **borde del párpado inferior**
- **Normal**: **+5 mm**
- **Importancia**:
  - Evalúa **retracción del párpado inferior**
  - Se usa en cirugía del párpado inferior y orbitopatía tiroidea

## 🔸3.

## Fissura palpebral (palpebral fissure height)

- **Qué mide**: Distancia vertical entre los márgenes palpebrales (superior e inferior), en mirada primaria
- **Normal**:
  - **Hombres**: ~ **8–10 mm**
  - **Mujeres**: ~ **9–12 mm**
- **Importancia**:
  - Se ve **reducida en ptosis**
  - Aumentada en **retracción palpebral**, **parálisis facial**, o **exoftalmos**

## 🔸4.

## Función del elevador (levator function / LF)

- **Qué mide**: Movimiento del párpado superior desde **mirada inferior máxima a mirada superior máxima**, mientras se **bloquea el músculo frontal** (presionando la frente)
- **Normal**: **≥ 12–15 mm**
- **Clasificación**:
  - **Buena**: > 10 mm
  - **Moderada**: 5–10 mm
  - **Pobre**: < 5 mm
- **Importancia**:
  - Clave para decidir tipo de cirugía de ptosis:
    - Buena función → resección del elevador
    - Mala función → suspensión frontal (frontalis sling)

## 🔸5.

## Altura del pliegue palpebral (eyelid crease height)

- **Qué mide**: Distancia del pliegue palpebral (surco) al margen palpebral, con ojo en mirada primaria
- **Normal**:
  - **Hombres**: ~ **6–8 mm**
  - **Mujeres**: ~ **8–10 mm**
- **Importancia**:
  - Alterado en ptosis aponeurótica (pliegue alto)
  - Útil en diagnóstico diferencial y planeamiento quirúrgico

## 🔸6.

## Distancia intercanthal

- **Qué mide**: Distancia entre ambos **cantos mediales**
- **Normal**: **~30–35 mm**
- **Importancia**:
  - Aumentada en **telecanto**
  - Comparar con distancia interpupilar para diferenciar de hipertelorismo

## 🔸7.

## Distancia interpupilar (DIP)

- **Qué mide**: Centro pupilar a centro pupilar
- **Normal**:
  - **Adulto promedio**: ~ **60–65 mm**
- **Importancia**:
  - Aumentada en **hipertelorismo verdadero**
  - Se compara con distancia intercantal para evaluar disarmonías

## 🔸8.

## Altura del canto lateral (canto lateral canthal tilt)

- **Qué evalúa**: Posición del canto lateral vs. medial
- **Normal**: Canto lateral está **1–2 mm por encima** del canto medial
- **Importancia**:
  - Canto descendido → signo de laxitud o disinserción del ligamento cantal lateral
  - Evaluado en cirugía estética y reconstructiva

## 📋RESUMEN TABULAR

| **Medida** | **Valor normal** | **Utilidad** |
|---|---|---|
| MRD1 | +4 a +5 mm | Cuantifica ptosis |
| MRD2 | +5 mm | Evalúa párpado inferior |
| Fisura palpebral | 9–12 mm (♀), 8–10 mm (♂) | Evalúa abertura palpebral |
| Función del elevador | ≥12 mm | Determina tipo de cirugía |
| Pliegue palpebral | 6–10 mm | Diagnóstico diferencial de ptosis |
| Distancia intercantal | 30–35 mm | Evalúa telecanto |
| Distancia interpupilar | 60–65 mm | Evalúa hipertelorismo |
| Canthal tilt | Canto lateral 1–2 mm más alto | Simetría y soporte lateral |
