---
categoria: apuntes
area: neuro
emoji: 🧠
seccion: Neuro-Ophta
orden_seccion: 8
orden: 18
fuente: OneNote del Dr. Castilla Martí
fecha: 2024-07-20
---
# HORNER - Syndrome claude Bernard HORNER

### Fisiopatología del Síndrome de Horner

El síndrome de Horner es el resultado de una interrupción en la vía simpática que inerva el ojo y la región periorbitaria. La vía simpática ocular es una ruta de tres neuronas, y la interrupción puede ocurrir en cualquiera de estos niveles, lo que lleva a los signos y síntomas característicos del síndrome de Horner.

#### Anatomía de la Vía Simpática

1. \*\*Primera Neurona (Central):\*\*

- Origina en el hipotálamo y desciende a través del tronco encefálico hasta el nivel de C8-T2 en la médula espinal, conocida como el centro cilioespinal de Budge.

2. \*\*Segunda Neurona (Pre-Ganglionar):\*\*

- Sale de la médula espinal a nivel de C8-T2 y viaja a través de la cadena simpática paravertebral hasta el ganglio cervical superior.

3. \*\*Tercera Neurona (Post-Ganglionar):\*\*

- Desde el ganglio cervical superior, las fibras post-ganglionares siguen la arteria carótida interna, ingresan en el cráneo y llegan al ojo. Estas fibras inervan el músculo dilatador de la pupila, el músculo de Müller (elevador del párpado superior) y las glándulas sudoríparas faciales.

#### Causas del Síndrome de Horner

Dependiendo del nivel de la lesión, las causas pueden variar considerablemente:

1. \*\*Lesión de la Primera Neurona:\*\*

- Accidentes cerebrovasculares

- Tumores (e.g., gliomas)

- Trauma

- Esclerosis múltiple
