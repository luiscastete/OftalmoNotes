---
categoria: apuntes
area: general
emoji: 🛠️
seccion: Technique-Procedures
orden_seccion: 13
orden: 5
fuente: OneNote del Dr. Castilla Martí
fecha: 2024-02-05
---
# Frottis cornéen

Bonjour à toutes et tous,

Après discussion avec le Dr. Hammer on vous repropose un exemple de bon frottis cornéen, ca peut être modifié selon la clinique évidement.

C'est similaire à celui-là envoyé par la Dre Sabaratnam mais nous avons rajouté la moxifloxacine (Vigamox) parmi les antibiotiques spécifiques à tester.

On profite pour rappeler quelques points:

-C'est important de spécifier la molécule de l'antibiotique qu'on veut tester (c'est arrivé que avec le nom commercial ils n'ont pas testé l'antibiotique voulu), les labos ne sont pas habitués à nos thérapies, ils testent les molécules qu'on utilise les plus souvent en médecine.

-Toujours demander l'antibiogramme/antifongigramme de le début (afin d'avoir une prise en charge spécifique plus rapide).

-Spécifier la thérapie démarrée ou qu'on souhaite démarrer.

-Réaliser de manière correcte le frottis ou demander de l'aide si besoin (souvent le matériel n'est pas assez ou il y a des contaminations et il faut répéter le frottis).
