---
categoria: apuntes
area: pediatria
emoji: 🧸
seccion: Pediatrie
orden_seccion: 9
orden: 32
fuente: OneNote del Dr. Castilla Martí
---
# Orbital Disorders

## Congenital anomalies

## Buphtalmos

Large eye as a result of increased intraocular pressure (IOP) in congenital glaucoma

## Microphtalmos

Small, disorganized eye – pathologique

## Nanophtalmos

Small eye with normal features – not pathologic

Associated with hyperopia and angle-closure glaucoma

## Infections

## Preseptal cellulitis

Infection ant to orbital septum : spares globe

Penetrating skin trauma, dacryocystitis, sinusitis-most common pediatric cause-\*\*\*

## Orbital Cellulitis

Infection posterior to orbital septum: involves globe

Most common cause of proptosis in children\*\*\*

Usually secondary to sinusitis\*\*- ethmoid sinus is most common-

Assoc with subperiosteal abcesses

ETIOLOGY: extension of infection from periorbital structures; sinusitis, dacryocistitis, dacryoadenitis, endophtalmositis, dental infection, trauma o previous surgery, endogeneous – bacteria with septic embolisation.

Organism – S aureus

Findings: pg 106
