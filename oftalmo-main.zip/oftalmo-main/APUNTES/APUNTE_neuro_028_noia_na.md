---
categoria: apuntes
area: neuro
emoji: 🧠
seccion: Neuro-Ophta
orden_seccion: 8
orden: 28
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-02-10
---
# NOIA-NA

Neuropathie optique ischemique anterieur- Non arteritique

Infarctus de la tete de NO sur trouble circulatoire de reseau arteriel ciliare posterieur court resultant en perte fonction, **d'origine non inflammatoire.**

## FR predisposants

-Disk at risk:

- C/D <0.1, drusen papillaires, hypoplasie

-FR cardiovasculaire:

- HTA, Hypercholesterolemie, obésité, tabagisme, DM, SAOS.

## SYMPTOMES

BAV monoculaire d'apparition brutale, pouvant se péjorer sur qqs semaines

Déficit de CV ipsilateral

- Souvents altitudinal inf
- Nearly 25% of patients will have central scotomas but the majority of patients will have an altitudinal field loss, inferior being most common[62].

Pas douleur, pas diplopie transitoire

## Anamneses de maladie Horton: nég TOUJOURS FAIRE!!

## SIGNES

Présents:

- RAPD
- Dyschromatopsie et atteinte du CV
- Oedeme papillaire unilat **+/- sectoriel**------------------------------------------------------------------------
- Hémorragie péripapillaire en flammèche
- Disk at risk dans oeil contralat. C/D: 0 or 0.1

Absents

- Autres signes neuro: troubles oculomotricite, atteinte des Nerfs V,VII,VIII.
- Rétinite, uveite, vasculite

- Si présents---changer DD!
