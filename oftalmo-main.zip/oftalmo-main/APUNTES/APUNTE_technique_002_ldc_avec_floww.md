---
categoria: apuntes
area: general
emoji: 🛠️
seccion: Technique-Procedures
orden_seccion: 13
orden: 2
fuente: OneNote del Dr. Castilla Martí
---
# LDC ( AVEC FLOWW)

## MISE EN PLACE LDC ( AVEC FLOWW)

Nettoyer le main avec sabon liquide

Positionner LDC sur l'index main droite avec les deux main des main opposer surélever paupière en regard vers le bas.

Demander patiente tenir paupier inf.

Mettre en place LDC  sur conj + faire regarde patient diffèrent directions et vérifier si bule + si bule bouger la LDC.
