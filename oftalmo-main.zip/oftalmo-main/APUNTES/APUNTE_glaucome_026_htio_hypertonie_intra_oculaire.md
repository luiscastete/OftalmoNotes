---
categoria: apuntes
area: glaucoma
emoji: 🟢
seccion: Glaucome
orden_seccion: 5
orden: 26
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-07-24
---
# HTIO-Hypertonie intra oculaire

Los factores asociados a un incremento de la PIO son los asociados a un aumento de la presión venosa epiescleral (agacharse o posición supina, aguantar la respiración, presión venosa central elevada, intubación, obstrucción del drenaje venoso orbitario, tocar instrumento de viento, maniobra de Vasalva, cuello de vestimenta o corbata apretada, ingesta excesiva de líquidos),los que producen un aumento de la presión en el ojo (blefarospasmo, llorar), temperatura corporal elevada, influencia hormonal (hipotiroidismo, oftalmopatía tiroidea), fármacos ( anticolinérgicos, corticoides, ketamina, LSD, topiramato, cafeína) y enfermedades como la uveítis o la hipertensión arterial (ésta última de manera insignificante).

Pg 348 kansky

## Ocular Hypertension (OHT)

IOP >21mmhg + open angle + without detectable glaucomateuse damage:

Aprox 1 of 10 will develop glaucome over 10 years period and m ayority wount develop glaucome in life time.

## RISK DEVELOPING GLAUCOMA ( consider this citeria )

- increases with older age
- Increses with higher hypertension (is not the same 21 than 28mmhg)
- Risk is greater in thin cornear <555um and lower in >588um.
- Cup/disc - the greater the ratio the greater the risk ( so more risk c/p 0.5 than 0.2)
- The higher de PSD
- Africans
- Males
- Heart disease
- Diabetes
- Familiy history + glaucoma
