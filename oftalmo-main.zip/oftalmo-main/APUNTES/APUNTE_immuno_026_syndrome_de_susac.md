---
categoria: apuntes
area: uveitis
emoji: 🔥
seccion: Immuno-infectio
orden_seccion: 7
orden: 26
fuente: OneNote del Dr. Castilla Martí
fecha: 2024-05-22
---
# Syndrome de Susac

maladie auto-immune rare qui affecte les petits vaisseaux sanguins du cerveau, de la rétine et de l'oreille interne.

Elle est également connue sous le nom **d'angiopathie rétinocochléocérébrale.** Cette condition a été décrite pour la première fois par le Dr John Susac en 1979.

Les principaux symptômes du syndrome de Susac incluent :

- **Encéphalopathie** : Les patients peuvent présenter des troubles cognitifs, des changements de comportement, des maux de tête, des troubles de la marche et des crises d'épilepsie.

- **Occlusions artérielles rétiniennes** : Elles peuvent entraîner une perte de vision partielle ou totale dans un ou les deux yeux.

- **Perte auditive** : Des pertes auditives neurosensorielles peuvent survenir, souvent de manière asymétrique et accompagnées de vertiges ou d'acouphènes.

Le diagnostic du syndrome de Susac repose sur une combinaison de critères cliniques, d'imagerie (comme l'IRM cérébrale) et d'examens complémentaires tels que la rétinographie et les tests auditifs. L'IRM peut montrer des lésions spécifiques au niveau du corps calleux, et des occlusions artérielles rétiniennes peuvent être observées lors d'un examen ophtalmologique.

Le traitement du syndrome de Susac implique généralement des immunosuppresseurs et des corticostéroïdes pour contrôler l'inflammation et prévenir les récidives. La prise en charge multidisciplinaire est souvent nécessaire, impliquant des neurologues, des ophtalmologues et des ORL.

## MALADIE RARISIME selon le prof (3 cas en 20 ans)

## La japonaise qu'on a vue, c'est probablement une Behçet bcp plus freq
