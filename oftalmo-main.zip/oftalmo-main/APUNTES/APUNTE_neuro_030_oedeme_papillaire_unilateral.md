---
categoria: apuntes
area: neuro
emoji: 🧠
seccion: Neuro-Ophta
orden_seccion: 8
orden: 30
fuente: OneNote del Dr. Castilla Martí
fecha: 2023-08-24
---
# Oedème papillaire unilatéral

AA-BILAN

## AA

Douleur?

Atteinte de la fonction visuelle? après quand?

Autres troubles neurologique? Après quand?

Accompagne des cephalées? Type?

Fievre?

Prise de antibiotiques?

Autres maladies systemiques?

## STATUS

AV

Neuro-ophta: CV par confrontation, ishihara, test désaturation au rouge

Pupilles: recherche de RAPD

Exophtalmométrie de Hertel

LAF: signe UAA? Vitrite?

FO Dilaté: recherche de lésions rétinniennes, vasculite.

## DD

Pseudo-oedeme papillaire ( drusen, hypoplasie )

Inflammatoire ( SEP,NMO,MOG, périnevrité optique, post-vacinnation)

Ischemique ( NOIA)

Infiltratif ( Sarcoidose, léeucemie, métastase)

Compressif ( lésion orbitaire)

Infectieux ( Lyme, TB, Syphilis, Bartonella, VIH)

Héréditaire ( neuropathie optique de Leber)

Oedeme papillaire de stase: très rarement unilateral.

Traumatique: exceptionnel

## AVEC SYMPT DE PERTE VISUELLE

- **AVEC DOULEURS:**
- Inflammatoire ( sarcoidose)
- Infectieux

- **SANS DOULEURS**
- Ischemique
- Infiltratif
- Compressif
- Neuropathie optique de Leber

## SANS SYMPT DE PERTE VISUELLE

Pseudo-oedeme

Oedeme papillaire de stase

Compressif: rarement

## DRAPEAUX ROUGES

- **AGE > 60 ans:** --HORTON! Exclure maladie de notre cher Hortonen urgence avec aa et VS, CRP,Thrombocytes ( vooir chapitre NOIA-A).

- **Exophtalmie:**
- Processus infiltratif-compressif.
- Si douleur: exclure syndrome inflammatoire et infiltration infectieuse orbitaire ( sinusite) en ruegnce ( aa évocatrice)
- SI pas douleurs: AA oncologique et bilan avec IRM cérébrale et orbitaire ( délais de qqs jours)

- **Cécité (AV < MM):**
- NOIA ( age>60 ans + FRCV + indolore)
- Neuropathie optique de Leber: jeune homme + indolore
- NMO: Jeune femme + douleurs

## STATUS

AV

Neuro-ophta: CV par confrontation, ishihara, test désaturation au rouge

Pupilles: recherche de RAPD

Exophtalmométrie de Hertel

LAF: signe UAA? Vitrite?

FO Dilaté: recherche de lésions rétinniennes, vasculite.

## BILAN COMPLEMENTAIRE

En fonction du dx suspecté et aprés examen clinique:

IRM orbitaire et cérebrale 8 delai selon l'urgence)

Examen labo: ( en urgence pour suspicion de Maladie de Horton): bilan infectieux, bilan auto-immuno, anticorps anti-NMO, test génétiques en unité spécialisée).

## QUAND REFERER EN UNITE NEURO-OPHTA

Si présnece de drapeaux rouge: discuter/présente le patient en unité.

Une foisla prise en charge initial effectué, le patient est suivi en unité.

Tout patient adressé de l'exterieurpour 2eme avisconcernant une turgescence papillaire unilateral et examiné directement en unité.

## REMARQUES

Neuropathie optique sans RAPD: possible seulement avec neuropathie optique de Leber\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*

Douleurs séveres corticosensibles: évocateurs de périnvrevrité optique ou sarcoidose.

Une périnevrité optique n'est pas associe à une SEP.
