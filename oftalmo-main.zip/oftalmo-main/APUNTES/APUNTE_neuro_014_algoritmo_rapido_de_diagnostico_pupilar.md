---
categoria: apuntes
area: neuro
emoji: 🧠
seccion: Neuro-Ophta
orden_seccion: 8
orden: 14
fuente: OneNote del Dr. Castilla Martí
---
# Algoritmo rápido de diagnóstico pupilar

## Algoritmo rápido de diagnóstico pupilar

## 1️⃣Pupila grande (midriasis) → problema parasimpático

Primera pregunta:

## ¿La pupila responde a la luz?

## ❌No responde → pensar en

## 1. Lesión del III par

Hallazgos:

- **midriasis**
- **ptosis marcada**
- **ojo en down and out**
- diplopía

Causas frecuentes:

- aneurisma de la **arteria comunicante posterior**
- compresión tumoral
- herniación uncal
