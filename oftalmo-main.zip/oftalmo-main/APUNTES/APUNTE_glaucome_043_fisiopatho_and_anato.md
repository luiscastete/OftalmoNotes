---
categoria: apuntes
area: glaucoma
emoji: 🟢
seccion: Glaucome
orden_seccion: 5
orden: 43
fuente: OneNote del Dr. Castilla Martí
fecha: 2022-11-23
---
# Fisiopatho and anato

Examination:

-Excavation

-Grosor

-Simetria ( >0,2 asimetrie sospechoso ++ glaucoma )

-Color

-Perdida difusa fibras o localizada ?

-Cambios vasculares?

Signos inespecificos glaucoma:

-ausencia vasos sanguineos circulineales

-signo de la bayoneta

-Signo de la manca laminar

-Hemorragias de la papila: en forma de llama, ++ en inf-temp.

FR xa Glaucoma:

1-edad

2-defecto fibras nerviosas retiniana

3-Relacion excavacion-papila alta

4-PIO alta

5-Cambios parapapilares

6-Espesor corneal fino

7-Ha Fam.

8-Miopia forte

## Aqueous composition

Aqueous humor has excess of: hydrogen, chloride and ascorbate.

Aqueous humorHas deficit of bicarbonate and is essentially protein free compared to palsma - explain optical clarity.

Protein composition of aqueous includes: albumin 50% aq. Prot. + groxwth factors + enzymes (carbonic anhydrase, lysozyme) + prostaglandines, cAMP, steroid hormones, catghecholamines and hyaluronic acid.
