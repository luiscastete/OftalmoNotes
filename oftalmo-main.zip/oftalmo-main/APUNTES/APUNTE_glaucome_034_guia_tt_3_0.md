---
categoria: apuntes
area: glaucoma
emoji: 🟢
seccion: Glaucome
orden_seccion: 5
orden: 34
fuente: OneNote del Dr. Castilla Martí
---
# Guía TT 3.0

## 🧭GUÍA CLÍNICA RÁPIDA: TRATAMIENTO TÓPICO DEL GLAUCOMA (EGS 2022)

## 🔶PASO 1: EVALUACIÓN INICIAL

• 📌 **Diagnóstico confirmado de glaucoma**

• 🎯 Estimar **PIO objetivo** según:

- Daño glaucomatoso
- Factores de riesgo (edad, PA sistémica, espesor corneal, historia familiar)
- Expectativa de vida

• ⚖️ Decidir entre iniciar **tratamiento tópico** o considerar **SLT** como primera opción si hay riesgo de baja adherencia o preferencia del paciente

## 🔶PASO 2: INICIAR MONOTERAPIA

- **✅1ª Línea – Análogos de Prostaglandinas (PGAs)- PROST**
- **Ejemplos**: Latanoprost, Travoprost, Bimatoprost, Tafluprost
- **Reducción PIO**: 25–35%
- **Dosis estándar**: 1 vez al día (por la noche)
- ✔️ Ventajas: Alta eficacia, buen perfil de seguridad, buena adherencia
- ❌ Contraindicaciones: Uveítis, edema macular, herpes ocular
- ⚠️ Efectos adversos: Hiperemia conj, Hiperpigmentación iris, Hipertricosis- aumento crecimiento pestañas, Atrofia grasa periocular
- Hiperpigmentación piel. Eritema pericoular cronico, Cefalea ocasional.

- 📋 Preguntas clave:
- ¿Tiene historia de uveítis o edema macular?
- ¿Está cómodo con cambios estéticos?

## 🔶PASO 3: RESPUESTA A MONOTERAPIA

❌ Si NO se alcanza la PIO objetivo pero hay buena tolerancia → Añadir fármaco de clase distinta o combinación fija
